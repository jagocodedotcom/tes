// ============================================
// MAIN SCRIPT
// ============================================

document.addEventListener('DOMContentLoaded', function() {
    // Touch feedback untuk buttons
    const buttons = document.querySelectorAll('button, .btn-submit, .quick-btn, .bottom-nav a, .product-card');
    buttons.forEach(btn => {
        btn.addEventListener('touchstart', function() {
            this.style.opacity = '0.7';
        });
        btn.addEventListener('touchend', function() {
            this.style.opacity = '1';
        });
    });

    // Auto-hide alert
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.transition = 'opacity 0.5s';
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 500);
        }, 4000);
    });

    // Format input rupiah
    const rupiahInputs = document.querySelectorAll('.rupiah-input');
    rupiahInputs.forEach(input => {
        input.addEventListener('input', function() {
            let value = this.value.replace(/[^0-9]/g, '');
            if (value) {
                this.value = 'Rp ' + Number(value).toLocaleString('id-ID');
            }
        });
    });
});

// ============================================
// FUNGSI GLOBAL
// ============================================

function formatRupiah(angka) {
    return 'Rp ' + Number(angka).toLocaleString('id-ID');
}

function showAlert(message, type = 'success') {
    const container = document.querySelector('.main-content') || document.querySelector('.container');
    const div = document.createElement('div');
    div.className = `alert ${type}`;
    div.innerHTML = message;
    container.prepend(div);
    
    setTimeout(() => {
        div.style.transition = 'opacity 0.5s';
        div.style.opacity = '0';
        setTimeout(() => div.remove(), 500);
    }, 4000);
}