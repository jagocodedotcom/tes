<?php
// ============================================
// FILE: includes/nav.php
// NAVIGASI UNTUK SEMUA HALAMAN
// ============================================
?>

<style>
/* Style untuk menu dropdown */
.menu-dropdown {
    position: relative;
    display: inline-block;
}

.menu-btn {
    background: var(--primary-light);
    color: white;
    padding: 8px 16px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-size: 14px;
}

.menu-content {
    display: none;
    position: absolute;
    background: white;
    min-width: 200px;
    box-shadow: 0 8px 16px rgba(0,0,0,0.2);
    border-radius: 8px;
    z-index: 1000;
    right: 0;
}

.menu-content a {
    color: var(--text);
    padding: 10px 16px;
    text-decoration: none;
    display: flex;
    align-items: center;
    gap: 10px;
    border-bottom: 1px solid #f0f0f0;
}

.menu-content a:hover {
    background: #f5f5f5;
}

.menu-dropdown:hover .menu-content {
    display: block;
}

/* Style untuk bottom nav tambahan */
.bottom-nav {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    display: flex;
    background: var(--card-bg);
    box-shadow: 0 -2px 12px rgba(0,0,0,0.08);
    padding: 6px 0 env(safe-area-inset-bottom);
    z-index: 1000;
    max-width: 480px;
    margin: 0 auto;
    border-radius: var(--radius) var(--radius) 0 0;
    overflow-x: auto;
    flex-wrap: nowrap;
}

.bottom-nav a {
    flex: 0 0 auto;
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 4px 10px;
    text-decoration: none;
    color: var(--text-light);
    font-size: 9px;
    transition: 0.2s;
    border: none;
    background: none;
    border-radius: 8px;
    min-width: 50px;
}

.bottom-nav a i {
    font-size: 18px;
    margin-bottom: 2px;
}

.bottom-nav a.active {
    color: var(--primary-light);
    background: rgba(76, 175, 80, 0.08);
}

.bottom-nav a span {
    font-size: 8px;
    white-space: nowrap;
}

/* Tombol tambahan di header */
.header-actions {
    display: flex;
    gap: 8px;
    align-items: center;
}

.header-actions .btn-icon {
    background: none;
    border: none;
    font-size: 18px;
    color: var(--text-light);
    cursor: pointer;
    padding: 4px 8px;
    border-radius: 50%;
}

.header-actions .btn-icon:hover {
    background: #f0f0f0;
}

/* Menu mobile */
@media (max-width: 480px) {
    .bottom-nav a {
        min-width: 40px;
        padding: 4px 6px;
    }
    .bottom-nav a i {
        font-size: 16px;
    }
    .bottom-nav a span {
        font-size: 7px;
    }
}
</style>

<!-- ============================================
     HEADER DENGAN MENU DROPDOWN
     ============================================ -->
<header class="header">
    <div>
        <h1><i class="fas fa-store"></i> Toko Kecil</h1>
        <span class="user-info"><i class="fas fa-user"></i> <?php echo $_SESSION['nama_lengkap'] ?? 'Guest'; ?> (<?php echo $_SESSION['role'] ?? 'Guest'; ?>)</span>
    </div>
    <div class="header-actions">
        <!-- Tombol Notifikasi -->
        <button class="btn-icon" onclick="location.href='../modules/notifikasi.php'">
            <i class="fas fa-bell"></i>
        </button>
        
        <!-- Menu Dropdown -->
        <div class="menu-dropdown">
            <button class="menu-btn"><i class="fas fa-bars"></i></button>
            <div class="menu-content">
                <a href="../index.php"><i class="fas fa-home"></i> Dashboard</a>
                <hr>
                <strong style="padding:8px 16px;color:var(--text-light);font-size:12px;">MASTER DATA</strong>
                <a href="../modules/produk.php"><i class="fas fa-box"></i> Produk</a>
                <a href="../modules/kategori.php"><i class="fas fa-tags"></i> Kategori</a>
                <a href="../modules/supplier.php"><i class="fas fa-truck"></i> Supplier</a>
                <a href="../modules/pelanggan.php"><i class="fas fa-users"></i> Pelanggan</a>
                <hr>
                <strong style="padding:8px 16px;color:var(--text-light);font-size:12px;">TRANSAKSI</strong>
                <a href="../modules/penjualan.php"><i class="fas fa-cash-register"></i> Kasir</a>
                <a href="../modules/pembelian.php"><i class="fas fa-shopping-cart"></i> Pembelian</a>
                <a href="../modules/retur_penjualan.php"><i class="fas fa-undo"></i> Retur Penjualan</a>
                <a href="../modules/retur_pembelian.php"><i class="fas fa-undo-alt"></i> Retur Pembelian</a>
                <hr>
                <strong style="padding:8px 16px;color:var(--text-light);font-size:12px;">LAPORAN</strong>
                <a href="../laporan/laba_rugi.php"><i class="fas fa-chart-line"></i> Laba Rugi</a>
                <a href="../laporan/stok.php"><i class="fas fa-cubes"></i> Laporan Stok</a>
                <a href="../laporan/penjualan.php"><i class="fas fa-file-invoice"></i> Laporan Penjualan</a>
                <a href="../laporan/export_excel.php"><i class="fas fa-file-excel"></i> Export Excel</a>
                <hr>
                <a href="../auth/logout.php"><i class="fas fa-sign-out-alt" style="color:#f44336;"></i> Logout</a>
            </div>
        </div>
    </div>
</header>

<!-- ============================================
     BOTTOM NAVIGASI (Untuk Mobile)
     ============================================ -->
<nav class="bottom-nav">
    <a href="../index.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">
        <i class="fas fa-home"></i><span>Dashboard</span>
    </a>
    <a href="../modules/penjualan.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'penjualan.php' ? 'active' : ''; ?>">
        <i class="fas fa-cash-register"></i><span>Kasir</span>
    </a>
    <a href="../modules/pembelian.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'pembelian.php' ? 'active' : ''; ?>">
        <i class="fas fa-truck"></i><span>Beli</span>
    </a>
    <a href="../modules/produk.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'produk.php' ? 'active' : ''; ?>">
        <i class="fas fa-box"></i><span>Produk</span>
    </a>
    <a href="../laporan/laba_rugi.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'laba_rugi.php' ? 'active' : ''; ?>">
        <i class="fas fa-chart-bar"></i><span>Laporan</span>
    </a>
</nav>