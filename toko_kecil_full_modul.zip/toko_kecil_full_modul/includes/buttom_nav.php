<?php
// ============================================
// FILE: includes/bottom_nav.php
// BOTTOM NAVIGATION UNTUK SEMUA HALAMAN
// ============================================
?>

<nav class="bottom-nav">
    <a href="../index.php"><i class="fas fa-home"></i><span>Dashboard</span></a>
    <a href="penjualan.php"><i class="fas fa-cash-register"></i><span>Kasir</span></a>
    <a href="pembelian.php"><i class="fas fa-truck"></i><span>Beli</span></a>
    <a href="produk.php"><i class="fas fa-box"></i><span>Produk</span></a>
    <a href="../laporan/laba_rugi.php"><i class="fas fa-chart-bar"></i><span>Laporan</span></a>
</nav>