<?php
// ============================================
// DATABASE CONNECTION
// ============================================
session_start();

$host = 'localhost';
$username = 'root';
$password = '';
$database = 'toko_kecil_full';

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

date_default_timezone_set('Asia/Jakarta');

// ============================================
// FUNGSI GLOBAL
// ============================================

// Cek login
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Cek role
function hasRole($role) {
    return isset($_SESSION['role']) && $_SESSION['role'] == $role;
}

// Redirect
function redirect($url) {
    header("Location: $url");
    exit();
}

// Generate nomor invoice
function generateInvoice() {
    return 'INV-' . date('Ymd') . '-' . rand(1000, 9999);
}

// Generate nomor PO
function generatePO() {
    return 'PO-' . date('Ymd') . '-' . rand(1000, 9999);
}

// Generate kode produk (TAMBAHKAN - diperlukan di modules/produk.php)
function generateKodeProduk() {
    return 'PRD-' . date('Ymd') . '-' . rand(1000, 9999);
}

// Generate kode supplier (TAMBAHKAN - diperlukan di modules/supplier.php)
function generateKodeSupplier() {
    return 'SUP-' . date('Ymd') . '-' . rand(1000, 9999);
}

// Format Rupiah
function rupiah($angka) {
    return 'Rp ' . number_format($angka, 0, ',', '.');
}

// Cek stok menipis
function getStokMenipis($conn) {
    $result = $conn->query("SELECT COUNT(*) as total FROM produk WHERE stok <= stok_minimal");
    return $result->fetch_assoc()['total'];
}

// Log aktivitas (DIPERBAIKI dengan error handling)
function logActivity($conn, $user_id, $aktivitas, $detail = '') {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $stmt = $conn->prepare("INSERT INTO log_aktivitas (user_id, aktivitas, detail, ip_address) VALUES (?, ?, ?, ?)");
    if ($stmt) {
        $stmt->bind_param("isss", $user_id, $aktivitas, $detail, $ip);
        $stmt->execute();
        $stmt->close();
    }
}

// Get nama user (TAMBAHKAN - diperlukan di beberapa file)
function getNamaUser($conn, $user_id) {
    $result = $conn->query("SELECT nama_lengkap FROM users WHERE id = $user_id");
    return $result->num_rows > 0 ? $result->fetch_assoc()['nama_lengkap'] : 'Unknown';
}

// Get nama kategori (TAMBAHKAN - diperlukan di beberapa file)
function getNamaKategori($conn, $id) {
    $result = $conn->query("SELECT nama_kategori FROM kategori WHERE id = $id");
    return $result->num_rows > 0 ? $result->fetch_assoc()['nama_kategori'] : '-';
}

// Get nama supplier (TAMBAHKAN - diperlukan di beberapa file)
function getNamaSupplier($conn, $id) {
    $result = $conn->query("SELECT nama_supplier FROM supplier WHERE id = $id");
    return $result->num_rows > 0 ? $result->fetch_assoc()['nama_supplier'] : '-';
}

// ============================================
// CEK SESSION LOGIN (DIPERBAIKI)
// ============================================
$current_page = basename($_SERVER['PHP_SELF']);
$current_dir = basename(dirname($_SERVER['PHP_SELF']));
$pages_public = ['login.php', 'register.php'];

if (!in_array($current_page, $pages_public) && !isLoggedIn()) {
    // Jika di folder config, redirect ke ../auth/login.php
    // Jika di folder lain, redirect ke auth/login.php
    if ($current_dir == 'config') {
        redirect('../auth/login.php');
    } else {
        redirect('auth/login.php');
    }
}
?>