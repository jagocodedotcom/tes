<?php
// ============================================
// FILE: config/search.php
// AJAX SEARCH PRODUK UNTUK KASIR (Termasuk Barcode)
// ============================================

// Koneksi database
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'toko_kecil_full';

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Koneksi database gagal: ' . $conn->connect_error]);
    exit();
}

// Ambil parameter pencarian
$q = $_GET['q'] ?? '';
$q = $conn->real_escape_string($q);

// Jika keyword kosong atau terlalu pendek
if (strlen($q) < 1) {
    header('Content-Type: application/json');
    echo json_encode([]);
    exit();
}

// Query pencarian produk (termasuk barcode supplier)
$sql = "
    SELECT p.*, k.nama_kategori 
    FROM produk p 
    LEFT JOIN kategori k ON p.kategori_id = k.id 
    WHERE (p.kode_produk LIKE '%$q%' 
    OR p.barcode LIKE '%$q%'
    OR p.nama_produk LIKE '%$q%')
    AND p.stok > 0
    ORDER BY 
        CASE 
            WHEN p.barcode LIKE '%$q%' THEN 1
            WHEN p.kode_produk LIKE '%$q%' THEN 2
            WHEN p.nama_produk LIKE '%$q%' THEN 3
            ELSE 4
        END,
        p.nama_produk 
    LIMIT 20
";

$result = $conn->query($sql);

$data = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

// Set header JSON
header('Content-Type: application/json');
echo json_encode($data);

$conn->close();
?>