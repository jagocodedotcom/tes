<?php
// ============================================
// FUNCTIONS.PHP - SEMUA FUNGSI GLOBAL
// ============================================

// Cek login
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Cek role
function hasRole($role) {
    return isset($_SESSION['role']) && $_SESSION['role'] == $role;
}

// Redirect
function redirect($url) {
    header("Location: $url");
    exit();
}

// Generate nomor invoice
function generateInvoice() {
    return 'INV-' . date('Ymd') . '-' . rand(1000, 9999);
}

// Generate nomor PO
function generatePO() {
    return 'PO-' . date('Ymd') . '-' . rand(1000, 9999);
}

// Generate kode produk
function generateKodeProduk() {
    return 'PRD-' . date('Ymd') . '-' . rand(1000, 9999);
}

// Generate kode supplier
function generateKodeSupplier() {
    return 'SUP-' . date('Ymd') . '-' . rand(1000, 9999);
}

// Format Rupiah
function rupiah($angka) {
    return 'Rp ' . number_format($angka, 0, ',', '.');
}

// Cek stok menipis
function getStokMenipis($conn) {
    $result = $conn->query("SELECT COUNT(*) as total FROM produk WHERE stok <= stok_minimal");
    return $result->fetch_assoc()['total'];
}

// Log aktivitas
function logActivity($conn, $user_id, $aktivitas, $detail = '') {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $stmt = $conn->prepare("INSERT INTO log_aktivitas (user_id, aktivitas, detail, ip_address) VALUES (?, ?, ?, ?)");
    if ($stmt) {
        $stmt->bind_param("isss", $user_id, $aktivitas, $detail, $ip);
        $stmt->execute();
        $stmt->close();
    }
}

// Get nama user
function getNamaUser($conn, $user_id) {
    $result = $conn->query("SELECT nama_lengkap FROM users WHERE id = $user_id");
    return $result->num_rows > 0 ? $result->fetch_assoc()['nama_lengkap'] : 'Unknown';
}

// Get nama kategori
function getNamaKategori($conn, $id) {
    $result = $conn->query("SELECT nama_kategori FROM kategori WHERE id = $id");
    return $result->num_rows > 0 ? $result->fetch_assoc()['nama_kategori'] : '-';
}

// Get nama supplier
function getNamaSupplier($conn, $id) {
    $result = $conn->query("SELECT nama_supplier FROM supplier WHERE id = $id");
    return $result->num_rows > 0 ? $result->fetch_assoc()['nama_supplier'] : '-';
}

// ============================================
// AJAX SEARCH PRODUK (Untuk Kasir) - DIPERBAIKI
// ============================================
// Hanya jalankan jika ada parameter action
if (isset($_GET['action']) && $_GET['action'] == 'search_produk') {
    // Include koneksi database
    require_once 'database.php';
    
    $q = $_GET['q'] ?? '';
    $q = $conn->real_escape_string($q);
    
    $result = $conn->query("
        SELECT p.*, k.nama_kategori 
        FROM produk p 
        LEFT JOIN kategori k ON p.kategori_id = k.id 
        WHERE (p.kode_produk LIKE '%$q%' 
        OR p.nama_produk LIKE '%$q%')
        AND p.stok > 0
        ORDER BY p.nama_produk 
        LIMIT 20
    ");
    
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    header('Content-Type: application/json');
    echo json_encode($data);
    exit();
}
// ============================================
// AJAX SEARCH PRODUK
// ============================================
if (isset($_GET['action']) && $_GET['action'] == 'search_produk') {
    // Koneksi database
    $host = 'localhost';
    $username = 'root';
    $password = '';
    $database = 'toko_kecil_full';
    
    $conn = new mysqli($host, $username, $password, $database);
    
    if ($conn->connect_error) {
        echo json_encode(['error' => 'Koneksi gagal']);
        exit();
    }
    
    $q = $_GET['q'] ?? '';
    $q = $conn->real_escape_string($q);
    
    $result = $conn->query("
        SELECT p.*, k.nama_kategori 
        FROM produk p 
        LEFT JOIN kategori k ON p.kategori_id = k.id 
        WHERE (p.kode_produk LIKE '%$q%' 
        OR p.nama_produk LIKE '%$q%')
        AND p.stok > 0
        ORDER BY p.nama_produk 
        LIMIT 20
    ");
    
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    header('Content-Type: application/json');
    echo json_encode($data);
    exit();
}
?>