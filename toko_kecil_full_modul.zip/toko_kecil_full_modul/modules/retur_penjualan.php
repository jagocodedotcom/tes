<?php
include '../config/database.php';

$message = '';
$retur_data = null;

// ============================================
// UPDATE STATUS RETUR
// ============================================
if (isset($_GET['update_status']) && isset($_GET['status'])) {
    $id = $_GET['update_status'];
    $status = $_GET['status'];
    
    $valid_status = ['pending', 'approved', 'rejected'];
    if (in_array($status, $valid_status)) {
        $stmt = $conn->prepare("UPDATE retur_penjualan SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $status, $id);
        
        if ($stmt->execute()) {
            logActivity($conn, $_SESSION['user_id'], 'Update Status Retur Penjualan', "Retur ID: $id, Status: $status");
            $message = '<div class="alert success"><i class="fas fa-check-circle"></i> Status retur berhasil diupdate menjadi <strong>' . strtoupper($status) . '</strong>!</div>';
            
            if (isset($_GET['invoice'])) {
                echo '<script>window.location.href = "retur_penjualan.php?invoice=' . $_GET['invoice'] . '&status_updated=1";</script>';
                exit();
            } else {
                echo '<script>window.location.href = "retur_penjualan.php?status_updated=1";</script>';
                exit();
            }
        } else {
            $message = '<div class="alert error"><i class="fas fa-exclamation-circle"></i> Gagal update status: ' . $conn->error . '</div>';
        }
    }
}

// Cek jika ada parameter invoice
if (isset($_GET['invoice'])) {
    $id = $_GET['invoice'];
    $result = $conn->query("
        SELECT r.*, 
               p.nama_produk, p.kode_produk, p.satuan,
               pen.no_invoice, pen.tanggal_penjualan,
               u.nama_lengkap as kasir
        FROM retur_penjualan r
        JOIN produk p ON r.produk_id = p.id
        LEFT JOIN penjualan pen ON r.penjualan_id = pen.id
        LEFT JOIN users u ON pen.user_id = u.id
        WHERE r.id = '$id'
    ");
    $retur_data = $result->fetch_assoc();
}

// Proses retur penjualan
if ($_SERVER['REQUEST_METHOD'] == 'POST' && !isset($_POST['print'])) {
    $penjualan_id = $_POST['penjualan_id'];
    $produk_id = $_POST['produk_id'];
    $jumlah = $_POST['jumlah'];
    $alasan = $_POST['alasan'];
    $tanggal = $_POST['tanggal'];

    $harga_result = $conn->query("SELECT harga_jual_saat FROM penjualan WHERE id = $penjualan_id");
    $harga = $harga_result->fetch_assoc()['harga_jual_saat'];
    $total_retur = $jumlah * $harga;

    $stmt = $conn->prepare("
        INSERT INTO retur_penjualan (penjualan_id, produk_id, jumlah, harga_retur, total_retur, alasan, tanggal_retur, user_id, status) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')
    ");
    $stmt->bind_param("iiiddssi", $penjualan_id, $produk_id, $jumlah, $harga, $total_retur, $alasan, $tanggal, $_SESSION['user_id']);

    if ($stmt->execute()) {
        $conn->query("UPDATE penjualan SET status = 'batal' WHERE id = $penjualan_id");
        logActivity($conn, $_SESSION['user_id'], 'Retur Penjualan', "Retur ID: " . $conn->insert_id);
        
        echo '<script>window.location.href = "retur_penjualan.php?invoice=' . $conn->insert_id . '";</script>';
        exit();
    } else {
        $message = '<div class="alert error"><i class="fas fa-exclamation-circle"></i> Gagal: ' . $conn->error . '</div>';
    }
}

// Ambil daftar penjualan untuk dropdown
$penjualan_list = $conn->query("
    SELECT pen.*, p.nama_produk, p.kode_produk 
    FROM penjualan pen 
    JOIN produk p ON pen.produk_id = p.id 
    WHERE pen.status = 'selesai' 
    ORDER BY pen.created_at DESC 
    LIMIT 50
");

// Riwayat retur
$riwayat_retur = $conn->query("
    SELECT r.*, p.nama_produk, p.kode_produk, 
           pen.no_invoice, u.nama_lengkap as kasir
    FROM retur_penjualan r
    JOIN produk p ON r.produk_id = p.id
    LEFT JOIN penjualan pen ON r.penjualan_id = pen.id
    LEFT JOIN users u ON r.user_id = u.id
    ORDER BY r.created_at DESC 
    LIMIT 20
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Retur Penjualan - Toko Kecil</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* ============================================
           RETUR PENJUALAN STYLES
           ============================================ */
        .retur-header {
            background: linear-gradient(135deg, #c62828 0%, #f44336 100%);
            color: white;
            padding: 14px 18px;
            border-radius: var(--radius);
            margin-bottom: 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        
        .retur-header .retur-title {
            font-size: 18px;
            font-weight: 700;
        }
        
        .retur-header .retur-title i {
            margin-right: 8px;
        }
        
        .retur-header .retur-date {
            font-size: 12px;
            opacity: 0.9;
            background: rgba(255,255,255,0.15);
            padding: 4px 12px;
            border-radius: 20px;
        }
        
        /* Selected Product */
        .selected-product {
            background: #ffebee;
            border: 2px solid #ef9a9a;
            border-radius: var(--radius-sm);
            padding: 12px 14px;
            margin-bottom: 14px;
            display: none;
        }
        
        .selected-product.show {
            display: block;
        }
        
        .selected-product .selected-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 4px;
        }
        
        .selected-product .selected-header .selected-name {
            font-weight: 700;
            font-size: 15px;
            color: #c62828;
        }
        
        .selected-product .selected-header .selected-code {
            font-size: 11px;
            color: var(--text-light);
            font-family: 'Courier New', monospace;
        }
        
        .selected-product .selected-details {
            display: flex;
            gap: 16px;
            font-size: 12px;
            color: var(--text-light);
            flex-wrap: wrap;
        }
        
        .selected-product .selected-details span i {
            margin-right: 4px;
            color: #f44336;
        }
        
        /* Form */
        .form-card-retur {
            background: var(--card-bg);
            border-radius: var(--radius);
            padding: 16px 14px;
            margin-bottom: 16px;
            box-shadow: var(--shadow);
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }
        
        .form-group {
            margin-bottom: 10px;
        }
        
        .form-group label {
            display: block;
            font-size: 12px;
            font-weight: 600;
            margin-bottom: 4px;
            color: var(--text-light);
        }
        
        .form-group label i {
            margin-right: 4px;
            color: #f44336;
        }
        
        .form-control {
            width: 100%;
            padding: 10px 12px;
            border: 2px solid #e8ecf1;
            border-radius: var(--radius-sm);
            font-size: 14px;
            background: #fafbfc;
            transition: var(--transition);
            font-family: inherit;
            color: var(--text);
        }
        
        .form-control:focus {
            outline: none;
            border-color: #f44336;
            background: white;
            box-shadow: 0 0 0 3px rgba(244, 67, 54, 0.1);
        }
        
        .form-control[readonly] {
            background: #f0f2f5;
            cursor: not-allowed;
        }
        
        .total-display-retur {
            background: linear-gradient(135deg, #ffebee 0%, #ffcdd2 100%);
            padding: 14px 18px;
            border-radius: var(--radius-sm);
            display: flex;
            justify-content: space-between;
            font-weight: 700;
            font-size: 16px;
            margin: 10px 0 14px 0;
            border: 2px solid #ef9a9a;
        }
        
        .total-display-retur span:last-child {
            color: #c62828;
            font-size: 22px;
        }
        
        .btn-submit-retur {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #c62828 0%, #f44336 100%);
            color: white;
            border: none;
            border-radius: var(--radius-sm);
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            transition: var(--transition);
        }
        
        .btn-submit-retur:active {
            transform: scale(0.97);
        }
        
        .btn-submit-retur:hover {
            opacity: 0.9;
            box-shadow: 0 4px 16px rgba(244, 67, 54, 0.3);
        }
        
        .btn-submit-retur:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        
        /* Invoice */
        .invoice-container {
            background: white;
            border-radius: var(--radius);
            box-shadow: var(--shadow-hover);
            padding: 24px 20px;
            margin-bottom: 20px;
        }
        
        .invoice-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            border-bottom: 3px double #f44336;
            padding-bottom: 16px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        
        .invoice-header .company-info h2 {
            color: #c62828;
            font-size: 22px;
            margin: 0;
        }
        
        .invoice-header .company-info p {
            margin: 4px 0;
            color: #666;
            font-size: 13px;
        }
        
        .invoice-header .invoice-info {
            text-align: right;
        }
        
        .invoice-header .invoice-info .invoice-title {
            font-size: 24px;
            font-weight: 700;
            color: #f44336;
            letter-spacing: 2px;
        }
        
        .invoice-header .invoice-info .invoice-number {
            font-size: 16px;
            font-weight: 600;
            color: #333;
        }
        
        .invoice-body {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 16px;
            margin-bottom: 20px;
        }
        
        .invoice-body .info-box {
            background: #f8f9fa;
            padding: 12px 16px;
            border-radius: var(--radius-sm);
            border-left: 4px solid #f44336;
        }
        
        .invoice-body .info-box .label {
            font-size: 10px;
            color: #999;
            text-transform: uppercase;
            font-weight: 600;
            letter-spacing: 0.5px;
        }
        
        .invoice-body .info-box .value {
            font-size: 15px;
            font-weight: 600;
            color: var(--text);
            margin-top: 2px;
        }
        
        .invoice-table {
            width: 100%;
            border-collapse: collapse;
            margin: 15px 0;
        }
        
        .invoice-table th {
            background: #ffebee;
            color: #c62828;
            padding: 10px 12px;
            text-align: left;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .invoice-table td {
            padding: 10px 12px;
            border-bottom: 1px solid #e8e8e8;
            font-size: 14px;
        }
        
        .invoice-table .total-row {
            background: #ffebee;
            font-weight: 600;
        }
        
        .invoice-table .total-row td {
            border-top: 2px solid #f44336;
            padding: 12px;
            font-size: 16px;
        }
        
        .invoice-table .total-row td:last-child {
            color: #c62828;
            font-size: 18px;
        }
        
        .invoice-footer {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
            padding-top: 15px;
            border-top: 2px solid #e8e8e8;
            flex-wrap: wrap;
        }
        
        .invoice-footer .signature {
            text-align: center;
            width: 200px;
        }
        
        .invoice-footer .signature .line {
            border-bottom: 1px solid #333;
            width: 150px;
            margin: 30px auto 5px;
        }
        
        .invoice-footer .signature .label {
            font-size: 11px;
            color: #999;
        }
        
        .invoice-actions {
            display: flex;
            gap: 10px;
            margin-top: 15px;
            flex-wrap: wrap;
        }
        
        .btn-print {
            padding: 10px 24px;
            background: #2196F3;
            color: white;
            border: none;
            border-radius: var(--radius-sm);
            cursor: pointer;
            font-size: 14px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: var(--transition);
        }
        
        .btn-print:hover {
            background: #1976D2;
        }
        
        .btn-back {
            padding: 10px 24px;
            background: #757575;
            color: white;
            border: none;
            border-radius: var(--radius-sm);
            cursor: pointer;
            font-size: 14px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: var(--transition);
            text-decoration: none;
        }
        
        .btn-back:hover {
            background: #616161;
        }
        
        /* Status Badge */
        .status-badge {
            display: inline-block;
            padding: 6px 16px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 600;
            letter-spacing: 0.5px;
        }
        
        .status-badge-pending {
            background: #fff3e0;
            color: #e65100;
            border: 2px solid #ff9800;
        }
        
        .status-badge-approved {
            background: #e8f5e9;
            color: #2e7d32;
            border: 2px solid #4CAF50;
        }
        
        .status-badge-rejected {
            background: #ffebee;
            color: #c62828;
            border: 2px solid #f44336;
        }
        
        .btn-status {
            padding: 6px 16px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 12px;
            font-weight: 600;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 4px;
            text-decoration: none;
        }
        
        .btn-status:hover {
            transform: scale(1.05);
        }
        
        .btn-status-pending {
            background: #ff9800;
            color: white;
        }
        
        .btn-status-approved {
            background: #4CAF50;
            color: white;
        }
        
        .btn-status-rejected {
            background: #f44336;
            color: white;
        }
        
        .btn-status .active {
            box-shadow: 0 0 0 3px rgba(0,0,0,0.2);
        }
        
        .status-edit-form {
            display: flex;
            gap: 8px;
            align-items: center;
            flex-wrap: wrap;
            padding: 10px 14px;
            background: #f5f5f5;
            border-radius: 8px;
            margin-top: 8px;
        }
        
        .status-edit-form label {
            font-weight: 500;
            font-size: 13px;
            color: var(--text-light);
        }
        
        .retur-alasan {
            background: #fff8e1;
            padding: 8px 12px;
            border-radius: 6px;
            border-left: 4px solid #ff9800;
            margin-top: 5px;
            font-size: 13px;
            color: #666;
        }
        
        .retur-alasan strong {
            color: #333;
        }
        
        /* Quick Actions */
        .quick-actions-retur {
            display: flex;
            gap: 8px;
            margin-bottom: 16px;
            flex-wrap: wrap;
        }
        
        .quick-actions-retur .btn-quick {
            padding: 8px 14px;
            border: none;
            border-radius: var(--radius-sm);
            cursor: pointer;
            font-weight: 600;
            font-size: 12px;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 6px;
            text-decoration: none;
            color: white;
        }
        
        .quick-actions-retur .btn-quick:active {
            transform: scale(0.95);
        }
        
        .quick-actions-retur .btn-quick.batal {
            background: #f44336;
        }
        
        .quick-actions-retur .btn-quick.batal:hover {
            background: #d32f2f;
        }
        
        .quick-actions-retur .btn-quick.reset {
            background: #FF9800;
        }
        
        .quick-actions-retur .btn-quick.reset:hover {
            background: #e68900;
        }
        
        .quick-actions-retur .btn-quick.penjualan {
            background: #2196F3;
        }
        
        .quick-actions-retur .btn-quick.penjualan:hover {
            background: #1976D2;
        }
        
        .badge {
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 10px;
            font-weight: 600;
        }
        
        .badge-success {
            background: #e8f5e9;
            color: #2e7d32;
        }
        
        .badge-warning {
            background: #fff3e0;
            color: #e65100;
        }
        
        .badge-danger {
            background: #ffebee;
            color: #c62828;
        }
        
        .text-danger {
            color: #f44336;
        }
        
        /* Responsive */
        @media (max-width: 480px) {
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .retur-header {
                flex-direction: column;
                text-align: center;
                gap: 4px;
            }
            
            .invoice-body {
                grid-template-columns: 1fr;
            }
            
            .invoice-header {
                flex-direction: column;
            }
            
            .invoice-header .invoice-info {
                text-align: left;
                margin-top: 10px;
            }
            
            .invoice-footer {
                flex-direction: column;
                align-items: center;
            }
            
            .invoice-container {
                padding: 15px;
            }
            
            .total-display-retur {
                font-size: 14px;
            }
            
            .total-display-retur span:last-child {
                font-size: 18px;
            }
            
            .status-edit-form {
                flex-direction: column;
                align-items: stretch;
            }
        }
        
        @media print {
            .no-print { display: none !important; }
            .bottom-nav { display: none !important; }
            .container { max-width: 100% !important; padding: 0 !important; }
            .invoice-container { box-shadow: none !important; padding: 15px !important; }
            .btn-print, .btn-back { display: none !important; }
            .header { display: none !important; }
            .invoice-actions { display: none !important; }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <header class="header">
            <a href="../index.php" class="back-btn"><i class="fas fa-arrow-left"></i></a>
            <h1><i class="fas fa-undo"></i> Retur Penjualan</h1>
            <a href="notifikasi.php" class="btn-icon" style="position:relative;">
                <i class="fas fa-bell" style="font-size:18px;color:var(--text-light);"></i>
                <?php 
                $unread = $conn->query("SELECT COUNT(*) as total FROM notifikasi WHERE user_id = {$_SESSION['user_id']} AND is_read = 0");
                $unread_count = $unread->num_rows > 0 ? $unread->fetch_assoc()['total'] : 0;
                if ($unread_count > 0): 
                ?>
                <span class="badge-icon"><?php echo $unread_count; ?></span>
                <?php endif; ?>
            </a>
        </header>

        <main class="main-content">
            <?php echo $message; ?>
            
            <?php if (isset($_GET['status_updated'])): ?>
            <div class="alert success"><i class="fas fa-check-circle"></i> Status retur berhasil diupdate!</div>
            <?php endif; ?>

            <!-- INVOICE RETUR VIEW -->
            <?php if ($retur_data): ?>
            <div class="invoice-container" id="invoiceContainer">
                <!-- Header Invoice -->
                <div class="invoice-header">
                    <div class="company-info">
                        <h2><i class="fas fa-store" style="color:#f44336;"></i> Toko Kecil</h2>
                        <p><i class="fas fa-map-marker-alt"></i> Jl. Toko No. 1, Jakarta</p>
                        <p><i class="fas fa-phone"></i> 021-555-0000</p>
                        <p><i class="fas fa-envelope"></i> info@tokokecil.com</p>
                    </div>
                    <div class="invoice-info">
                        <div class="invoice-title">RETUR PENJUALAN</div>
                        <div class="invoice-number"># RET-<?php echo str_pad($retur_data['id'], 6, '0', STR_PAD_LEFT); ?></div>
                        <div style="margin-top:8px;">
                            <span class="status-badge status-badge-<?php echo $retur_data['status']; ?>">
                                <i class="fas fa-<?php echo $retur_data['status'] == 'pending' ? 'clock' : ($retur_data['status'] == 'approved' ? 'check-circle' : 'times-circle'); ?>"></i>
                                <?php echo strtoupper($retur_data['status']); ?>
                            </span>
                        </div>
                    </div>
                </div>

                <!-- Body Invoice -->
                <div class="invoice-body">
                    <div class="info-box">
                        <div class="label"><i class="fas fa-receipt"></i> Invoice Asli</div>
                        <div class="value"><?php echo $retur_data['no_invoice'] ?? '-'; ?></div>
                        <div style="font-size:13px;color:#666;margin-top:4px;">
                            <i class="fas fa-calendar"></i> <?php echo date('d F Y', strtotime($retur_data['tanggal_penjualan'] ?? $retur_data['tanggal_retur'])); ?>
                        </div>
                    </div>
                    <div class="info-box">
                        <div class="label"><i class="fas fa-box"></i> Produk</div>
                        <div class="value"><?php echo $retur_data['nama_produk']; ?></div>
                        <div style="font-size:13px;color:#666;margin-top:4px;">
                            <i class="fas fa-barcode"></i> <?php echo $retur_data['kode_produk']; ?>
                        </div>
                    </div>
                    <div class="info-box">
                        <div class="label"><i class="fas fa-user"></i> Kasir</div>
                        <div class="value"><?php echo $retur_data['kasir'] ?? 'Admin'; ?></div>
                        <div style="font-size:13px;color:#666;margin-top:4px;">
                            <i class="fas fa-calendar"></i> <?php echo date('d F Y', strtotime($retur_data['tanggal_retur'])); ?>
                        </div>
                    </div>
                </div>

                <!-- Tabel Retur -->
                <table class="invoice-table">
                    <thead>
                        <tr>
                            <th style="width:15%;">Kode</th>
                            <th style="width:35%;">Nama Produk</th>
                            <th style="width:15%;">Satuan</th>
                            <th style="width:10%;">Jumlah</th>
                            <th style="width:15%;">Harga Retur</th>
                            <th style="width:15%;">Total Retur</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo $retur_data['kode_produk']; ?></td>
                            <td><?php echo $retur_data['nama_produk']; ?></td>
                            <td><?php echo $retur_data['satuan'] ?? 'Pcs'; ?></td>
                            <td class="text-danger"><?php echo $retur_data['jumlah']; ?></td>
                            <td><?php echo rupiah($retur_data['harga_retur']); ?></td>
                            <td class="text-danger"><?php echo rupiah($retur_data['total_retur']); ?></td>
                        </tr>
                    </tbody>
                    <tfoot>
                        <tr class="total-row">
                            <td colspan="5" style="text-align:right;font-size:16px;">Total Retur</td>
                            <td style="font-size:18px;color:#c62828;">
                                <?php echo rupiah($retur_data['total_retur']); ?>
                            </td>
                        </tr>
                    </tfoot>
                </table>

                <!-- Alasan Retur -->
                <?php if ($retur_data['alasan']): ?>
                <div class="retur-alasan">
                    <strong><i class="fas fa-comment"></i> Alasan Retur:</strong> <?php echo $retur_data['alasan']; ?>
                </div>
                <?php endif; ?>

                <!-- Edit Status -->
                <div class="status-edit-form no-print">
                    <label><i class="fas fa-edit"></i> Ubah Status:</label>
                    
                    <a href="?update_status=<?php echo $retur_data['id']; ?>&status=pending&invoice=<?php echo $retur_data['id']; ?>" 
                       class="btn-status btn-status-pending <?php echo $retur_data['status'] == 'pending' ? 'active' : ''; ?>"
                       onclick="return confirm('Ubah status menjadi PENDING?')">
                        <i class="fas fa-clock"></i> Pending
                    </a>
                    
                    <a href="?update_status=<?php echo $retur_data['id']; ?>&status=approved&invoice=<?php echo $retur_data['id']; ?>" 
                       class="btn-status btn-status-approved <?php echo $retur_data['status'] == 'approved' ? 'active' : ''; ?>"
                       onclick="return confirm('Ubah status menjadi APPROVED? Stok akan otomatis bertambah.')">
                        <i class="fas fa-check-circle"></i> Approved
                    </a>
                    
                    <a href="?update_status=<?php echo $retur_data['id']; ?>&status=rejected&invoice=<?php echo $retur_data['id']; ?>" 
                       class="btn-status btn-status-rejected <?php echo $retur_data['status'] == 'rejected' ? 'active' : ''; ?>"
                       onclick="return confirm('Ubah status menjadi REJECTED?')">
                        <i class="fas fa-times-circle"></i> Rejected
                    </a>
                    
                    <span style="font-size:11px;color:var(--text-light);margin-left:auto;">
                        <i class="fas fa-info-circle"></i> Status aktif akan otomatis terupdate
                    </span>
                </div>

                <!-- Footer Invoice -->
                <div class="invoice-footer">
                    <div class="signature">
                        <div class="line"></div>
                        <div class="label">Pelanggan</div>
                    </div>
                    <div class="signature">
                        <div class="line"></div>
                        <div class="label">Kasir</div>
                    </div>
                    <div class="signature">
                        <div class="line"></div>
                        <div class="label">Manajer</div>
                    </div>
                </div>

                <!-- Tombol Aksi -->
                <div class="invoice-actions no-print">
                    <button class="btn-print" onclick="window.print()">
                        <i class="fas fa-print"></i> Cetak Retur
                    </button>
                    <a href="retur_penjualan.php" class="btn-back">
                        <i class="fas fa-arrow-left"></i> Kembali
                    </a>
                </div>
            </div>
            <?php else: ?>

            <!-- Retur Header -->
            <div class="retur-header">
                <div class="retur-title">
                    <i class="fas fa-undo-alt"></i> Form Retur Penjualan
                </div>
                <div class="retur-date">
                    <i class="fas fa-calendar-alt"></i> <?php echo date('l, d F Y'); ?>
                </div>
            </div>

            <!-- FORM RETUR PENJUALAN -->
            <div class="form-card-retur">
                <h3 style="font-size:15px;font-weight:700;color:#c62828;margin-bottom:12px;">
                    <i class="fas fa-undo-alt"></i> Form Retur
                </h3>
                
                <form method="POST">
                    <div class="form-group">
                        <label><i class="fas fa-receipt"></i> Pilih Transaksi Penjualan</label>
                        <select name="penjualan_id" id="penjualanSelect" required class="form-control" onchange="pilihPenjualan()">
                            <option value="">-- Pilih Invoice --</option>
                            <?php while ($row = $penjualan_list->fetch_assoc()): ?>
                            <option value="<?php echo $row['id']; ?>" 
                                    data-produk="<?php echo $row['produk_id']; ?>" 
                                    data-jumlah="<?php echo $row['jumlah']; ?>"
                                    data-harga="<?php echo $row['harga_jual_saat']; ?>"
                                    data-nama="<?php echo $row['nama_produk']; ?>"
                                    data-kode="<?php echo $row['kode_produk']; ?>">
                                <?php echo $row['no_invoice']; ?> - <?php echo $row['nama_produk']; ?> (<?php echo $row['jumlah']; ?> pcs)
                            </option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <!-- Selected Product -->
                    <div class="selected-product" id="selectedProduct">
                        <div class="selected-header">
                            <span class="selected-name" id="selectedNama">-</span>
                            <span class="selected-code" id="selectedKode">-</span>
                        </div>
                        <div class="selected-details">
                            <span><i class="fas fa-tag"></i> Harga: <strong id="selectedHarga">Rp 0</strong></span>
                            <span><i class="fas fa-cubes"></i> Maks Retur: <strong id="selectedMax">0</strong> pcs</span>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label><i class="fas fa-barcode"></i> Kode Produk</label>
                            <input type="text" id="kodeProduk" readonly class="form-control" placeholder="-">
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-box"></i> Nama Produk</label>
                            <input type="text" id="namaProduk" readonly class="form-control" placeholder="-">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label><i class="fas fa-hashtag"></i> Jumlah Retur</label>
                            <input type="number" name="jumlah" id="jumlahRetur" min="1" required class="form-control" placeholder="Masukkan jumlah retur" oninput="hitungTotalRetur()">
                            <small id="maxRetur" style="color:var(--text-light);font-size:11px;"></small>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-tag"></i> Harga Retur</label>
                            <input type="number" name="harga" id="hargaRetur" readonly class="form-control" placeholder="0">
                        </div>
                    </div>

                    <input type="hidden" name="produk_id" id="produkId">

                    <div class="form-group">
                        <label><i class="fas fa-comment"></i> Alasan Retur</label>
                        <textarea name="alasan" class="form-control" rows="2" placeholder="Masukkan alasan retur..."></textarea>
                    </div>

                    <div class="form-group">
                        <label><i class="fas fa-calendar"></i> Tanggal Retur</label>
                        <input type="date" name="tanggal" value="<?php echo date('Y-m-d'); ?>" required class="form-control">
                    </div>

                    <div class="total-display-retur">
                        <span>Total Retur</span>
                        <span id="totalReturDisplay">Rp 0</span>
                    </div>

                    <button type="submit" class="btn-submit-retur" id="btnSubmitRetur">
                        <i class="fas fa-undo"></i> Proses Retur
                    </button>
                </form>
            </div>

            <!-- Quick Actions -->
            <div class="quick-actions-retur">
                <button class="btn-quick batal" onclick="resetFormRetur()">
                    <i class="fas fa-times"></i> Batal
                </button>
                <button class="btn-quick reset" onclick="resetFormRetur()">
                    <i class="fas fa-undo"></i> Reset
                </button>
                <a href="penjualan.php" class="btn-quick penjualan">
                    <i class="fas fa-cash-register"></i> Kasir
                </a>
            </div>

            <!-- RIWAYAT RETUR -->
            <div class="section">
                <h3><i class="fas fa-history"></i> Riwayat Retur Penjualan</h3>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>ID Retur</th>
                                <th>Invoice</th>
                                <th>Tanggal</th>
                                <th>Produk</th>
                                <th>Jml</th>
                                <th>Total</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $riwayat_retur->fetch_assoc()): ?>
                            <tr>
                                <td><small>#RET-<?php echo str_pad($row['id'], 6, '0', STR_PAD_LEFT); ?></small></td>
                                <td><?php echo $row['no_invoice'] ?? '-'; ?></td>
                                <td><?php echo date('d/m/Y', strtotime($row['tanggal_retur'])); ?></td>
                                <td><?php echo $row['nama_produk']; ?></td>
                                <td class="text-danger"><?php echo $row['jumlah']; ?></td>
                                <td class="text-danger"><?php echo rupiah($row['total_retur']); ?></td>
                                <td>
                                    <span class="badge <?php 
                                        echo $row['status'] == 'pending' ? 'badge-warning' : 
                                            ($row['status'] == 'approved' ? 'badge-success' : 'badge-danger'); 
                                    ?>">
                                        <?php echo $row['status']; ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="?invoice=<?php echo $row['id']; ?>" class="btn-primary" style="padding:4px 8px;font-size:11px;">
                                        <i class="fas fa-file-invoice"></i>
                                    </a>
                                    <div class="dropdown" style="display:inline-block;position:relative;">
                                        <button class="btn-primary" style="padding:4px 8px;font-size:11px;background:#9C27B0;border:none;border-radius:4px;cursor:pointer;">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <div class="dropdown-content" style="display:none;position:absolute;background:white;min-width:120px;box-shadow:0 4px 8px rgba(0,0,0,0.1);border-radius:4px;z-index:100;">
                                            <a href="?update_status=<?php echo $row['id']; ?>&status=pending" style="display:block;padding:6px 12px;color:#e65100;text-decoration:none;font-size:11px;border-bottom:1px solid #eee;">
                                                <i class="fas fa-clock"></i> Pending
                                            </a>
                                            <a href="?update_status=<?php echo $row['id']; ?>&status=approved" style="display:block;padding:6px 12px;color:#2e7d32;text-decoration:none;font-size:11px;border-bottom:1px solid #eee;" onclick="return confirm('Ubah status menjadi APPROVED? Stok akan otomatis bertambah.')">
                                                <i class="fas fa-check-circle"></i> Approved
                                            </a>
                                            <a href="?update_status=<?php echo $row['id']; ?>&status=rejected" style="display:block;padding:6px 12px;color:#c62828;text-decoration:none;font-size:11px;" onclick="return confirm('Ubah status menjadi REJECTED?')">
                                                <i class="fas fa-times-circle"></i> Rejected
                                            </a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>
        </main>

        <!-- Bottom Navigation -->
        <nav class="bottom-nav">
            <a href="../index.php"><i class="fas fa-home"></i><span>Dashboard</span></a>
            <a href="penjualan.php"><i class="fas fa-cash-register"></i><span>Kasir</span></a>
            <a href="pembelian.php"><i class="fas fa-truck"></i><span>Beli</span></a>
            <a href="produk.php"><i class="fas fa-box"></i><span>Produk</span></a>
            <a href="../laporan/laba_rugi.php"><i class="fas fa-chart-bar"></i><span>Laporan</span></a>
        </nav>
    </div>

    <script>
        // ============================================
        // PILIH PENJUALAN
        // ============================================
        function pilihPenjualan() {
            const select = document.getElementById('penjualanSelect');
            const selected = select.options[select.selectedIndex];
            
            if (selected.value) {
                document.getElementById('produkId').value = selected.dataset.produk;
                document.getElementById('kodeProduk').value = selected.dataset.kode || '-';
                document.getElementById('namaProduk').value = selected.dataset.nama || '-';
                document.getElementById('hargaRetur').value = selected.dataset.harga || 0;
                document.getElementById('jumlahRetur').max = selected.dataset.jumlah || 0;
                document.getElementById('maxRetur').textContent = 'Maksimal retur: ' + (selected.dataset.jumlah || 0) + ' pcs';
                document.getElementById('jumlahRetur').value = 1;
                
                document.getElementById('selectedNama').textContent = selected.dataset.nama || '-';
                document.getElementById('selectedKode').textContent = selected.dataset.kode || '-';
                document.getElementById('selectedHarga').textContent = 'Rp ' + (selected.dataset.harga || 0).toLocaleString('id-ID');
                document.getElementById('selectedMax').textContent = selected.dataset.jumlah || 0;
                document.getElementById('selectedProduct').classList.add('show');
                
                hitungTotalRetur();
            } else {
                document.getElementById('selectedProduct').classList.remove('show');
            }
        }

        // ============================================
        // HITUNG TOTAL RETUR
        // ============================================
        function hitungTotalRetur() {
            const jumlah = parseInt(document.getElementById('jumlahRetur').value) || 0;
            const harga = parseInt(document.getElementById('hargaRetur').value) || 0;
            const total = jumlah * harga;
            document.getElementById('totalReturDisplay').textContent = 'Rp ' + total.toLocaleString('id-ID');
            
            const maxRetur = parseInt(document.getElementById('jumlahRetur').max) || 0;
            const btnSubmit = document.getElementById('btnSubmitRetur');
            
            if (jumlah > maxRetur && maxRetur > 0) {
                document.getElementById('totalReturDisplay').style.color = '#c62828';
                btnSubmit.disabled = true;
                btnSubmit.style.opacity = '0.5';
                btnSubmit.innerHTML = '<i class="fas fa-exclamation-circle"></i> Jumlah melebihi batas!';
            } else {
                document.getElementById('totalReturDisplay').style.color = '';
                btnSubmit.disabled = false;
                btnSubmit.style.opacity = '1';
                btnSubmit.innerHTML = '<i class="fas fa-undo"></i> Proses Retur';
            }
        }

        // ============================================
        // RESET FORM
        // ============================================
        function resetFormRetur() {
            document.querySelector('.form-card-retur form').reset();
            document.getElementById('totalReturDisplay').textContent = 'Rp 0';
            document.getElementById('selectedProduct').classList.remove('show');
            document.getElementById('kodeProduk').value = '';
            document.getElementById('namaProduk').value = '';
            document.getElementById('hargaRetur').value = '';
            document.getElementById('produkId').value = '';
            document.getElementById('totalReturDisplay').style.color = '';
            document.getElementById('btnSubmitRetur').disabled = false;
            document.getElementById('btnSubmitRetur').style.opacity = '1';
            document.getElementById('btnSubmitRetur').innerHTML = '<i class="fas fa-undo"></i> Proses Retur';
        }

        document.getElementById('jumlahRetur').addEventListener('input', hitungTotalRetur);
        document.getElementById('hargaRetur').addEventListener('input', hitungTotalRetur);

        // ============================================
        // DROPDOWN EDIT STATUS
        // ============================================
        document.querySelectorAll('.dropdown').forEach(function(dropdown) {
            dropdown.addEventListener('mouseenter', function() {
                this.querySelector('.dropdown-content').style.display = 'block';
            });
            dropdown.addEventListener('mouseleave', function() {
                this.querySelector('.dropdown-content').style.display = 'none';
            });
        });

        // ============================================
        // AUTO-HIDE ALERT
        // ============================================
        document.addEventListener('DOMContentLoaded', function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(function(alert) {
                setTimeout(function() {
                    alert.style.transition = 'opacity 0.5s';
                    alert.style.opacity = '0';
                    setTimeout(function() {
                        alert.style.display = 'none';
                    }, 500);
                }, 5000);
            });
        });
    </script>
    <script src="../js/script.js"></script>
</body>
</html>