<?php
include '../config/database.php';

$message = '';
$edit_data = null;
$search = $_GET['search'] ?? '';

// Hapus data
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    // Ambil nama produk untuk log
    $nama_produk = $conn->query("SELECT nama_produk FROM produk WHERE id = $id")->fetch_assoc()['nama_produk'];
    if ($conn->query("DELETE FROM produk WHERE id = $id")) {
        logActivity($conn, $_SESSION['user_id'], 'Hapus Produk', "Produk: $nama_produk");
        $message = '<div class="alert success"><i class="fas fa-check-circle"></i> Produk berhasil dihapus!</div>';
    }
}

// Edit - ambil data
if (isset($_GET['edit'])) {
    $result = $conn->query("SELECT * FROM produk WHERE id = {$_GET['edit']}");
    $edit_data = $result->fetch_assoc();
}

// ============================================
// FUNGSI GENERATE KODE PRODUK OTOMATIS
// ============================================
function generateKodeProdukOtomatis($conn) {
    $result = $conn->query("SELECT kode_produk FROM produk ORDER BY id DESC LIMIT 1");
    
    if ($result->num_rows > 0) {
        $last_code = $result->fetch_assoc()['kode_produk'];
        $last_number = (int) substr($last_code, -4);
        $new_number = str_pad($last_number + 1, 4, '0', STR_PAD_LEFT);
        return 'PRD-' . date('Ymd') . '-' . $new_number;
    } else {
        return 'PRD-' . date('Ymd') . '-0001';
    }
}

// Simpan data
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'] ?? 0;
    $kode_produk = $_POST['kode_produk'];
    $barcode = $_POST['barcode'] ?? '';
    $nama_produk = $_POST['nama_produk'];
    $kategori_id = $_POST['kategori_id'] ?: null;
    $supplier_id = $_POST['supplier_id'] ?: null;
    $harga_beli = $_POST['harga_beli'];
    $harga_jual = $_POST['harga_jual'];
    $stok = $_POST['stok'] ?? 0;
    $stok_minimal = $_POST['stok_minimal'] ?? 5;
    $satuan = $_POST['satuan'];
    $deskripsi = $_POST['deskripsi'];

    if ($id > 0) {
        $stmt = $conn->prepare("
            UPDATE produk SET 
                kode_produk=?, barcode=?, nama_produk=?, kategori_id=?, supplier_id=?, 
                harga_beli=?, harga_jual=?, stok=?, stok_minimal=?, satuan=?, deskripsi=? 
            WHERE id=?
        ");
        $stmt->bind_param("ssssiiiiiissi", $kode_produk, $barcode, $nama_produk, $kategori_id, $supplier_id, 
            $harga_beli, $harga_jual, $stok, $stok_minimal, $satuan, $deskripsi, $id);
        logActivity($conn, $_SESSION['user_id'], 'Update Produk', "Produk: $nama_produk");
        $message = '<div class="alert success"><i class="fas fa-check-circle"></i> Produk berhasil diupdate!</div>';
    } else {
        $stmt = $conn->prepare("
            INSERT INTO produk (kode_produk, barcode, nama_produk, kategori_id, supplier_id, harga_beli, harga_jual, stok, stok_minimal, satuan, deskripsi) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->bind_param("sssiiiiiiss", $kode_produk, $barcode, $nama_produk, $kategori_id, $supplier_id, 
            $harga_beli, $harga_jual, $stok, $stok_minimal, $satuan, $deskripsi);
        logActivity($conn, $_SESSION['user_id'], 'Tambah Produk', "Produk: $nama_produk");
        $message = '<div class="alert success"><i class="fas fa-check-circle"></i> Produk berhasil ditambahkan!</div>';
    }
    
    if ($stmt->execute()) {
        $edit_data = null;
        echo '<script>window.location.href = "produk.php?success=1";</script>';
    } else {
        $message = '<div class="alert error"><i class="fas fa-exclamation-circle"></i> Gagal: ' . $conn->error . '</div>';
    }
}

// Query dengan pencarian
$sql = "
    SELECT p.*, k.nama_kategori, s.nama_supplier 
    FROM produk p 
    LEFT JOIN kategori k ON p.kategori_id = k.id 
    LEFT JOIN supplier s ON p.supplier_id = s.id 
";

if ($search) {
    $search = $conn->real_escape_string($search);
    $sql .= " WHERE p.kode_produk LIKE '%$search%' 
              OR p.barcode LIKE '%$search%'
              OR p.nama_produk LIKE '%$search%' 
              OR k.nama_kategori LIKE '%$search%' 
              OR s.nama_supplier LIKE '%$search%' ";
}

$sql .= " ORDER BY p.created_at DESC";
$produk = $conn->query($sql);

$kode_baru = generateKodeProdukOtomatis($conn);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Manajemen Produk - Toko Kecil</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* ============================================
           PRODUK PAGE STYLES
           ============================================ */
        .form-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
            flex-wrap: wrap;
        }
        
        .form-header h3 {
            font-size: 16px;
            font-weight: 700;
            color: var(--primary-dark);
            margin: 0;
        }
        
        .form-header .badge-status {
            font-size: 11px;
            padding: 4px 12px;
            border-radius: 20px;
            background: #e3f2fd;
            color: #0d47a1;
        }
        
        /* Barcode Preview */
        .barcode-preview {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 14px;
            background: linear-gradient(135deg, #f5f5f5 0%, #e8f5e9 100%);
            border: 2px dashed #a5d6a7;
            border-radius: var(--radius-sm);
            margin-top: 6px;
            flex-wrap: wrap;
        }
        
        .barcode-preview .barcode-label {
            font-size: 11px;
            color: var(--text-light);
            font-weight: 500;
        }
        
        .barcode-preview .barcode-text {
            font-family: 'Courier New', monospace;
            font-size: 22px;
            letter-spacing: 4px;
            font-weight: bold;
            color: #2E7D32;
            background: white;
            padding: 4px 14px;
            border-radius: 4px;
            border: 1px solid #4CAF50;
        }
        
        .barcode-preview .barcode-empty {
            color: #999;
            font-style: italic;
            font-size: 13px;
            font-family: Arial, sans-serif;
        }
        
        .barcode-preview .barcode-icon {
            font-size: 24px;
            color: #666;
        }
        
        .barcode-hint {
            font-size: 10px;
            color: var(--text-light);
            margin-top: 3px;
            display: flex;
            align-items: center;
            gap: 4px;
        }
        
        .barcode-hint i {
            color: #FF9800;
        }
        
        /* Product Card di Daftar */
        .product-list-card {
            background: var(--card-bg);
            border-radius: var(--radius-sm);
            padding: 10px 12px;
            margin-bottom: 8px;
            box-shadow: var(--shadow);
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: var(--transition);
            border-left: 3px solid transparent;
        }
        
        .product-list-card:hover {
            border-left-color: var(--primary-light);
        }
        
        .product-list-card .product-info-left {
            flex: 1;
            min-width: 0;
        }
        
        .product-list-card .product-name {
            font-weight: 600;
            font-size: 14px;
        }
        
        .product-list-card .product-meta {
            font-size: 11px;
            color: var(--text-light);
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            margin-top: 2px;
        }
        
        .product-list-card .product-meta .barcode-tag {
            font-family: 'Courier New', monospace;
            background: #f5f5f5;
            padding: 0 6px;
            border-radius: 3px;
        }
        
        .product-list-card .product-stock-info {
            text-align: right;
            margin-right: 10px;
        }
        
        .product-list-card .product-stock-info .stock-number {
            font-size: 18px;
            font-weight: 700;
        }
        
        .product-list-card .product-stock-info .stock-label {
            font-size: 10px;
            color: var(--text-light);
        }
        
        .product-list-card .product-actions {
            display: flex;
            gap: 4px;
        }
        
        .product-list-card .product-actions .btn-action {
            padding: 4px 8px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 11px;
            transition: var(--transition);
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 3px;
        }
        
        .product-list-card .product-actions .btn-edit {
            background: #2196F3;
            color: white;
        }
        
        .product-list-card .product-actions .btn-edit:hover {
            background: #1976D2;
        }
        
        .product-list-card .product-actions .btn-delete {
            background: #f44336;
            color: white;
        }
        
        .product-list-card .product-actions .btn-delete:hover {
            background: #d32f2f;
        }
        
        .product-list-card .product-actions .btn-copy {
            background: #FF9800;
            color: white;
        }
        
        .product-list-card .product-actions .btn-copy:hover {
            background: #e68900;
        }
        
        .product-list-card .product-actions .btn-copy:disabled {
            opacity: 0.4;
            cursor: not-allowed;
        }
        
        .status-dot {
            display: inline-block;
            width: 8px;
            height: 8px;
            border-radius: 50%;
            margin-right: 4px;
        }
        
        .status-dot.aman { background: #4CAF50; }
        .status-dot.menipis { background: #FF9800; }
        .status-dot.kosong { background: #f44336; }
        
        .stock-badge {
            font-size: 10px;
            padding: 2px 8px;
            border-radius: 10px;
            font-weight: 600;
        }
        
        .stock-badge.aman {
            background: #e8f5e9;
            color: #2e7d32;
        }
        
        .stock-badge.menipis {
            background: #fff3e0;
            color: #e65100;
        }
        
        .stock-badge.kosong {
            background: #ffebee;
            color: #c62828;
        }
        
        /* Search Box */
        .search-box {
            display: flex;
            gap: 8px;
            margin-bottom: 12px;
            flex-wrap: wrap;
        }
        
        .search-box input {
            flex: 1;
            padding: 10px 14px;
            border: 2px solid #e8ecf1;
            border-radius: var(--radius-sm);
            font-size: 14px;
            min-width: 150px;
            transition: var(--transition);
        }
        
        .search-box input:focus {
            border-color: var(--primary-light);
            outline: none;
            box-shadow: 0 0 0 3px rgba(76, 175, 80, 0.1);
        }
        
        .search-box .btn-search {
            padding: 10px 18px;
            background: var(--primary-light);
            color: white;
            border: none;
            border-radius: var(--radius-sm);
            cursor: pointer;
            font-weight: 600;
            transition: var(--transition);
        }
        
        .search-box .btn-search:hover {
            background: var(--primary-dark);
        }
        
        .search-box .btn-clear {
            padding: 10px 18px;
            background: #f44336;
            color: white;
            border: none;
            border-radius: var(--radius-sm);
            cursor: pointer;
            font-weight: 600;
            transition: var(--transition);
        }
        
        .search-box .btn-clear:hover {
            background: #d32f2f;
        }
        
        .search-info {
            font-size: 11px;
            color: var(--text-light);
            margin-bottom: 10px;
        }
        
        .search-info strong {
            color: var(--text);
        }
        
        /* Responsive */
        @media (max-width: 480px) {
            .product-list-card {
                flex-wrap: wrap;
                gap: 6px;
            }
            
            .product-list-card .product-stock-info {
                text-align: left;
                margin-right: 0;
                width: 100%;
            }
            
            .product-list-card .product-stock-info .stock-number {
                font-size: 15px;
            }
            
            .product-list-card .product-actions {
                width: 100%;
                justify-content: flex-end;
            }
            
            .barcode-preview .barcode-text {
                font-size: 16px;
                letter-spacing: 2px;
            }
            
            .search-box input {
                min-width: 100px;
                font-size: 13px;
            }
            
            .search-box .btn-search,
            .search-box .btn-clear {
                padding: 8px 12px;
                font-size: 12px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <header class="header">
            <a href="../index.php" class="back-btn"><i class="fas fa-arrow-left"></i></a>
            <h1><i class="fas fa-box"></i> Manajemen Produk</h1>
            <a href="notifikasi.php" class="btn-icon" style="position:relative;">
                <i class="fas fa-bell" style="font-size:18px;color:var(--text-light);"></i>
                <?php 
                $unread = $conn->query("SELECT COUNT(*) as total FROM notifikasi WHERE user_id = {$_SESSION['user_id']} AND is_read = 0");
                $unread_count = $unread->num_rows > 0 ? $unread->fetch_assoc()['total'] : 0;
                if ($unread_count > 0): 
                ?>
                <span class="badge-icon"><?php echo $unread_count; ?></span>
                <?php endif; ?>
            </a>
        </header>

        <main class="main-content">
            <?php echo $message; ?>
            
            <?php if (isset($_GET['success'])): ?>
            <div class="alert success"><i class="fas fa-check-circle"></i> Data berhasil disimpan!</div>
            <?php endif; ?>

            <!-- Form Produk -->
            <div class="form-card">
                <div class="form-header">
                    <h3><i class="fas fa-<?php echo $edit_data ? 'edit' : 'plus-circle'; ?>"></i> <?php echo $edit_data ? 'Edit Produk' : 'Tambah Produk Baru'; ?></h3>
                    <?php if ($edit_data): ?>
                    <span class="badge-status"><i class="fas fa-pencil-alt"></i> Mode Edit</span>
                    <?php endif; ?>
                </div>
                
                <?php if (!$edit_data): ?>
                <div style="font-size:11px;color:var(--text-light);margin-bottom:10px;background:#f5f5f5;padding:6px 12px;border-radius:6px;">
                    <i class="fas fa-info-circle" style="color:var(--primary-light);"></i> 
                    Kode produk akan digenerate otomatis: <strong><?php echo $kode_baru; ?></strong>
                </div>
                <?php endif; ?>
                
                <form method="POST" id="formProduk">
                    <input type="hidden" name="id" value="<?php echo $edit_data['id'] ?? 0; ?>">
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label><i class="fas fa-barcode"></i> Kode Produk</label>
                            <input type="text" name="kode_produk" id="kodeProduk" 
                                   value="<?php echo $edit_data['kode_produk'] ?? $kode_baru; ?>" 
                                   required class="form-control" 
                                   readonly
                                   style="background:#f0f7f0;font-weight:bold;color:#2E7D32;font-size:13px;">
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-qrcode"></i> Barcode Supplier</label>
                            <input type="text" name="barcode" id="barcode" 
                                   value="<?php echo $edit_data['barcode'] ?? ''; ?>" 
                                   class="form-control" 
                                   placeholder="Dari label supplier"
                                   style="font-family:'Courier New',monospace;letter-spacing:1px;"
                                   oninput="updateBarcodePreview()">
                            <div class="barcode-hint">
                                <i class="fas fa-info-circle"></i> 
                                <span>Kosongkan jika tidak ada barcode dari supplier</span>
                            </div>
                        </div>
                    </div>

                    <!-- Preview Barcode -->
                    <div class="barcode-preview" id="barcodePreviewContainer">
                        <span class="barcode-icon"><i class="fas fa-barcode"></i></span>
                        <span class="barcode-label">Preview Barcode:</span>
                        <span class="barcode-text" id="barcodePreview">
                            <?php 
                            $barcode_value = $edit_data['barcode'] ?? '';
                            if ($barcode_value): 
                                echo $barcode_value; 
                            else: 
                            ?>
                            <span class="barcode-empty">(Belum diisi)</span>
                            <?php endif; ?>
                        </span>
                        <button type="button" class="btn-action btn-copy" onclick="copyBarcode(document.getElementById('barcode').value || '(kosong)')" style="font-size:11px;padding:4px 12px;">
                            <i class="fas fa-copy"></i> Copy
                        </button>
                    </div>

                    <div class="form-group" style="margin-top:10px;">
                        <label><i class="fas fa-box"></i> Nama Produk</label>
                        <input type="text" name="nama_produk" value="<?php echo $edit_data['nama_produk'] ?? ''; ?>" required class="form-control" placeholder="Masukkan nama produk">
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label><i class="fas fa-tags"></i> Kategori</label>
                            <select name="kategori_id" class="form-control">
                                <option value="">-- Pilih Kategori --</option>
                                <?php
                                $kategori = $conn->query("SELECT * FROM kategori ORDER BY nama_kategori");
                                while ($row = $kategori->fetch_assoc()):
                                ?>
                                <option value="<?php echo $row['id']; ?>" <?php echo ($edit_data['kategori_id'] ?? 0) == $row['id'] ? 'selected' : ''; ?>>
                                    <?php echo $row['nama_kategori']; ?>
                                </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-truck"></i> Supplier</label>
                            <select name="supplier_id" class="form-control">
                                <option value="">-- Pilih Supplier --</option>
                                <?php
                                $supplier = $conn->query("SELECT * FROM supplier ORDER BY nama_supplier");
                                while ($row = $supplier->fetch_assoc()):
                                ?>
                                <option value="<?php echo $row['id']; ?>" <?php echo ($edit_data['supplier_id'] ?? 0) == $row['id'] ? 'selected' : ''; ?>>
                                    <?php echo $row['nama_supplier']; ?>
                                </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label><i class="fas fa-money-bill-wave"></i> Harga Beli</label>
                            <input type="number" name="harga_beli" value="<?php echo $edit_data['harga_beli'] ?? 0; ?>" required class="form-control" step="100" placeholder="0">
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-tag"></i> Harga Jual</label>
                            <input type="number" name="harga_jual" value="<?php echo $edit_data['harga_jual'] ?? 0; ?>" required class="form-control" step="100" placeholder="0">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label><i class="fas fa-cubes"></i> Stok Awal</label>
                            <input type="number" name="stok" value="<?php echo $edit_data['stok'] ?? 0; ?>" class="form-control" placeholder="0">
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-exclamation-triangle"></i> Stok Minimal</label>
                            <input type="number" name="stok_minimal" value="<?php echo $edit_data['stok_minimal'] ?? 5; ?>" class="form-control" placeholder="5">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label><i class="fas fa-ruler"></i> Satuan</label>
                            <input type="text" name="satuan" value="<?php echo $edit_data['satuan'] ?? 'Pcs'; ?>" class="form-control" placeholder="Pcs">
                        </div>
                        <div class="form-group" style="display:flex;align-items:flex-end;">
                            <button type="submit" class="btn-submit" style="margin-top:0;width:100%;">
                                <i class="fas fa-save"></i> <?php echo $edit_data ? 'Update Produk' : 'Simpan Produk'; ?>
                            </button>
                        </div>
                    </div>

                    <div class="form-group">
                        <label><i class="fas fa-align-left"></i> Deskripsi</label>
                        <textarea name="deskripsi" class="form-control" rows="2" placeholder="Deskripsi produk..."><?php echo $edit_data['deskripsi'] ?? ''; ?></textarea>
                    </div>
                </form>
            </div>

            <!-- Pencarian Produk -->
            <div class="section">
                <h3><i class="fas fa-search"></i> Cari Produk</h3>
                <div class="search-box">
                    <input type="text" id="searchInput" placeholder="🔍 Cari kode, barcode, nama, kategori, supplier..." 
                           value="<?php echo htmlspecialchars($search); ?>" 
                           onkeyup="if(event.key=='Enter') window.location.href='produk.php?search='+encodeURIComponent(this.value)">
                    <button class="btn-search" onclick="window.location.href='produk.php?search='+encodeURIComponent(document.getElementById('searchInput').value)">
                        <i class="fas fa-search"></i> Cari
                    </button>
                    <button class="btn-clear" onclick="window.location.href='produk.php'">
                        <i class="fas fa-times"></i> Reset
                    </button>
                </div>
                <div class="search-info">
                    <i class="fas fa-info-circle"></i> 
                    Total: <strong><?php echo $produk->num_rows; ?></strong> produk ditemukan
                    <?php if ($search): ?>
                    <span style="margin-left:10px;">
                        <i class="fas fa-filter"></i> Filter: "<strong><?php echo htmlspecialchars($search); ?></strong>"
                        <a href="produk.php" style="color:#f44336;margin-left:6px;text-decoration:none;">✕ Hapus</a>
                    </span>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Daftar Produk - Card View -->
            <div class="section" style="padding:10px 12px;">
                <h3><i class="fas fa-list"></i> Daftar Produk</h3>
                
                <?php if ($produk->num_rows > 0): ?>
                    <?php while ($row = $produk->fetch_assoc()): 
                        // Tentukan status stok
                        if ($row['stok'] <= 0) {
                            $status_stok = 'Kosong';
                            $status_class = 'kosong';
                            $dot_class = 'kosong';
                        } elseif ($row['stok'] <= $row['stok_minimal']) {
                            $status_stok = 'Menipis';
                            $status_class = 'menipis';
                            $dot_class = 'menipis';
                        } else {
                            $status_stok = 'Aman';
                            $status_class = 'aman';
                            $dot_class = 'aman';
                        }
                    ?>
                    <div class="product-list-card">
                        <div class="product-info-left">
                            <div class="product-name">
                                <?php echo $row['nama_produk']; ?>
                                <span class="stock-badge <?php echo $status_class; ?>" style="font-size:8px;margin-left:6px;">
                                    <span class="status-dot <?php echo $dot_class; ?>"></span>
                                    <?php echo $status_stok; ?>
                                </span>
                            </div>
                            <div class="product-meta">
                                <span><i class="fas fa-barcode"></i> <?php echo $row['kode_produk']; ?></span>
                                <?php if ($row['barcode']): ?>
                                <span class="barcode-tag"><i class="fas fa-qrcode"></i> <?php echo $row['barcode']; ?></span>
                                <?php endif; ?>
                                <span><i class="fas fa-tags"></i> <?php echo $row['nama_kategori'] ?? '-'; ?></span>
                                <span><i class="fas fa-truck"></i> <?php echo $row['nama_supplier'] ?? '-'; ?></span>
                                <span><i class="fas fa-tag"></i> <?php echo rupiah($row['harga_jual']); ?></span>
                            </div>
                        </div>
                        <div class="product-stock-info">
                            <div class="stock-number" style="color: <?php echo $row['stok'] <= $row['stok_minimal'] ? '#f44336' : '#4CAF50'; ?>;">
                                <?php echo $row['stok']; ?>
                            </div>
                            <div class="stock-label">Stok</div>
                        </div>
                        <div class="product-actions">
                            <a href="?edit=<?php echo $row['id']; ?>" class="btn-action btn-edit" title="Edit">
                                <i class="fas fa-edit"></i>
                            </a>
                            <a href="?delete=<?php echo $row['id']; ?>" onclick="return confirm('Yakin hapus produk ini?')" class="btn-action btn-delete" title="Hapus">
                                <i class="fas fa-trash"></i>
                            </a>
                            <?php if ($row['barcode']): ?>
                            <button onclick="copyBarcode('<?php echo $row['barcode']; ?>')" class="btn-action btn-copy" title="Copy Barcode">
                                <i class="fas fa-copy"></i>
                            </button>
                            <?php else: ?>
                            <button class="btn-action btn-copy" disabled title="Tidak ada barcode" style="opacity:0.4;cursor:not-allowed;">
                                <i class="fas fa-copy"></i>
                            </button>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div style="text-align:center;padding:30px 10px;color:var(--text-light);">
                        <i class="fas fa-box-open" style="font-size:40px;display:block;margin-bottom:10px;color:#ddd;"></i>
                        <p><?php echo $search ? 'Produk tidak ditemukan' : 'Belum ada produk. Silakan tambahkan produk pertama!'; ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </main>

        <!-- Bottom Navigation -->
        <nav class="bottom-nav">
            <a href="../index.php"><i class="fas fa-home"></i><span>Dashboard</span></a>
            <a href="penjualan.php"><i class="fas fa-cash-register"></i><span>Kasir</span></a>
            <a href="pembelian.php"><i class="fas fa-truck"></i><span>Beli</span></a>
            <a href="produk.php" class="active"><i class="fas fa-box"></i><span>Produk</span></a>
            <a href="../laporan/laba_rugi.php"><i class="fas fa-chart-bar"></i><span>Laporan</span></a>
        </nav>
    </div>

    <script>
        // ============================================
        // UPDATE PREVIEW BARCODE
        // ============================================
        function updateBarcodePreview() {
            const barcodeInput = document.getElementById('barcode');
            const barcodePreview = document.getElementById('barcodePreview');
            const value = barcodeInput.value.trim();
            
            if (value) {
                barcodePreview.innerHTML = value;
                barcodePreview.className = 'barcode-text';
            } else {
                barcodePreview.innerHTML = '<span class="barcode-empty">(Belum diisi)</span>';
                barcodePreview.className = 'barcode-text';
            }
        }

        // ============================================
        // COPY BARCODE
        // ============================================
        function copyBarcode(barcode) {
            if (!barcode || barcode === '(kosong)') {
                showToast('⚠️ Barcode kosong, tidak ada yang bisa di-copy');
                return;
            }
            
            if (navigator.clipboard) {
                navigator.clipboard.writeText(barcode).then(function() {
                    showToast('✅ Barcode copied: ' + barcode);
                }).catch(function() {
                    copyBarcodeFallback(barcode);
                });
            } else {
                copyBarcodeFallback(barcode);
            }
        }

        function copyBarcodeFallback(barcode) {
            const textarea = document.createElement('textarea');
            textarea.value = barcode;
            document.body.appendChild(textarea);
            textarea.select();
            document.execCommand('copy');
            document.body.removeChild(textarea);
            showToast('✅ Barcode copied: ' + barcode);
        }

        // ============================================
        // SHOW TOAST NOTIFICATION
        // ============================================
        function showToast(message) {
            const oldToast = document.querySelector('.toast-notification');
            if (oldToast) oldToast.remove();
            
            const toast = document.createElement('div');
            toast.className = 'toast-notification';
            toast.style.cssText = `
                position: fixed;
                bottom: 80px;
                left: 50%;
                transform: translateX(-50%);
                background: #333;
                color: white;
                padding: 10px 20px;
                border-radius: 8px;
                z-index: 9999;
                font-size: 13px;
                box-shadow: 0 4px 12px rgba(0,0,0,0.3);
                animation: fadeInUp 0.3s ease;
                max-width: 90%;
                text-align: center;
            `;
            toast.textContent = message;
            document.body.appendChild(toast);
            
            setTimeout(function() {
                toast.style.transition = 'opacity 0.5s';
                toast.style.opacity = '0';
                setTimeout(function() {
                    toast.remove();
                }, 500);
            }, 2000);
        }

        // ============================================
        // AUTO-HIDE ALERT
        // ============================================
        document.addEventListener('DOMContentLoaded', function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(function(alert) {
                setTimeout(function() {
                    alert.style.transition = 'opacity 0.5s';
                    alert.style.opacity = '0';
                    setTimeout(function() {
                        alert.style.display = 'none';
                    }, 500);
                }, 5000);
            });
        });

        // ============================================
        // CSS UNTUK TOAST
        // ============================================
        const style = document.createElement('style');
        style.textContent = `
            @keyframes fadeInUp {
                from {
                    opacity: 0;
                    transform: translateX(-50%) translateY(20px);
                }
                to {
                    opacity: 1;
                    transform: translateX(-50%) translateY(0);
                }
            }
        `;
        document.head.appendChild(style);
    </script>
    <script src="../js/script.js"></script>
</body>
</html>