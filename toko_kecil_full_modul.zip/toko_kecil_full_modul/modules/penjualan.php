<?php
include '../config/database.php';

$message = '';
$product = null;

// Ambil data produk jika ada ID
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $result = $conn->query("SELECT * FROM produk WHERE id = $id");
    $product = $result->fetch_assoc();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $produk_id = $_POST['produk_id'];
    $jumlah = $_POST['jumlah'];
    $harga_jual = $_POST['harga_jual'];
    $diskon = $_POST['diskon'] ?? 0;
    $total = $jumlah * $harga_jual - $diskon;
    $pelanggan = $_POST['pelanggan'] ?? 'Umum';
    $metode = $_POST['metode_pembayaran'] ?? 'tunai';
    $tanggal = $_POST['tanggal'];
    $no_invoice = generateInvoice();

    $stmt = $conn->prepare("
        INSERT INTO penjualan 
        (no_invoice, user_id, produk_id, jumlah, harga_jual_saat, total_penjualan, diskon, total_bayar, tanggal_penjualan, pelanggan, metode_pembayaran, status) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'selesai')
    ");
    $stmt->bind_param("siiddddsss", $no_invoice, $_SESSION['user_id'], $produk_id, $jumlah, $harga_jual, $total, $diskon, $total, $tanggal, $pelanggan, $metode);

    if ($stmt->execute()) {
        logActivity($conn, $_SESSION['user_id'], 'Penjualan', "Invoice: $no_invoice, Produk ID: $produk_id, Jumlah: $jumlah");
        $message = '<div class="alert success"><i class="fas fa-check-circle"></i> Penjualan berhasil! Invoice: ' . $no_invoice . '</div>';
        echo '<script>document.getElementById("formPenjualan").reset(); document.getElementById("totalDisplay").textContent = "Rp 0";</script>';
    } else {
        $message = '<div class="alert error"><i class="fas fa-exclamation-circle"></i> Gagal: ' . $conn->error . '</div>';
    }
}

// Ambil daftar produk untuk ditampilkan
$produk_list = $conn->query("SELECT * FROM produk WHERE stok > 0 ORDER BY nama_produk LIMIT 20");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Kasir - Toko Kecil</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* ============================================
           KASIR PAGE STYLES
           ============================================ */
        .kasir-header {
            background: linear-gradient(135deg, #1B5E20 0%, #4CAF50 100%);
            color: white;
            padding: 14px 18px;
            border-radius: var(--radius);
            margin-bottom: 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        
        .kasir-header .kasir-title {
            font-size: 18px;
            font-weight: 700;
        }
        
        .kasir-header .kasir-title i {
            margin-right: 8px;
        }
        
        .kasir-header .kasir-date {
            font-size: 12px;
            opacity: 0.9;
            background: rgba(255,255,255,0.15);
            padding: 4px 12px;
            border-radius: 20px;
        }
        
        /* Search */
        .search-container {
            position: relative;
            margin-bottom: 16px;
        }
        
        .search-container input {
            width: 100%;
            padding: 12px 16px 12px 44px;
            border: 2px solid #e8ecf1;
            border-radius: var(--radius-sm);
            font-size: 15px;
            transition: var(--transition);
            background: white;
        }
        
        .search-container input:focus {
            border-color: var(--primary-light);
            outline: none;
            box-shadow: 0 0 0 4px rgba(76, 175, 80, 0.1);
        }
        
        .search-container .search-icon {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-light);
            font-size: 16px;
        }
        
        .search-hint {
            font-size: 11px;
            color: var(--text-light);
            display: flex;
            align-items: center;
            gap: 6px;
            margin-top: 4px;
        }
        
        .search-hint i {
            color: #FF9800;
        }
        
        /* Search Results */
        .search-results {
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: white;
            border-radius: 0 0 var(--radius-sm) var(--radius-sm);
            box-shadow: 0 8px 24px rgba(0,0,0,0.15);
            max-height: 320px;
            overflow-y: auto;
            z-index: 1000;
            display: none;
        }
        
        .search-results.show {
            display: block;
        }
        
        .search-results .result-item {
            padding: 10px 14px;
            border-bottom: 1px solid #f0f2f5;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: var(--transition);
        }
        
        .search-results .result-item:hover {
            background: #f5f5f5;
        }
        
        .search-results .result-item:active {
            background: #e8f5e9;
        }
        
        .search-results .result-item .product-name {
            font-weight: 600;
            font-size: 14px;
        }
        
        .search-results .result-item .product-info {
            font-size: 11px;
            color: var(--text-light);
        }
        
        .search-results .result-item .product-barcode {
            font-size: 11px;
            color: #FF9800;
            font-family: 'Courier New', monospace;
        }
        
        .search-results .result-item .product-price {
            color: var(--primary-light);
            font-weight: 700;
            font-size: 15px;
        }
        
        .search-results .result-item .match-tag {
            font-size: 9px;
            padding: 2px 8px;
            border-radius: 10px;
            background: #e3f2fd;
            color: #0d47a1;
            margin-left: 6px;
        }
        
        /* Selected Product Display */
        .selected-product {
            background: #f0f7f0;
            border: 2px solid #a5d6a7;
            border-radius: var(--radius-sm);
            padding: 12px 14px;
            margin-bottom: 14px;
            display: none;
        }
        
        .selected-product.show {
            display: block;
        }
        
        .selected-product .selected-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 4px;
        }
        
        .selected-product .selected-header .selected-name {
            font-weight: 700;
            font-size: 15px;
            color: var(--primary-dark);
        }
        
        .selected-product .selected-header .selected-code {
            font-size: 11px;
            color: var(--text-light);
            font-family: 'Courier New', monospace;
        }
        
        .selected-product .selected-details {
            display: flex;
            gap: 16px;
            font-size: 12px;
            color: var(--text-light);
            flex-wrap: wrap;
        }
        
        .selected-product .selected-details span i {
            margin-right: 4px;
            color: var(--primary-light);
        }
        
        /* Form */
        .form-card-kasir {
            background: var(--card-bg);
            border-radius: var(--radius);
            padding: 16px 14px;
            margin-bottom: 16px;
            box-shadow: var(--shadow);
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }
        
        .form-group {
            margin-bottom: 10px;
        }
        
        .form-group label {
            display: block;
            font-size: 12px;
            font-weight: 600;
            margin-bottom: 4px;
            color: var(--text-light);
        }
        
        .form-group label i {
            margin-right: 4px;
            color: var(--primary-light);
        }
        
        .form-control {
            width: 100%;
            padding: 10px 12px;
            border: 2px solid #e8ecf1;
            border-radius: var(--radius-sm);
            font-size: 14px;
            background: #fafbfc;
            transition: var(--transition);
            font-family: inherit;
            color: var(--text);
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--primary-light);
            background: white;
            box-shadow: 0 0 0 3px rgba(76, 175, 80, 0.1);
        }
        
        .form-control[readonly] {
            background: #f0f2f5;
            cursor: not-allowed;
        }
        
        .total-display-kasir {
            background: linear-gradient(135deg, #e8f5e9 0%, #c8e6c9 100%);
            padding: 14px 18px;
            border-radius: var(--radius-sm);
            display: flex;
            justify-content: space-between;
            font-weight: 700;
            font-size: 16px;
            margin: 10px 0 14px 0;
            border: 2px solid #a5d6a7;
        }
        
        .total-display-kasir span:last-child {
            color: var(--primary-dark);
            font-size: 22px;
        }
        
        .btn-submit-kasir {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #1B5E20 0%, #4CAF50 100%);
            color: white;
            border: none;
            border-radius: var(--radius-sm);
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            transition: var(--transition);
        }
        
        .btn-submit-kasir:active {
            transform: scale(0.97);
        }
        
        .btn-submit-kasir:hover {
            opacity: 0.9;
            box-shadow: 0 4px 16px rgba(76, 175, 80, 0.3);
        }
        
        .btn-submit-kasir:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        
        /* Quick Products */
        .product-grid-custom {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(80px, 1fr));
            gap: 8px;
            margin-top: 10px;
        }
        
        .product-item {
            background: white;
            border: 2px solid #e8ecf1;
            border-radius: var(--radius-sm);
            padding: 10px 6px;
            text-align: center;
            cursor: pointer;
            transition: var(--transition);
        }
        
        .product-item:hover {
            border-color: var(--primary-light);
            background: #f5f5f5;
        }
        
        .product-item:active {
            transform: scale(0.95);
        }
        
        .product-item .p-name {
            font-size: 10px;
            font-weight: 500;
            display: block;
            line-height: 1.2;
        }
        
        .product-item .p-price {
            font-size: 11px;
            color: var(--primary-light);
            font-weight: 700;
        }
        
        .product-item .p-stock {
            font-size: 9px;
            color: var(--text-light);
        }
        
        /* Quick Actions */
        .quick-actions-kasir {
            display: flex;
            gap: 8px;
            margin-bottom: 16px;
            flex-wrap: wrap;
        }
        
        .quick-actions-kasir .btn-quick {
            padding: 8px 14px;
            border: none;
            border-radius: var(--radius-sm);
            cursor: pointer;
            font-weight: 600;
            font-size: 12px;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 6px;
            text-decoration: none;
            color: white;
        }
        
        .quick-actions-kasir .btn-quick:active {
            transform: scale(0.95);
        }
        
        .quick-actions-kasir .btn-quick.batal {
            background: #f44336;
        }
        
        .quick-actions-kasir .btn-quick.batal:hover {
            background: #d32f2f;
        }
        
        .quick-actions-kasir .btn-quick.reset {
            background: #FF9800;
        }
        
        .quick-actions-kasir .btn-quick.reset:hover {
            background: #e68900;
        }
        
        .quick-actions-kasir .btn-quick.pelanggan {
            background: #9C27B0;
        }
        
        .quick-actions-kasir .btn-quick.pelanggan:hover {
            background: #7B1FA2;
        }
        
        /* Responsive */
        @media (max-width: 480px) {
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .product-grid-custom {
                grid-template-columns: repeat(3, 1fr);
            }
            
            .kasir-header {
                flex-direction: column;
                text-align: center;
                gap: 4px;
            }
            
            .product-item {
                padding: 8px 4px;
            }
            
            .product-item .p-name {
                font-size: 9px;
            }
            
            .product-item .p-price {
                font-size: 10px;
            }
            
            .total-display-kasir {
                font-size: 14px;
            }
            
            .total-display-kasir span:last-child {
                font-size: 18px;
            }
        }
        
        @media (min-width: 768px) {
            .product-grid-custom {
                grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <header class="header">
            <a href="../index.php" class="back-btn"><i class="fas fa-arrow-left"></i></a>
            <h1><i class="fas fa-cash-register"></i> Kasir</h1>
            <a href="notifikasi.php" class="btn-icon" style="position:relative;">
                <i class="fas fa-bell" style="font-size:18px;color:var(--text-light);"></i>
                <?php 
                $unread = $conn->query("SELECT COUNT(*) as total FROM notifikasi WHERE user_id = {$_SESSION['user_id']} AND is_read = 0");
                $unread_count = $unread->num_rows > 0 ? $unread->fetch_assoc()['total'] : 0;
                if ($unread_count > 0): 
                ?>
                <span class="badge-icon"><?php echo $unread_count; ?></span>
                <?php endif; ?>
            </a>
        </header>

        <!-- Kasir Header -->
        <div class="kasir-header">
            <div class="kasir-title">
                <i class="fas fa-shopping-cart"></i> Transaksi Penjualan
            </div>
            <div class="kasir-date">
                <i class="fas fa-calendar-alt"></i> <?php echo date('l, d F Y'); ?>
            </div>
        </div>

        <main class="main-content">
            <?php echo $message; ?>

            <!-- Pencarian Produk -->
            <div class="search-container">
                <span class="search-icon"><i class="fas fa-search"></i></span>
                <input type="text" id="searchProduk" placeholder="Cari produk... (kode, barcode, nama)" autocomplete="off">
                <div class="search-hint">
                    <i class="fas fa-qrcode"></i> 
                    <span>Bisa scan barcode supplier langsung</span>
                </div>
                <div id="searchResults" class="search-results"></div>
            </div>

            <!-- Selected Product -->
            <div class="selected-product" id="selectedProduct">
                <div class="selected-header">
                    <span class="selected-name" id="selectedNama">-</span>
                    <span class="selected-code" id="selectedKode">-</span>
                </div>
                <div class="selected-details">
                    <span><i class="fas fa-tag"></i> Harga: <strong id="selectedHarga">Rp 0</strong></span>
                    <span><i class="fas fa-cubes"></i> Stok: <strong id="selectedStok">0</strong></span>
                    <?php if ($product): ?>
                    <span><i class="fas fa-qrcode"></i> Barcode: <strong id="selectedBarcode"><?php echo $product['barcode'] ?? '-'; ?></strong></span>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Form Penjualan -->
            <form method="POST" id="formPenjualan" class="form-card-kasir">
                <input type="hidden" name="produk_id" id="produkId">
                
                <div class="form-row">
                    <div class="form-group">
                        <label><i class="fas fa-barcode"></i> Kode Produk</label>
                        <input type="text" id="kodeProduk" readonly class="form-control" placeholder="Pilih produk di atas">
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-qrcode"></i> Barcode Supplier</label>
                        <input type="text" id="barcodeSupplier" readonly class="form-control" placeholder="Dari label supplier">
                    </div>
                </div>

                <div class="form-group">
                    <label><i class="fas fa-box"></i> Nama Produk</label>
                    <input type="text" id="namaProduk" readonly class="form-control" placeholder="Pilih produk di atas">
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label><i class="fas fa-tag"></i> Harga Jual</label>
                        <input type="number" name="harga_jual" id="hargaJual" required class="form-control" placeholder="0" step="100" readonly>
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-cubes"></i> Stok</label>
                        <input type="number" id="stok" readonly class="form-control" placeholder="0">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label><i class="fas fa-hashtag"></i> Jumlah</label>
                        <input type="number" name="jumlah" id="jumlah" min="1" required class="form-control" placeholder="0" oninput="hitungTotal()">
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-percent"></i> Diskon (Rp)</label>
                        <input type="number" name="diskon" id="diskon" min="0" class="form-control" placeholder="0" oninput="hitungTotal()">
                    </div>
                </div>

                <div class="form-group">
                    <label><i class="fas fa-user"></i> Pelanggan</label>
                    <input type="text" name="pelanggan" class="form-control" placeholder="Nama pelanggan (opsional)">
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label><i class="fas fa-credit-card"></i> Metode Pembayaran</label>
                        <select name="metode_pembayaran" class="form-control">
                            <option value="tunai">💵 Tunai</option>
                            <option value="transfer">🏦 Transfer</option>
                            <option value="qris">📱 QRIS</option>
                            <option value="credit_card">💳 Kartu Kredit</option>
                            <option value="debit">💳 Kartu Debit</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-calendar"></i> Tanggal</label>
                        <input type="date" name="tanggal" value="<?php echo date('Y-m-d'); ?>" required class="form-control">
                    </div>
                </div>

                <div class="total-display-kasir">
                    <span>💰 Total Bayar</span>
                    <span id="totalDisplay">Rp 0</span>
                </div>

                <button type="submit" class="btn-submit-kasir" id="btnSubmit">
                    <i class="fas fa-save"></i> Proses Penjualan
                </button>
            </form>

            <!-- Quick Actions -->
            <div class="quick-actions-kasir">
                <button class="btn-quick batal" onclick="resetForm()">
                    <i class="fas fa-times"></i> Batal
                </button>
                <button class="btn-quick reset" onclick="resetForm()">
                    <i class="fas fa-undo"></i> Reset
                </button>
                <a href="pelanggan.php" class="btn-quick pelanggan">
                    <i class="fas fa-users"></i> Kelola Pelanggan
                </a>
            </div>

            <!-- Daftar Produk Cepat -->
            <div class="section">
                <h3><i class="fas fa-boxes"></i> Pilih Produk Cepat</h3>
                <div class="product-grid-custom">
                    <?php while ($row = $produk_list->fetch_assoc()): ?>
                    <div class="product-item" onclick="pilihProduk(<?php echo $row['id']; ?>, '<?php echo $row['kode_produk']; ?>', '<?php echo addslashes($row['nama_produk']); ?>', <?php echo $row['harga_jual']; ?>, <?php echo $row['stok']; ?>, '<?php echo $row['barcode'] ?? ''; ?>')">
                        <span class="p-name"><?php echo substr($row['nama_produk'], 0, 20); ?></span>
                        <span class="p-price"><?php echo rupiah($row['harga_jual']); ?></span>
                        <span class="p-stock">Stok: <?php echo $row['stok']; ?></span>
                    </div>
                    <?php endwhile; ?>
                </div>
            </div>
        </main>

        <!-- Bottom Navigation -->
        <nav class="bottom-nav">
            <a href="../index.php"><i class="fas fa-home"></i><span>Dashboard</span></a>
            <a href="penjualan.php" class="active"><i class="fas fa-cash-register"></i><span>Kasir</span></a>
            <a href="pembelian.php"><i class="fas fa-truck"></i><span>Beli</span></a>
            <a href="produk.php"><i class="fas fa-box"></i><span>Produk</span></a>
            <a href="../laporan/laba_rugi.php"><i class="fas fa-chart-bar"></i><span>Laporan</span></a>
        </nav>
    </div>

    <script>
        // ============================================
        // FUNGSI PILIH PRODUK
        // ============================================
        function pilihProduk(id, kode, nama, harga, stok, barcode) {
            document.getElementById('produkId').value = id;
            document.getElementById('kodeProduk').value = kode;
            document.getElementById('namaProduk').value = nama;
            document.getElementById('hargaJual').value = harga;
            document.getElementById('stok').value = stok;
            document.getElementById('barcodeSupplier').value = barcode || '(kosong)';
            document.getElementById('jumlah').value = 1;
            document.getElementById('diskon').value = 0;
            
            // Tampilkan selected product
            document.getElementById('selectedNama').textContent = nama;
            document.getElementById('selectedKode').textContent = kode;
            document.getElementById('selectedHarga').textContent = 'Rp ' + harga.toLocaleString('id-ID');
            document.getElementById('selectedStok').textContent = stok;
            document.getElementById('selectedBarcode').textContent = barcode || '-';
            document.getElementById('selectedProduct').classList.add('show');
            
            // Sembunyikan hasil pencarian
            document.getElementById('searchResults').classList.remove('show');
            document.getElementById('searchProduk').value = '';
            
            // Hitung total
            hitungTotal();
        }

        // ============================================
        // FUNGSI HITUNG TOTAL
        // ============================================
        function hitungTotal() {
            const jumlah = parseInt(document.getElementById('jumlah').value) || 0;
            const harga = parseInt(document.getElementById('hargaJual').value) || 0;
            const diskon = parseInt(document.getElementById('diskon').value) || 0;
            const total = (jumlah * harga) - diskon;
            
            document.getElementById('totalDisplay').textContent = 'Rp ' + total.toLocaleString('id-ID');
            
            // Validasi stok
            const stok = parseInt(document.getElementById('stok').value) || 0;
            const btnSubmit = document.getElementById('btnSubmit');
            
            if (jumlah > stok && stok > 0) {
                document.getElementById('totalDisplay').style.color = '#f44336';
                btnSubmit.disabled = true;
                btnSubmit.style.opacity = '0.5';
                btnSubmit.innerHTML = '<i class="fas fa-exclamation-circle"></i> Stok Tidak Cukup!';
            } else {
                document.getElementById('totalDisplay').style.color = '';
                btnSubmit.disabled = false;
                btnSubmit.style.opacity = '1';
                btnSubmit.innerHTML = '<i class="fas fa-save"></i> Proses Penjualan';
            }
        }

        // ============================================
        // RESET FORM
        // ============================================
        function resetForm() {
            document.getElementById('formPenjualan').reset();
            document.getElementById('totalDisplay').textContent = 'Rp 0';
            document.getElementById('selectedProduct').classList.remove('show');
            document.getElementById('kodeProduk').value = '';
            document.getElementById('namaProduk').value = '';
            document.getElementById('hargaJual').value = '';
            document.getElementById('stok').value = '';
            document.getElementById('barcodeSupplier').value = '';
            document.getElementById('produkId').value = '';
            document.getElementById('searchProduk').value = '';
            document.getElementById('searchResults').classList.remove('show');
            document.getElementById('totalDisplay').style.color = '';
            document.getElementById('btnSubmit').disabled = false;
            document.getElementById('btnSubmit').style.opacity = '1';
            document.getElementById('btnSubmit').innerHTML = '<i class="fas fa-save"></i> Proses Penjualan';
        }

        // ============================================
        // PENCARIAN PRODUK (Live Search)
        // ============================================
        const searchInput = document.getElementById('searchProduk');
        const searchResults = document.getElementById('searchResults');
        let searchTimeout;

        searchInput.addEventListener('input', function(e) {
            const keyword = this.value.trim();
            
            clearTimeout(searchTimeout);
            
            if (keyword.length < 1) {
                searchResults.classList.remove('show');
                return;
            }
            
            searchTimeout = setTimeout(function() {
                fetch('../config/search.php?q=' + encodeURIComponent(keyword))
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok: ' + response.status);
                        }
                        return response.json();
                    })
                    .then(data => {
                        let html = '';
                        if (data.length > 0) {
                            data.forEach(function(p) {
                                let matchTag = '';
                                if (p.barcode && p.barcode.toLowerCase().includes(keyword.toLowerCase())) {
                                    matchTag = '<span class="match-tag">📱 Barcode</span>';
                                } else if (p.kode_produk.toLowerCase().includes(keyword.toLowerCase())) {
                                    matchTag = '<span class="match-tag">🏷️ Kode</span>';
                                } else if (p.nama_produk.toLowerCase().includes(keyword.toLowerCase())) {
                                    matchTag = '<span class="match-tag">📦 Nama</span>';
                                }
                                
                                html += `
                                    <div class="result-item" onclick="pilihProduk(${p.id}, '${p.kode_produk}', '${p.nama_produk}', ${p.harga_jual}, ${p.stok}, '${p.barcode || ''}')">
                                        <div>
                                            <div class="product-name">${p.nama_produk} ${matchTag}</div>
                                            <div class="product-info">
                                                ${p.kode_produk} 
                                                ${p.barcode ? '| <span class="product-barcode">📱 ' + p.barcode + '</span>' : ''}
                                                | Stok: ${p.stok} ${p.satuan || 'Pcs'}
                                            </div>
                                        </div>
                                        <div class="product-price">${formatRupiah(p.harga_jual)}</div>
                                    </div>
                                `;
                            });
                        } else {
                            html = `<div style="padding:16px;text-align:center;color:var(--text-light);">
                                <i class="fas fa-search"></i> Produk tidak ditemukan
                            </div>`;
                        }
                        searchResults.innerHTML = html;
                        searchResults.classList.add('show');
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        searchResults.innerHTML = `<div style="padding:16px;text-align:center;color:#f44336;">
                            <i class="fas fa-exclamation-circle"></i> Gagal memuat data
                        </div>`;
                        searchResults.classList.add('show');
                    });
            }, 300);
        });

        // Enter key - pilih hasil pertama
        searchInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                const firstResult = searchResults.querySelector('.result-item');
                if (firstResult) {
                    firstResult.click();
                }
            }
        });

        // Sembunyikan hasil saat klik di luar
        document.addEventListener('click', function(e) {
            if (!searchInput.contains(e.target) && !searchResults.contains(e.target)) {
                searchResults.classList.remove('show');
            }
        });

        // ============================================
        // FORMAT RUPIAH
        // ============================================
        function formatRupiah(angka) {
            return 'Rp ' + Number(angka).toLocaleString('id-ID');
        }

        // ============================================
        // EVENT LISTENERS
        // ============================================
        document.getElementById('jumlah').addEventListener('input', hitungTotal);
        document.getElementById('diskon').addEventListener('input', hitungTotal);

        // ============================================
        // SHORTCUT: Fokus ke pencarian dengan Ctrl+F
        // ============================================
        document.addEventListener('keydown', function(e) {
            if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
                e.preventDefault();
                document.getElementById('searchProduk').focus();
            }
        });

        // ============================================
        // AUTO-HIDE ALERT
        // ============================================
        document.addEventListener('DOMContentLoaded', function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(function(alert) {
                setTimeout(function() {
                    alert.style.transition = 'opacity 0.5s';
                    alert.style.opacity = '0';
                    setTimeout(function() {
                        alert.style.display = 'none';
                    }, 500);
                }, 5000);
            });
        });
    </script>
    <script src="../js/script.js"></script>
</body>
</html>