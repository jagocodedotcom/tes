<?php
include '../config/database.php';

$message = '';
$invoice_data = null;

// Cek jika ada parameter invoice
if (isset($_GET['invoice'])) {
    $no_po = $_GET['invoice'];
    $result = $conn->query("
        SELECT pbl.*, 
               pr.nama_produk, pr.kode_produk, pr.satuan,
               s.nama_supplier, s.alamat as supplier_alamat, s.no_telp as supplier_telp,
               u.nama_lengkap as kasir
        FROM pembelian pbl
        JOIN produk pr ON pbl.produk_id = pr.id
        LEFT JOIN supplier s ON pbl.supplier_id = s.id
        LEFT JOIN users u ON pbl.user_id = u.id
        WHERE pbl.no_po = '$no_po'
    ");
    $invoice_data = $result->fetch_assoc();
}

// Proses pembelian
if ($_SERVER['REQUEST_METHOD'] == 'POST' && !isset($_POST['print'])) {
    $produk_id = $_POST['produk_id'];
    $supplier_id = $_POST['supplier_id'] ?: null;
    $jumlah = $_POST['jumlah'];
    $harga_beli = $_POST['harga_beli'];
    $diskon = $_POST['diskon'] ?? 0;
    $total_harga = ($jumlah * $harga_beli) - $diskon;
    $tanggal = $_POST['tanggal'];
    $no_po = generatePO();

    $stmt = $conn->prepare("
        INSERT INTO pembelian (no_po, user_id, produk_id, supplier_id, jumlah, harga_beli_saat, total_harga, diskon, total_bayar, tanggal_pembelian, status) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'selesai')
    ");
    $stmt->bind_param("siiiddddds", $no_po, $_SESSION['user_id'], $produk_id, $supplier_id, 
        $jumlah, $harga_beli, $total_harga, $diskon, $total_harga, $tanggal);

    if ($stmt->execute()) {
        // Update harga beli produk
        $conn->query("UPDATE produk SET harga_beli = $harga_beli WHERE id = $produk_id");
        logActivity($conn, $_SESSION['user_id'], 'Pembelian', "PO: $no_po, Produk ID: $produk_id, Jumlah: $jumlah");
        
        echo '<script>window.location.href = "pembelian.php?invoice=' . $no_po . '";</script>';
        exit();
    } else {
        $message = '<div class="alert error"><i class="fas fa-exclamation-circle"></i> Gagal: ' . $conn->error . '</div>';
    }
}

// Ambil data untuk form
$produk = $conn->query("SELECT * FROM produk ORDER BY nama_produk");
$supplier = $conn->query("SELECT * FROM supplier ORDER BY nama_supplier");
$riwayat = $conn->query("
    SELECT pbl.*, pr.nama_produk, s.nama_supplier 
    FROM pembelian pbl 
    JOIN produk pr ON pbl.produk_id = pr.id 
    LEFT JOIN supplier s ON pbl.supplier_id = s.id 
    ORDER BY pbl.created_at DESC 
    LIMIT 20
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Pembelian - Toko Kecil</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* ============================================
           PEMBELIAN PAGE STYLES
           ============================================ */
        .pembelian-header {
            background: linear-gradient(135deg, #E65100 0%, #FF9800 100%);
            color: white;
            padding: 14px 18px;
            border-radius: var(--radius);
            margin-bottom: 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        
        .pembelian-header .pembelian-title {
            font-size: 18px;
            font-weight: 700;
        }
        
        .pembelian-header .pembelian-title i {
            margin-right: 8px;
        }
        
        .pembelian-header .pembelian-date {
            font-size: 12px;
            opacity: 0.9;
            background: rgba(255,255,255,0.15);
            padding: 4px 12px;
            border-radius: 20px;
        }
        
        /* Selected Product */
        .selected-product {
            background: #fff3e0;
            border: 2px solid #ffcc80;
            border-radius: var(--radius-sm);
            padding: 12px 14px;
            margin-bottom: 14px;
            display: none;
        }
        
        .selected-product.show {
            display: block;
        }
        
        .selected-product .selected-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 4px;
        }
        
        .selected-product .selected-header .selected-name {
            font-weight: 700;
            font-size: 15px;
            color: #E65100;
        }
        
        .selected-product .selected-header .selected-code {
            font-size: 11px;
            color: var(--text-light);
            font-family: 'Courier New', monospace;
        }
        
        .selected-product .selected-details {
            display: flex;
            gap: 16px;
            font-size: 12px;
            color: var(--text-light);
            flex-wrap: wrap;
        }
        
        .selected-product .selected-details span i {
            margin-right: 4px;
            color: #FF9800;
        }
        
        /* Form */
        .form-card-pembelian {
            background: var(--card-bg);
            border-radius: var(--radius);
            padding: 16px 14px;
            margin-bottom: 16px;
            box-shadow: var(--shadow);
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }
        
        .form-group {
            margin-bottom: 10px;
        }
        
        .form-group label {
            display: block;
            font-size: 12px;
            font-weight: 600;
            margin-bottom: 4px;
            color: var(--text-light);
        }
        
        .form-group label i {
            margin-right: 4px;
            color: #FF9800;
        }
        
        .form-control {
            width: 100%;
            padding: 10px 12px;
            border: 2px solid #e8ecf1;
            border-radius: var(--radius-sm);
            font-size: 14px;
            background: #fafbfc;
            transition: var(--transition);
            font-family: inherit;
            color: var(--text);
        }
        
        .form-control:focus {
            outline: none;
            border-color: #FF9800;
            background: white;
            box-shadow: 0 0 0 3px rgba(255, 152, 0, 0.1);
        }
        
        .form-control[readonly] {
            background: #f0f2f5;
            cursor: not-allowed;
        }
        
        .total-display-pembelian {
            background: linear-gradient(135deg, #fff3e0 0%, #ffe0b2 100%);
            padding: 14px 18px;
            border-radius: var(--radius-sm);
            display: flex;
            justify-content: space-between;
            font-weight: 700;
            font-size: 16px;
            margin: 10px 0 14px 0;
            border: 2px solid #ffcc80;
        }
        
        .total-display-pembelian span:last-child {
            color: #E65100;
            font-size: 22px;
        }
        
        .btn-submit-pembelian {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #E65100 0%, #FF9800 100%);
            color: white;
            border: none;
            border-radius: var(--radius-sm);
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            transition: var(--transition);
        }
        
        .btn-submit-pembelian:active {
            transform: scale(0.97);
        }
        
        .btn-submit-pembelian:hover {
            opacity: 0.9;
            box-shadow: 0 4px 16px rgba(255, 152, 0, 0.3);
        }
        
        /* Invoice */
        .invoice-container {
            background: white;
            border-radius: var(--radius);
            box-shadow: var(--shadow-hover);
            padding: 24px 20px;
            margin-bottom: 20px;
        }
        
        .invoice-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            border-bottom: 3px double #FF9800;
            padding-bottom: 16px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        
        .invoice-header .company-info h2 {
            color: #E65100;
            font-size: 22px;
            margin: 0;
        }
        
        .invoice-header .company-info p {
            margin: 4px 0;
            color: #666;
            font-size: 13px;
        }
        
        .invoice-header .invoice-info {
            text-align: right;
        }
        
        .invoice-header .invoice-info .invoice-title {
            font-size: 24px;
            font-weight: 700;
            color: #FF9800;
            letter-spacing: 2px;
        }
        
        .invoice-header .invoice-info .invoice-number {
            font-size: 16px;
            font-weight: 600;
            color: #333;
        }
        
        .invoice-body {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
            margin-bottom: 20px;
        }
        
        .invoice-body .info-box {
            background: #f8f9fa;
            padding: 12px 16px;
            border-radius: var(--radius-sm);
            border-left: 4px solid #FF9800;
        }
        
        .invoice-body .info-box .label {
            font-size: 10px;
            color: #999;
            text-transform: uppercase;
            font-weight: 600;
            letter-spacing: 0.5px;
        }
        
        .invoice-body .info-box .value {
            font-size: 15px;
            font-weight: 600;
            color: var(--text);
            margin-top: 2px;
        }
        
        .invoice-table {
            width: 100%;
            border-collapse: collapse;
            margin: 15px 0;
        }
        
        .invoice-table th {
            background: #fff3e0;
            color: #E65100;
            padding: 10px 12px;
            text-align: left;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .invoice-table td {
            padding: 10px 12px;
            border-bottom: 1px solid #e8e8e8;
            font-size: 14px;
        }
        
        .invoice-table .total-row {
            background: #fff3e0;
            font-weight: 600;
        }
        
        .invoice-table .total-row td {
            border-top: 2px solid #FF9800;
            padding: 12px;
            font-size: 16px;
        }
        
        .invoice-table .total-row td:last-child {
            color: #E65100;
            font-size: 18px;
        }
        
        .invoice-footer {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
            padding-top: 15px;
            border-top: 2px solid #e8e8e8;
            flex-wrap: wrap;
        }
        
        .invoice-footer .signature {
            text-align: center;
            width: 200px;
        }
        
        .invoice-footer .signature .line {
            border-bottom: 1px solid #333;
            width: 150px;
            margin: 30px auto 5px;
        }
        
        .invoice-footer .signature .label {
            font-size: 11px;
            color: #999;
        }
        
        .invoice-actions {
            display: flex;
            gap: 10px;
            margin-top: 15px;
            flex-wrap: wrap;
        }
        
        .btn-print {
            padding: 10px 24px;
            background: #2196F3;
            color: white;
            border: none;
            border-radius: var(--radius-sm);
            cursor: pointer;
            font-size: 14px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: var(--transition);
        }
        
        .btn-print:hover {
            background: #1976D2;
        }
        
        .btn-back {
            padding: 10px 24px;
            background: #757575;
            color: white;
            border: none;
            border-radius: var(--radius-sm);
            cursor: pointer;
            font-size: 14px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: var(--transition);
            text-decoration: none;
        }
        
        .btn-back:hover {
            background: #616161;
        }
        
        /* Quick Actions */
        .quick-actions-pembelian {
            display: flex;
            gap: 8px;
            margin-bottom: 16px;
            flex-wrap: wrap;
        }
        
        .quick-actions-pembelian .btn-quick {
            padding: 8px 14px;
            border: none;
            border-radius: var(--radius-sm);
            cursor: pointer;
            font-weight: 600;
            font-size: 12px;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 6px;
            text-decoration: none;
            color: white;
        }
        
        .quick-actions-pembelian .btn-quick:active {
            transform: scale(0.95);
        }
        
        .quick-actions-pembelian .btn-quick.batal {
            background: #f44336;
        }
        
        .quick-actions-pembelian .btn-quick.batal:hover {
            background: #d32f2f;
        }
        
        .quick-actions-pembelian .btn-quick.reset {
            background: #FF9800;
        }
        
        .quick-actions-pembelian .btn-quick.reset:hover {
            background: #e68900;
        }
        
        .quick-actions-pembelian .btn-quick.supplier {
            background: #9C27B0;
        }
        
        .quick-actions-pembelian .btn-quick.supplier:hover {
            background: #7B1FA2;
        }
        
        /* Responsive */
        @media (max-width: 480px) {
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .pembelian-header {
                flex-direction: column;
                text-align: center;
                gap: 4px;
            }
            
            .invoice-body {
                grid-template-columns: 1fr;
            }
            
            .invoice-header {
                flex-direction: column;
            }
            
            .invoice-header .invoice-info {
                text-align: left;
                margin-top: 10px;
            }
            
            .invoice-footer {
                flex-direction: column;
                align-items: center;
            }
            
            .invoice-container {
                padding: 15px;
            }
            
            .total-display-pembelian {
                font-size: 14px;
            }
            
            .total-display-pembelian span:last-child {
                font-size: 18px;
            }
        }
        
        @media print {
            .no-print { display: none !important; }
            .bottom-nav { display: none !important; }
            .container { max-width: 100% !important; padding: 0 !important; }
            .invoice-container { box-shadow: none !important; padding: 15px !important; }
            .btn-print, .btn-back { display: none !important; }
            .header { display: none !important; }
            .invoice-actions { display: none !important; }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <header class="header">
            <a href="../index.php" class="back-btn"><i class="fas fa-arrow-left"></i></a>
            <h1><i class="fas fa-truck"></i> Pembelian</h1>
            <a href="notifikasi.php" class="btn-icon" style="position:relative;">
                <i class="fas fa-bell" style="font-size:18px;color:var(--text-light);"></i>
                <?php 
                $unread = $conn->query("SELECT COUNT(*) as total FROM notifikasi WHERE user_id = {$_SESSION['user_id']} AND is_read = 0");
                $unread_count = $unread->num_rows > 0 ? $unread->fetch_assoc()['total'] : 0;
                if ($unread_count > 0): 
                ?>
                <span class="badge-icon"><?php echo $unread_count; ?></span>
                <?php endif; ?>
            </a>
        </header>

        <main class="main-content">
            <?php echo $message; ?>

            <!-- INVOICE VIEW -->
            <?php if ($invoice_data): ?>
            <div class="invoice-container" id="invoiceContainer">
                <!-- Header Invoice -->
                <div class="invoice-header">
                    <div class="company-info">
                        <h2><i class="fas fa-store" style="color:#FF9800;"></i> Toko Kecil</h2>
                        <p><i class="fas fa-map-marker-alt"></i> Jl. Toko No. 1, Jakarta</p>
                        <p><i class="fas fa-phone"></i> 021-555-0000</p>
                        <p><i class="fas fa-envelope"></i> info@tokokecil.com</p>
                    </div>
                    <div class="invoice-info">
                        <div class="invoice-title">PURCHASE ORDER</div>
                        <div class="invoice-number"># <?php echo $invoice_data['no_po']; ?></div>
                        <div style="margin-top:5px;">
                            <span class="badge badge-success"><?php echo $invoice_data['status']; ?></span>
                        </div>
                    </div>
                </div>

                <!-- Body Invoice -->
                <div class="invoice-body">
                    <div class="info-box">
                        <div class="label"><i class="fas fa-user"></i> Supplier</div>
                        <div class="value"><?php echo $invoice_data['nama_supplier'] ?? 'Supplier Tidak Diketahui'; ?></div>
                        <div style="font-size:13px;color:#666;margin-top:4px;">
                            <?php echo $invoice_data['supplier_alamat'] ?? ''; ?>
                            <?php if ($invoice_data['supplier_telp']): ?>
                            <br><i class="fas fa-phone"></i> <?php echo $invoice_data['supplier_telp']; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="info-box">
                        <div class="label"><i class="fas fa-info-circle"></i> Detail Pembelian</div>
                        <div class="value">Tanggal: <?php echo date('d F Y', strtotime($invoice_data['tanggal_pembelian'])); ?></div>
                        <div style="font-size:13px;color:#666;margin-top:4px;">
                            <i class="fas fa-user"></i> Kasir: <?php echo $invoice_data['kasir'] ?? 'Admin'; ?>
                        </div>
                    </div>
                </div>

                <!-- Tabel Produk -->
                <table class="invoice-table">
                    <thead>
                        <tr>
                            <th style="width:15%;">Kode</th>
                            <th style="width:35%;">Nama Produk</th>
                            <th style="width:15%;">Satuan</th>
                            <th style="width:10%;">Jumlah</th>
                            <th style="width:15%;">Harga</th>
                            <th style="width:15%;">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo $invoice_data['kode_produk']; ?></td>
                            <td><?php echo $invoice_data['nama_produk']; ?></td>
                            <td><?php echo $invoice_data['satuan'] ?? 'Pcs'; ?></td>
                            <td><?php echo $invoice_data['jumlah']; ?></td>
                            <td><?php echo rupiah($invoice_data['harga_beli_saat']); ?></td>
                            <td><?php echo rupiah($invoice_data['total_harga']); ?></td>
                        </tr>
                    </tbody>
                    <tfoot>
                        <?php if ($invoice_data['diskon'] > 0): ?>
                        <tr>
                            <td colspan="4" style="text-align:right;font-weight:500;">Diskon</td>
                            <td colspan="2"><?php echo rupiah($invoice_data['diskon']); ?></td>
                        </tr>
                        <?php endif; ?>
                        <tr class="total-row">
                            <td colspan="4" style="text-align:right;font-size:16px;">Total Pembelian</td>
                            <td colspan="2" style="font-size:18px;color:#E65100;">
                                <?php echo rupiah($invoice_data['total_bayar']); ?>
                            </td>
                        </tr>
                    </tfoot>
                </table>

                <!-- Footer Invoice -->
                <div class="invoice-footer">
                    <div class="signature">
                        <div class="line"></div>
                        <div class="label">Penerima</div>
                    </div>
                    <div class="signature">
                        <div class="line"></div>
                        <div class="label">Supplier</div>
                    </div>
                    <div class="signature">
                        <div class="line"></div>
                        <div class="label">Kasir</div>
                    </div>
                </div>

                <!-- Tombol Aksi -->
                <div class="invoice-actions no-print">
                    <button class="btn-print" onclick="window.print()">
                        <i class="fas fa-print"></i> Cetak Invoice
                    </button>
                    <a href="pembelian.php" class="btn-back">
                        <i class="fas fa-arrow-left"></i> Kembali
                    </a>
                </div>
            </div>
            <?php else: ?>

            <!-- Pembelian Header -->
            <div class="pembelian-header">
                <div class="pembelian-title">
                    <i class="fas fa-shopping-cart"></i> Pembelian Stok
                </div>
                <div class="pembelian-date">
                    <i class="fas fa-calendar-alt"></i> <?php echo date('l, d F Y'); ?>
                </div>
            </div>

            <!-- FORM PEMBELIAN -->
            <form method="POST" class="form-card-pembelian">
                <h3 style="font-size:15px;font-weight:700;color:#E65100;margin-bottom:12px;">
                    <i class="fas fa-plus-circle"></i> Form Pembelian
                </h3>
                
                <div class="form-group">
                    <label><i class="fas fa-box"></i> Pilih Produk</label>
                    <select name="produk_id" id="produkSelect" required class="form-control" onchange="pilihProduk()">
                        <option value="">-- Pilih Produk --</option>
                        <?php while ($row = $produk->fetch_assoc()): ?>
                        <option value="<?php echo $row['id']; ?>" data-harga="<?php echo $row['harga_beli']; ?>" data-nama="<?php echo $row['nama_produk']; ?>" data-kode="<?php echo $row['kode_produk']; ?>" data-stok="<?php echo $row['stok']; ?>">
                            <?php echo $row['nama_produk']; ?> (Stok: <?php echo $row['stok']; ?>) - Rp <?php echo number_format($row['harga_beli'], 0, ',', '.'); ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <!-- Selected Product -->
                <div class="selected-product" id="selectedProduct">
                    <div class="selected-header">
                        <span class="selected-name" id="selectedNama">-</span>
                        <span class="selected-code" id="selectedKode">-</span>
                    </div>
                    <div class="selected-details">
                        <span><i class="fas fa-cubes"></i> Stok: <strong id="selectedStok">0</strong></span>
                    </div>
                </div>

                <div class="form-group">
                    <label><i class="fas fa-truck"></i> Supplier</label>
                    <select name="supplier_id" class="form-control">
                        <option value="">-- Pilih Supplier --</option>
                        <?php 
                        $supplier_selected = $conn->query("SELECT * FROM supplier ORDER BY nama_supplier");
                        while ($row = $supplier_selected->fetch_assoc()):
                        ?>
                        <option value="<?php echo $row['id']; ?>">
                            <?php echo $row['nama_supplier']; ?> - <?php echo $row['no_telp']; ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label><i class="fas fa-hashtag"></i> Jumlah</label>
                        <input type="number" name="jumlah" id="jumlah" min="1" required class="form-control" placeholder="0" oninput="hitungTotalPembelian()">
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-tag"></i> Harga Beli</label>
                        <input type="number" name="harga_beli" id="hargaBeli" required class="form-control" placeholder="0" oninput="hitungTotalPembelian()">
                    </div>
                </div>

                <div class="form-group">
                    <label><i class="fas fa-percent"></i> Diskon</label>
                    <input type="number" name="diskon" id="diskon" min="0" class="form-control" placeholder="0" oninput="hitungTotalPembelian()">
                </div>

                <div class="form-group">
                    <label><i class="fas fa-calendar"></i> Tanggal</label>
                    <input type="date" name="tanggal" value="<?php echo date('Y-m-d'); ?>" required class="form-control">
                </div>

                <div class="total-display-pembelian">
                    <span>Total Pembayaran</span>
                    <span id="totalDisplay">Rp 0</span>
                </div>

                <button type="submit" class="btn-submit-pembelian"><i class="fas fa-save"></i> Proses Pembelian</button>
            </form>

            <!-- Quick Actions -->
            <div class="quick-actions-pembelian">
                <button class="btn-quick batal" onclick="resetFormPembelian()">
                    <i class="fas fa-times"></i> Batal
                </button>
                <button class="btn-quick reset" onclick="resetFormPembelian()">
                    <i class="fas fa-undo"></i> Reset
                </button>
                <a href="supplier.php" class="btn-quick supplier">
                    <i class="fas fa-truck"></i> Kelola Supplier
                </a>
            </div>

            <!-- RIWAYAT PEMBELIAN -->
            <div class="section">
                <h3><i class="fas fa-history"></i> Riwayat Pembelian</h3>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>No. PO</th>
                                <th>Tanggal</th>
                                <th>Produk</th>
                                <th>Jumlah</th>
                                <th>Total</th>
                                <th>Supplier</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $riwayat->fetch_assoc()): ?>
                            <tr>
                                <td><small><?php echo $row['no_po']; ?></small></td>
                                <td><?php echo date('d/m/Y', strtotime($row['tanggal_pembelian'])); ?></td>
                                <td><?php echo $row['nama_produk']; ?></td>
                                <td><?php echo $row['jumlah']; ?></td>
                                <td><?php echo rupiah($row['total_bayar']); ?></td>
                                <td><?php echo $row['nama_supplier'] ?? '-'; ?></td>
                                <td>
                                    <span class="badge badge-success"><?php echo $row['status']; ?></span>
                                </td>
                                <td>
                                    <a href="?invoice=<?php echo $row['no_po']; ?>" class="btn-primary" style="padding:4px 8px;font-size:11px;">
                                        <i class="fas fa-file-invoice"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>
        </main>

        <!-- Bottom Navigation -->
        <nav class="bottom-nav">
            <a href="../index.php"><i class="fas fa-home"></i><span>Dashboard</span></a>
            <a href="penjualan.php"><i class="fas fa-cash-register"></i><span>Kasir</span></a>
            <a href="pembelian.php" class="active"><i class="fas fa-truck"></i><span>Beli</span></a>
            <a href="produk.php"><i class="fas fa-box"></i><span>Produk</span></a>
            <a href="../laporan/laba_rugi.php"><i class="fas fa-chart-bar"></i><span>Laporan</span></a>
        </nav>
    </div>

    <script>
        // ============================================
        // PILIH PRODUK
        // ============================================
        function pilihProduk() {
            const select = document.getElementById('produkSelect');
            const selected = select.options[select.selectedIndex];
            
            if (selected.value) {
                document.getElementById('hargaBeli').value = selected.dataset.harga;
                document.getElementById('selectedNama').textContent = selected.dataset.nama;
                document.getElementById('selectedKode').textContent = selected.dataset.kode;
                document.getElementById('selectedStok').textContent = selected.dataset.stok;
                document.getElementById('selectedProduct').classList.add('show');
                hitungTotalPembelian();
            } else {
                document.getElementById('selectedProduct').classList.remove('show');
            }
        }

        // ============================================
        // RESET FORM
        // ============================================
        function resetFormPembelian() {
            document.querySelector('.form-card-pembelian form').reset();
            document.getElementById('totalDisplay').textContent = 'Rp 0';
            document.getElementById('selectedProduct').classList.remove('show');
            document.getElementById('hargaBeli').value = '';
        }

        // ============================================
        // HITUNG TOTAL PEMBELIAN
        // ============================================
        function hitungTotalPembelian() {
            const jumlah = parseInt(document.getElementById('jumlah').value) || 0;
            const harga = parseInt(document.getElementById('hargaBeli').value) || 0;
            const diskon = parseInt(document.getElementById('diskon').value) || 0;
            const total = (jumlah * harga) - diskon;
            document.getElementById('totalDisplay').textContent = 'Rp ' + total.toLocaleString('id-ID');
        }

        // Event listeners
        document.getElementById('jumlah').addEventListener('input', hitungTotalPembelian);
        document.getElementById('hargaBeli').addEventListener('input', hitungTotalPembelian);
        document.getElementById('diskon').addEventListener('input', hitungTotalPembelian);

        // ============================================
        // AUTO-HIDE ALERT
        // ============================================
        document.addEventListener('DOMContentLoaded', function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(function(alert) {
                setTimeout(function() {
                    alert.style.transition = 'opacity 0.5s';
                    alert.style.opacity = '0';
                    setTimeout(function() {
                        alert.style.display = 'none';
                    }, 500);
                }, 5000);
            });
        });
    </script>
    <script src="../js/script.js"></script>
</body>
</html>