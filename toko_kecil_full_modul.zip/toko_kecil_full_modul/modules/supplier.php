<?php
include '../config/database.php';

$message = '';
$edit_data = null;
$search = $_GET['search'] ?? '';

// Hapus data
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $nama_supplier = $conn->query("SELECT nama_supplier FROM supplier WHERE id = $id")->fetch_assoc()['nama_supplier'];
    
    // Cek apakah supplier masih digunakan di produk
    $cek_produk = $conn->query("SELECT COUNT(*) as total FROM produk WHERE supplier_id = $id");
    $total_produk = $cek_produk->fetch_assoc()['total'];
    
    if ($total_produk > 0) {
        $message = '<div class="alert error"><i class="fas fa-exclamation-circle"></i> Supplier "' . $nama_supplier . '" tidak bisa dihapus karena masih mensupply ' . $total_produk . ' produk!</div>';
    } else {
        if ($conn->query("DELETE FROM supplier WHERE id = $id")) {
            logActivity($conn, $_SESSION['user_id'], 'Hapus Supplier', "Supplier: $nama_supplier");
            $message = '<div class="alert success"><i class="fas fa-check-circle"></i> Supplier "' . $nama_supplier . '" berhasil dihapus!</div>';
        }
    }
}

// Edit - ambil data
if (isset($_GET['edit'])) {
    $result = $conn->query("SELECT * FROM supplier WHERE id = {$_GET['edit']}");
    $edit_data = $result->fetch_assoc();
}

// Generate kode supplier
function generateKodeSupplierOtomatis($conn) {
    $result = $conn->query("SELECT kode_supplier FROM supplier ORDER BY id DESC LIMIT 1");
    
    if ($result->num_rows > 0) {
        $last_code = $result->fetch_assoc()['kode_supplier'];
        $last_number = (int) substr($last_code, -4);
        $new_number = str_pad($last_number + 1, 4, '0', STR_PAD_LEFT);
        return 'SUP-' . date('Ymd') . '-' . $new_number;
    } else {
        return 'SUP-' . date('Ymd') . '-0001';
    }
}

// Simpan data
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'] ?? 0;
    $kode_supplier = $_POST['kode_supplier'];
    $nama_supplier = trim($_POST['nama_supplier']);
    $alamat = trim($_POST['alamat']);
    $no_telp = trim($_POST['no_telp']);
    $email = trim($_POST['email']);
    $kontak_person = trim($_POST['kontak_person']);

    if (empty($nama_supplier)) {
        $message = '<div class="alert error"><i class="fas fa-exclamation-circle"></i> Nama supplier tidak boleh kosong!</div>';
    } else {
        if ($id > 0) {
            $stmt = $conn->prepare("
                UPDATE supplier SET 
                    kode_supplier=?, nama_supplier=?, alamat=?, no_telp=?, email=?, kontak_person=? 
                WHERE id=?
            ");
            $stmt->bind_param("ssssssi", $kode_supplier, $nama_supplier, $alamat, $no_telp, $email, $kontak_person, $id);
            logActivity($conn, $_SESSION['user_id'], 'Update Supplier', "Supplier: $nama_supplier");
            $message = '<div class="alert success"><i class="fas fa-check-circle"></i> Supplier "' . $nama_supplier . '" berhasil diupdate!</div>';
        } else {
            $stmt = $conn->prepare("
                INSERT INTO supplier (kode_supplier, nama_supplier, alamat, no_telp, email, kontak_person) 
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $stmt->bind_param("ssssss", $kode_supplier, $nama_supplier, $alamat, $no_telp, $email, $kontak_person);
            logActivity($conn, $_SESSION['user_id'], 'Tambah Supplier', "Supplier: $nama_supplier");
            $message = '<div class="alert success"><i class="fas fa-check-circle"></i> Supplier "' . $nama_supplier . '" berhasil ditambahkan!</div>';
        }
        
        if ($stmt->execute()) {
            $edit_data = null;
            echo '<script>window.location.href = "supplier.php?success=1";</script>';
        } else {
            $message = '<div class="alert error"><i class="fas fa-exclamation-circle"></i> Gagal: ' . $conn->error . '</div>';
        }
    }
}

// Query dengan pencarian
$sql = "SELECT s.*, COUNT(p.id) as total_produk 
        FROM supplier s 
        LEFT JOIN produk p ON s.id = p.supplier_id 
        GROUP BY s.id";

if ($search) {
    $search = $conn->real_escape_string($search);
    $sql .= " WHERE s.kode_supplier LIKE '%$search%' 
              OR s.nama_supplier LIKE '%$search%' 
              OR s.kontak_person LIKE '%$search%'
              OR s.no_telp LIKE '%$search%'";
}

$sql .= " ORDER BY s.nama_supplier ASC";
$supplier = $conn->query($sql);

$kode_baru = generateKodeSupplierOtomatis($conn);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Manajemen Supplier - Toko Kecil</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* ============================================
           SUPPLIER PAGE STYLES
           ============================================ */
        .form-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
            flex-wrap: wrap;
        }
        
        .form-header h3 {
            font-size: 16px;
            font-weight: 700;
            color: var(--primary-dark);
            margin: 0;
        }
        
        .form-header .badge-status {
            font-size: 11px;
            padding: 4px 12px;
            border-radius: 20px;
            background: #e3f2fd;
            color: #0d47a1;
        }
        
        .kode-info {
            font-size: 11px;
            color: var(--text-light);
            margin-bottom: 10px;
            background: #f5f5f5;
            padding: 6px 12px;
            border-radius: 6px;
        }
        
        .kode-info i {
            color: var(--primary-light);
        }
        
        .kode-info strong {
            color: var(--text);
        }
        
        /* Search Box */
        .search-box {
            display: flex;
            gap: 8px;
            margin-bottom: 12px;
            flex-wrap: wrap;
        }
        
        .search-box input {
            flex: 1;
            padding: 10px 14px;
            border: 2px solid #e8ecf1;
            border-radius: var(--radius-sm);
            font-size: 14px;
            min-width: 150px;
            transition: var(--transition);
        }
        
        .search-box input:focus {
            border-color: var(--primary-light);
            outline: none;
            box-shadow: 0 0 0 3px rgba(76, 175, 80, 0.1);
        }
        
        .search-box .btn-search {
            padding: 10px 18px;
            background: var(--primary-light);
            color: white;
            border: none;
            border-radius: var(--radius-sm);
            cursor: pointer;
            font-weight: 600;
            transition: var(--transition);
        }
        
        .search-box .btn-search:hover {
            background: var(--primary-dark);
        }
        
        .search-box .btn-clear {
            padding: 10px 18px;
            background: #f44336;
            color: white;
            border: none;
            border-radius: var(--radius-sm);
            cursor: pointer;
            font-weight: 600;
            transition: var(--transition);
        }
        
        .search-box .btn-clear:hover {
            background: #d32f2f;
        }
        
        .search-info {
            font-size: 11px;
            color: var(--text-light);
            margin-bottom: 10px;
        }
        
        .search-info strong {
            color: var(--text);
        }
        
        /* Supplier Card Grid */
        .supplier-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }
        
        .supplier-card {
            background: var(--card-bg);
            border-radius: var(--radius-sm);
            padding: 14px 14px;
            box-shadow: var(--shadow);
            transition: var(--transition);
            border-left: 4px solid #FF9800;
            display: flex;
            flex-direction: column;
            position: relative;
        }
        
        .supplier-card:active {
            transform: scale(0.97);
        }
        
        .supplier-card .supplier-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 6px;
        }
        
        .supplier-card .supplier-name {
            font-size: 15px;
            font-weight: 700;
            color: var(--text);
        }
        
        .supplier-card .supplier-code {
            font-size: 10px;
            color: var(--text-light);
            background: #f5f5f5;
            padding: 2px 8px;
            border-radius: 4px;
            font-family: 'Courier New', monospace;
        }
        
        .supplier-card .supplier-contact {
            font-size: 12px;
            color: var(--text-light);
            display: flex;
            flex-direction: column;
            gap: 2px;
            margin-bottom: 8px;
        }
        
        .supplier-card .supplier-contact .contact-item {
            display: flex;
            align-items: center;
            gap: 6px;
        }
        
        .supplier-card .supplier-contact .contact-item i {
            width: 14px;
            font-size: 12px;
            color: #FF9800;
        }
        
        .supplier-card .supplier-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-top: 8px;
            border-top: 1px solid #f0f2f5;
            font-size: 11px;
            color: var(--text-light);
            margin-top: auto;
        }
        
        .supplier-card .supplier-meta .total-produk {
            background: #fff3e0;
            padding: 2px 10px;
            border-radius: 12px;
            font-weight: 600;
            color: #e65100;
        }
        
        .supplier-card .supplier-actions {
            display: flex;
            gap: 4px;
        }
        
        .supplier-card .supplier-actions .btn-action {
            padding: 4px 8px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 11px;
            transition: var(--transition);
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 3px;
        }
        
        .supplier-card .supplier-actions .btn-edit {
            background: #2196F3;
            color: white;
        }
        
        .supplier-card .supplier-actions .btn-edit:hover {
            background: #1976D2;
        }
        
        .supplier-card .supplier-actions .btn-delete {
            background: #f44336;
            color: white;
        }
        
        .supplier-card .supplier-actions .btn-delete:hover {
            background: #d32f2f;
        }
        
        .supplier-card .supplier-actions .btn-view {
            background: #FF9800;
            color: white;
        }
        
        .supplier-card .supplier-actions .btn-view:hover {
            background: #e68900;
        }
        
        .supplier-card .supplier-alamat {
            font-size: 11px;
            color: var(--text-light);
            margin-bottom: 6px;
            display: flex;
            align-items: flex-start;
            gap: 4px;
        }
        
        .supplier-card .supplier-alamat i {
            color: #FF9800;
            margin-top: 2px;
        }
        
        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: var(--text-light);
        }
        
        .empty-state i {
            font-size: 48px;
            color: #ddd;
            display: block;
            margin-bottom: 12px;
        }
        
        /* Responsive */
        @media (max-width: 480px) {
            .supplier-grid {
                grid-template-columns: 1fr;
            }
            
            .search-box input {
                min-width: 100px;
                font-size: 13px;
            }
            
            .search-box .btn-search,
            .search-box .btn-clear {
                padding: 8px 12px;
                font-size: 12px;
            }
            
            .supplier-card {
                padding: 12px 12px;
            }
            
            .supplier-card .supplier-header {
                flex-wrap: wrap;
            }
        }
        
        @media (min-width: 768px) {
            .supplier-grid {
                grid-template-columns: 1fr 1fr 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <header class="header">
            <a href="../index.php" class="back-btn"><i class="fas fa-arrow-left"></i></a>
            <h1><i class="fas fa-truck"></i> Manajemen Supplier</h1>
            <a href="notifikasi.php" class="btn-icon" style="position:relative;">
                <i class="fas fa-bell" style="font-size:18px;color:var(--text-light);"></i>
                <?php 
                $unread = $conn->query("SELECT COUNT(*) as total FROM notifikasi WHERE user_id = {$_SESSION['user_id']} AND is_read = 0");
                $unread_count = $unread->num_rows > 0 ? $unread->fetch_assoc()['total'] : 0;
                if ($unread_count > 0): 
                ?>
                <span class="badge-icon"><?php echo $unread_count; ?></span>
                <?php endif; ?>
            </a>
        </header>

        <main class="main-content">
            <?php echo $message; ?>
            
            <?php if (isset($_GET['success'])): ?>
            <div class="alert success"><i class="fas fa-check-circle"></i> Data berhasil disimpan!</div>
            <?php endif; ?>

            <!-- Form Supplier -->
            <div class="form-card">
                <div class="form-header">
                    <h3><i class="fas fa-<?php echo $edit_data ? 'edit' : 'plus-circle'; ?>"></i> <?php echo $edit_data ? 'Edit Supplier' : 'Tambah Supplier Baru'; ?></h3>
                    <?php if ($edit_data): ?>
                    <span class="badge-status"><i class="fas fa-pencil-alt"></i> Mode Edit</span>
                    <?php endif; ?>
                </div>
                
                <?php if (!$edit_data): ?>
                <div class="kode-info">
                    <i class="fas fa-info-circle"></i> 
                    Kode supplier akan digenerate otomatis: <strong><?php echo $kode_baru; ?></strong>
                </div>
                <?php endif; ?>
                
                <form method="POST">
                    <input type="hidden" name="id" value="<?php echo $edit_data['id'] ?? 0; ?>">
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label><i class="fas fa-barcode"></i> Kode Supplier</label>
                            <input type="text" name="kode_supplier" value="<?php echo $edit_data['kode_supplier'] ?? $kode_baru; ?>" required class="form-control" readonly style="background:#f0f7f0;font-weight:bold;color:#e65100;font-size:13px;">
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-building"></i> Nama Supplier</label>
                            <input type="text" name="nama_supplier" value="<?php echo $edit_data['nama_supplier'] ?? ''; ?>" required class="form-control" placeholder="Masukkan nama supplier" autofocus>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-map-marker-alt"></i> Alamat</label>
                        <textarea name="alamat" class="form-control" rows="2" placeholder="Masukkan alamat supplier..."><?php echo $edit_data['alamat'] ?? ''; ?></textarea>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label><i class="fas fa-phone"></i> No. Telepon</label>
                            <input type="text" name="no_telp" value="<?php echo $edit_data['no_telp'] ?? ''; ?>" class="form-control" placeholder="08xx-xxxx-xxxx">
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-envelope"></i> Email</label>
                            <input type="email" name="email" value="<?php echo $edit_data['email'] ?? ''; ?>" class="form-control" placeholder="email@supplier.com">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-user-tie"></i> Kontak Person</label>
                        <input type="text" name="kontak_person" value="<?php echo $edit_data['kontak_person'] ?? ''; ?>" class="form-control" placeholder="Nama kontak person">
                    </div>
                    
                    <button type="submit" class="btn-submit">
                        <i class="fas fa-save"></i> <?php echo $edit_data ? 'Update Supplier' : 'Simpan Supplier'; ?>
                    </button>
                </form>
            </div>

            <!-- Pencarian Supplier -->
            <div class="section">
                <h3><i class="fas fa-search"></i> Cari Supplier</h3>
                <div class="search-box">
                    <input type="text" id="searchInput" placeholder="🔍 Cari kode, nama, kontak, atau telepon..." 
                           value="<?php echo htmlspecialchars($search); ?>" 
                           onkeyup="if(event.key=='Enter') window.location.href='supplier.php?search='+encodeURIComponent(this.value)">
                    <button class="btn-search" onclick="window.location.href='supplier.php?search='+encodeURIComponent(document.getElementById('searchInput').value)">
                        <i class="fas fa-search"></i> Cari
                    </button>
                    <button class="btn-clear" onclick="window.location.href='supplier.php'">
                        <i class="fas fa-times"></i> Reset
                    </button>
                </div>
                <div class="search-info">
                    <i class="fas fa-info-circle"></i> 
                    Total: <strong><?php echo $supplier->num_rows; ?></strong> supplier ditemukan
                    <?php if ($search): ?>
                    <span style="margin-left:10px;">
                        <i class="fas fa-filter"></i> Filter: "<strong><?php echo htmlspecialchars($search); ?></strong>"
                        <a href="supplier.php" style="color:#f44336;margin-left:6px;text-decoration:none;">✕ Hapus</a>
                    </span>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Daftar Supplier - Card Grid -->
            <div class="section" style="padding:10px 12px;">
                <h3><i class="fas fa-list"></i> Daftar Supplier</h3>
                
                <?php if ($supplier->num_rows > 0): ?>
                    <div class="supplier-grid">
                        <?php while ($row = $supplier->fetch_assoc()): ?>
                        <div class="supplier-card">
                            <div class="supplier-header">
                                <span class="supplier-name"><?php echo $row['nama_supplier']; ?></span>
                                <span class="supplier-code"><?php echo $row['kode_supplier']; ?></span>
                            </div>
                            
                            <?php if ($row['alamat']): ?>
                            <div class="supplier-alamat">
                                <i class="fas fa-map-marker-alt"></i>
                                <span><?php echo $row['alamat']; ?></span>
                            </div>
                            <?php endif; ?>
                            
                            <div class="supplier-contact">
                                <?php if ($row['no_telp']): ?>
                                <div class="contact-item">
                                    <i class="fas fa-phone"></i>
                                    <span><?php echo $row['no_telp']; ?></span>
                                </div>
                                <?php endif; ?>
                                <?php if ($row['email']): ?>
                                <div class="contact-item">
                                    <i class="fas fa-envelope"></i>
                                    <span><?php echo $row['email']; ?></span>
                                </div>
                                <?php endif; ?>
                                <?php if ($row['kontak_person']): ?>
                                <div class="contact-item">
                                    <i class="fas fa-user-tie"></i>
                                    <span>Kontak: <strong><?php echo $row['kontak_person']; ?></strong></span>
                                </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="supplier-meta">
                                <span class="total-produk">
                                    <i class="fas fa-box"></i> <?php echo $row['total_produk']; ?> Produk
                                </span>
                                <div class="supplier-actions">
                                    <a href="?edit=<?php echo $row['id']; ?>" class="btn-action btn-edit" title="Edit Supplier">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="?delete=<?php echo $row['id']; ?>" onclick="return confirm('Yakin hapus supplier ini?')" class="btn-action btn-delete" title="Hapus Supplier">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                    <a href="produk.php?search=<?php echo urlencode($row['nama_supplier']); ?>" class="btn-action btn-view" title="Lihat Produk">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php endwhile; ?>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-truck"></i>
                        <p><?php echo $search ? 'Supplier tidak ditemukan' : 'Belum ada supplier. Silakan tambahkan supplier pertama!'; ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </main>

        <!-- Bottom Navigation -->
        <nav class="bottom-nav">
            <a href="../index.php"><i class="fas fa-home"></i><span>Dashboard</span></a>
            <a href="penjualan.php"><i class="fas fa-cash-register"></i><span>Kasir</span></a>
            <a href="pembelian.php"><i class="fas fa-truck"></i><span>Beli</span></a>
            <a href="produk.php"><i class="fas fa-box"></i><span>Produk</span></a>
            <a href="../laporan/laba_rugi.php"><i class="fas fa-chart-bar"></i><span>Laporan</span></a>
        </nav>
    </div>

    <script>
        // ============================================
        // AUTO-HIDE ALERT
        // ============================================
        document.addEventListener('DOMContentLoaded', function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(function(alert) {
                setTimeout(function() {
                    alert.style.transition = 'opacity 0.5s';
                    alert.style.opacity = '0';
                    setTimeout(function() {
                        alert.style.display = 'none';
                    }, 500);
                }, 5000);
            });
        });
    </script>
    <script src="../js/script.js"></script>
</body>
</html>