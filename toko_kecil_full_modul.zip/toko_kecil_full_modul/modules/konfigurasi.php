<?php
include '../config/database.php';

// Hanya admin yang bisa akses
if (!hasRole('admin') && !hasRole('manager')) {
    redirect('../index.php');
}

$message = '';

// Ambil data konfigurasi
$config = $conn->query("SELECT * FROM konfigurasi_toko ORDER BY id DESC LIMIT 1")->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_toko = $_POST['nama_toko'];
    $alamat_toko = $_POST['alamat_toko'];
    $no_telp = $_POST['no_telp'];
    $email = $_POST['email'];
    $footer = $_POST['footer'];
    $pajak_percent = $_POST['pajak_percent'];
    $diskon_maksimal = $_POST['diskon_maksimal'];
    $currency = $_POST['currency'];
    $timezone = $_POST['timezone'];

    if ($config) {
        $stmt = $conn->prepare("
            UPDATE konfigurasi_toko SET 
                nama_toko=?, alamat_toko=?, no_telp=?, email=?, 
                footer=?, pajak_percent=?, diskon_maksimal=?, currency=?, timezone=? 
            WHERE id=?
        ");
        $stmt->bind_param("sssssddssi", $nama_toko, $alamat_toko, $no_telp, $email, 
            $footer, $pajak_percent, $diskon_maksimal, $currency, $timezone, $config['id']);
    } else {
        $stmt = $conn->prepare("
            INSERT INTO konfigurasi_toko (nama_toko, alamat_toko, no_telp, email, footer, pajak_percent, diskon_maksimal, currency, timezone) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->bind_param("sssssddss", $nama_toko, $alamat_toko, $no_telp, $email, 
            $footer, $pajak_percent, $diskon_maksimal, $currency, $timezone);
    }

    if ($stmt->execute()) {
        logActivity($conn, $_SESSION['user_id'], 'Update Konfigurasi', "Konfigurasi toko diupdate");
        $message = '<div class="alert success">Konfigurasi berhasil disimpan!</div>';
        $config = $conn->query("SELECT * FROM konfigurasi_toko ORDER BY id DESC LIMIT 1")->fetch_assoc();
    } else {
        $message = '<div class="alert error">Gagal: ' . $conn->error . '</div>';
    }
}

$timezones = [
    'Asia/Jakarta' => 'WIB (Jakarta)',
    'Asia/Makassar' => 'WITA (Makassar)',
    'Asia/Jayapura' => 'WIT (Jayapura)',
];

$currencies = [
    'Rp' => 'Rupiah (Rp)',
    '$' => 'Dollar ($)',
    'RM' => 'Ringgit (RM)',
    'S$' => 'Singapore Dollar (S$)',
];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Konfigurasi Toko - Toko Kecil</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <!-- Header -->
        <header class="header">
            <a href="../index.php" class="back-btn"><i class="fas fa-arrow-left"></i></a>
            <h1><i class="fas fa-cog"></i> Konfigurasi Toko</h1>
            <span></span>
        </header>

        <main class="main-content">
            <h2><i class="fas fa-cog"></i> Konfigurasi Toko</h2>

            <?php echo $message; ?>

            <div class="form-card">
                <form method="POST">
                    <div class="form-group">
                        <label>Nama Toko</label>
                        <input type="text" name="nama_toko" value="<?php echo $config['nama_toko'] ?? 'Toko Kecil'; ?>" required class="form-control">
                    </div>

                    <div class="form-group">
                        <label>Alamat Toko</label>
                        <textarea name="alamat_toko" class="form-control" rows="2"><?php echo $config['alamat_toko'] ?? ''; ?></textarea>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label>No. Telp</label>
                            <input type="text" name="no_telp" value="<?php echo $config['no_telp'] ?? ''; ?>" class="form-control">
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" name="email" value="<?php echo $config['email'] ?? ''; ?>" class="form-control">
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Footer</label>
                        <input type="text" name="footer" value="<?php echo $config['footer'] ?? '© 2026 Toko Kecil - All Rights Reserved'; ?>" class="form-control">
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label>Pajak (%)</label>
                            <input type="number" name="pajak_percent" step="0.01" value="<?php echo $config['pajak_percent'] ?? 11; ?>" class="form-control">
                        </div>
                        <div class="form-group">
                            <label>Diskon Maksimal (%)</label>
                            <input type="number" name="diskon_maksimal" step="0.01" value="<?php echo $config['diskon_maksimal'] ?? 50; ?>" class="form-control">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label>Mata Uang</label>
                            <select name="currency" class="form-control">
                                <?php foreach ($currencies as $key => $value): ?>
                                <option value="<?php echo $key; ?>" <?php echo ($config['currency'] ?? 'Rp') == $key ? 'selected' : ''; ?>>
                                    <?php echo $value; ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Zona Waktu</label>
                            <select name="timezone" class="form-control">
                                <?php foreach ($timezones as $key => $value): ?>
                                <option value="<?php echo $key; ?>" <?php echo ($config['timezone'] ?? 'Asia/Jakarta') == $key ? 'selected' : ''; ?>>
                                    <?php echo $value; ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <button type="submit" class="btn-submit"><i class="fas fa-save"></i> Simpan Konfigurasi</button>
                </form>
            </div>
        </main>

        <!-- Bottom Navigation -->
        <nav class="bottom-nav">
            <a href="../index.php"><i class="fas fa-home"></i><span>Dashboard</span></a>
            <a href="penjualan.php"><i class="fas fa-cash-register"></i><span>Kasir</span></a>
            <a href="pembelian.php"><i class="fas fa-truck"></i><span>Beli</span></a>
            <a href="produk.php"><i class="fas fa-box"></i><span>Produk</span></a>
            <a href="../laporan/laba_rugi.php"><i class="fas fa-chart-bar"></i><span>Laporan</span></a>
        </nav>
    </div>
    <script src="../js/script.js"></script>
</body>
</html>