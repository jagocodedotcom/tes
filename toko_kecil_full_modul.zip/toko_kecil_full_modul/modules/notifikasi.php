<?php
include '../config/database.php';

// Ambil notifikasi
$notifikasi = $conn->query("
    SELECT * FROM notifikasi 
    WHERE user_id = {$_SESSION['user_id']} 
    ORDER BY created_at DESC 
    LIMIT 50
");

// Tandai semua sebagai sudah dibaca
if (isset($_GET['read_all'])) {
    $conn->query("UPDATE notifikasi SET is_read = 1 WHERE user_id = {$_SESSION['user_id']}");
    redirect('notifikasi.php');
}

// Hapus notifikasi
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM notifikasi WHERE id = $id AND user_id = {$_SESSION['user_id']}");
    redirect('notifikasi.php');
}

// Cek stok menipis dan buat notifikasi
function cekStokMenipis($conn) {
    $result = $conn->query("
        SELECT id, nama_produk, stok, stok_minimal 
        FROM produk 
        WHERE stok <= stok_minimal
    ");
    
    while ($row = $result->fetch_assoc()) {
        $check = $conn->query("
            SELECT id FROM notifikasi 
            WHERE user_id = {$_SESSION['user_id']} 
            AND detail LIKE '%{$row['nama_produk']}%' 
            AND is_read = 0
        ");
        if ($check->num_rows == 0) {
            $conn->query("
                INSERT INTO notifikasi (user_id, judul, pesan, link) 
                VALUES (
                    {$_SESSION['user_id']}, 
                    'Stok Menipis', 
                    'Stok produk {$row['nama_produk']} tinggal {$row['stok']} (minimal {$row['stok_minimal']})', 
                    'modules/produk.php?edit={$row['id']}'
                )
            ");
        }
    }
}

// Jalankan pengecekan stok
cekStokMenipis($conn);

$total_unread = $conn->query("
    SELECT COUNT(*) as total FROM notifikasi 
    WHERE user_id = {$_SESSION['user_id']} AND is_read = 0
")->fetch_assoc()['total'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifikasi - Toko Kecil</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <!-- Header -->
        <header class="header">
            <a href="../index.php" class="back-btn"><i class="fas fa-arrow-left"></i></a>
            <h1><i class="fas fa-bell"></i> Notifikasi</h1>
            <span></span>
        </header>

        <main class="main-content">
            <div class="section-header" style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
                <h2><i class="fas fa-bell"></i> Notifikasi</h2>
                <div>
                    <?php if ($total_unread > 0): ?>
                    <a href="?read_all=1" class="btn-primary" style="font-size:12px;">
                        <i class="fas fa-check-double"></i> Tandai Semua
                    </a>
                    <?php endif; ?>
                </div>
            </div>

            <div class="section">
                <?php if ($notifikasi->num_rows > 0): ?>
                    <?php while ($row = $notifikasi->fetch_assoc()): ?>
                    <div class="notification-item <?php echo $row['is_read'] ? 'read' : 'unread'; ?>" 
                         style="display:flex;justify-content:space-between;align-items:center;padding:12px;border-bottom:1px solid #f0f0f0;<?php echo $row['is_read'] ? '' : 'background:#f0f7f0;border-left:4px solid #4CAF50;'; ?>">
                        <div>
                            <div style="font-weight:500;font-size:14px;">
                                <?php echo $row['judul']; ?>
                                <?php if (!$row['is_read']): ?>
                                <span class="badge badge-success" style="font-size:8px;">BARU</span>
                                <?php endif; ?>
                            </div>
                            <div style="font-size:13px;color:var(--text-light);margin-top:4px;">
                                <?php echo $row['pesan']; ?>
                            </div>
                            <div style="font-size:11px;color:var(--text-light);margin-top:4px;">
                                <i class="fas fa-clock"></i> <?php echo date('d/m/Y H:i', strtotime($row['created_at'])); ?>
                            </div>
                        </div>
                        <div>
                            <?php if ($row['link']): ?>
                            <a href="../<?php echo $row['link']; ?>" class="btn-primary" style="padding:4px 10px;font-size:11px;">
                                <i class="fas fa-arrow-right"></i>
                            </a>
                            <?php endif; ?>
                            <a href="?delete=<?php echo $row['id']; ?>" class="btn-danger" style="padding:4px 8px;font-size:11px;" onclick="return confirm('Yakin hapus notifikasi ini?')">
                                <i class="fas fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p style="text-align:center;padding:30px;color:var(--text-light);">
                        <i class="fas fa-bell-slash" style="font-size:40px;display:block;margin-bottom:10px;"></i>
                        Tidak ada notifikasi
                    </p>
                <?php endif; ?>
            </div>
        </main>

        <!-- Bottom Navigation -->
        <nav class="bottom-nav">
            <a href="../index.php"><i class="fas fa-home"></i><span>Dashboard</span></a>
            <a href="penjualan.php"><i class="fas fa-cash-register"></i><span>Kasir</span></a>
            <a href="pembelian.php"><i class="fas fa-truck"></i><span>Beli</span></a>
            <a href="produk.php"><i class="fas fa-box"></i><span>Produk</span></a>
            <a href="../laporan/laba_rugi.php"><i class="fas fa-chart-bar"></i><span>Laporan</span></a>
        </nav>
    </div>
    <script src="../js/script.js"></script>
</body>
</html>