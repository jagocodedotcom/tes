<?php
include '../config/database.php';

$message = '';
$edit_data = null;
$search = $_GET['search'] ?? '';

// Hapus data
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $nama_pelanggan = $conn->query("SELECT nama_pelanggan FROM pelanggan WHERE id = $id")->fetch_assoc()['nama_pelanggan'];
    
    if ($conn->query("DELETE FROM pelanggan WHERE id = $id")) {
        logActivity($conn, $_SESSION['user_id'], 'Hapus Pelanggan', "Pelanggan: $nama_pelanggan");
        $message = '<div class="alert success"><i class="fas fa-check-circle"></i> Pelanggan "' . $nama_pelanggan . '" berhasil dihapus!</div>';
    }
}

// Edit - ambil data
if (isset($_GET['edit'])) {
    $result = $conn->query("SELECT * FROM pelanggan WHERE id = {$_GET['edit']}");
    $edit_data = $result->fetch_assoc();
}

// Generate kode pelanggan
function generateKodePelangganOtomatis($conn) {
    $result = $conn->query("SELECT kode_pelanggan FROM pelanggan ORDER BY id DESC LIMIT 1");
    
    if ($result->num_rows > 0) {
        $last_code = $result->fetch_assoc()['kode_pelanggan'];
        $last_number = (int) substr($last_code, -4);
        $new_number = str_pad($last_number + 1, 4, '0', STR_PAD_LEFT);
        return 'CUST-' . date('Ymd') . '-' . $new_number;
    } else {
        return 'CUST-' . date('Ymd') . '-0001';
    }
}

// Simpan data
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'] ?? 0;
    $kode_pelanggan = $_POST['kode_pelanggan'];
    $nama_pelanggan = trim($_POST['nama_pelanggan']);
    $alamat = trim($_POST['alamat']);
    $no_telp = trim($_POST['no_telp']);
    $email = trim($_POST['email']);
    $jenis_kelamin = $_POST['jenis_kelamin'];
    $tanggal_lahir = $_POST['tanggal_lahir'];

    if (empty($nama_pelanggan)) {
        $message = '<div class="alert error"><i class="fas fa-exclamation-circle"></i> Nama pelanggan tidak boleh kosong!</div>';
    } else {
        if ($id > 0) {
            $stmt = $conn->prepare("
                UPDATE pelanggan SET 
                    kode_pelanggan=?, nama_pelanggan=?, alamat=?, no_telp=?, 
                    email=?, jenis_kelamin=?, tanggal_lahir=? 
                WHERE id=?
            ");
            $stmt->bind_param("sssssssi", $kode_pelanggan, $nama_pelanggan, $alamat, $no_telp, 
                $email, $jenis_kelamin, $tanggal_lahir, $id);
            logActivity($conn, $_SESSION['user_id'], 'Update Pelanggan', "Pelanggan: $nama_pelanggan");
            $message = '<div class="alert success"><i class="fas fa-check-circle"></i> Pelanggan "' . $nama_pelanggan . '" berhasil diupdate!</div>';
        } else {
            $stmt = $conn->prepare("
                INSERT INTO pelanggan (kode_pelanggan, nama_pelanggan, alamat, no_telp, email, jenis_kelamin, tanggal_lahir) 
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->bind_param("sssssss", $kode_pelanggan, $nama_pelanggan, $alamat, $no_telp, 
                $email, $jenis_kelamin, $tanggal_lahir);
            logActivity($conn, $_SESSION['user_id'], 'Tambah Pelanggan', "Pelanggan: $nama_pelanggan");
            $message = '<div class="alert success"><i class="fas fa-check-circle"></i> Pelanggan "' . $nama_pelanggan . '" berhasil ditambahkan!</div>';
        }
        
        if ($stmt->execute()) {
            $edit_data = null;
            echo '<script>window.location.href = "pelanggan.php?success=1";</script>';
        } else {
            $message = '<div class="alert error"><i class="fas fa-exclamation-circle"></i> Gagal: ' . $conn->error . '</div>';
        }
    }
}

// Query dengan pencarian
$sql = "SELECT * FROM pelanggan";

if ($search) {
    $search = $conn->real_escape_string($search);
    $sql .= " WHERE kode_pelanggan LIKE '%$search%' 
              OR nama_pelanggan LIKE '%$search%' 
              OR no_telp LIKE '%$search%'
              OR email LIKE '%$search%'";
}

$sql .= " ORDER BY nama_pelanggan ASC";
$pelanggan = $conn->query($sql);

$kode_baru = generateKodePelangganOtomatis($conn);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Manajemen Pelanggan - Toko Kecil</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* ============================================
           PELANGGAN PAGE STYLES
           ============================================ */
        .form-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
            flex-wrap: wrap;
        }
        
        .form-header h3 {
            font-size: 16px;
            font-weight: 700;
            color: var(--primary-dark);
            margin: 0;
        }
        
        .form-header .badge-status {
            font-size: 11px;
            padding: 4px 12px;
            border-radius: 20px;
            background: #e3f2fd;
            color: #0d47a1;
        }
        
        .kode-info {
            font-size: 11px;
            color: var(--text-light);
            margin-bottom: 10px;
            background: #f5f5f5;
            padding: 6px 12px;
            border-radius: 6px;
        }
        
        .kode-info i {
            color: #9C27B0;
        }
        
        .kode-info strong {
            color: var(--text);
        }
        
        /* Search Box */
        .search-box {
            display: flex;
            gap: 8px;
            margin-bottom: 12px;
            flex-wrap: wrap;
        }
        
        .search-box input {
            flex: 1;
            padding: 10px 14px;
            border: 2px solid #e8ecf1;
            border-radius: var(--radius-sm);
            font-size: 14px;
            min-width: 150px;
            transition: var(--transition);
        }
        
        .search-box input:focus {
            border-color: #9C27B0;
            outline: none;
            box-shadow: 0 0 0 3px rgba(156, 39, 176, 0.1);
        }
        
        .search-box .btn-search {
            padding: 10px 18px;
            background: #9C27B0;
            color: white;
            border: none;
            border-radius: var(--radius-sm);
            cursor: pointer;
            font-weight: 600;
            transition: var(--transition);
        }
        
        .search-box .btn-search:hover {
            background: #7B1FA2;
        }
        
        .search-box .btn-clear {
            padding: 10px 18px;
            background: #f44336;
            color: white;
            border: none;
            border-radius: var(--radius-sm);
            cursor: pointer;
            font-weight: 600;
            transition: var(--transition);
        }
        
        .search-box .btn-clear:hover {
            background: #d32f2f;
        }
        
        .search-info {
            font-size: 11px;
            color: var(--text-light);
            margin-bottom: 10px;
        }
        
        .search-info strong {
            color: var(--text);
        }
        
        /* Pelanggan Card Grid */
        .pelanggan-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }
        
        .pelanggan-card {
            background: var(--card-bg);
            border-radius: var(--radius-sm);
            padding: 14px 14px;
            box-shadow: var(--shadow);
            transition: var(--transition);
            border-left: 4px solid #9C27B0;
            display: flex;
            flex-direction: column;
            position: relative;
        }
        
        .pelanggan-card:active {
            transform: scale(0.97);
        }
        
        .pelanggan-card .pelanggan-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 6px;
        }
        
        .pelanggan-card .pelanggan-name {
            font-size: 15px;
            font-weight: 700;
            color: var(--text);
        }
        
        .pelanggan-card .pelanggan-code {
            font-size: 10px;
            color: var(--text-light);
            background: #f5f5f5;
            padding: 2px 8px;
            border-radius: 4px;
            font-family: 'Courier New', monospace;
        }
        
        .pelanggan-card .pelanggan-info {
            font-size: 12px;
            color: var(--text-light);
            display: flex;
            flex-direction: column;
            gap: 2px;
            margin-bottom: 8px;
        }
        
        .pelanggan-card .pelanggan-info .info-item {
            display: flex;
            align-items: center;
            gap: 6px;
        }
        
        .pelanggan-card .pelanggan-info .info-item i {
            width: 14px;
            font-size: 12px;
            color: #9C27B0;
        }
        
        .pelanggan-card .pelanggan-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-top: 8px;
            border-top: 1px solid #f0f2f5;
            font-size: 11px;
            color: var(--text-light);
            margin-top: auto;
        }
        
        .pelanggan-card .pelanggan-meta .poin {
            background: #f3e5f5;
            padding: 2px 10px;
            border-radius: 12px;
            font-weight: 600;
            color: #6a1b9a;
        }
        
        .pelanggan-card .pelanggan-meta .total-belanja {
            font-weight: 600;
            color: #4CAF50;
        }
        
        .pelanggan-card .pelanggan-actions {
            display: flex;
            gap: 4px;
        }
        
        .pelanggan-card .pelanggan-actions .btn-action {
            padding: 4px 8px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 11px;
            transition: var(--transition);
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 3px;
        }
        
        .pelanggan-card .pelanggan-actions .btn-edit {
            background: #2196F3;
            color: white;
        }
        
        .pelanggan-card .pelanggan-actions .btn-edit:hover {
            background: #1976D2;
        }
        
        .pelanggan-card .pelanggan-actions .btn-delete {
            background: #f44336;
            color: white;
        }
        
        .pelanggan-card .pelanggan-actions .btn-delete:hover {
            background: #d32f2f;
        }
        
        .pelanggan-card .gender-badge {
            font-size: 10px;
            padding: 2px 8px;
            border-radius: 10px;
            font-weight: 600;
        }
        
        .gender-badge.laki {
            background: #e3f2fd;
            color: #0d47a1;
        }
        
        .gender-badge.perempuan {
            background: #fce4ec;
            color: #c62828;
        }
        
        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: var(--text-light);
        }
        
        .empty-state i {
            font-size: 48px;
            color: #ddd;
            display: block;
            margin-bottom: 12px;
        }
        
        /* Responsive */
        @media (max-width: 480px) {
            .pelanggan-grid {
                grid-template-columns: 1fr;
            }
            
            .search-box input {
                min-width: 100px;
                font-size: 13px;
            }
            
            .search-box .btn-search,
            .search-box .btn-clear {
                padding: 8px 12px;
                font-size: 12px;
            }
            
            .pelanggan-card {
                padding: 12px 12px;
            }
            
            .pelanggan-card .pelanggan-header {
                flex-wrap: wrap;
            }
        }
        
        @media (min-width: 768px) {
            .pelanggan-grid {
                grid-template-columns: 1fr 1fr 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <header class="header">
            <a href="../index.php" class="back-btn"><i class="fas fa-arrow-left"></i></a>
            <h1><i class="fas fa-users"></i> Manajemen Pelanggan</h1>
            <a href="notifikasi.php" class="btn-icon" style="position:relative;">
                <i class="fas fa-bell" style="font-size:18px;color:var(--text-light);"></i>
                <?php 
                $unread = $conn->query("SELECT COUNT(*) as total FROM notifikasi WHERE user_id = {$_SESSION['user_id']} AND is_read = 0");
                $unread_count = $unread->num_rows > 0 ? $unread->fetch_assoc()['total'] : 0;
                if ($unread_count > 0): 
                ?>
                <span class="badge-icon"><?php echo $unread_count; ?></span>
                <?php endif; ?>
            </a>
        </header>

        <main class="main-content">
            <?php echo $message; ?>
            
            <?php if (isset($_GET['success'])): ?>
            <div class="alert success"><i class="fas fa-check-circle"></i> Data berhasil disimpan!</div>
            <?php endif; ?>

            <!-- Form Pelanggan -->
            <div class="form-card">
                <div class="form-header">
                    <h3><i class="fas fa-<?php echo $edit_data ? 'edit' : 'plus-circle'; ?>"></i> <?php echo $edit_data ? 'Edit Pelanggan' : 'Tambah Pelanggan Baru'; ?></h3>
                    <?php if ($edit_data): ?>
                    <span class="badge-status"><i class="fas fa-pencil-alt"></i> Mode Edit</span>
                    <?php endif; ?>
                </div>
                
                <?php if (!$edit_data): ?>
                <div class="kode-info">
                    <i class="fas fa-info-circle"></i> 
                    Kode pelanggan akan digenerate otomatis: <strong><?php echo $kode_baru; ?></strong>
                </div>
                <?php endif; ?>
                
                <form method="POST">
                    <input type="hidden" name="id" value="<?php echo $edit_data['id'] ?? 0; ?>">
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label><i class="fas fa-id-card"></i> Kode Pelanggan</label>
                            <input type="text" name="kode_pelanggan" value="<?php echo $edit_data['kode_pelanggan'] ?? $kode_baru; ?>" required class="form-control" readonly style="background:#f3e5f5;font-weight:bold;color:#6a1b9a;font-size:13px;">
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-user"></i> Nama Pelanggan</label>
                            <input type="text" name="nama_pelanggan" value="<?php echo $edit_data['nama_pelanggan'] ?? ''; ?>" required class="form-control" placeholder="Masukkan nama pelanggan" autofocus>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-map-marker-alt"></i> Alamat</label>
                        <textarea name="alamat" class="form-control" rows="2" placeholder="Masukkan alamat pelanggan..."><?php echo $edit_data['alamat'] ?? ''; ?></textarea>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label><i class="fas fa-phone"></i> No. Telepon</label>
                            <input type="text" name="no_telp" value="<?php echo $edit_data['no_telp'] ?? ''; ?>" class="form-control" placeholder="08xx-xxxx-xxxx">
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-envelope"></i> Email</label>
                            <input type="email" name="email" value="<?php echo $edit_data['email'] ?? ''; ?>" class="form-control" placeholder="email@pelanggan.com">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label><i class="fas fa-venus-mars"></i> Jenis Kelamin</label>
                            <select name="jenis_kelamin" class="form-control">
                                <option value="L" <?php echo ($edit_data['jenis_kelamin'] ?? 'L') == 'L' ? 'selected' : ''; ?>>👨 Laki-laki</option>
                                <option value="P" <?php echo ($edit_data['jenis_kelamin'] ?? '') == 'P' ? 'selected' : ''; ?>>👩 Perempuan</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-birthday-cake"></i> Tanggal Lahir</label>
                            <input type="date" name="tanggal_lahir" value="<?php echo $edit_data['tanggal_lahir'] ?? ''; ?>" class="form-control">
                        </div>
                    </div>
                    
                    <button type="submit" class="btn-submit" style="background:#9C27B0;">
                        <i class="fas fa-save"></i> <?php echo $edit_data ? 'Update Pelanggan' : 'Simpan Pelanggan'; ?>
                    </button>
                </form>
            </div>

            <!-- Pencarian Pelanggan -->
            <div class="section">
                <h3><i class="fas fa-search"></i> Cari Pelanggan</h3>
                <div class="search-box">
                    <input type="text" id="searchInput" placeholder="🔍 Cari kode, nama, telepon, atau email..." 
                           value="<?php echo htmlspecialchars($search); ?>" 
                           onkeyup="if(event.key=='Enter') window.location.href='pelanggan.php?search='+encodeURIComponent(this.value)">
                    <button class="btn-search" onclick="window.location.href='pelanggan.php?search='+encodeURIComponent(document.getElementById('searchInput').value)">
                        <i class="fas fa-search"></i> Cari
                    </button>
                    <button class="btn-clear" onclick="window.location.href='pelanggan.php'">
                        <i class="fas fa-times"></i> Reset
                    </button>
                </div>
                <div class="search-info">
                    <i class="fas fa-info-circle"></i> 
                    Total: <strong><?php echo $pelanggan->num_rows; ?></strong> pelanggan ditemukan
                    <?php if ($search): ?>
                    <span style="margin-left:10px;">
                        <i class="fas fa-filter"></i> Filter: "<strong><?php echo htmlspecialchars($search); ?></strong>"
                        <a href="pelanggan.php" style="color:#f44336;margin-left:6px;text-decoration:none;">✕ Hapus</a>
                    </span>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Daftar Pelanggan - Card Grid -->
            <div class="section" style="padding:10px 12px;">
                <h3><i class="fas fa-list"></i> Daftar Pelanggan</h3>
                
                <?php if ($pelanggan->num_rows > 0): ?>
                    <div class="pelanggan-grid">
                        <?php while ($row = $pelanggan->fetch_assoc()): 
                            $gender_label = $row['jenis_kelamin'] == 'L' ? 'Laki-laki' : 'Perempuan';
                            $gender_class = $row['jenis_kelamin'] == 'L' ? 'laki' : 'perempuan';
                        ?>
                        <div class="pelanggan-card">
                            <div class="pelanggan-header">
                                <span class="pelanggan-name">
                                    <?php echo $row['nama_pelanggan']; ?>
                                    <span class="gender-badge <?php echo $gender_class; ?>">
                                        <?php echo $row['jenis_kelamin'] == 'L' ? '👨' : '👩'; ?>
                                        <?php echo $gender_label; ?>
                                    </span>
                                </span>
                                <span class="pelanggan-code"><?php echo $row['kode_pelanggan']; ?></span>
                            </div>
                            
                            <div class="pelanggan-info">
                                <?php if ($row['alamat']): ?>
                                <div class="info-item">
                                    <i class="fas fa-map-marker-alt"></i>
                                    <span><?php echo $row['alamat']; ?></span>
                                </div>
                                <?php endif; ?>
                                <?php if ($row['no_telp']): ?>
                                <div class="info-item">
                                    <i class="fas fa-phone"></i>
                                    <span><?php echo $row['no_telp']; ?></span>
                                </div>
                                <?php endif; ?>
                                <?php if ($row['email']): ?>
                                <div class="info-item">
                                    <i class="fas fa-envelope"></i>
                                    <span><?php echo $row['email']; ?></span>
                                </div>
                                <?php endif; ?>
                                <?php if ($row['tanggal_lahir']): ?>
                                <div class="info-item">
                                    <i class="fas fa-birthday-cake"></i>
                                    <span><?php echo date('d F Y', strtotime($row['tanggal_lahir'])); ?></span>
                                </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="pelanggan-meta">
                                <span class="poin">
                                    <i class="fas fa-star"></i> <?php echo $row['poin'] ?? 0; ?> Poin
                                </span>
                                <span class="total-belanja">
                                    <i class="fas fa-shopping-cart"></i> <?php echo rupiah($row['total_belanja'] ?? 0); ?>
                                </span>
                                <div class="pelanggan-actions">
                                    <a href="?edit=<?php echo $row['id']; ?>" class="btn-action btn-edit" title="Edit Pelanggan">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="?delete=<?php echo $row['id']; ?>" onclick="return confirm('Yakin hapus pelanggan ini?')" class="btn-action btn-delete" title="Hapus Pelanggan">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php endwhile; ?>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-users"></i>
                        <p><?php echo $search ? 'Pelanggan tidak ditemukan' : 'Belum ada pelanggan. Silakan tambahkan pelanggan pertama!'; ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </main>

        <!-- Bottom Navigation -->
        <nav class="bottom-nav">
            <a href="../index.php"><i class="fas fa-home"></i><span>Dashboard</span></a>
            <a href="penjualan.php"><i class="fas fa-cash-register"></i><span>Kasir</span></a>
            <a href="pembelian.php"><i class="fas fa-truck"></i><span>Beli</span></a>
            <a href="produk.php"><i class="fas fa-box"></i><span>Produk</span></a>
            <a href="../laporan/laba_rugi.php"><i class="fas fa-chart-bar"></i><span>Laporan</span></a>
        </nav>
    </div>

    <script>
        // ============================================
        // AUTO-HIDE ALERT
        // ============================================
        document.addEventListener('DOMContentLoaded', function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(function(alert) {
                setTimeout(function() {
                    alert.style.transition = 'opacity 0.5s';
                    alert.style.opacity = '0';
                    setTimeout(function() {
                        alert.style.display = 'none';
                    }, 500);
                }, 5000);
            });
        });
    </script>
    <script src="../js/script.js"></script>
</body>
</html>