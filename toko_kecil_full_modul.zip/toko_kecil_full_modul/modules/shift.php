<?php
include '../config/database.php';

$message = '';
$shift_open = false;

// Cek apakah ada shift yang sedang berjalan
$current_shift = $conn->query("
    SELECT * FROM kasir_shift 
    WHERE user_id = {$_SESSION['user_id']} AND status = 'open'
")->fetch_assoc();

if ($current_shift) {
    $shift_open = true;
}

// Buka shift
if (isset($_POST['open_shift'])) {
    $awal_kas = $_POST['awal_kas'];
    $stmt = $conn->prepare("
        INSERT INTO kasir_shift (user_id, shift_start, awal_kas, status) 
        VALUES (?, NOW(), ?, 'open')
    ");
    $stmt->bind_param("id", $_SESSION['user_id'], $awal_kas);
    
    if ($stmt->execute()) {
        logActivity($conn, $_SESSION['user_id'], 'Buka Shift', "Awal Kas: $awal_kas");
        $message = '<div class="alert success">Shift berhasil dibuka!</div>';
        redirect('shift.php');
    } else {
        $message = '<div class="alert error">Gagal: ' . $conn->error . '</div>';
    }
}

// Tutup shift
if (isset($_POST['close_shift'])) {
    $id = $_POST['shift_id'];
    $akhir_kas = $_POST['akhir_kas'];
    
    // Hitung total penjualan selama shift
    $shift_data = $conn->query("SELECT shift_start FROM kasir_shift WHERE id = $id")->fetch_assoc();
    $total_penjualan = $conn->query("
        SELECT COALESCE(SUM(total_bayar), 0) as total 
        FROM penjualan 
        WHERE user_id = {$_SESSION['user_id']} 
        AND tanggal_penjualan = CURDATE() 
        AND created_at >= '{$shift_data['shift_start']}'
        AND status = 'selesai'
    ")->fetch_assoc()['total'];
    
    $total_transaksi = $conn->query("
        SELECT COUNT(*) as total 
        FROM penjualan 
        WHERE user_id = {$_SESSION['user_id']} 
        AND tanggal_penjualan = CURDATE() 
        AND created_at >= '{$shift_data['shift_start']}'
        AND status = 'selesai'
    ")->fetch_assoc()['total'];
    
    $selisih = $akhir_kas - ($current_shift['awal_kas'] + $total_penjualan);
    
    $stmt = $conn->prepare("
        UPDATE kasir_shift SET 
            shift_end = NOW(), 
            akhir_kas = ?, 
            total_penjualan = ?, 
            total_transaksi = ?, 
            selisih = ?, 
            status = 'closed' 
        WHERE id = ?
    ");
    $stmt->bind_param("ddiid", $akhir_kas, $total_penjualan, $total_transaksi, $selisih, $id);
    
    if ($stmt->execute()) {
        logActivity($conn, $_SESSION['user_id'], 'Tutup Shift', "Akhir Kas: $akhir_kas, Selisih: $selisih");
        $message = '<div class="alert success">Shift berhasil ditutup! Selisih: ' . rupiah($selisih) . '</div>';
        redirect('shift.php');
    } else {
        $message = '<div class="alert error">Gagal: ' . $conn->error . '</div>';
    }
}

// Riwayat shift
$riwayat_shift = $conn->query("
    SELECT * FROM kasir_shift 
    WHERE user_id = {$_SESSION['user_id']} 
    ORDER BY created_at DESC 
    LIMIT 20
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shift Kasir - Toko Kecil</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <!-- Header -->
        <header class="header">
            <a href="../index.php" class="back-btn"><i class="fas fa-arrow-left"></i></a>
            <h1><i class="fas fa-clock"></i> Shift Kasir</h1>
            <span></span>
        </header>

        <main class="main-content">
            <h2><i class="fas fa-clock"></i> Shift Kasir</h2>

            <?php echo $message; ?>

            <?php if ($shift_open): ?>
                <!-- Shift Sedang Berjalan -->
                <div class="form-card" style="border:2px solid #4CAF50;">
                    <h3 style="color:#4CAF50;">
                        <i class="fas fa-check-circle"></i> Shift Sedang Berjalan
                    </h3>
                    <div style="margin:10px 0;">
                        <p><strong>Dibuka:</strong> <?php echo date('d/m/Y H:i', strtotime($current_shift['shift_start'])); ?></p>
                        <p><strong>Awal Kas:</strong> <?php echo rupiah($current_shift['awal_kas']); ?></p>
                    </div>
                    
                    <form method="POST">
                        <input type="hidden" name="shift_id" value="<?php echo $current_shift['id']; ?>">
                        <div class="form-group">
                            <label>Kas Akhir</label>
                            <input type="number" name="akhir_kas" required placeholder="Masukkan jumlah kas akhir" class="form-control">
                        </div>
                        <button type="submit" name="close_shift" class="btn-submit" style="background:#f44336;">
                            <i class="fas fa-lock"></i> Tutup Shift
                        </button>
                    </form>
                </div>
            <?php else: ?>
                <!-- Buka Shift -->
                <div class="form-card">
                    <h3><i class="fas fa-play"></i> Buka Shift</h3>
                    <form method="POST">
                        <div class="form-group">
                            <label>Saldo Awal Kas</label>
                            <input type="number" name="awal_kas" required placeholder="Masukkan saldo awal" class="form-control" value="0">
                        </div>
                        <button type="submit" name="open_shift" class="btn-submit">
                            <i class="fas fa-play"></i> Buka Shift
                        </button>
                    </form>
                </div>
            <?php endif; ?>

            <!-- Riwayat Shift -->
            <div class="section">
                <h3><i class="fas fa-history"></i> Riwayat Shift</h3>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Tanggal</th>
                                <th>Mulai</th>
                                <th>Selesai</th>
                                <th>Awal Kas</th>
                                <th>Akhir Kas</th>
                                <th>Penjualan</th>
                                <th>Transaksi</th>
                                <th>Selisih</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $riwayat_shift->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo date('d/m/Y', strtotime($row['shift_start'])); ?></td>
                                <td><?php echo date('H:i', strtotime($row['shift_start'])); ?></td>
                                <td><?php echo $row['shift_end'] ? date('H:i', strtotime($row['shift_end'])) : '-'; ?></td>
                                <td><?php echo rupiah($row['awal_kas']); ?></td>
                                <td><?php echo $row['akhir_kas'] ? rupiah($row['akhir_kas']) : '-'; ?></td>
                                <td><?php echo rupiah($row['total_penjualan']); ?></td>
                                <td><?php echo $row['total_transaksi']; ?></td>
                                <td style="color: <?php echo ($row['selisih'] ?? 0) >= 0 ? '#4CAF50' : '#f44336'; ?>;">
                                    <?php echo $row['selisih'] !== null ? rupiah($row['selisih']) : '-'; ?>
                                </td>
                                <td>
                                    <span class="badge <?php echo $row['status'] == 'closed' ? 'badge-success' : 'badge-warning'; ?>">
                                        <?php echo $row['status']; ?>
                                    </span>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>

        <!-- Bottom Navigation -->
        <nav class="bottom-nav">
            <a href="../index.php"><i class="fas fa-home"></i><span>Dashboard</span></a>
            <a href="penjualan.php"><i class="fas fa-cash-register"></i><span>Kasir</span></a>
            <a href="pembelian.php"><i class="fas fa-truck"></i><span>Beli</span></a>
            <a href="produk.php"><i class="fas fa-box"></i><span>Produk</span></a>
            <a href="../laporan/laba_rugi.php"><i class="fas fa-chart-bar"></i><span>Laporan</span></a>
        </nav>
    </div>
    <script src="../js/script.js"></script>
</body>
</html>