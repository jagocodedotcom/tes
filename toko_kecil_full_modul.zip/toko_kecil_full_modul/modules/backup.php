<?php
include '../config/database.php';

// Hanya admin yang bisa backup
if (!hasRole('admin')) {
    redirect('../index.php');
}

$message = '';
$backup_dir = '../backup/';

// Buat folder backup jika belum ada
if (!is_dir($backup_dir)) {
    mkdir($backup_dir, 0777, true);
}

// Fungsi backup database
function backupDatabase($conn, $backup_dir) {
    $tables = array();
    $result = $conn->query("SHOW TABLES");
    while ($row = $result->fetch_row()) {
        $tables[] = $row[0];
    }

    $backup_data = "-- ============================================\n";
    $backup_data .= "-- BACKUP DATABASE: " . date('Y-m-d H:i:s') . "\n";
    $backup_data .= "-- ============================================\n\n";
    $backup_data .= "SET FOREIGN_KEY_CHECKS = 0;\n\n";

    foreach ($tables as $table) {
        $result = $conn->query("SELECT * FROM $table");
        $num_fields = $result->field_count;

        $backup_data .= "DROP TABLE IF EXISTS `$table`;\n";
        $create = $conn->query("SHOW CREATE TABLE $table")->fetch_row();
        $backup_data .= $create[1] . ";\n\n";

        if ($result->num_rows > 0) {
            $backup_data .= "INSERT INTO `$table` VALUES\n";
            $rows = [];
            while ($row = $result->fetch_row()) {
                $values = [];
                foreach ($row as $value) {
                    $values[] = is_null($value) ? 'NULL' : "'" . addslashes($value) . "'";
                }
                $rows[] = "(" . implode(', ', $values) . ")";
            }
            $backup_data .= implode(",\n", $rows) . ";\n\n";
        }
    }

    $backup_data .= "SET FOREIGN_KEY_CHECKS = 1;\n";

    // Simpan file
    $filename = $backup_dir . 'backup_' . date('Y-m-d_H-i-s') . '.sql';
    file_put_contents($filename, $backup_data);

    return $filename;
}

// Proses backup
if (isset($_GET['action']) && $_GET['action'] == 'backup') {
    $filename = backupDatabase($conn, $backup_dir);
    logActivity($conn, $_SESSION['user_id'], 'Backup Database', "File: " . basename($filename));
    $message = '<div class="alert success"><i class="fas fa-check-circle"></i> Backup berhasil! File: ' . basename($filename) . '</div>';
}

// Hapus backup
if (isset($_GET['delete'])) {
    $file = $backup_dir . $_GET['delete'];
    if (file_exists($file) && unlink($file)) {
        $message = '<div class="alert success"><i class="fas fa-check-circle"></i> File backup berhasil dihapus!</div>';
    }
}

// Restore backup
if (isset($_GET['restore'])) {
    $file = $backup_dir . $_GET['restore'];
    if (file_exists($file)) {
        $sql = file_get_contents($file);
        if ($conn->multi_query($sql)) {
            logActivity($conn, $_SESSION['user_id'], 'Restore Database', "File: " . basename($file));
            $message = '<div class="alert success"><i class="fas fa-check-circle"></i> Restore database berhasil!</div>';
        } else {
            $message = '<div class="alert error"><i class="fas fa-exclamation-circle"></i> Gagal restore: ' . $conn->error . '</div>';
        }
    }
}

// Daftar file backup
$backup_files = glob($backup_dir . '*.sql');
rsort($backup_files);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Backup Database - Toko Kecil</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <!-- Header -->
        <header class="header">
            <a href="../index.php" class="back-btn"><i class="fas fa-arrow-left"></i></a>
            <h1><i class="fas fa-database"></i> Backup & Restore</h1>
            <span></span>
        </header>

        <main class="main-content">
            <h2><i class="fas fa-database"></i> Backup & Restore Database</h2>

            <?php echo $message; ?>

            <!-- Tombol Backup -->
            <div class="form-card" style="text-align:center;">
                <h3>Buat Backup Baru</h3>
                <p style="color:var(--text-light);font-size:13px;margin-bottom:12px;">
                    Backup akan menyimpan seluruh data database ke file .sql
                </p>
                <a href="?action=backup" class="btn-submit" style="display:inline-block;width:auto;padding:12px 30px;background:#4CAF50;text-decoration:none;">
                    <i class="fas fa-download"></i> Backup Sekarang
                </a>
            </div>

            <!-- Daftar Backup -->
            <div class="section">
                <h3><i class="fas fa-list"></i> Daftar File Backup</h3>
                <?php if (count($backup_files) > 0): ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Nama File</th>
                                <th>Ukuran</th>
                                <th>Tanggal</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($backup_files as $file): 
                                $filename = basename($file);
                                $size = filesize($file);
                                $size_str = $size > 1048576 ? round($size/1048576, 2) . ' MB' : round($size/1024, 2) . ' KB';
                            ?>
                            <tr>
                                <td><small><?php echo $filename; ?></small></td>
                                <td><?php echo $size_str; ?></td>
                                <td><?php echo date('d/m/Y H:i', filemtime($file)); ?></td>
                                <td>
                                    <a href="<?php echo $file; ?>" download class="btn-primary" style="padding:4px 8px;font-size:11px;">
                                        <i class="fas fa-download"></i>
                                    </a>
                                    <a href="?restore=<?php echo $filename; ?>" onclick="return confirm('Yakin restore database? Data saat ini akan diganti!')" class="btn-primary" style="padding:4px 8px;font-size:11px;background:#FF9800;">
                                        <i class="fas fa-undo"></i>
                                    </a>
                                    <a href="?delete=<?php echo $filename; ?>" onclick="return confirm('Yakin hapus file backup ini?')" class="btn-danger" style="padding:4px 8px;font-size:11px;">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <p style="text-align:center;padding:20px;color:var(--text-light);">
                    <i class="fas fa-info-circle"></i> Belum ada file backup
                </p>
                <?php endif; ?>
            </div>
        </main>

        <!-- Bottom Navigation -->
        <nav class="bottom-nav">
            <a href="../index.php"><i class="fas fa-home"></i><span>Dashboard</span></a>
            <a href="penjualan.php"><i class="fas fa-cash-register"></i><span>Kasir</span></a>
            <a href="pembelian.php"><i class="fas fa-truck"></i><span>Beli</span></a>
            <a href="produk.php"><i class="fas fa-box"></i><span>Produk</span></a>
            <a href="../laporan/laba_rugi.php"><i class="fas fa-chart-bar"></i><span>Laporan</span></a>
        </nav>
    </div>
    <script src="../js/script.js"></script>
</body>
</html>