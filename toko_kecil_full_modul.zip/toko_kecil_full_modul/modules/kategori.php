<?php
include '../config/database.php';

$message = '';
$edit_data = null;
$search = $_GET['search'] ?? '';

// Hapus data
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $nama_kategori = $conn->query("SELECT nama_kategori FROM kategori WHERE id = $id")->fetch_assoc()['nama_kategori'];
    
    // Cek apakah kategori masih digunakan di produk
    $cek_produk = $conn->query("SELECT COUNT(*) as total FROM produk WHERE kategori_id = $id");
    $total_produk = $cek_produk->fetch_assoc()['total'];
    
    if ($total_produk > 0) {
        $message = '<div class="alert error"><i class="fas fa-exclamation-circle"></i> Kategori "' . $nama_kategori . '" tidak bisa dihapus karena masih digunakan oleh ' . $total_produk . ' produk!</div>';
    } else {
        if ($conn->query("DELETE FROM kategori WHERE id = $id")) {
            logActivity($conn, $_SESSION['user_id'], 'Hapus Kategori', "Kategori: $nama_kategori");
            $message = '<div class="alert success"><i class="fas fa-check-circle"></i> Kategori "' . $nama_kategori . '" berhasil dihapus!</div>';
        }
    }
}

// Edit - ambil data
if (isset($_GET['edit'])) {
    $result = $conn->query("SELECT * FROM kategori WHERE id = {$_GET['edit']}");
    $edit_data = $result->fetch_assoc();
}

// Simpan data
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'] ?? 0;
    $nama_kategori = trim($_POST['nama_kategori']);
    $deskripsi = trim($_POST['deskripsi']);

    if (empty($nama_kategori)) {
        $message = '<div class="alert error"><i class="fas fa-exclamation-circle"></i> Nama kategori tidak boleh kosong!</div>';
    } else {
        if ($id > 0) {
            $stmt = $conn->prepare("UPDATE kategori SET nama_kategori=?, deskripsi=? WHERE id=?");
            $stmt->bind_param("ssi", $nama_kategori, $deskripsi, $id);
            logActivity($conn, $_SESSION['user_id'], 'Update Kategori', "Kategori: $nama_kategori");
            $message = '<div class="alert success"><i class="fas fa-check-circle"></i> Kategori "' . $nama_kategori . '" berhasil diupdate!</div>';
        } else {
            $stmt = $conn->prepare("INSERT INTO kategori (nama_kategori, deskripsi) VALUES (?, ?)");
            $stmt->bind_param("ss", $nama_kategori, $deskripsi);
            logActivity($conn, $_SESSION['user_id'], 'Tambah Kategori', "Kategori: $nama_kategori");
            $message = '<div class="alert success"><i class="fas fa-check-circle"></i> Kategori "' . $nama_kategori . '" berhasil ditambahkan!</div>';
        }
        
        if ($stmt->execute()) {
            $edit_data = null;
            echo '<script>window.location.href = "kategori.php?success=1";</script>';
        } else {
            $message = '<div class="alert error"><i class="fas fa-exclamation-circle"></i> Gagal: ' . $conn->error . '</div>';
        }
    }
}

// Query dengan pencarian
$sql = "SELECT k.*, COUNT(p.id) as total_produk 
        FROM kategori k 
        LEFT JOIN produk p ON k.id = p.kategori_id 
        GROUP BY k.id";

if ($search) {
    $search = $conn->real_escape_string($search);
    $sql .= " WHERE k.nama_kategori LIKE '%$search%' 
              OR k.deskripsi LIKE '%$search%'";
}

$sql .= " ORDER BY k.nama_kategori ASC";
$kategori = $conn->query($sql);

// Warna random untuk icon kategori
$warna_kategori = ['#4CAF50', '#2196F3', '#FF9800', '#9C27B0', '#f44336', '#00BCD4', '#795548', '#607D8B', '#E91E63', '#3F51B5'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Manajemen Kategori - Toko Kecil</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* ============================================
           KATEGORI PAGE STYLES
           ============================================ */
        .form-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
            flex-wrap: wrap;
        }
        
        .form-header h3 {
            font-size: 16px;
            font-weight: 700;
            color: var(--primary-dark);
            margin: 0;
        }
        
        .form-header .badge-status {
            font-size: 11px;
            padding: 4px 12px;
            border-radius: 20px;
            background: #e3f2fd;
            color: #0d47a1;
        }
        
        /* Search Box */
        .search-box {
            display: flex;
            gap: 8px;
            margin-bottom: 12px;
            flex-wrap: wrap;
        }
        
        .search-box input {
            flex: 1;
            padding: 10px 14px;
            border: 2px solid #e8ecf1;
            border-radius: var(--radius-sm);
            font-size: 14px;
            min-width: 150px;
            transition: var(--transition);
        }
        
        .search-box input:focus {
            border-color: var(--primary-light);
            outline: none;
            box-shadow: 0 0 0 3px rgba(76, 175, 80, 0.1);
        }
        
        .search-box .btn-search {
            padding: 10px 18px;
            background: var(--primary-light);
            color: white;
            border: none;
            border-radius: var(--radius-sm);
            cursor: pointer;
            font-weight: 600;
            transition: var(--transition);
        }
        
        .search-box .btn-search:hover {
            background: var(--primary-dark);
        }
        
        .search-box .btn-clear {
            padding: 10px 18px;
            background: #f44336;
            color: white;
            border: none;
            border-radius: var(--radius-sm);
            cursor: pointer;
            font-weight: 600;
            transition: var(--transition);
        }
        
        .search-box .btn-clear:hover {
            background: #d32f2f;
        }
        
        .search-info {
            font-size: 11px;
            color: var(--text-light);
            margin-bottom: 10px;
        }
        
        .search-info strong {
            color: var(--text);
        }
        
        /* Kategori Card Grid */
        .kategori-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }
        
        .kategori-card {
            background: var(--card-bg);
            border-radius: var(--radius-sm);
            padding: 14px 14px;
            box-shadow: var(--shadow);
            transition: var(--transition);
            border-left: 4px solid var(--primary-light);
            display: flex;
            flex-direction: column;
            position: relative;
            overflow: hidden;
        }
        
        .kategori-card:active {
            transform: scale(0.97);
        }
        
        .kategori-card .kategori-icon {
            font-size: 28px;
            margin-bottom: 6px;
        }
        
        .kategori-card .kategori-name {
            font-size: 15px;
            font-weight: 700;
            color: var(--text);
            margin-bottom: 2px;
        }
        
        .kategori-card .kategori-deskripsi {
            font-size: 12px;
            color: var(--text-light);
            flex: 1;
            margin-bottom: 8px;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
        
        .kategori-card .kategori-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-top: 8px;
            border-top: 1px solid #f0f2f5;
            font-size: 11px;
            color: var(--text-light);
        }
        
        .kategori-card .kategori-meta .total-produk {
            background: #f0f4f8;
            padding: 2px 10px;
            border-radius: 12px;
            font-weight: 600;
            color: var(--text);
        }
        
        .kategori-card .kategori-actions {
            display: flex;
            gap: 4px;
        }
        
        .kategori-card .kategori-actions .btn-action {
            padding: 4px 8px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 11px;
            transition: var(--transition);
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 3px;
        }
        
        .kategori-card .kategori-actions .btn-edit {
            background: #2196F3;
            color: white;
        }
        
        .kategori-card .kategori-actions .btn-edit:hover {
            background: #1976D2;
        }
        
        .kategori-card .kategori-actions .btn-delete {
            background: #f44336;
            color: white;
        }
        
        .kategori-card .kategori-actions .btn-delete:hover {
            background: #d32f2f;
        }
        
        .kategori-card .kategori-actions .btn-view {
            background: #FF9800;
            color: white;
        }
        
        .kategori-card .kategori-actions .btn-view:hover {
            background: #e68900;
        }
        
        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: var(--text-light);
        }
        
        .empty-state i {
            font-size: 48px;
            color: #ddd;
            display: block;
            margin-bottom: 12px;
        }
        
        /* Responsive */
        @media (max-width: 480px) {
            .kategori-grid {
                grid-template-columns: 1fr;
            }
            
            .search-box input {
                min-width: 100px;
                font-size: 13px;
            }
            
            .search-box .btn-search,
            .search-box .btn-clear {
                padding: 8px 12px;
                font-size: 12px;
            }
            
            .kategori-card {
                padding: 12px 12px;
            }
            
            .kategori-card .kategori-icon {
                font-size: 22px;
            }
        }
        
        @media (min-width: 768px) {
            .kategori-grid {
                grid-template-columns: 1fr 1fr 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <header class="header">
            <a href="../index.php" class="back-btn"><i class="fas fa-arrow-left"></i></a>
            <h1><i class="fas fa-tags"></i> Manajemen Kategori</h1>
            <a href="notifikasi.php" class="btn-icon" style="position:relative;">
                <i class="fas fa-bell" style="font-size:18px;color:var(--text-light);"></i>
                <?php 
                $unread = $conn->query("SELECT COUNT(*) as total FROM notifikasi WHERE user_id = {$_SESSION['user_id']} AND is_read = 0");
                $unread_count = $unread->num_rows > 0 ? $unread->fetch_assoc()['total'] : 0;
                if ($unread_count > 0): 
                ?>
                <span class="badge-icon"><?php echo $unread_count; ?></span>
                <?php endif; ?>
            </a>
        </header>

        <main class="main-content">
            <?php echo $message; ?>
            
            <?php if (isset($_GET['success'])): ?>
            <div class="alert success"><i class="fas fa-check-circle"></i> Data berhasil disimpan!</div>
            <?php endif; ?>

            <!-- Form Kategori -->
            <div class="form-card">
                <div class="form-header">
                    <h3><i class="fas fa-<?php echo $edit_data ? 'edit' : 'plus-circle'; ?>"></i> <?php echo $edit_data ? 'Edit Kategori' : 'Tambah Kategori Baru'; ?></h3>
                    <?php if ($edit_data): ?>
                    <span class="badge-status"><i class="fas fa-pencil-alt"></i> Mode Edit</span>
                    <?php endif; ?>
                </div>
                
                <form method="POST">
                    <input type="hidden" name="id" value="<?php echo $edit_data['id'] ?? 0; ?>">
                    
                    <div class="form-group">
                        <label><i class="fas fa-tag"></i> Nama Kategori</label>
                        <input type="text" name="nama_kategori" value="<?php echo $edit_data['nama_kategori'] ?? ''; ?>" required class="form-control" placeholder="Masukkan nama kategori" autofocus>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-align-left"></i> Deskripsi</label>
                        <textarea name="deskripsi" class="form-control" rows="2" placeholder="Deskripsi kategori..."><?php echo $edit_data['deskripsi'] ?? ''; ?></textarea>
                    </div>
                    
                    <button type="submit" class="btn-submit">
                        <i class="fas fa-save"></i> <?php echo $edit_data ? 'Update Kategori' : 'Simpan Kategori'; ?>
                    </button>
                </form>
            </div>

            <!-- Pencarian Kategori -->
            <div class="section">
                <h3><i class="fas fa-search"></i> Cari Kategori</h3>
                <div class="search-box">
                    <input type="text" id="searchInput" placeholder="🔍 Cari nama atau deskripsi kategori..." 
                           value="<?php echo htmlspecialchars($search); ?>" 
                           onkeyup="if(event.key=='Enter') window.location.href='kategori.php?search='+encodeURIComponent(this.value)">
                    <button class="btn-search" onclick="window.location.href='kategori.php?search='+encodeURIComponent(document.getElementById('searchInput').value)">
                        <i class="fas fa-search"></i> Cari
                    </button>
                    <button class="btn-clear" onclick="window.location.href='kategori.php'">
                        <i class="fas fa-times"></i> Reset
                    </button>
                </div>
                <div class="search-info">
                    <i class="fas fa-info-circle"></i> 
                    Total: <strong><?php echo $kategori->num_rows; ?></strong> kategori ditemukan
                    <?php if ($search): ?>
                    <span style="margin-left:10px;">
                        <i class="fas fa-filter"></i> Filter: "<strong><?php echo htmlspecialchars($search); ?></strong>"
                        <a href="kategori.php" style="color:#f44336;margin-left:6px;text-decoration:none;">✕ Hapus</a>
                    </span>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Daftar Kategori - Card Grid -->
            <div class="section" style="padding:10px 12px;">
                <h3><i class="fas fa-list"></i> Daftar Kategori</h3>
                
                <?php if ($kategori->num_rows > 0): ?>
                    <div class="kategori-grid">
                        <?php 
                        $i = 0;
                        while ($row = $kategori->fetch_assoc()): 
                            $warna = $warna_kategori[$i % count($warna_kategori)];
                            $icons = ['fas fa-utensils', 'fas fa-glass-cheers', 'fas fa-home', 'fas fa-heartbeat', 'fas fa-microchip', 'fas fa-tshirt', 'fas fa-pen', 'fas fa-running', 'fas fa-car', 'fas fa-gamepad'];
                            $icon = $icons[$i % count($icons)];
                        ?>
                        <div class="kategori-card" style="border-left-color: <?php echo $warna; ?>;">
                            <div class="kategori-icon" style="color: <?php echo $warna; ?>;">
                                <i class="<?php echo $icon; ?>"></i>
                            </div>
                            <div class="kategori-name"><?php echo $row['nama_kategori']; ?></div>
                            <div class="kategori-deskripsi"><?php echo $row['deskripsi'] ?: 'Tidak ada deskripsi'; ?></div>
                            <div class="kategori-meta">
                                <span class="total-produk">
                                    <i class="fas fa-box"></i> <?php echo $row['total_produk']; ?> Produk
                                </span>
                                <div class="kategori-actions">
                                    <a href="?edit=<?php echo $row['id']; ?>" class="btn-action btn-edit" title="Edit Kategori">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="?delete=<?php echo $row['id']; ?>" onclick="return confirm('Yakin hapus kategori ini?')" class="btn-action btn-delete" title="Hapus Kategori">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                    <a href="produk.php?search=<?php echo urlencode($row['nama_kategori']); ?>" class="btn-action btn-view" title="Lihat Produk">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php 
                        $i++;
                        endwhile; 
                        ?>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-tags"></i>
                        <p><?php echo $search ? 'Kategori tidak ditemukan' : 'Belum ada kategori. Silakan tambahkan kategori pertama!'; ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </main>

        <!-- Bottom Navigation -->
        <nav class="bottom-nav">
            <a href="../index.php"><i class="fas fa-home"></i><span>Dashboard</span></a>
            <a href="penjualan.php"><i class="fas fa-cash-register"></i><span>Kasir</span></a>
            <a href="pembelian.php"><i class="fas fa-truck"></i><span>Beli</span></a>
            <a href="produk.php"><i class="fas fa-box"></i><span>Produk</span></a>
            <a href="../laporan/laba_rugi.php"><i class="fas fa-chart-bar"></i><span>Laporan</span></a>
        </nav>
    </div>

    <script>
        // ============================================
        // AUTO-HIDE ALERT
        // ============================================
        document.addEventListener('DOMContentLoaded', function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(function(alert) {
                setTimeout(function() {
                    alert.style.transition = 'opacity 0.5s';
                    alert.style.opacity = '0';
                    setTimeout(function() {
                        alert.style.display = 'none';
                    }, 500);
                }, 5000);
            });
        });
    </script>
    <script src="../js/script.js"></script>
</body>
</html>