<?php
include '../config/database.php';

$message = '';
$retur_data = null;

// ============================================
// UPDATE STATUS RETUR PEMBELIAN
// ============================================
if (isset($_GET['update_status']) && isset($_GET['status'])) {
    $id = $_GET['update_status'];
    $status = $_GET['status'];
    
    // Validasi status
    $valid_status = ['pending', 'approved', 'rejected'];
    if (in_array($status, $valid_status)) {
        $stmt = $conn->prepare("UPDATE retur_pembelian SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $status, $id);
        
        if ($stmt->execute()) {
            logActivity($conn, $_SESSION['user_id'], 'Update Status Retur Pembelian', "Retur ID: $id, Status: $status");
            $message = '<div class="alert success"><i class="fas fa-check-circle"></i> Status retur berhasil diupdate menjadi <strong>' . strtoupper($status) . '</strong>!</div>';
            
            if (isset($_GET['invoice'])) {
                echo '<script>window.location.href = "retur_pembelian.php?invoice=' . $_GET['invoice'] . '&status_updated=1";</script>';
                exit();
            } else {
                echo '<script>window.location.href = "retur_pembelian.php?status_updated=1";</script>';
                exit();
            }
        } else {
            $message = '<div class="alert error"><i class="fas fa-exclamation-circle"></i> Gagal update status: ' . $conn->error . '</div>';
        }
    }
}

// Cek jika ada parameter invoice
if (isset($_GET['invoice'])) {
    $id = $_GET['invoice'];
    $result = $conn->query("
        SELECT r.*, 
               p.nama_produk, p.kode_produk, p.satuan,
               pbl.no_po, pbl.tanggal_pembelian,
               s.nama_supplier,
               u.nama_lengkap as kasir
        FROM retur_pembelian r
        JOIN produk p ON r.produk_id = p.id
        LEFT JOIN pembelian pbl ON r.pembelian_id = pbl.id
        LEFT JOIN supplier s ON r.supplier_id = s.id
        LEFT JOIN users u ON r.user_id = u.id
        WHERE r.id = '$id'
    ");
    $retur_data = $result->fetch_assoc();
}

// Proses retur pembelian
if ($_SERVER['REQUEST_METHOD'] == 'POST' && !isset($_POST['print'])) {
    $pembelian_id = $_POST['pembelian_id'];
    $produk_id = $_POST['produk_id'];
    $supplier_id = $_POST['supplier_id'] ?: null;
    $jumlah = $_POST['jumlah'];
    $alasan = $_POST['alasan'];
    $tanggal = $_POST['tanggal'];

    // Ambil harga beli saat pembelian
    $harga_result = $conn->query("SELECT harga_beli_saat FROM pembelian WHERE id = $pembelian_id");
    $harga = $harga_result->fetch_assoc()['harga_beli_saat'];
    $total_retur = $jumlah * $harga;

    $stmt = $conn->prepare("
        INSERT INTO retur_pembelian (pembelian_id, produk_id, supplier_id, jumlah, harga_retur, total_retur, alasan, tanggal_retur, user_id, status) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')
    ");
    $stmt->bind_param("iiiddsssi", $pembelian_id, $produk_id, $supplier_id, $jumlah, $harga, $total_retur, $alasan, $tanggal, $_SESSION['user_id']);

    if ($stmt->execute()) {
        // Update status pembelian menjadi batal
        $conn->query("UPDATE pembelian SET status = 'batal' WHERE id = $pembelian_id");
        logActivity($conn, $_SESSION['user_id'], 'Retur Pembelian', "Retur ID: " . $conn->insert_id);
        
        echo '<script>window.location.href = "retur_pembelian.php?invoice=' . $conn->insert_id . '";</script>';
        exit();
    } else {
        $message = '<div class="alert error"><i class="fas fa-exclamation-circle"></i> Gagal: ' . $conn->error . '</div>';
    }
}

// Ambil daftar pembelian untuk dropdown
$pembelian_list = $conn->query("
    SELECT pbl.*, p.nama_produk, p.kode_produk, s.nama_supplier
    FROM pembelian pbl 
    JOIN produk p ON pbl.produk_id = p.id 
    LEFT JOIN supplier s ON pbl.supplier_id = s.id
    WHERE pbl.status = 'selesai' 
    ORDER BY pbl.created_at DESC 
    LIMIT 50
");

// Riwayat retur
$riwayat_retur = $conn->query("
    SELECT r.*, p.nama_produk, p.kode_produk, 
           pbl.no_po, s.nama_supplier, u.nama_lengkap as kasir
    FROM retur_pembelian r
    JOIN produk p ON r.produk_id = p.id
    LEFT JOIN pembelian pbl ON r.pembelian_id = pbl.id
    LEFT JOIN supplier s ON r.supplier_id = s.id
    LEFT JOIN users u ON r.user_id = u.id
    ORDER BY r.created_at DESC 
    LIMIT 20
");

// Ambil daftar supplier untuk dropdown
$supplier_list = $conn->query("SELECT * FROM supplier ORDER BY nama_supplier");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Retur Pembelian - Toko Kecil</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .invoice-container {
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            padding: 30px;
            margin-bottom: 20px;
            position: relative;
        }
        
        .invoice-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            border-bottom: 3px double #ff9800;
            padding-bottom: 15px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        
        .invoice-header .company-info h2 {
            color: #2E7D32;
            font-size: 24px;
            margin: 0;
        }
        
        .invoice-header .company-info p {
            margin: 4px 0;
            color: #666;
            font-size: 13px;
        }
        
        .invoice-header .invoice-info {
            text-align: right;
        }
        
        .invoice-header .invoice-info .invoice-title {
            font-size: 28px;
            font-weight: 700;
            color: #ff9800;
            letter-spacing: 2px;
        }
        
        .invoice-header .invoice-info .invoice-number {
            font-size: 18px;
            font-weight: 600;
            color: #333;
        }
        
        .invoice-body {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .invoice-body .info-box {
            background: #f8f9fa;
            padding: 12px 16px;
            border-radius: 8px;
            border-left: 4px solid #ff9800;
        }
        
        .invoice-body .info-box .label {
            font-size: 11px;
            color: #999;
            text-transform: uppercase;
            font-weight: 600;
            letter-spacing: 0.5px;
        }
        
        .invoice-body .info-box .value {
            font-size: 15px;
            font-weight: 500;
            color: #333;
            margin-top: 2px;
        }
        
        .invoice-table {
            width: 100%;
            border-collapse: collapse;
            margin: 15px 0;
        }
        
        .invoice-table th {
            background: #fff3e0;
            color: #e65100;
            padding: 10px 12px;
            text-align: left;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .invoice-table td {
            padding: 10px 12px;
            border-bottom: 1px solid #e8e8e8;
            font-size: 14px;
        }
        
        .invoice-table .total-row {
            background: #fff3e0;
            font-weight: 600;
        }
        
        .invoice-table .total-row td {
            border-top: 2px solid #ff9800;
            padding: 12px;
            font-size: 16px;
        }
        
        .invoice-table .total-row td:last-child {
            color: #e65100;
            font-size: 18px;
        }
        
        .invoice-footer {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
            padding-top: 15px;
            border-top: 2px solid #e8e8e8;
            flex-wrap: wrap;
        }
        
        .invoice-footer .signature {
            text-align: center;
            width: 200px;
        }
        
        .invoice-footer .signature .line {
            border-bottom: 1px solid #333;
            width: 150px;
            margin: 30px auto 5px;
        }
        
        .invoice-footer .signature .label {
            font-size: 11px;
            color: #999;
        }
        
        .invoice-actions {
            display: flex;
            gap: 10px;
            margin-top: 15px;
            flex-wrap: wrap;
        }
        
        .btn-print {
            padding: 10px 24px;
            background: #2196F3;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: 0.2s;
        }
        
        .btn-print:hover {
            background: #1976D2;
        }
        
        .btn-back {
            padding: 10px 24px;
            background: #757575;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: 0.2s;
            text-decoration: none;
        }
        
        .btn-back:hover {
            background: #616161;
        }
        
        .badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
        }
        
        .badge-success {
            background: #e8f5e9;
            color: #2e7d32;
        }
        
        .badge-warning {
            background: #fff3e0;
            color: #e65100;
        }
        
        .badge-danger {
            background: #ffebee;
            color: #c62828;
        }
        
        .text-danger {
            color: #f44336;
        }
        
        .text-success {
            color: #4CAF50;
        }
        
        .retur-alasan {
            background: #fff8e1;
            padding: 8px 12px;
            border-radius: 6px;
            border-left: 4px solid #ff9800;
            margin-top: 5px;
            font-size: 13px;
            color: #666;
        }
        
        .retur-alasan strong {
            color: #333;
        }
        
        /* ============================================
           STATUS BUTTONS
           ============================================ */
        .status-actions {
            display: flex;
            gap: 8px;
            margin-top: 10px;
            flex-wrap: wrap;
        }
        
        .btn-status {
            padding: 6px 16px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 12px;
            font-weight: 600;
            transition: 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            text-decoration: none;
        }
        
        .btn-status:hover {
            transform: scale(1.05);
        }
        
        .btn-status-pending {
            background: #ff9800;
            color: white;
        }
        
        .btn-status-approved {
            background: #4CAF50;
            color: white;
        }
        
        .btn-status-rejected {
            background: #f44336;
            color: white;
        }
        
        .btn-status-pending:hover {
            background: #e68900;
        }
        
        .btn-status-approved:hover {
            background: #388E3C;
        }
        
        .btn-status-rejected:hover {
            background: #d32f2f;
        }
        
        .btn-status .active {
            box-shadow: 0 0 0 3px rgba(0,0,0,0.2);
        }
        
        .status-badge {
            display: inline-block;
            padding: 6px 16px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 600;
            letter-spacing: 0.5px;
        }
        
        .status-badge-pending {
            background: #fff3e0;
            color: #e65100;
            border: 2px solid #ff9800;
        }
        
        .status-badge-approved {
            background: #e8f5e9;
            color: #2e7d32;
            border: 2px solid #4CAF50;
        }
        
        .status-badge-rejected {
            background: #ffebee;
            color: #c62828;
            border: 2px solid #f44336;
        }
        
        .status-edit-form {
            display: flex;
            gap: 8px;
            align-items: center;
            flex-wrap: wrap;
            padding: 10px 14px;
            background: #f5f5f5;
            border-radius: 8px;
            margin-top: 8px;
        }
        
        .status-edit-form label {
            font-weight: 500;
            font-size: 13px;
            color: var(--text-light);
        }
        
        .dropdown {
            display: inline-block;
            position: relative;
        }
        
        .dropdown-content {
            display: none;
            position: absolute;
            background: white;
            min-width: 120px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            border-radius: 4px;
            z-index: 100;
        }
        
        .dropdown:hover .dropdown-content {
            display: block;
        }
        
        .dropdown-content a {
            display: block;
            padding: 6px 12px;
            text-decoration: none;
            font-size: 11px;
            border-bottom: 1px solid #eee;
        }
        
        .dropdown-content a:hover {
            background: #f5f5f5;
        }
        
        @media print {
            .no-print { display: none !important; }
            .bottom-nav { display: none !important; }
            .container { max-width: 100% !important; padding: 0 !important; }
            .invoice-container { box-shadow: none !important; padding: 15px !important; }
            .btn-print, .btn-back { display: none !important; }
            .header { display: none !important; }
            .invoice-actions { display: none !important; }
        }
        
        @media (max-width: 768px) {
            .invoice-body {
                grid-template-columns: 1fr;
            }
            .invoice-header {
                flex-direction: column;
            }
            .invoice-header .invoice-info {
                text-align: left;
                margin-top: 10px;
            }
            .invoice-footer {
                flex-direction: column;
                align-items: center;
            }
            .invoice-container {
                padding: 15px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <header class="header">
            <a href="../index.php" class="back-btn"><i class="fas fa-arrow-left"></i></a>
            <h1><i class="fas fa-undo-alt"></i> Retur Pembelian</h1>
            <span></span>
        </header>

        <main class="main-content">
            <?php echo $message; ?>
            
            <?php if (isset($_GET['status_updated'])): ?>
            <div class="alert success"><i class="fas fa-check-circle"></i> Status retur berhasil diupdate!</div>
            <?php endif; ?>

            <!-- INVOICE RETUR VIEW -->
            <?php if ($retur_data): ?>
            <div class="invoice-container" id="invoiceContainer">
                <!-- Header Invoice -->
                <div class="invoice-header">
                    <div class="company-info">
                        <h2><i class="fas fa-store" style="color:#4CAF50;"></i> Toko Kecil</h2>
                        <p><i class="fas fa-map-marker-alt"></i> Jl. Toko No. 1, Jakarta</p>
                        <p><i class="fas fa-phone"></i> 021-555-0000</p>
                        <p><i class="fas fa-envelope"></i> info@tokokecil.com</p>
                    </div>
                    <div class="invoice-info">
                        <div class="invoice-title">RETUR PEMBELIAN</div>
                        <div class="invoice-number"># RETB-<?php echo str_pad($retur_data['id'], 6, '0', STR_PAD_LEFT); ?></div>
                        <div style="margin-top:8px;">
                            <span class="status-badge status-badge-<?php echo $retur_data['status']; ?>">
                                <i class="fas fa-<?php echo $retur_data['status'] == 'pending' ? 'clock' : ($retur_data['status'] == 'approved' ? 'check-circle' : 'times-circle'); ?>"></i>
                                <?php echo strtoupper($retur_data['status']); ?>
                            </span>
                        </div>
                    </div>
                </div>

                <!-- Body Invoice -->
                <div class="invoice-body">
                    <div class="info-box">
                        <div class="label"><i class="fas fa-receipt"></i> PO Asli</div>
                        <div class="value"><?php echo $retur_data['no_po'] ?? '-'; ?></div>
                        <div style="font-size:13px;color:#666;margin-top:4px;">
                            <i class="fas fa-calendar"></i> <?php echo date('d F Y', strtotime($retur_data['tanggal_pembelian'] ?? $retur_data['tanggal_retur'])); ?>
                        </div>
                    </div>
                    <div class="info-box">
                        <div class="label"><i class="fas fa-box"></i> Produk</div>
                        <div class="value"><?php echo $retur_data['nama_produk']; ?></div>
                        <div style="font-size:13px;color:#666;margin-top:4px;">
                            <i class="fas fa-barcode"></i> <?php echo $retur_data['kode_produk']; ?>
                        </div>
                    </div>
                    <div class="info-box">
                        <div class="label"><i class="fas fa-truck"></i> Supplier</div>
                        <div class="value"><?php echo $retur_data['nama_supplier'] ?? '-'; ?></div>
                        <div style="font-size:13px;color:#666;margin-top:4px;">
                            <i class="fas fa-user"></i> <?php echo $retur_data['kasir'] ?? 'Admin'; ?>
                        </div>
                    </div>
                </div>

                <!-- Tabel Retur -->
                <table class="invoice-table">
                    <thead>
                        <tr>
                            <th style="width:15%;">Kode</th>
                            <th style="width:35%;">Nama Produk</th>
                            <th style="width:15%;">Satuan</th>
                            <th style="width:10%;">Jumlah</th>
                            <th style="width:15%;">Harga Retur</th>
                            <th style="width:15%;">Total Retur</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo $retur_data['kode_produk']; ?></td>
                            <td><?php echo $retur_data['nama_produk']; ?></td>
                            <td><?php echo $retur_data['satuan'] ?? 'Pcs'; ?></td>
                            <td class="text-danger"><?php echo $retur_data['jumlah']; ?></td>
                            <td><?php echo rupiah($retur_data['harga_retur']); ?></td>
                            <td class="text-danger"><?php echo rupiah($retur_data['total_retur']); ?></td>
                        </tr>
                    </tbody>
                    <tfoot>
                        <tr class="total-row">
                            <td colspan="5" style="text-align:right;font-size:16px;">Total Retur</td>
                            <td style="font-size:18px;color:#e65100;">
                                <?php echo rupiah($retur_data['total_retur']); ?>
                            </td>
                        </tr>
                    </tfoot>
                </table>

                <!-- Alasan Retur -->
                <?php if ($retur_data['alasan']): ?>
                <div class="retur-alasan">
                    <strong><i class="fas fa-comment"></i> Alasan Retur:</strong> <?php echo $retur_data['alasan']; ?>
                </div>
                <?php endif; ?>

                <!-- Edit Status -->
                <div class="status-edit-form no-print">
                    <label><i class="fas fa-edit"></i> Ubah Status:</label>
                    
                    <a href="?update_status=<?php echo $retur_data['id']; ?>&status=pending&invoice=<?php echo $retur_data['id']; ?>" 
                       class="btn-status btn-status-pending <?php echo $retur_data['status'] == 'pending' ? 'active' : ''; ?>"
                       onclick="return confirm('Ubah status menjadi PENDING?')">
                        <i class="fas fa-clock"></i> Pending
                    </a>
                    
                    <a href="?update_status=<?php echo $retur_data['id']; ?>&status=approved&invoice=<?php echo $retur_data['id']; ?>" 
                       class="btn-status btn-status-approved <?php echo $retur_data['status'] == 'approved' ? 'active' : ''; ?>"
                       onclick="return confirm('Ubah status menjadi APPROVED? Stok akan otomatis berkurang.')">
                        <i class="fas fa-check-circle"></i> Approved
                    </a>
                    
                    <a href="?update_status=<?php echo $retur_data['id']; ?>&status=rejected&invoice=<?php echo $retur_data['id']; ?>" 
                       class="btn-status btn-status-rejected <?php echo $retur_data['status'] == 'rejected' ? 'active' : ''; ?>"
                       onclick="return confirm('Ubah status menjadi REJECTED?')">
                        <i class="fas fa-times-circle"></i> Rejected
                    </a>
                    
                    <span style="font-size:11px;color:var(--text-light);margin-left:auto;">
                        <i class="fas fa-info-circle"></i> Status aktif akan otomatis terupdate
                    </span>
                </div>

                <!-- Footer Invoice -->
                <div class="invoice-footer">
                    <div class="signature">
                        <div class="line"></div>
                        <div class="label">Supplier</div>
                    </div>
                    <div class="signature">
                        <div class="line"></div>
                        <div class="label">Kasir</div>
                    </div>
                    <div class="signature">
                        <div class="line"></div>
                        <div class="label">Manajer</div>
                    </div>
                </div>

                <!-- Tombol Aksi -->
                <div class="invoice-actions no-print">
                    <button class="btn-print" onclick="window.print()">
                        <i class="fas fa-print"></i> Cetak Retur
                    </button>
                    <a href="retur_pembelian.php" class="btn-back">
                        <i class="fas fa-arrow-left"></i> Kembali
                    </a>
                </div>
            </div>
            <?php else: ?>

            <!-- FORM RETUR PEMBELIAN -->
            <div class="form-card">
                <h3><i class="fas fa-undo-alt"></i> Form Retur Pembelian</h3>
                <form method="POST">
                    <div class="form-group">
                        <label><i class="fas fa-receipt"></i> Pilih Transaksi Pembelian</label>
                        <select name="pembelian_id" id="pembelianSelect" required class="form-control">
                            <option value="">-- Pilih PO --</option>
                            <?php while ($row = $pembelian_list->fetch_assoc()): ?>
                            <option value="<?php echo $row['id']; ?>" 
                                    data-produk="<?php echo $row['produk_id']; ?>" 
                                    data-supplier="<?php echo $row['supplier_id']; ?>"
                                    data-jumlah="<?php echo $row['jumlah']; ?>"
                                    data-harga="<?php echo $row['harga_beli_saat']; ?>"
                                    data-nama="<?php echo $row['nama_produk']; ?>"
                                    data-kode="<?php echo $row['kode_produk']; ?>"
                                    data-suppliernama="<?php echo $row['nama_supplier']; ?>">
                                <?php echo $row['no_po']; ?> - <?php echo $row['nama_produk']; ?> (<?php echo $row['jumlah']; ?> pcs) - Rp <?php echo number_format($row['harga_beli_saat'], 0, ',', '.'); ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label><i class="fas fa-barcode"></i> Kode Produk</label>
                            <input type="text" id="kodeProduk" readonly class="form-control" placeholder="-">
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-box"></i> Nama Produk</label>
                            <input type="text" id="namaProduk" readonly class="form-control" placeholder="-">
                        </div>
                    </div>

                    <div class="form-group">
                        <label><i class="fas fa-truck"></i> Supplier</label>
                        <input type="text" id="namaSupplier" readonly class="form-control" placeholder="-">
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label><i class="fas fa-hashtag"></i> Jumlah Retur</label>
                            <input type="number" name="jumlah" id="jumlahRetur" min="1" required class="form-control" placeholder="Masukkan jumlah retur">
                            <small id="maxRetur" style="color:var(--text-light);font-size:11px;"></small>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-tag"></i> Harga Retur</label>
                            <input type="number" name="harga" id="hargaRetur" readonly class="form-control" placeholder="0">
                        </div>
                    </div>

                    <input type="hidden" name="produk_id" id="produkId">
                    <input type="hidden" name="supplier_id" id="supplierId">

                    <div class="form-group">
                        <label><i class="fas fa-comment"></i> Alasan Retur</label>
                        <textarea name="alasan" class="form-control" rows="2" placeholder="Masukkan alasan retur..."></textarea>
                    </div>

                    <div class="form-group">
                        <label><i class="fas fa-calendar"></i> Tanggal Retur</label>
                        <input type="date" name="tanggal" value="<?php echo date('Y-m-d'); ?>" required class="form-control">
                    </div>

                    <div class="total-display" style="margin:12px 0;">
                        <span>Total Retur</span>
                        <span id="totalReturDisplay">Rp 0</span>
                    </div>

                    <button type="submit" class="btn-submit" style="background:#ff9800;">
                        <i class="fas fa-undo-alt"></i> Proses Retur Pembelian
                    </button>
                </form>
            </div>

            <!-- RIWAYAT RETUR -->
            <div class="section">
                <h3><i class="fas fa-history"></i> Riwayat Retur Pembelian</h3>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>ID Retur</th>
                                <th>PO</th>
                                <th>Tanggal</th>
                                <th>Produk</th>
                                <th>Jml</th>
                                <th>Total</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $riwayat_retur->fetch_assoc()): ?>
                            <tr>
                                <td><small>#RETB-<?php echo str_pad($row['id'], 6, '0', STR_PAD_LEFT); ?></small></td>
                                <td><?php echo $row['no_po'] ?? '-'; ?></td>
                                <td><?php echo date('d/m/Y', strtotime($row['tanggal_retur'])); ?></td>
                                <td><?php echo $row['nama_produk']; ?></td>
                                <td class="text-danger"><?php echo $row['jumlah']; ?></td>
                                <td class="text-danger"><?php echo rupiah($row['total_retur']); ?></td>
                                <td>
                                    <span class="badge <?php 
                                        echo $row['status'] == 'pending' ? 'badge-warning' : 
                                            ($row['status'] == 'approved' ? 'badge-success' : 'badge-danger'); 
                                    ?>">
                                        <?php echo $row['status']; ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="?invoice=<?php echo $row['id']; ?>" class="btn-primary" style="padding:4px 8px;font-size:11px;">
                                        <i class="fas fa-file-invoice"></i>
                                    </a>
                                    <div class="dropdown" style="display:inline-block;position:relative;">
                                        <button class="btn-primary" style="padding:4px 8px;font-size:11px;background:#9C27B0;border:none;border-radius:4px;cursor:pointer;">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <div class="dropdown-content" style="display:none;position:absolute;background:white;min-width:120px;box-shadow:0 4px 8px rgba(0,0,0,0.1);border-radius:4px;z-index:100;">
                                            <a href="?update_status=<?php echo $row['id']; ?>&status=pending" style="display:block;padding:6px 12px;color:#e65100;text-decoration:none;font-size:11px;border-bottom:1px solid #eee;">
                                                <i class="fas fa-clock"></i> Pending
                                            </a>
                                            <a href="?update_status=<?php echo $row['id']; ?>&status=approved" style="display:block;padding:6px 12px;color:#2e7d32;text-decoration:none;font-size:11px;border-bottom:1px solid #eee;" onclick="return confirm('Ubah status menjadi APPROVED? Stok akan otomatis berkurang.')">
                                                <i class="fas fa-check-circle"></i> Approved
                                            </a>
                                            <a href="?update_status=<?php echo $row['id']; ?>&status=rejected" style="display:block;padding:6px 12px;color:#c62828;text-decoration:none;font-size:11px;" onclick="return confirm('Ubah status menjadi REJECTED?')">
                                                <i class="fas fa-times-circle"></i> Rejected
                                            </a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>
        </main>

        <!-- Bottom Navigation -->
        <nav class="bottom-nav">
            <a href="../index.php"><i class="fas fa-home"></i><span>Dashboard</span></a>
            <a href="penjualan.php"><i class="fas fa-cash-register"></i><span>Kasir</span></a>
            <a href="pembelian.php"><i class="fas fa-truck"></i><span>Beli</span></a>
            <a href="produk.php"><i class="fas fa-box"></i><span>Produk</span></a>
            <a href="../laporan/laba_rugi.php"><i class="fas fa-chart-bar"></i><span>Laporan</span></a>
        </nav>
    </div>

    <script>
        // ============================================
        // AUTO FILL DATA PRODUK SAAT PILIH PEMBELIAN
        // ============================================
        document.getElementById('pembelianSelect').addEventListener('change', function() {
            const selected = this.options[this.selectedIndex];
            if (selected.value) {
                document.getElementById('produkId').value = selected.dataset.produk;
                document.getElementById('supplierId').value = selected.dataset.supplier || '';
                document.getElementById('kodeProduk').value = selected.dataset.kode || '-';
                document.getElementById('namaProduk').value = selected.dataset.nama || '-';
                document.getElementById('namaSupplier').value = selected.dataset.suppliernama || '-';
                document.getElementById('hargaRetur').value = selected.dataset.harga || 0;
                document.getElementById('jumlahRetur').max = selected.dataset.jumlah || 0;
                document.getElementById('maxRetur').textContent = 'Maksimal retur: ' + (selected.dataset.jumlah || 0) + ' pcs';
                document.getElementById('jumlahRetur').value = 1;
                hitungTotalRetur();
            }
        });

        // ============================================
        // HITUNG TOTAL RETUR
        // ============================================
        function hitungTotalRetur() {
            const jumlah = parseInt(document.getElementById('jumlahRetur').value) || 0;
            const harga = parseInt(document.getElementById('hargaRetur').value) || 0;
            const total = jumlah * harga;
            document.getElementById('totalReturDisplay').textContent = 'Rp ' + total.toLocaleString('id-ID');
            
            // Validasi stok retur
            const maxRetur = parseInt(document.getElementById('jumlahRetur').max) || 0;
            const btnSubmit = document.querySelector('button[type="submit"]');
            if (jumlah > maxRetur && maxRetur > 0) {
                document.getElementById('totalReturDisplay').style.color = '#f44336';
                btnSubmit.disabled = true;
                btnSubmit.style.opacity = '0.5';
                btnSubmit.innerHTML = '<i class="fas fa-exclamation-circle"></i> Jumlah melebihi batas!';
            } else {
                document.getElementById('totalReturDisplay').style.color = '';
                btnSubmit.disabled = false;
                btnSubmit.style.opacity = '1';
                btnSubmit.innerHTML = '<i class="fas fa-undo-alt"></i> Proses Retur Pembelian';
            }
        }

        document.getElementById('jumlahRetur').addEventListener('input', hitungTotalRetur);
        document.getElementById('hargaRetur').addEventListener('input', hitungTotalRetur);

        // ============================================
        // DROPDOWN EDIT STATUS
        // ============================================
        document.querySelectorAll('.dropdown').forEach(function(dropdown) {
            dropdown.addEventListener('mouseenter', function() {
                this.querySelector('.dropdown-content').style.display = 'block';
            });
            dropdown.addEventListener('mouseleave', function() {
                this.querySelector('.dropdown-content').style.display = 'none';
            });
        });

        // ============================================
        // AUTO-HIDE ALERT
        // ============================================
        document.addEventListener('DOMContentLoaded', function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(function(alert) {
                setTimeout(function() {
                    alert.style.transition = 'opacity 0.5s';
                    alert.style.opacity = '0';
                    setTimeout(function() {
                        alert.style.display = 'none';
                    }, 500);
                }, 5000);
            });
        });
    </script>
    <script src="../js/script.js"></script>
</body>
</html>