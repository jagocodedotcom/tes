<?php
include '../config/database.php';

// Hanya admin dan manager yang bisa akses
if (!hasRole('admin') && !hasRole('manager')) {
    redirect('../index.php');
}

$message = '';
$edit_data = null;

// Hapus user (tidak bisa hapus sendiri)
if (isset($_GET['delete']) && $_GET['delete'] != $_SESSION['user_id']) {
    $id = $_GET['delete'];
    if ($conn->query("DELETE FROM users WHERE id = $id")) {
        logActivity($conn, $_SESSION['user_id'], 'Hapus User', "User ID: $id");
        $message = '<div class="alert success">User berhasil dihapus!</div>';
    }
}

// Edit - ambil data
if (isset($_GET['edit'])) {
    $result = $conn->query("SELECT * FROM users WHERE id = {$_GET['edit']}");
    $edit_data = $result->fetch_assoc();
}

// Simpan data
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'] ?? 0;
    $username = $_POST['username'];
    $password = $_POST['password'];
    $nama_lengkap = $_POST['nama_lengkap'];
    $role = $_POST['role'];
    $no_telp = $_POST['no_telp'];
    $alamat = $_POST['alamat'];
    $is_active = $_POST['is_active'] ?? 1;

    if ($id > 0) {
        // Update
        if ($password) {
            $stmt = $conn->prepare("
                UPDATE users SET 
                    username=?, password=MD5(?), nama_lengkap=?, role=?, no_telp=?, alamat=?, is_active=? 
                WHERE id=?
            ");
            $stmt->bind_param("ssssssii", $username, $password, $nama_lengkap, $role, $no_telp, $alamat, $is_active, $id);
        } else {
            $stmt = $conn->prepare("
                UPDATE users SET 
                    username=?, nama_lengkap=?, role=?, no_telp=?, alamat=?, is_active=? 
                WHERE id=?
            ");
            $stmt->bind_param("sssssii", $username, $nama_lengkap, $role, $no_telp, $alamat, $is_active, $id);
        }
        logActivity($conn, $_SESSION['user_id'], 'Update User', "User: $username");
        $message = '<div class="alert success">User berhasil diupdate!</div>';
    } else {
        // Insert
        if (empty($password)) {
            $message = '<div class="alert error">Password harus diisi untuk user baru!</div>';
        } else {
            $stmt = $conn->prepare("
                INSERT INTO users (username, password, nama_lengkap, role, no_telp, alamat, is_active) 
                VALUES (?, MD5(?), ?, ?, ?, ?, ?)
            ");
            $stmt->bind_param("ssssssi", $username, $password, $nama_lengkap, $role, $no_telp, $alamat, $is_active);
            logActivity($conn, $_SESSION['user_id'], 'Tambah User', "User: $username");
            $message = '<div class="alert success">User berhasil ditambahkan!</div>';
        }
    }
    
    if (isset($stmt) && $stmt->execute()) {
        $edit_data = null;
    } elseif (isset($stmt) && !$stmt->execute()) {
        $message = '<div class="alert error">Gagal: ' . $conn->error . '</div>';
    }
}

// Ambil semua user
$users = $conn->query("SELECT * FROM users ORDER BY nama_lengkap");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen User - Toko Kecil</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <!-- Header -->
        <header class="header">
            <a href="../index.php" class="back-btn"><i class="fas fa-arrow-left"></i></a>
            <h1><i class="fas fa-users-cog"></i> Manajemen User</h1>
            <span></span>
        </header>

        <main class="main-content">
            <?php echo $message; ?>

            <div class="form-card">
                <h3><?php echo $edit_data ? 'Edit User' : 'Tambah User'; ?></h3>
                <form method="POST">
                    <input type="hidden" name="id" value="<?php echo $edit_data['id'] ?? 0; ?>">
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>Username</label>
                            <input type="text" name="username" value="<?php echo $edit_data['username'] ?? ''; ?>" required class="form-control">
                        </div>
                        <div class="form-group">
                            <label>Password <?php echo $edit_data ? '(Kosongkan jika tidak diubah)' : ''; ?></label>
                            <input type="password" name="password" <?php echo $edit_data ? '' : 'required'; ?> class="form-control" placeholder="Min 6 karakter">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label>Nama Lengkap</label>
                            <input type="text" name="nama_lengkap" value="<?php echo $edit_data['nama_lengkap'] ?? ''; ?>" required class="form-control">
                        </div>
                        <div class="form-group">
                            <label>Role</label>
                            <select name="role" class="form-control">
                                <option value="admin" <?php echo ($edit_data['role'] ?? '') == 'admin' ? 'selected' : ''; ?>>Admin</option>
                                <option value="manager" <?php echo ($edit_data['role'] ?? '') == 'manager' ? 'selected' : ''; ?>>Manager</option>
                                <option value="kasir" <?php echo ($edit_data['role'] ?? '') == 'kasir' ? 'selected' : ''; ?>>Kasir</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>No. Telp</label>
                        <input type="text" name="no_telp" value="<?php echo $edit_data['no_telp'] ?? ''; ?>" class="form-control">
                    </div>

                    <div class="form-group">
                        <label>Alamat</label>
                        <textarea name="alamat" class="form-control" rows="2"><?php echo $edit_data['alamat'] ?? ''; ?></textarea>
                    </div>

                    <div class="form-group">
                        <label>Status</label>
                        <select name="is_active" class="form-control">
                            <option value="1" <?php echo ($edit_data['is_active'] ?? 1) == 1 ? 'selected' : ''; ?>>Aktif</option>
                            <option value="0" <?php echo ($edit_data['is_active'] ?? 1) == 0 ? 'selected' : ''; ?>>Nonaktif</option>
                        </select>
                    </div>

                    <button type="submit" class="btn-submit"><i class="fas fa-save"></i> <?php echo $edit_data ? 'Update' : 'Simpan'; ?></button>
                </form>
            </div>

            <div class="section">
                <h3><i class="fas fa-list"></i> Daftar User</h3>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Username</th>
                                <th>Nama</th>
                                <th>Role</th>
                                <th>Telp</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $users->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $row['username']; ?></td>
                                <td><?php echo $row['nama_lengkap']; ?></td>
                                <td><span class="badge badge-success"><?php echo $row['role']; ?></span></td>
                                <td><?php echo $row['no_telp']; ?></td>
                                <td>
                                    <span class="badge <?php echo $row['is_active'] ? 'badge-success' : 'badge-danger'; ?>">
                                        <?php echo $row['is_active'] ? 'Aktif' : 'Nonaktif'; ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($row['id'] != $_SESSION['user_id']): ?>
                                    <a href="?edit=<?php echo $row['id']; ?>" class="btn-primary" style="padding:4px 8px;font-size:11px;">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="?delete=<?php echo $row['id']; ?>" onclick="return confirm('Yakin hapus user ini?')" class="btn-danger" style="padding:4px 8px;font-size:11px;">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                    <?php else: ?>
                                    <span style="color:var(--text-light);font-size:11px;">(Anda)</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>

        <!-- Bottom Navigation -->
        <nav class="bottom-nav">
            <a href="../index.php"><i class="fas fa-home"></i><span>Dashboard</span></a>
            <a href="penjualan.php"><i class="fas fa-cash-register"></i><span>Kasir</span></a>
            <a href="pembelian.php"><i class="fas fa-truck"></i><span>Beli</span></a>
            <a href="produk.php"><i class="fas fa-box"></i><span>Produk</span></a>
            <a href="../laporan/laba_rugi.php"><i class="fas fa-chart-bar"></i><span>Laporan</span></a>
        </nav>
    </div>
    <script src="../js/script.js"></script>
</body>
</html>