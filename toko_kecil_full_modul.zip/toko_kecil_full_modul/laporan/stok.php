<?php
include '../config/database.php';

// ============================================
// DATA STOK
// ============================================

// Ambil semua data stok
$stok = $conn->query("
    SELECT p.*, k.nama_kategori, s.nama_supplier 
    FROM produk p 
    LEFT JOIN kategori k ON p.kategori_id = k.id 
    LEFT JOIN supplier s ON p.supplier_id = s.id 
    ORDER BY p.stok ASC
");

// Hitung total stok dan nilai
$total_stok = 0;
$total_nilai = 0;
$total_produk = 0;
$stok_menipis_count = 0;
$stok_kosong_count = 0;
$stok_aman_count = 0;

$data_stok = [];
while ($row = $stok->fetch_assoc()) {
    $nilai = $row['stok'] * $row['harga_beli'];
    $total_stok += $row['stok'];
    $total_nilai += $nilai;
    $total_produk++;
    
    if ($row['stok'] <= 0) {
        $stok_kosong_count++;
    } elseif ($row['stok'] <= $row['stok_minimal']) {
        $stok_menipis_count++;
    } else {
        $stok_aman_count++;
    }
    
    $data_stok[] = $row;
}

// Re-run query untuk tampilan
$stok->data_seek(0);

// Kategori dengan stok terbanyak
$kategori_stok = $conn->query("
    SELECT k.nama_kategori, SUM(p.stok) as total_stok, SUM(p.stok * p.harga_beli) as total_nilai
    FROM produk p
    LEFT JOIN kategori k ON p.kategori_id = k.id
    GROUP BY k.id
    ORDER BY total_stok DESC
    LIMIT 5
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Laporan Stok - Toko Kecil</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* ============================================
           LAPORAN STOK STYLE
           ============================================ */
        .report-header {
            background: linear-gradient(135deg, #0D47A1 0%, #2196F3 100%);
            color: white;
            padding: 20px 24px;
            border-radius: var(--radius);
            margin-bottom: 20px;
            box-shadow: var(--shadow);
        }
        
        .report-header h2 {
            font-size: 22px;
            font-weight: 700;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .report-header p {
            margin: 6px 0 0 0;
            opacity: 0.9;
            font-size: 14px;
        }
        
        .report-header .period {
            font-size: 13px;
            opacity: 0.8;
            margin-top: 4px;
        }
        
        /* Export buttons */
        .export-section {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        
        .export-section .btn-export {
            padding: 10px 20px;
            border: none;
            border-radius: var(--radius-sm);
            cursor: pointer;
            font-weight: 600;
            font-size: 13px;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
            color: white;
        }
        
        .export-section .btn-export:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 16px rgba(0,0,0,0.2);
        }
        
        .export-section .btn-export:active {
            transform: scale(0.97);
        }
        
        .export-section .btn-excel {
            background: #217346;
        }
        
        .export-section .btn-excel:hover {
            background: #1a5c38;
        }
        
        .export-section .btn-print {
            background: #1976D2;
        }
        
        .export-section .btn-print:hover {
            background: #0d47a1;
        }
        
        /* Summary Cards */
        .summary-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 12px;
            margin-bottom: 20px;
        }
        
        .summary-card {
            background: var(--card-bg);
            border-radius: var(--radius-sm);
            padding: 16px 18px;
            box-shadow: var(--shadow);
            transition: var(--transition);
        }
        
        .summary-card:active {
            transform: scale(0.97);
        }
        
        .summary-card .summary-icon {
            font-size: 28px;
            margin-bottom: 6px;
        }
        
        .summary-card .summary-label {
            font-size: 11px;
            color: var(--text-light);
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.3px;
        }
        
        .summary-card .summary-value {
            font-size: 20px;
            font-weight: 700;
            margin-top: 2px;
        }
        
        .summary-card .summary-sub {
            font-size: 12px;
            color: var(--text-light);
            margin-top: 2px;
        }
        
        .summary-card.primary { border-left: 4px solid #2196F3; }
        .summary-card.success { border-left: 4px solid #4CAF50; }
        .summary-card.warning { border-left: 4px solid #FF9800; }
        .summary-card.danger { border-left: 4px solid #f44336; }
        .summary-card.purple { border-left: 4px solid #9C27B0; }
        
        .text-success { color: #4CAF50; }
        .text-danger { color: #f44336; }
        .text-warning { color: #FF9800; }
        .text-primary { color: #2196F3; }
        .text-purple { color: #9C27B0; }
        
        /* Charts */
        .chart-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
            margin-bottom: 20px;
        }
        
        .chart-box {
            background: var(--card-bg);
            border-radius: var(--radius);
            padding: 16px 18px;
            box-shadow: var(--shadow);
        }
        
        .chart-box h4 {
            font-size: 14px;
            font-weight: 600;
            margin: 0 0 12px 0;
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--text);
        }
        
        .chart-box h4 i {
            color: #2196F3;
        }
        
        .chart-container {
            position: relative;
            height: 200px;
            width: 100%;
        }
        
        /* Detail Table */
        .detail-table {
            background: var(--card-bg);
            border-radius: var(--radius);
            padding: 16px 18px;
            box-shadow: var(--shadow);
            margin-bottom: 20px;
        }
        
        .detail-table h4 {
            font-size: 14px;
            font-weight: 600;
            margin: 0 0 12px 0;
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--text);
        }
        
        .detail-table h4 i {
            color: #2196F3;
        }
        
        .detail-table .table-responsive {
            margin: 0 -4px;
        }
        
        .detail-table table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
            min-width: 600px;
        }
        
        .detail-table table th {
            background: #e3f2fd;
            padding: 10px 12px;
            text-align: left;
            font-weight: 600;
            color: #0d47a1;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-bottom: 2px solid #90caf9;
        }
        
        .detail-table table td {
            padding: 10px 12px;
            border-bottom: 1px solid #f0f2f5;
        }
        
        .detail-table table .total-row {
            background: #e3f2fd;
            font-weight: 700;
            border-top: 2px solid #2196F3;
        }
        
        .detail-table table .total-row td {
            padding: 12px;
            color: #0d47a1;
        }
        
        .detail-table table .empty-row td {
            text-align: center;
            padding: 30px;
            color: var(--text-light);
        }
        
        .badge {
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 10px;
            font-weight: 600;
            display: inline-block;
        }
        
        .badge-success {
            background: #e8f5e9;
            color: #2e7d32;
        }
        
        .badge-danger {
            background: #ffebee;
            color: #c62828;
        }
        
        .badge-warning {
            background: #fff3e0;
            color: #e65100;
        }
        
        .badge-info {
            background: #e3f2fd;
            color: #0d47a1;
        }
        
        .status-dot {
            display: inline-block;
            width: 10px;
            height: 10px;
            border-radius: 50%;
            margin-right: 4px;
        }
        
        .status-dot.aman { background: #4CAF50; }
        .status-dot.menipis { background: #FF9800; }
        .status-dot.kosong { background: #f44336; }
        
        /* Responsive */
        @media (max-width: 768px) {
            .summary-grid {
                grid-template-columns: 1fr 1fr;
            }
            
            .chart-grid {
                grid-template-columns: 1fr;
            }
            
            .export-section {
                justify-content: center;
            }
            
            .export-section .btn-export {
                flex: 1;
                justify-content: center;
                min-width: 100px;
            }
        }
        
        @media (max-width: 480px) {
            .summary-grid {
                grid-template-columns: 1fr 1fr;
                gap: 8px;
            }
            
            .summary-card {
                padding: 12px 14px;
            }
            
            .summary-card .summary-value {
                font-size: 16px;
            }
            
            .report-header {
                padding: 16px 18px;
            }
            
            .report-header h2 {
                font-size: 18px;
            }
            
            .detail-table {
                padding: 12px;
            }
            
            .export-section .btn-export {
                font-size: 11px;
                padding: 8px 12px;
                min-width: 80px;
            }
        }
        
        @media print {
            .no-print { display: none !important; }
            .bottom-nav { display: none !important; }
            .container { max-width: 100% !important; padding: 0 !important; }
            .report-header { background: #0D47A1 !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            .summary-card { box-shadow: none !important; border: 1px solid #ddd; }
            .chart-box { box-shadow: none !important; border: 1px solid #ddd; }
            .detail-table { box-shadow: none !important; border: 1px solid #ddd; }
            .export-section { display: none !important; }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <header class="header no-print">
            <a href="../index.php" class="back-btn"><i class="fas fa-arrow-left"></i></a>
            <h1><i class="fas fa-cubes"></i> Laporan Stok</h1>
            <span></span>
        </header>

        <main class="main-content">
            <!-- Report Header -->
            <div class="report-header">
                <h2><i class="fas fa-warehouse"></i> Laporan Stok Barang</h2>
                <p>Per <strong><?php echo date('d F Y'); ?></strong></p>
                <div class="period">
                    <i class="fas fa-info-circle"></i> 
                    Total Produk: <strong><?php echo $total_produk; ?></strong> item
                    | Total Nilai Stok: <strong><?php echo rupiah($total_nilai); ?></strong>
                </div>
            </div>

            <!-- Export Section -->
            <div class="export-section no-print">
                <a href="export_excel.php?type=stok" class="btn-export btn-excel">
                    <i class="fas fa-file-excel"></i> Export Excel
                </a>
                <button class="btn-export btn-print" onclick="window.print()">
                    <i class="fas fa-print"></i> Cetak
                </button>
            </div>

            <!-- Summary Cards -->
            <div class="summary-grid">
                <div class="summary-card primary">
                    <div class="summary-icon">📦</div>
                    <div class="summary-label">Total Produk</div>
                    <div class="summary-value text-primary"><?php echo $total_produk; ?></div>
                    <div class="summary-sub">Item produk terdaftar</div>
                </div>
                <div class="summary-card success">
                    <div class="summary-icon">✅</div>
                    <div class="summary-label">Stok Aman</div>
                    <div class="summary-value text-success"><?php echo $stok_aman_count; ?></div>
                    <div class="summary-sub">Stok di atas minimal</div>
                </div>
                <div class="summary-card warning">
                    <div class="summary-icon">⚠️</div>
                    <div class="summary-label">Stok Menipis</div>
                    <div class="summary-value text-warning"><?php echo $stok_menipis_count; ?></div>
                    <div class="summary-sub">Perlu segera restok</div>
                </div>
                <div class="summary-card danger">
                    <div class="summary-icon">🚫</div>
                    <div class="summary-label">Stok Kosong</div>
                    <div class="summary-value text-danger"><?php echo $stok_kosong_count; ?></div>
                    <div class="summary-sub">Segera diisi!</div>
                </div>
                <div class="summary-card purple" style="grid-column: span 2;">
                    <div class="summary-icon">💰</div>
                    <div class="summary-label">Total Nilai Stok</div>
                    <div class="summary-value text-purple" style="font-size: 24px;"><?php echo rupiah($total_nilai); ?></div>
                    <div class="summary-sub">
                        <i class="fas fa-box"></i> <?php echo $total_stok; ?> unit barang
                        | Rata-rata per produk: <?php echo $total_produk > 0 ? rupiah($total_nilai / $total_produk) : rupiah(0); ?>
                    </div>
                </div>
            </div>

            <!-- Charts -->
            <div class="chart-grid">
                <div class="chart-box">
                    <h4><i class="fas fa-chart-doughnut"></i> Status Stok</h4>
                    <div class="chart-container">
                        <canvas id="chartStatusStok"></canvas>
                    </div>
                </div>
                <div class="chart-box">
                    <h4><i class="fas fa-chart-bar"></i> Stok per Kategori (Top 5)</h4>
                    <div class="chart-container">
                        <canvas id="chartKategoriStok"></canvas>
                    </div>
                </div>
            </div>

            <!-- Detail Stok -->
            <div class="detail-table">
                <h4><i class="fas fa-list"></i> Detail Stok Barang</h4>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Kode</th>
                                <th>Nama Produk</th>
                                <th>Kategori</th>
                                <th style="text-align:center;">Stok</th>
                                <th style="text-align:center;">Minimal</th>
                                <th style="text-align:center;">Status</th>
                                <th style="text-align:right;">Nilai Stok</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($stok->num_rows > 0): ?>
                                <?php 
                                $no = 1;
                                while ($row = $stok->fetch_assoc()): 
                                    $nilai = $row['stok'] * $row['harga_beli'];
                                    if ($row['stok'] <= 0) {
                                        $status = 'Kosong';
                                        $status_class = 'danger';
                                        $dot_class = 'kosong';
                                    } elseif ($row['stok'] <= $row['stok_minimal']) {
                                        $status = 'Menipis';
                                        $status_class = 'warning';
                                        $dot_class = 'menipis';
                                    } else {
                                        $status = 'Aman';
                                        $status_class = 'success';
                                        $dot_class = 'aman';
                                    }
                                ?>
                                <tr>
                                    <td><small><?php echo $row['kode_produk']; ?></small></td>
                                    <td><?php echo $row['nama_produk']; ?></td>
                                    <td><?php echo $row['nama_kategori'] ?? '-'; ?></td>
                                    <td style="text-align:center; font-weight:600; <?php echo $row['stok'] <= $row['stok_minimal'] ? 'color:#f44336;' : ''; ?>">
                                        <?php echo $row['stok']; ?>
                                    </td>
                                    <td style="text-align:center;"><?php echo $row['stok_minimal']; ?></td>
                                    <td style="text-align:center;">
                                        <span class="status-dot <?php echo $dot_class; ?>"></span>
                                        <span class="badge badge-<?php echo $status_class; ?>">
                                            <?php echo $status; ?>
                                        </span>
                                    </td>
                                    <td style="text-align:right;"><?php echo rupiah($nilai); ?></td>
                                </tr>
                                <?php endwhile; ?>
                                <tr class="total-row">
                                    <td colspan="3" style="text-align:right;">Total</td>
                                    <td style="text-align:center;"><?php echo $total_stok; ?></td>
                                    <td colspan="2"></td>
                                    <td style="text-align:right;"><?php echo rupiah($total_nilai); ?></td>
                                </tr>
                            <?php else: ?>
                                <tr class="empty-row">
                                    <td colspan="7">
                                        <i class="fas fa-info-circle"></i> Belum ada data produk
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>

        <!-- Bottom Navigation -->
        <nav class="bottom-nav no-print">
            <a href="../index.php"><i class="fas fa-home"></i><span>Dashboard</span></a>
            <a href="../modules/penjualan.php"><i class="fas fa-cash-register"></i><span>Kasir</span></a>
            <a href="../modules/pembelian.php"><i class="fas fa-truck"></i><span>Beli</span></a>
            <a href="../modules/produk.php"><i class="fas fa-box"></i><span>Produk</span></a>
            <a href="laba_rugi.php" class="active"><i class="fas fa-chart-bar"></i><span>Laporan</span></a>
        </nav>
    </div>

    <script>
        // ============================================
        // CHART STATUS STOK (Doughnut)
        // ============================================
        <?php
        $aman = max($stok_aman_count, 0);
        $menipis = max($stok_menipis_count, 0);
        $kosong = max($stok_kosong_count, 0);
        ?>
        new Chart(document.getElementById('chartStatusStok'), {
            type: 'doughnut',
            data: {
                labels: ['Aman', 'Menipis', 'Kosong'],
                datasets: [{
                    data: [<?php echo $aman; ?>, <?php echo $menipis; ?>, <?php echo $kosong; ?>],
                    backgroundColor: ['#4CAF50', '#FF9800', '#f44336'],
                    borderWidth: 2,
                    borderColor: '#fff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 16,
                            font: { size: 12 }
                        }
                    }
                },
                cutout: '65%'
            }
        });

        // ============================================
        // CHART KATEGORI STOK (Bar)
        // ============================================
        <?php
        $labels_kategori = [];
        $data_kategori = [];
        $colors_kategori = ['#2196F3', '#4CAF50', '#FF9800', '#9C27B0', '#f44336'];
        
        $i = 0;
        while ($row = $kategori_stok->fetch_assoc()) {
            $labels_kategori[] = $row['nama_kategori'] ?? 'Tanpa Kategori';
            $data_kategori[] = $row['total_stok'];
            $i++;
        }
        ?>
        new Chart(document.getElementById('chartKategoriStok'), {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($labels_kategori); ?>,
                datasets: [{
                    label: 'Jumlah Stok',
                    data: <?php echo json_encode($data_kategori); ?>,
                    backgroundColor: <?php echo json_encode(array_slice($colors_kategori, 0, count($data_kategori))); ?>,
                    borderRadius: 6,
                    borderSkipped: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    },
                    x: {
                        ticks: {
                            maxRotation: 30,
                            minRotation: 0
                        }
                    }
                }
            }
        });
    </script>
    <script src="../js/script.js"></script>
</body>
</html>