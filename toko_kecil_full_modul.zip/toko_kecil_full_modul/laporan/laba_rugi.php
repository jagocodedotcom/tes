<?php
include '../config/database.php';

$bulan = $_GET['bulan'] ?? date('Y-m');
list($tahun, $bulan_angka) = explode('-', $bulan);

// ============================================
// PERHITUNGAN LABA RUGI
// ============================================

// Total Penjualan
$result = $conn->query("
    SELECT COALESCE(SUM(total_bayar), 0) as total 
    FROM penjualan 
    WHERE MONTH(tanggal_penjualan) = $bulan_angka 
    AND YEAR(tanggal_penjualan) = $tahun 
    AND status = 'selesai'
");
$total_penjualan = $result->fetch_assoc()['total'];

// Total HPP = Total Pembelian
$result = $conn->query("
    SELECT COALESCE(SUM(total_harga), 0) as total 
    FROM pembelian 
    WHERE MONTH(tanggal_pembelian) = $bulan_angka 
    AND YEAR(tanggal_pembelian) = $tahun 
    AND status = 'selesai'
");
$total_hpp = $result->fetch_assoc()['total'];

// Laba Kotor
$laba_kotor = $total_penjualan - $total_hpp;

// Biaya Operasional
$result = $conn->query("
    SELECT COALESCE(SUM(nominal), 0) as total 
    FROM biaya_operasional 
    WHERE MONTH(tanggal) = $bulan_angka 
    AND YEAR(tanggal) = $tahun
");
$total_biaya = $result->fetch_assoc()['total'];

// Laba Bersih
$laba_bersih = $laba_kotor - $total_biaya;

// Margin
$margin = $total_penjualan > 0 ? ($laba_kotor / $total_penjualan) * 100 : 0;

// Detail biaya
$biaya_detail = $conn->query("
    SELECT * FROM biaya_operasional 
    WHERE MONTH(tanggal) = $bulan_angka 
    AND YEAR(tanggal) = $tahun 
    ORDER BY tanggal
");

// Detail penjualan per produk
$produk_terjual = $conn->query("
    SELECT 
        p.nama_produk,
        COALESCE(SUM(pen.jumlah), 0) as terjual,
        COALESCE(SUM(pen.total_bayar), 0) as pendapatan,
        COALESCE(SUM(pen.jumlah * p.harga_beli), 0) as hpp_produk
    FROM produk p
    LEFT JOIN penjualan pen ON p.id = pen.produk_id 
        AND MONTH(pen.tanggal_penjualan) = $bulan_angka 
        AND YEAR(pen.tanggal_penjualan) = $tahun
        AND pen.status = 'selesai'
    GROUP BY p.id
    HAVING terjual > 0
    ORDER BY pendapatan DESC
");

// Total transaksi
$total_transaksi = $conn->query("
    SELECT COUNT(*) as total 
    FROM penjualan 
    WHERE MONTH(tanggal_penjualan) = $bulan_angka 
    AND YEAR(tanggal_penjualan) = $tahun 
    AND status = 'selesai'
")->fetch_assoc()['total'];

// Nama bulan
$nama_bulan = [
    '01' => 'Januari', '02' => 'Februari', '03' => 'Maret',
    '04' => 'April', '05' => 'Mei', '06' => 'Juni',
    '07' => 'Juli', '08' => 'Agustus', '09' => 'September',
    '10' => 'Oktober', '11' => 'November', '12' => 'Desember'
];
$bulan_nama = $nama_bulan[$bulan_angka] . ' ' . $tahun;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Laporan Laba Rugi - Toko Kecil</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* ============================================
           LAPORAN STYLE
           ============================================ */
        .report-header {
            background: linear-gradient(135deg, #1B5E20 0%, #4CAF50 100%);
            color: white;
            padding: 20px 24px;
            border-radius: var(--radius);
            margin-bottom: 20px;
            box-shadow: var(--shadow);
        }
        
        .report-header h2 {
            font-size: 22px;
            font-weight: 700;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .report-header p {
            margin: 6px 0 0 0;
            opacity: 0.9;
            font-size: 14px;
        }
        
        .report-header .period {
            font-size: 13px;
            opacity: 0.8;
            margin-top: 4px;
        }
        
        /* Filter */
        .filter-form {
            background: var(--card-bg);
            border-radius: var(--radius);
            padding: 16px 20px;
            margin-bottom: 20px;
            box-shadow: var(--shadow);
            display: flex;
            align-items: flex-end;
            gap: 12px;
            flex-wrap: wrap;
        }
        
        .filter-form .form-group {
            margin-bottom: 0;
            flex: 1;
            min-width: 150px;
        }
        
        .filter-form .form-group label {
            font-size: 12px;
            font-weight: 600;
            color: var(--text-light);
            display: block;
            margin-bottom: 4px;
        }
        
        .filter-form input[type="month"] {
            width: 100%;
            padding: 10px 14px;
            border: 2px solid #e8ecf1;
            border-radius: var(--radius-sm);
            font-size: 14px;
            background: #fafbfc;
            transition: var(--transition);
        }
        
        .filter-form input[type="month"]:focus {
            border-color: var(--primary-light);
            outline: none;
            box-shadow: 0 0 0 4px rgba(76, 175, 80, 0.1);
        }
        
        .filter-form .btn-filter {
            padding: 10px 24px;
            background: var(--primary-gradient);
            color: white;
            border: none;
            border-radius: var(--radius-sm);
            cursor: pointer;
            font-weight: 600;
            font-size: 14px;
            transition: var(--transition);
            min-width: 80px;
        }
        
        .filter-form .btn-filter:hover {
            opacity: 0.9;
            box-shadow: 0 4px 16px rgba(76, 175, 80, 0.3);
        }
        
        .filter-form .btn-filter:active {
            transform: scale(0.97);
        }
        
        /* Export buttons */
        .export-section {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        
        .export-section .btn-export {
            padding: 10px 20px;
            border: none;
            border-radius: var(--radius-sm);
            cursor: pointer;
            font-weight: 600;
            font-size: 13px;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
            color: white;
        }
        
        .export-section .btn-export:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 16px rgba(0,0,0,0.2);
        }
        
        .export-section .btn-export:active {
            transform: scale(0.97);
        }
        
        .export-section .btn-excel {
            background: #217346;
        }
        
        .export-section .btn-excel:hover {
            background: #1a5c38;
        }
        
        .export-section .btn-pdf {
            background: #d32f2f;
        }
        
        .export-section .btn-pdf:hover {
            background: #b71c1c;
        }
        
        .export-section .btn-print {
            background: #1976D2;
        }
        
        .export-section .btn-print:hover {
            background: #0d47a1;
        }
        
        /* Summary Cards */
        .summary-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 12px;
            margin-bottom: 20px;
        }
        
        .summary-card {
            background: var(--card-bg);
            border-radius: var(--radius-sm);
            padding: 16px 18px;
            box-shadow: var(--shadow);
            transition: var(--transition);
        }
        
        .summary-card:active {
            transform: scale(0.97);
        }
        
        .summary-card .summary-icon {
            font-size: 28px;
            margin-bottom: 6px;
        }
        
        .summary-card .summary-label {
            font-size: 11px;
            color: var(--text-light);
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.3px;
        }
        
        .summary-card .summary-value {
            font-size: 20px;
            font-weight: 700;
            margin-top: 2px;
        }
        
        .summary-card .summary-sub {
            font-size: 12px;
            color: var(--text-light);
            margin-top: 2px;
        }
        
        .summary-card.primary { border-left: 4px solid #2196F3; }
        .summary-card.warning { border-left: 4px solid #FF9800; }
        .summary-card.success { border-left: 4px solid #4CAF50; }
        .summary-card.danger { border-left: 4px solid #f44336; }
        .summary-card.purple { border-left: 4px solid #9C27B0; }
        .summary-card.teal { border-left: 4px solid #00BCD4; }
        
        .text-success { color: #4CAF50; }
        .text-danger { color: #f44336; }
        .text-warning { color: #FF9800; }
        .text-primary { color: #2196F3; }
        .text-purple { color: #9C27B0; }
        
        /* Charts */
        .chart-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
            margin-bottom: 20px;
        }
        
        .chart-box {
            background: var(--card-bg);
            border-radius: var(--radius);
            padding: 16px 18px;
            box-shadow: var(--shadow);
        }
        
        .chart-box h4 {
            font-size: 14px;
            font-weight: 600;
            margin: 0 0 12px 0;
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--text);
        }
        
        .chart-box h4 i {
            color: var(--primary-light);
        }
        
        .chart-container {
            position: relative;
            height: 220px;
            width: 100%;
        }
        
        /* Detail Table */
        .detail-table {
            background: var(--card-bg);
            border-radius: var(--radius);
            padding: 16px 18px;
            box-shadow: var(--shadow);
            margin-bottom: 20px;
        }
        
        .detail-table h4 {
            font-size: 14px;
            font-weight: 600;
            margin: 0 0 12px 0;
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--text);
        }
        
        .detail-table h4 i {
            color: var(--primary-light);
        }
        
        .detail-table .table-responsive {
            margin: 0 -4px;
        }
        
        .detail-table table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
            min-width: 500px;
        }
        
        .detail-table table th {
            background: #f0f4f8;
            padding: 10px 12px;
            text-align: left;
            font-weight: 600;
            color: var(--text-light);
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-bottom: 2px solid #e8ecf1;
        }
        
        .detail-table table td {
            padding: 10px 12px;
            border-bottom: 1px solid #f0f2f5;
        }
        
        .detail-table table .total-row {
            background: #f0f7f0;
            font-weight: 700;
            border-top: 2px solid #4CAF50;
        }
        
        .detail-table table .total-row td {
            padding: 12px;
        }
        
        .detail-table table .empty-row td {
            text-align: center;
            padding: 30px;
            color: var(--text-light);
        }
        
        .badge {
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 10px;
            font-weight: 600;
            display: inline-block;
        }
        
        .badge-success {
            background: #e8f5e9;
            color: #2e7d32;
        }
        
        .badge-danger {
            background: #ffebee;
            color: #c62828;
        }
        
        .badge-warning {
            background: #fff3e0;
            color: #e65100;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .summary-grid {
                grid-template-columns: 1fr 1fr;
            }
            
            .chart-grid {
                grid-template-columns: 1fr;
            }
            
            .filter-form {
                flex-direction: column;
                align-items: stretch;
            }
            
            .filter-form .form-group {
                min-width: unset;
            }
            
            .filter-form .btn-filter {
                width: 100%;
            }
            
            .export-section {
                justify-content: center;
            }
            
            .export-section .btn-export {
                flex: 1;
                justify-content: center;
                min-width: 100px;
            }
        }
        
        @media (max-width: 480px) {
            .summary-grid {
                grid-template-columns: 1fr 1fr;
                gap: 8px;
            }
            
            .summary-card {
                padding: 12px 14px;
            }
            
            .summary-card .summary-value {
                font-size: 16px;
            }
            
            .report-header {
                padding: 16px 18px;
            }
            
            .report-header h2 {
                font-size: 18px;
            }
            
            .detail-table {
                padding: 12px;
            }
            
            .export-section .btn-export {
                font-size: 11px;
                padding: 8px 12px;
                min-width: 80px;
            }
        }
        
        @media print {
            .no-print { display: none !important; }
            .bottom-nav { display: none !important; }
            .container { max-width: 100% !important; padding: 0 !important; }
            .report-header { background: #1B5E20 !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            .summary-card { box-shadow: none !important; border: 1px solid #ddd; }
            .chart-box { box-shadow: none !important; border: 1px solid #ddd; }
            .detail-table { box-shadow: none !important; border: 1px solid #ddd; }
            .filter-form { display: none !important; }
            .export-section { display: none !important; }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <header class="header no-print">
            <a href="../index.php" class="back-btn"><i class="fas fa-arrow-left"></i></a>
            <h1><i class="fas fa-chart-line"></i> Laba Rugi</h1>
            <span></span>
        </header>

        <main class="main-content">
            <!-- Report Header -->
            <div class="report-header">
                <h2><i class="fas fa-store"></i> Laporan Laba Rugi</h2>
                <p>Periode: <strong><?php echo $bulan_nama; ?></strong></p>
                <div class="period">
                    <i class="fas fa-calendar-alt"></i> 
                    Total Transaksi: <strong><?php echo $total_transaksi; ?></strong> penjualan
                    <?php if ($total_transaksi > 0): ?>
                    | Rata-rata per transaksi: <strong><?php echo rupiah($total_penjualan / $total_transaksi); ?></strong>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Filter -->
            <form method="GET" class="filter-form no-print">
                <div class="form-group">
                    <label><i class="fas fa-calendar-alt"></i> Periode Bulan</label>
                    <input type="month" name="bulan" value="<?php echo $bulan; ?>">
                </div>
                <button type="submit" class="btn-filter">
                    <i class="fas fa-filter"></i> Tampilkan
                </button>
            </form>

            <!-- Export Section -->
            <div class="export-section no-print">
                <a href="export_excel.php?type=laba&bulan=<?php echo $bulan; ?>" class="btn-export btn-excel">
                    <i class="fas fa-file-excel"></i> Export Excel
                </a>
                <button class="btn-export btn-print" onclick="window.print()">
                    <i class="fas fa-print"></i> Cetak
                </button>
            </div>

            <!-- Summary Cards -->
            <div class="summary-grid">
                <div class="summary-card primary">
                    <div class="summary-icon">💰</div>
                    <div class="summary-label">Total Penjualan</div>
                    <div class="summary-value text-primary"><?php echo rupiah($total_penjualan); ?></div>
                    <div class="summary-sub"><?php echo $total_transaksi; ?> transaksi</div>
                </div>
                <div class="summary-card warning">
                    <div class="summary-icon">📦</div>
                    <div class="summary-label">HPP (Pembelian)</div>
                    <div class="summary-value text-warning"><?php echo rupiah($total_hpp); ?></div>
                    <div class="summary-sub">Biaya pokok penjualan</div>
                </div>
                <div class="summary-card success">
                    <div class="summary-icon">📈</div>
                    <div class="summary-label">Laba Kotor</div>
                    <div class="summary-value text-success"><?php echo rupiah($laba_kotor); ?></div>
                    <div class="summary-sub">Margin: <?php echo number_format($margin, 1); ?>%</div>
                </div>
                <div class="summary-card danger">
                    <div class="summary-icon">💸</div>
                    <div class="summary-label">Biaya Operasional</div>
                    <div class="summary-value text-danger"><?php echo rupiah($total_biaya); ?></div>
                    <div class="summary-sub"><?php echo $biaya_detail->num_rows; ?> item biaya</div>
                </div>
                <div class="summary-card purple" style="grid-column: span 2;">
                    <div class="summary-icon">🏆</div>
                    <div class="summary-label">Laba Bersih</div>
                    <div class="summary-value" style="color: <?php echo $laba_bersih >= 0 ? '#4CAF50' : '#f44336'; ?>; font-size: 24px;">
                        <?php echo rupiah($laba_bersih); ?>
                    </div>
                    <div class="summary-sub">
                        <?php if ($laba_bersih >= 0): ?>
                        <i class="fas fa-arrow-up text-success"></i> Bisnis menguntungkan
                        <?php else: ?>
                        <i class="fas fa-arrow-down text-danger"></i> Bisnis merugi
                        <?php endif; ?>
                        | Rasio Laba: <?php echo $total_penjualan > 0 ? number_format(($laba_bersih / $total_penjualan) * 100, 1) : 0; ?>%
                    </div>
                </div>
            </div>

            <!-- Charts -->
            <div class="chart-grid">
                <div class="chart-box">
                    <h4><i class="fas fa-chart-pie"></i> Komposisi Pendapatan</h4>
                    <div class="chart-container">
                        <canvas id="chartPendapatan"></canvas>
                    </div>
                </div>
                <div class="chart-box">
                    <h4><i class="fas fa-chart-bar"></i> Top 5 Produk Terlaris</h4>
                    <div class="chart-container">
                        <canvas id="chartTopProduk"></canvas>
                    </div>
                </div>
            </div>

            <!-- Detail Produk -->
            <div class="detail-table">
                <h4><i class="fas fa-box"></i> Detail Penjualan Per Produk</h4>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Produk</th>
                                <th style="text-align:center;">Terjual</th>
                                <th style="text-align:right;">Pendapatan</th>
                                <th style="text-align:right;">HPP</th>
                                <th style="text-align:right;">Laba</th>
                                <th style="text-align:right;">Margin</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($produk_terjual->num_rows > 0): ?>
                                <?php 
                                $total_laba_all = 0;
                                while ($row = $produk_terjual->fetch_assoc()): 
                                    $laba = $row['pendapatan'] - $row['hpp_produk'];
                                    $total_laba_all += $laba;
                                    $margin_produk = $row['pendapatan'] > 0 ? ($laba / $row['pendapatan']) * 100 : 0;
                                ?>
                                <tr>
                                    <td><?php echo $row['nama_produk']; ?></td>
                                    <td style="text-align:center;"><?php echo $row['terjual']; ?></td>
                                    <td style="text-align:right;"><?php echo rupiah($row['pendapatan']); ?></td>
                                    <td style="text-align:right;"><?php echo rupiah($row['hpp_produk']); ?></td>
                                    <td style="text-align:right; color: <?php echo $laba >= 0 ? '#4CAF50' : '#f44336'; ?>;">
                                        <?php echo rupiah($laba); ?>
                                    </td>
                                    <td style="text-align:right;">
                                        <span class="badge <?php echo $margin_produk >= 30 ? 'badge-success' : ($margin_produk >= 10 ? 'badge-warning' : 'badge-danger'); ?>">
                                            <?php echo number_format($margin_produk, 1); ?>%
                                        </span>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                                <tr class="total-row">
                                    <td colspan="4" style="text-align:right;">Total Laba Produk</td>
                                    <td style="text-align:right; color: <?php echo $total_laba_all >= 0 ? '#4CAF50' : '#f44336'; ?>;">
                                        <?php echo rupiah($total_laba_all); ?>
                                    </td>
                                    <td></td>
                                </tr>
                            <?php else: ?>
                                <tr class="empty-row">
                                    <td colspan="6">
                                        <i class="fas fa-info-circle"></i> Belum ada data penjualan bulan ini
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Biaya Operasional -->
            <div class="detail-table">
                <h4><i class="fas fa-money-bill-wave"></i> Rincian Biaya Operasional</h4>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Tanggal</th>
                                <th>Jenis Biaya</th>
                                <th>Deskripsi</th>
                                <th style="text-align:right;">Nominal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($biaya_detail->num_rows > 0): ?>
                                <?php while ($row = $biaya_detail->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo date('d/m/Y', strtotime($row['tanggal'])); ?></td>
                                    <td>
                                        <span class="badge badge-warning">
                                            <?php echo $row['jenis_biaya']; ?>
                                        </span>
                                    </td>
                                    <td><?php echo $row['deskripsi']; ?></td>
                                    <td style="text-align:right;"><?php echo rupiah($row['nominal']); ?></td>
                                </tr>
                                <?php endwhile; ?>
                                <tr class="total-row">
                                    <td colspan="3" style="text-align:right;">Total Biaya Operasional</td>
                                    <td style="text-align:right;"><?php echo rupiah($total_biaya); ?></td>
                                </tr>
                            <?php else: ?>
                                <tr class="empty-row">
                                    <td colspan="4">
                                        <i class="fas fa-info-circle"></i> Belum ada biaya operasional bulan ini
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>

        <!-- Bottom Navigation -->
        <nav class="bottom-nav no-print">
            <a href="../index.php"><i class="fas fa-home"></i><span>Dashboard</span></a>
            <a href="../modules/penjualan.php"><i class="fas fa-cash-register"></i><span>Kasir</span></a>
            <a href="../modules/pembelian.php"><i class="fas fa-truck"></i><span>Beli</span></a>
            <a href="../modules/produk.php"><i class="fas fa-box"></i><span>Produk</span></a>
            <a href="laba_rugi.php" class="active"><i class="fas fa-chart-bar"></i><span>Laporan</span></a>
        </nav>
    </div>

    <script>
        // ============================================
        // CHART PENDAPATAN (Doughnut)
        // ============================================
        <?php
        $laba_kotor_chart = max($laba_kotor, 0);
        $hpp_chart = max($total_hpp, 0);
        ?>
        new Chart(document.getElementById('chartPendapatan'), {
            type: 'doughnut',
            data: {
                labels: ['Laba Kotor', 'HPP'],
                datasets: [{
                    data: [<?php echo $laba_kotor_chart; ?>, <?php echo $hpp_chart; ?>],
                    backgroundColor: ['#4CAF50', '#FF9800'],
                    borderWidth: 2,
                    borderColor: '#fff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 16,
                            font: { size: 12 }
                        }
                    }
                },
                cutout: '65%'
            }
        });

        // ============================================
        // CHART TOP 5 PRODUK (Bar)
        // ============================================
        <?php
        $labels_top = [];
        $data_top = [];
        $colors_top = ['#4CAF50', '#2196F3', '#FF9800', '#9C27B0', '#f44336'];
        
        $result_top = $conn->query("
            SELECT p.nama_produk, COALESCE(SUM(pen.total_bayar), 0) as total
            FROM produk p
            LEFT JOIN penjualan pen ON p.id = pen.produk_id 
                AND MONTH(pen.tanggal_penjualan) = $bulan_angka 
                AND YEAR(pen.tanggal_penjualan) = $tahun
                AND pen.status = 'selesai'
            GROUP BY p.id
            HAVING total > 0
            ORDER BY total DESC
            LIMIT 5
        ");
        $i = 0;
        while ($row = $result_top->fetch_assoc()) {
            $labels_top[] = $row['nama_produk'];
            $data_top[] = $row['total'];
            $i++;
        }
        ?>
        new Chart(document.getElementById('chartTopProduk'), {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($labels_top); ?>,
                datasets: [{
                    label: 'Penjualan (Rp)',
                    data: <?php echo json_encode($data_top); ?>,
                    backgroundColor: <?php echo json_encode(array_slice($colors_top, 0, count($data_top))); ?>,
                    borderRadius: 6,
                    borderSkipped: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return 'Rp ' + value.toLocaleString('id-ID');
                            }
                        }
                    },
                    x: {
                        ticks: {
                            maxRotation: 30,
                            minRotation: 0
                        }
                    }
                }
            }
        });
    </script>
    <script src="../js/script.js"></script>
</body>
</html>