<?php
include '../config/database.php';

// Set header untuk Excel
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=laporan_toko_".date('Y-m-d').".xls");

$type = $_GET['type'] ?? 'laba';

echo "<html><head><meta charset='UTF-8'></head><body>";
echo "<h2>Laporan Toko Kecil</h2>";
echo "<p>Tanggal: " . date('d/m/Y H:i') . "</p><hr>";

if ($type == 'laba' || $type == 'all') {
    $bulan = $_GET['bulan'] ?? date('Y-m');
    list($tahun, $bulan_angka) = explode('-', $bulan);
    
    echo "<h3>Laporan Laba Rugi - " . date('F Y', strtotime($bulan)) . "</h3>";
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>Keterangan</th><th>Nominal</th></tr>";
    
    $result = $conn->query("SELECT COALESCE(SUM(total_bayar), 0) as total FROM penjualan WHERE MONTH(tanggal_penjualan) = $bulan_angka AND YEAR(tanggal_penjualan) = $tahun AND status = 'selesai'");
    $penjualan = $result->fetch_assoc()['total'];
    echo "<tr><td>Total Penjualan</td><td>" . rupiah($penjualan) . "</td></tr>";
    
    $result = $conn->query("SELECT COALESCE(SUM(total_harga), 0) as total FROM pembelian WHERE MONTH(tanggal_pembelian) = $bulan_angka AND YEAR(tanggal_pembelian) = $tahun AND status = 'selesai'");
    $hpp = $result->fetch_assoc()['total'];
    echo "<tr><td>HPP (Pembelian)</td><td>" . rupiah($hpp) . "</td></tr>";
    
    $laba_kotor = $penjualan - $hpp;
    echo "<tr><td><strong>Laba Kotor</strong></td><td><strong>" . rupiah($laba_kotor) . "</strong></td></tr>";
    
    $result = $conn->query("SELECT COALESCE(SUM(nominal), 0) as total FROM biaya_operasional WHERE MONTH(tanggal) = $bulan_angka AND YEAR(tanggal) = $tahun");
    $biaya = $result->fetch_assoc()['total'];
    echo "<tr><td>Biaya Operasional</td><td>" . rupiah($biaya) . "</td></tr>";
    
    $laba_bersih = $laba_kotor - $biaya;
    echo "<tr><td><strong>Laba Bersih</strong></td><td><strong>" . rupiah($laba_bersih) . "</strong></td></tr>";
    echo "</table><br>";
}

if ($type == 'stok' || $type == 'all') {
    echo "<h3>Laporan Stok</h3>";
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>Kode</th><th>Nama Produk</th><th>Kategori</th><th>Stok</th><th>Minimal</th><th>Status</th><th>Nilai Stok</th></tr>";
    
    $stok = $conn->query("
        SELECT p.*, k.nama_kategori 
        FROM produk p 
        LEFT JOIN kategori k ON p.kategori_id = k.id 
        ORDER BY p.stok ASC
    ");
    $total_nilai = 0;
    while ($row = $stok->fetch_assoc()) {
        $nilai = $row['stok'] * $row['harga_beli'];
        $total_nilai += $nilai;
        $status = $row['stok'] <= $row['stok_minimal'] ? 'Menipis' : 'Aman';
        echo "<tr>
            <td>{$row['kode_produk']}</td>
            <td>{$row['nama_produk']}</td>
            <td>{$row['nama_kategori']}</td>
            <td>{$row['stok']}</td>
            <td>{$row['stok_minimal']}</td>
            <td>$status</td>
            <td>" . rupiah($nilai) . "</td>
        </tr>";
    }
    echo "<tr><td colspan='6' style='text-align:right;'><strong>Total Nilai Stok</strong></td><td><strong>" . rupiah($total_nilai) . "</strong></td></tr>";
    echo "</table>";
}

echo "</body></html>";
?>