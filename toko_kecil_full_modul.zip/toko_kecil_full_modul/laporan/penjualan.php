<?php
include '../config/database.php';

$tanggal_awal = $_GET['tanggal_awal'] ?? date('Y-m-01');
$tanggal_akhir = $_GET['tanggal_akhir'] ?? date('Y-m-d');
$filter_produk = $_GET['filter_produk'] ?? '';
$filter_user = $_GET['filter_user'] ?? '';

// ============================================
// DATA PENJUALAN
// ============================================

$sql = "
    SELECT pen.*, p.nama_produk, p.kode_produk, u.nama_lengkap as kasir, 
           (pen.total_bayar / pen.jumlah) as harga_satuan
    FROM penjualan pen
    JOIN produk p ON pen.produk_id = p.id
    LEFT JOIN users u ON pen.user_id = u.id
    WHERE pen.tanggal_penjualan BETWEEN '$tanggal_awal' AND '$tanggal_akhir'
    AND pen.status = 'selesai'
";

if ($filter_produk) {
    $sql .= " AND pen.produk_id = '$filter_produk'";
}
if ($filter_user) {
    $sql .= " AND pen.user_id = '$filter_user'";
}

$sql .= " ORDER BY pen.tanggal_penjualan DESC, pen.created_at DESC";

$penjualan = $conn->query($sql);

// Total penjualan
$result_total = $conn->query("
    SELECT 
        COALESCE(SUM(total_bayar), 0) as total,
        COUNT(*) as total_transaksi,
        COALESCE(SUM(jumlah), 0) as total_barang,
        COALESCE(AVG(total_bayar), 0) as rata_rata,
        COUNT(DISTINCT pelanggan) as total_pelanggan
    FROM penjualan
    WHERE tanggal_penjualan BETWEEN '$tanggal_awal' AND '$tanggal_akhir'
    AND status = 'selesai'
");
$total_data = $result_total->fetch_assoc();

// Penjualan per hari
$penjualan_harian = $conn->query("
    SELECT 
        tanggal_penjualan,
        COUNT(*) as transaksi,
        SUM(total_bayar) as total,
        SUM(jumlah) as barang
    FROM penjualan
    WHERE tanggal_penjualan BETWEEN '$tanggal_awal' AND '$tanggal_akhir'
    AND status = 'selesai'
    GROUP BY tanggal_penjualan
    ORDER BY tanggal_penjualan
");

// Metode pembayaran
$metode_pembayaran = $conn->query("
    SELECT 
        metode_pembayaran,
        COUNT(*) as jumlah,
        SUM(total_bayar) as total
    FROM penjualan
    WHERE tanggal_penjualan BETWEEN '$tanggal_awal' AND '$tanggal_akhir'
    AND status = 'selesai'
    GROUP BY metode_pembayaran
");

$produk_list = $conn->query("SELECT id, nama_produk FROM produk ORDER BY nama_produk");
$user_list = $conn->query("SELECT id, nama_lengkap FROM users WHERE role = 'kasir' ORDER BY nama_lengkap");

// Top 5 produk terlaris
$top_produk = $conn->query("
    SELECT 
        p.nama_produk,
        SUM(pen.jumlah) as total_terjual,
        SUM(pen.total_bayar) as total_pendapatan
    FROM penjualan pen
    JOIN produk p ON pen.produk_id = p.id
    WHERE pen.tanggal_penjualan BETWEEN '$tanggal_awal' AND '$tanggal_akhir'
    AND pen.status = 'selesai'
    GROUP BY pen.produk_id
    ORDER BY total_pendapatan DESC
    LIMIT 5
");

// Label untuk chart
$labels_harian = [];
$data_harian = [];
while ($row = $penjualan_harian->fetch_assoc()) {
    $labels_harian[] = date('d M', strtotime($row['tanggal_penjualan']));
    $data_harian[] = $row['total'];
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Laporan Penjualan - Toko Kecil</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* ============================================
           LAPORAN PENJUALAN STYLE
           ============================================ */
        .report-header {
            background: linear-gradient(135deg, #004D40 0%, #009688 100%);
            color: white;
            padding: 20px 24px;
            border-radius: var(--radius);
            margin-bottom: 20px;
            box-shadow: var(--shadow);
        }
        
        .report-header h2 {
            font-size: 22px;
            font-weight: 700;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .report-header p {
            margin: 6px 0 0 0;
            opacity: 0.9;
            font-size: 14px;
        }
        
        .report-header .period {
            font-size: 13px;
            opacity: 0.8;
            margin-top: 4px;
        }
        
        /* Navigasi Laporan */
        .laporan-nav {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            margin-bottom: 16px;
        }
        
        .laporan-nav .btn-nav {
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 12px;
            text-decoration: none;
            background: #f0f0f0;
            color: var(--text);
            border: 1px solid #ddd;
            transition: var(--transition);
        }
        
        .laporan-nav .btn-nav:hover {
            background: #e0e0e0;
        }
        
        .laporan-nav .btn-nav.active {
            background: #009688;
            color: white;
            border-color: #009688;
        }
        
        .laporan-nav .btn-nav i {
            margin-right: 4px;
        }
        
        /* Filter */
        .filter-form {
            background: var(--card-bg);
            border-radius: var(--radius);
            padding: 16px 20px;
            margin-bottom: 20px;
            box-shadow: var(--shadow);
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 12px;
            align-items: flex-end;
        }
        
        .filter-form .form-group {
            margin-bottom: 0;
        }
        
        .filter-form .form-group label {
            font-size: 12px;
            font-weight: 600;
            color: var(--text-light);
            display: block;
            margin-bottom: 4px;
        }
        
        .filter-form .form-control {
            width: 100%;
            padding: 10px 12px;
            border: 2px solid #e8ecf1;
            border-radius: var(--radius-sm);
            font-size: 13px;
            background: #fafbfc;
            transition: var(--transition);
        }
        
        .filter-form .form-control:focus {
            border-color: #009688;
            outline: none;
            box-shadow: 0 0 0 4px rgba(0, 150, 136, 0.1);
        }
        
        .filter-form .btn-filter {
            padding: 10px 24px;
            background: linear-gradient(135deg, #004D40 0%, #009688 100%);
            color: white;
            border: none;
            border-radius: var(--radius-sm);
            cursor: pointer;
            font-weight: 600;
            font-size: 14px;
            transition: var(--transition);
            min-width: 100px;
        }
        
        .filter-form .btn-filter:hover {
            opacity: 0.9;
            box-shadow: 0 4px 16px rgba(0, 150, 136, 0.3);
        }
        
        .filter-form .btn-filter:active {
            transform: scale(0.97);
        }
        
        /* Export buttons */
        .export-section {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        
        .export-section .btn-export {
            padding: 10px 20px;
            border: none;
            border-radius: var(--radius-sm);
            cursor: pointer;
            font-weight: 600;
            font-size: 13px;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
            color: white;
        }
        
        .export-section .btn-export:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 16px rgba(0,0,0,0.2);
        }
        
        .export-section .btn-export:active {
            transform: scale(0.97);
        }
        
        .export-section .btn-excel {
            background: #217346;
        }
        
        .export-section .btn-excel:hover {
            background: #1a5c38;
        }
        
        .export-section .btn-print {
            background: #1976D2;
        }
        
        .export-section .btn-print:hover {
            background: #0d47a1;
        }
        
        /* Summary Cards */
        .summary-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 12px;
            margin-bottom: 20px;
        }
        
        .summary-card {
            background: var(--card-bg);
            border-radius: var(--radius-sm);
            padding: 16px 18px;
            box-shadow: var(--shadow);
            transition: var(--transition);
        }
        
        .summary-card:active {
            transform: scale(0.97);
        }
        
        .summary-card .summary-icon {
            font-size: 28px;
            margin-bottom: 6px;
        }
        
        .summary-card .summary-label {
            font-size: 11px;
            color: var(--text-light);
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.3px;
        }
        
        .summary-card .summary-value {
            font-size: 20px;
            font-weight: 700;
            margin-top: 2px;
        }
        
        .summary-card .summary-sub {
            font-size: 12px;
            color: var(--text-light);
            margin-top: 2px;
        }
        
        .summary-card.teal { border-left: 4px solid #009688; }
        .summary-card.primary { border-left: 4px solid #2196F3; }
        .summary-card.success { border-left: 4px solid #4CAF50; }
        .summary-card.warning { border-left: 4px solid #FF9800; }
        .summary-card.purple { border-left: 4px solid #9C27B0; }
        .summary-card.orange { border-left: 4px solid #FF5722; }
        
        .text-teal { color: #009688; }
        .text-success { color: #4CAF50; }
        .text-danger { color: #f44336; }
        .text-warning { color: #FF9800; }
        .text-primary { color: #2196F3; }
        .text-purple { color: #9C27B0; }
        .text-orange { color: #FF5722; }
        
        /* Charts */
        .chart-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
            margin-bottom: 20px;
        }
        
        .chart-box {
            background: var(--card-bg);
            border-radius: var(--radius);
            padding: 16px 18px;
            box-shadow: var(--shadow);
        }
        
        .chart-box h4 {
            font-size: 14px;
            font-weight: 600;
            margin: 0 0 12px 0;
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--text);
        }
        
        .chart-box h4 i {
            color: #009688;
        }
        
        .chart-container {
            position: relative;
            height: 200px;
            width: 100%;
        }
        
        /* Detail Table */
        .detail-table {
            background: var(--card-bg);
            border-radius: var(--radius);
            padding: 16px 18px;
            box-shadow: var(--shadow);
            margin-bottom: 20px;
        }
        
        .detail-table h4 {
            font-size: 14px;
            font-weight: 600;
            margin: 0 0 12px 0;
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--text);
        }
        
        .detail-table h4 i {
            color: #009688;
        }
        
        .detail-table .table-responsive {
            margin: 0 -4px;
        }
        
        .detail-table table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
            min-width: 700px;
        }
        
        .detail-table table th {
            background: #e0f2f1;
            padding: 10px 12px;
            text-align: left;
            font-weight: 600;
            color: #004D40;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-bottom: 2px solid #80cbc4;
        }
        
        .detail-table table td {
            padding: 10px 12px;
            border-bottom: 1px solid #f0f2f5;
        }
        
        .detail-table table .total-row {
            background: #e0f2f1;
            font-weight: 700;
            border-top: 2px solid #009688;
        }
        
        .detail-table table .total-row td {
            padding: 12px;
            color: #004D40;
        }
        
        .detail-table table .empty-row td {
            text-align: center;
            padding: 30px;
            color: var(--text-light);
        }
        
        .badge {
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 10px;
            font-weight: 600;
            display: inline-block;
        }
        
        .badge-success {
            background: #e8f5e9;
            color: #2e7d32;
        }
        
        .badge-warning {
            background: #fff3e0;
            color: #e65100;
        }
        
        .badge-info {
            background: #e3f2fd;
            color: #0d47a1;
        }
        
        .badge-teal {
            background: #e0f2f1;
            color: #004D40;
        }
        
        .payment-method {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
        }
        
        .payment-method.tunai { background: #e8f5e9; color: #2e7d32; }
        .payment-method.transfer { background: #e3f2fd; color: #0d47a1; }
        .payment-method.qris { background: #f3e5f5; color: #6a1b9a; }
        .payment-method.credit { background: #fff3e0; color: #e65100; }
        .payment-method.debit { background: #fce4ec; color: #c62828; }
        
        /* Responsive */
        @media (max-width: 768px) {
            .summary-grid {
                grid-template-columns: 1fr 1fr;
            }
            
            .chart-grid {
                grid-template-columns: 1fr;
            }
            
            .filter-form {
                grid-template-columns: 1fr;
            }
            
            .export-section {
                justify-content: center;
            }
            
            .export-section .btn-export {
                flex: 1;
                justify-content: center;
                min-width: 100px;
            }
        }
        
        @media (max-width: 480px) {
            .summary-grid {
                grid-template-columns: 1fr 1fr;
                gap: 8px;
            }
            
            .summary-card {
                padding: 12px 14px;
            }
            
            .summary-card .summary-value {
                font-size: 16px;
            }
            
            .report-header {
                padding: 16px 18px;
            }
            
            .report-header h2 {
                font-size: 18px;
            }
            
            .detail-table {
                padding: 12px;
            }
            
            .export-section .btn-export {
                font-size: 11px;
                padding: 8px 12px;
                min-width: 80px;
            }
        }
        
        @media print {
            .no-print { display: none !important; }
            .bottom-nav { display: none !important; }
            .container { max-width: 100% !important; padding: 0 !important; }
            .report-header { background: #004D40 !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            .summary-card { box-shadow: none !important; border: 1px solid #ddd; }
            .chart-box { box-shadow: none !important; border: 1px solid #ddd; }
            .detail-table { box-shadow: none !important; border: 1px solid #ddd; }
            .filter-form { display: none !important; }
            .export-section { display: none !important; }
            .laporan-nav { display: none !important; }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <header class="header no-print">
            <a href="../index.php" class="back-btn"><i class="fas fa-arrow-left"></i></a>
            <h1><i class="fas fa-file-invoice"></i> Laporan Penjualan</h1>
            <span></span>
        </header>

        <main class="main-content">
            <!-- Report Header -->
            <div class="report-header">
                <h2><i class="fas fa-chart-line"></i> Laporan Penjualan</h2>
                <p>Periode: <strong><?php echo date('d F Y', strtotime($tanggal_awal)); ?> - <?php echo date('d F Y', strtotime($tanggal_akhir)); ?></strong></p>
                <div class="period">
                    <i class="fas fa-calendar-alt"></i> 
                    Total Transaksi: <strong><?php echo $total_data['total_transaksi']; ?></strong>
                    | Total Pelanggan: <strong><?php echo $total_data['total_pelanggan']; ?></strong>
                    | Rata-rata per transaksi: <strong><?php echo rupiah($total_data['rata_rata']); ?></strong>
                </div>
            </div>

            <!-- Navigasi Laporan -->
            <div class="laporan-nav no-print">
                <a href="laba_rugi.php" class="btn-nav"><i class="fas fa-chart-line"></i> Laba Rugi</a>
                <a href="stok.php" class="btn-nav"><i class="fas fa-cubes"></i> Stok</a>
                <a href="penjualan.php" class="btn-nav active"><i class="fas fa-file-invoice"></i> Penjualan</a>
                <a href="export_excel.php" class="btn-nav"><i class="fas fa-file-excel"></i> Export</a>
            </div>

            <!-- Filter -->
            <form method="GET" class="filter-form no-print">
                <div class="form-group">
                    <label><i class="fas fa-calendar-alt"></i> Tanggal Awal</label>
                    <input type="date" name="tanggal_awal" value="<?php echo $tanggal_awal; ?>" class="form-control">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-calendar-alt"></i> Tanggal Akhir</label>
                    <input type="date" name="tanggal_akhir" value="<?php echo $tanggal_akhir; ?>" class="form-control">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-box"></i> Produk</label>
                    <select name="filter_produk" class="form-control">
                        <option value="">Semua Produk</option>
                        <?php while ($row = $produk_list->fetch_assoc()): ?>
                        <option value="<?php echo $row['id']; ?>" <?php echo $filter_produk == $row['id'] ? 'selected' : ''; ?>>
                            <?php echo $row['nama_produk']; ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-user"></i> Kasir</label>
                    <select name="filter_user" class="form-control">
                        <option value="">Semua Kasir</option>
                        <?php while ($row = $user_list->fetch_assoc()): ?>
                        <option value="<?php echo $row['id']; ?>" <?php echo $filter_user == $row['id'] ? 'selected' : ''; ?>>
                            <?php echo $row['nama_lengkap']; ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group" style="display:flex; align-items:flex-end;">
                    <button type="submit" class="btn-filter">
                        <i class="fas fa-filter"></i> Tampilkan
                    </button>
                </div>
            </form>

            <!-- Export Section -->
            <div class="export-section no-print">
                <a href="export_excel.php?type=penjualan&tanggal_awal=<?php echo $tanggal_awal; ?>&tanggal_akhir=<?php echo $tanggal_akhir; ?>" class="btn-export btn-excel">
                    <i class="fas fa-file-excel"></i> Export Excel
                </a>
                <button class="btn-export btn-print" onclick="window.print()">
                    <i class="fas fa-print"></i> Cetak
                </button>
            </div>

            <!-- Summary Cards -->
            <div class="summary-grid">
                <div class="summary-card teal">
                    <div class="summary-icon">💰</div>
                    <div class="summary-label">Total Penjualan</div>
                    <div class="summary-value text-teal"><?php echo rupiah($total_data['total']); ?></div>
                    <div class="summary-sub"><?php echo $total_data['total_transaksi']; ?> transaksi</div>
                </div>
                <div class="summary-card primary">
                    <div class="summary-icon">📊</div>
                    <div class="summary-label">Rata-rata per Transaksi</div>
                    <div class="summary-value text-primary"><?php echo rupiah($total_data['rata_rata']); ?></div>
                    <div class="summary-sub">Nilai rata-rata</div>
                </div>
                <div class="summary-card success">
                    <div class="summary-icon">📦</div>
                    <div class="summary-label">Total Barang Terjual</div>
                    <div class="summary-value text-success"><?php echo $total_data['total_barang']; ?></div>
                    <div class="summary-sub">Unit barang</div>
                </div>
                <div class="summary-card warning">
                    <div class="summary-icon">👤</div>
                    <div class="summary-label">Total Pelanggan</div>
                    <div class="summary-value text-warning"><?php echo $total_data['total_pelanggan']; ?></div>
                    <div class="summary-sub">Pelanggan unik</div>
                </div>
            </div>

            <!-- Charts -->
            <div class="chart-grid">
                <div class="chart-box">
                    <h4><i class="fas fa-chart-bar"></i> Penjualan Harian</h4>
                    <div class="chart-container">
                        <canvas id="chartHarian"></canvas>
                    </div>
                </div>
                <div class="chart-box">
                    <h4><i class="fas fa-chart-pie"></i> Metode Pembayaran</h4>
                    <div class="chart-container">
                        <canvas id="chartMetode"></canvas>
                    </div>
                </div>
            </div>

            <!-- Top 5 Produk -->
            <div class="chart-box" style="margin-bottom:20px;">
                <h4><i class="fas fa-trophy"></i> Top 5 Produk Terlaris</h4>
                <div class="table-responsive">
                    <table style="width:100%;border-collapse:collapse;font-size:13px;">
                        <thead>
                            <tr style="background:#e0f2f1;">
                                <th style="padding:10px 12px;text-align:left;color:#004D40;font-size:11px;text-transform:uppercase;">No</th>
                                <th style="padding:10px 12px;text-align:left;color:#004D40;font-size:11px;text-transform:uppercase;">Produk</th>
                                <th style="padding:10px 12px;text-align:center;color:#004D40;font-size:11px;text-transform:uppercase;">Terjual</th>
                                <th style="padding:10px 12px;text-align:right;color:#004D40;font-size:11px;text-transform:uppercase;">Pendapatan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $no = 1;
                            while ($row = $top_produk->fetch_assoc()): 
                            ?>
                            <tr>
                                <td style="padding:8px 12px;border-bottom:1px solid #f0f2f5;font-weight:600;color:#009688;">
                                    #<?php echo $no++; ?>
                                </td>
                                <td style="padding:8px 12px;border-bottom:1px solid #f0f2f5;"><?php echo $row['nama_produk']; ?></td>
                                <td style="padding:8px 12px;border-bottom:1px solid #f0f2f5;text-align:center;">
                                    <span class="badge badge-teal"><?php echo $row['total_terjual']; ?> unit</span>
                                </td>
                                <td style="padding:8px 12px;border-bottom:1px solid #f0f2f5;text-align:right;font-weight:600;">
                                    <?php echo rupiah($row['total_pendapatan']); ?>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                            <?php if ($no == 1): ?>
                            <tr>
                                <td colspan="4" style="text-align:center;padding:20px;color:var(--text-light);">
                                    <i class="fas fa-info-circle"></i> Belum ada data penjualan
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Detail Penjualan -->
            <div class="detail-table">
                <h4><i class="fas fa-list"></i> Detail Transaksi Penjualan</h4>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Invoice</th>
                                <th>Tanggal</th>
                                <th>Produk</th>
                                <th style="text-align:center;">Jml</th>
                                <th style="text-align:right;">Harga</th>
                                <th style="text-align:right;">Total</th>
                                <th>Kasir</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($penjualan->num_rows > 0): ?>
                                <?php while ($row = $penjualan->fetch_assoc()): ?>
                                <tr>
                                    <td><small><?php echo $row['no_invoice']; ?></small></td>
                                    <td><?php echo date('d/m/Y', strtotime($row['tanggal_penjualan'])); ?></td>
                                    <td><?php echo $row['nama_produk']; ?></td>
                                    <td style="text-align:center;"><?php echo $row['jumlah']; ?></td>
                                    <td style="text-align:right;"><?php echo rupiah($row['harga_jual_saat']); ?></td>
                                    <td style="text-align:right;font-weight:600;"><?php echo rupiah($row['total_bayar']); ?></td>
                                    <td><?php echo $row['kasir'] ?? '-'; ?></td>
                                    <td>
                                        <span class="badge badge-success"><?php echo $row['status']; ?></span>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                                <tr class="total-row">
                                    <td colspan="5" style="text-align:right;">Total</td>
                                    <td style="text-align:right;"><?php echo rupiah($total_data['total']); ?></td>
                                    <td colspan="2"></td>
                                </tr>
                            <?php else: ?>
                                <tr class="empty-row">
                                    <td colspan="8">
                                        <i class="fas fa-info-circle"></i> Tidak ada data penjualan pada periode ini
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>

        <!-- Bottom Navigation -->
        <nav class="bottom-nav no-print">
            <a href="../index.php"><i class="fas fa-home"></i><span>Dashboard</span></a>
            <a href="../modules/penjualan.php"><i class="fas fa-cash-register"></i><span>Kasir</span></a>
            <a href="../modules/pembelian.php"><i class="fas fa-truck"></i><span>Beli</span></a>
            <a href="../modules/produk.php"><i class="fas fa-box"></i><span>Produk</span></a>
            <a href="laba_rugi.php" class="active"><i class="fas fa-chart-bar"></i><span>Laporan</span></a>
        </nav>
    </div>

    <script>
        // ============================================
        // CHART PENJUALAN HARIAN (Bar)
        // ============================================
        <?php
        $labels_harian_chart = [];
        $data_harian_chart = [];
        $penjualan_harian->data_seek(0);
        while ($row = $penjualan_harian->fetch_assoc()) {
            $labels_harian_chart[] = date('d M', strtotime($row['tanggal_penjualan']));
            $data_harian_chart[] = $row['total'];
        }
        ?>
        new Chart(document.getElementById('chartHarian'), {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($labels_harian_chart); ?>,
                datasets: [{
                    label: 'Penjualan (Rp)',
                    data: <?php echo json_encode($data_harian_chart); ?>,
                    backgroundColor: 'rgba(0, 150, 136, 0.6)',
                    borderColor: '#009688',
                    borderWidth: 2,
                    borderRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return 'Rp ' + value.toLocaleString('id-ID');
                            }
                        }
                    }
                }
            }
        });

        // ============================================
        // CHART METODE PEMBAYARAN (Doughnut)
        // ============================================
        <?php
        $labels_metode = [];
        $data_metode = [];
        $colors_metode = ['#4CAF50', '#2196F3', '#9C27B0', '#FF9800', '#f44336'];
        $icons_metode = ['💵', '🏦', '📱', '💳', '💳'];
        
        $metode_pembayaran->data_seek(0);
        while ($row = $metode_pembayaran->fetch_assoc()) {
            $labels_metode[] = ucfirst($row['metode_pembayaran']);
            $data_metode[] = $row['total'];
        }
        ?>
        new Chart(document.getElementById('chartMetode'), {
            type: 'doughnut',
            data: {
                labels: <?php echo json_encode($labels_metode); ?>,
                datasets: [{
                    data: <?php echo json_encode($data_metode); ?>,
                    backgroundColor: <?php echo json_encode(array_slice($colors_metode, 0, count($data_metode))); ?>,
                    borderWidth: 2,
                    borderColor: '#fff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 16,
                            font: { size: 12 }
                        }
                    }
                },
                cutout: '60%'
            }
        });
    </script>
    <script src="../js/script.js"></script>
</body>
</html>