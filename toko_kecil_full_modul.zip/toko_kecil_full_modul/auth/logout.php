<?php
include '../config/database.php';

if (isset($_SESSION['user_id'])) {
    logActivity($conn, $_SESSION['user_id'], 'Logout', 'User logout');
}

session_destroy();
header("Location: login.php");
exit();
?>