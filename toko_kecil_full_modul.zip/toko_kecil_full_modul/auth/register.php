<?php
include '../config/database.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = md5($_POST['password']);
    $nama_lengkap = $_POST['nama_lengkap'];
    $no_telp = $_POST['no_telp'] ?? '';
    $role = 'kasir'; // Default role

    // Cek username sudah ada
    $check = $conn->query("SELECT id FROM users WHERE username = '$username'");
    if ($check->num_rows > 0) {
        $message = '<div class="alert error">Username sudah digunakan!</div>';
    } else {
        $stmt = $conn->prepare("INSERT INTO users (username, password, nama_lengkap, no_telp, role) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $username, $password, $nama_lengkap, $no_telp, $role);
        
        if ($stmt->execute()) {
            $message = '<div class="alert success">Registrasi berhasil! Silakan login.</div>';
        } else {
            $message = '<div class="alert error">Gagal: ' . $conn->error . '</div>';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Toko Kecil</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="auth-page">
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-header">
                <i class="fas fa-store" style="font-size: 48px; color: #4CAF50;"></i>
                <h1>Daftar Akun</h1>
                <p>Buat akun baru untuk toko</p>
            </div>

            <?php echo $message; ?>

            <form method="POST" class="auth-form">
                <div class="form-group">
                    <label><i class="fas fa-user"></i> Username</label>
                    <input type="text" name="username" required placeholder="Masukkan username">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-user-circle"></i> Nama Lengkap</label>
                    <input type="text" name="nama_lengkap" required placeholder="Masukkan nama lengkap">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-lock"></i> Password</label>
                    <input type="password" name="password" required placeholder="Masukkan password">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-phone"></i> No. Telp</label>
                    <input type="text" name="no_telp" placeholder="Masukkan no. telp">
                </div>
                <button type="submit" class="btn-submit">
                    <i class="fas fa-user-plus"></i> Daftar
                </button>
            </form>
            <div class="auth-footer">
                <small>Sudah punya akun? <a href="login.php">Login di sini</a></small>
            </div>
        </div>
    </div>
</body>
</html>