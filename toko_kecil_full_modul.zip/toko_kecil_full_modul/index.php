<?php
include 'config/database.php';

// Statistik
$total_produk = $conn->query("SELECT COUNT(*) as total FROM produk")->fetch_assoc()['total'];
$total_kategori = $conn->query("SELECT COUNT(*) as total FROM kategori")->fetch_assoc()['total'];
$total_supplier = $conn->query("SELECT COUNT(*) as total FROM supplier")->fetch_assoc()['total'];
$total_pelanggan = $conn->query("SELECT COUNT(*) as total FROM pelanggan")->fetch_assoc()['total'] ?? 0;

// Penjualan hari ini
$penjualan_hari = $conn->query("SELECT COALESCE(SUM(total_bayar), 0) as total FROM penjualan WHERE tanggal_penjualan = CURDATE() AND status = 'selesai'")->fetch_assoc()['total'];

// Pembelian hari ini
$pembelian_hari = $conn->query("SELECT COALESCE(SUM(total_harga), 0) as total FROM pembelian WHERE tanggal_pembelian = CURDATE() AND status = 'selesai'")->fetch_assoc()['total'];

// Laba kotor hari ini
$laba_hari = $conn->query("
    SELECT COALESCE(SUM((p.harga_jual - p.harga_beli) * pen.jumlah), 0) as laba 
    FROM penjualan pen 
    JOIN produk p ON pen.produk_id = p.id 
    WHERE pen.tanggal_penjualan = CURDATE() AND pen.status = 'selesai'
")->fetch_assoc()['laba'];

// Biaya operasional bulan ini
$biaya_bulan = $conn->query("
    SELECT COALESCE(SUM(nominal), 0) as total 
    FROM biaya_operasional 
    WHERE MONTH(tanggal) = MONTH(CURDATE()) AND YEAR(tanggal) = YEAR(CURDATE())
")->fetch_assoc()['total'];

// Laba bersih = laba kotor - biaya
$laba_bersih = $laba_hari - ($biaya_bulan / 30);

// Stok menipis
$stok_menipis = getStokMenipis($conn);

// Total transaksi hari ini
$total_transaksi_hari = $conn->query("
    SELECT COUNT(*) as total FROM penjualan 
    WHERE tanggal_penjualan = CURDATE() AND status = 'selesai'
")->fetch_assoc()['total'];

// ============================================
// CEK SHIFT AKTIF
// ============================================
$shift_aktif = $conn->query("
    SELECT * FROM kasir_shift 
    WHERE user_id = {$_SESSION['user_id']} AND status = 'open'
")->num_rows > 0;

// ============================================
// CEK NOTIFIKASI BELUM DIBACA
// ============================================
$notif_unread = $conn->query("
    SELECT COUNT(*) as total FROM notifikasi 
    WHERE user_id = {$_SESSION['user_id']} AND is_read = 0
")->fetch_assoc()['total'];

// ============================================
// DATA UNTUK GRAFIK
// ============================================

// Penjualan 7 hari terakhir
$labels_7hari = [];
$data_7hari = [];
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $labels_7hari[] = date('d M', strtotime($date));
    $result = $conn->query("SELECT COALESCE(SUM(total_bayar), 0) as total FROM penjualan WHERE tanggal_penjualan = '$date' AND status = 'selesai'");
    $data_7hari[] = $result->fetch_assoc()['total'];
}

// Penjualan per bulan (6 bulan terakhir)
$labels_6bulan = [];
$data_6bulan = [];
for ($i = 5; $i >= 0; $i--) {
    $month = date('Y-m', strtotime("-$i months"));
    $labels_6bulan[] = date('M Y', strtotime($month));
    $result = $conn->query("
        SELECT COALESCE(SUM(total_bayar), 0) as total 
        FROM penjualan 
        WHERE DATE_FORMAT(tanggal_penjualan, '%Y-%m') = '$month' 
        AND status = 'selesai'
    ");
    $data_6bulan[] = $result->fetch_assoc()['total'];
}

// 10 Penjualan terakhir
$penjualan_terakhir = $conn->query("
    SELECT p.nama_produk, pen.jumlah, pen.total_bayar, pen.tanggal_penjualan, pen.status, pen.no_invoice
    FROM penjualan pen 
    JOIN produk p ON pen.produk_id = p.id 
    WHERE pen.status = 'selesai'
    ORDER BY pen.created_at DESC LIMIT 10
");

// Produk terlaris bulan ini
$produk_terlaris = $conn->query("
    SELECT p.nama_produk, SUM(pen.jumlah) as total_terjual, SUM(pen.total_bayar) as total_pendapatan
    FROM penjualan pen 
    JOIN produk p ON pen.produk_id = p.id 
    WHERE MONTH(pen.tanggal_penjualan) = MONTH(CURDATE()) 
    AND YEAR(pen.tanggal_penjualan) = YEAR(CURDATE())
    AND pen.status = 'selesai'
    GROUP BY p.id
    ORDER BY total_terjual DESC
    LIMIT 5
");

// Transaksi hari ini (detail)
$transaksi_hari_ini = $conn->query("
    SELECT pen.*, p.nama_produk 
    FROM penjualan pen 
    JOIN produk p ON pen.produk_id = p.id 
    WHERE pen.tanggal_penjualan = CURDATE() 
    AND pen.status = 'selesai'
    ORDER BY pen.created_at DESC 
    LIMIT 10
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Dashboard - Toko Kecil</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* ============================================
           DASHBOARD EXTRA STYLES
           ============================================ */
        .greeting-section {
            background: linear-gradient(135deg, #1B5E20 0%, #4CAF50 100%);
            color: white;
            padding: 18px 24px;
            border-radius: var(--radius);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        
        .greeting-section h2 {
            font-size: 20px;
            font-weight: 700;
            margin: 0;
        }
        
        .greeting-section .greeting-sub {
            font-size: 13px;
            opacity: 0.9;
        }
        
        .greeting-section .greeting-date {
            font-size: 13px;
            opacity: 0.8;
            background: rgba(255,255,255,0.15);
            padding: 6px 14px;
            border-radius: 20px;
        }
        
        /* Quick Actions */
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(6, 1fr);
            gap: 8px;
            margin-bottom: 20px;
        }
        
        .quick-btn {
            padding: 12px 6px;
            border-radius: var(--radius-sm);
            color: white;
            text-decoration: none;
            text-align: center;
            font-size: 10px;
            font-weight: 600;
            transition: var(--transition);
            box-shadow: var(--shadow);
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 4px;
            border: none;
            cursor: pointer;
            position: relative;
            min-height: 60px;
        }
        
        .quick-btn i {
            font-size: 20px;
        }
        
        .quick-btn:active {
            transform: scale(0.94);
        }
        
        .quick-btn .btn-label {
            font-size: 8px;
            line-height: 1.2;
            opacity: 0.9;
        }
        
        .quick-btn .badge-notif {
            position: absolute;
            top: -5px;
            right: -5px;
            background: #f44336;
            color: white;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 9px;
            min-width: 18px;
            text-align: center;
        }
        
        .quick-btn .badge-shift {
            position: absolute;
            top: -5px;
            right: -5px;
            background: #4CAF50;
            color: white;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 8px;
        }
        
        /* Charts */
        .chart-grid-dashboard {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
            margin-bottom: 20px;
        }
        
        .chart-box {
            background: var(--card-bg);
            border-radius: var(--radius);
            padding: 16px 18px;
            box-shadow: var(--shadow);
        }
        
        .chart-box h4 {
            font-size: 14px;
            font-weight: 600;
            margin: 0 0 12px 0;
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--text);
        }
        
        .chart-box h4 i {
            color: var(--primary-light);
        }
        
        .chart-container {
            position: relative;
            height: 180px;
            width: 100%;
        }
        
        /* Top Products */
        .top-product-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 8px 0;
            border-bottom: 1px solid #f0f2f5;
        }
        
        .top-product-item:last-child {
            border-bottom: none;
        }
        
        .top-product-item .rank {
            width: 24px;
            height: 24px;
            border-radius: 50%;
            background: var(--primary-light);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 11px;
            font-weight: 700;
            margin-right: 10px;
            flex-shrink: 0;
        }
        
        .top-product-item .rank.gold { background: #FFD700; color: #333; }
        .top-product-item .rank.silver { background: #C0C0C0; color: #333; }
        .top-product-item .rank.bronze { background: #CD7F32; color: white; }
        
        .top-product-item .product-name {
            flex: 1;
            font-weight: 500;
            font-size: 13px;
        }
        
        .top-product-item .product-info {
            text-align: right;
            font-size: 12px;
            color: var(--text-light);
        }
        
        .top-product-item .product-info .amount {
            font-weight: 600;
            color: var(--text);
        }
        
        /* Today Transactions */
        .today-transaction {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 6px 0;
            border-bottom: 1px solid #f0f2f5;
            font-size: 13px;
        }
        
        .today-transaction:last-child {
            border-bottom: none;
        }
        
        .today-transaction .time {
            font-size: 11px;
            color: var(--text-light);
        }
        
        .today-transaction .amount {
            font-weight: 600;
            color: var(--primary-dark);
        }
        
        /* Status badges */
        .status-badge {
            display: inline-block;
            padding: 2px 10px;
            border-radius: 12px;
            font-size: 10px;
            font-weight: 600;
        }
        
        .status-badge.success {
            background: #e8f5e9;
            color: #2e7d32;
        }
        
        .status-badge.warning {
            background: #fff3e0;
            color: #e65100;
        }
        
        .status-badge.danger {
            background: #ffebee;
            color: #c62828;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .quick-actions {
                grid-template-columns: repeat(4, 1fr);
            }
            
            .chart-grid-dashboard {
                grid-template-columns: 1fr;
            }
            
            .greeting-section {
                flex-direction: column;
                text-align: center;
                gap: 8px;
            }
            
            .greeting-section .greeting-date {
                font-size: 12px;
            }
        }
        
        @media (max-width: 480px) {
            .quick-actions {
                grid-template-columns: repeat(3, 1fr);
                gap: 5px;
            }
            
            .quick-btn {
                padding: 8px 4px;
                min-height: 50px;
                font-size: 8px;
            }
            
            .quick-btn i {
                font-size: 14px;
            }
            
            .quick-btn .btn-label {
                font-size: 7px;
            }
            
            .stats-grid {
                grid-template-columns: 1fr 1fr;
                gap: 8px;
            }
            
            .stat-card {
                padding: 12px 10px;
            }
            
            .stat-card .stat-value {
                font-size: 14px;
            }
            
            .stat-card .stat-icon {
                font-size: 18px;
                width: 34px;
                height: 34px;
            }
            
            .greeting-section h2 {
                font-size: 16px;
            }
            
            .chart-box {
                padding: 12px;
            }
            
            .chart-container {
                height: 150px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <header class="header">
            <div>
                <h1><i class="fas fa-store"></i> Toko Kecil</h1>
                <span class="user-info"><i class="fas fa-user"></i> <?php echo $_SESSION['nama_lengkap'] ?? 'Guest'; ?> (<?php echo $_SESSION['role'] ?? 'Guest'; ?>)</span>
            </div>
            <div class="header-actions">
                <!-- Shift Icon -->
                <a href="modules/shift.php" class="btn-icon" title="Shift Kasir">
                    <i class="fas fa-clock"></i>
                    <?php if ($shift_aktif): ?>
                    <span class="badge-shift-icon">●</span>
                    <?php endif; ?>
                </a>
                <!-- Notification Icon -->
                <a href="modules/notifikasi.php" class="btn-icon" title="Notifikasi">
                    <i class="fas fa-bell"></i>
                    <?php if ($notif_unread > 0): ?>
                    <span class="badge-icon"><?php echo $notif_unread; ?></span>
                    <?php endif; ?>
                </a>
                <!-- Menu Dropdown -->
                <div class="menu-dropdown">
                    <button class="menu-btn"><i class="fas fa-bars"></i></button>
                    <div class="menu-content">
                        <div class="menu-header">📊 DASHBOARD</div>
                        <a href="index.php"><i class="fas fa-home"></i> Dashboard</a>
                        
                        <div class="menu-header">📦 MASTER DATA</div>
                        <a href="modules/produk.php"><i class="fas fa-box"></i> Produk</a>
                        <a href="modules/kategori.php"><i class="fas fa-tags"></i> Kategori</a>
                        <a href="modules/supplier.php"><i class="fas fa-truck"></i> Supplier</a>
                        <a href="modules/pelanggan.php"><i class="fas fa-users"></i> Pelanggan</a>
                        
                        <div class="menu-header">💰 TRANSAKSI</div>
                        <a href="modules/penjualan.php"><i class="fas fa-cash-register"></i> Kasir / POS</a>
                        <a href="modules/pembelian.php"><i class="fas fa-shopping-cart"></i> Pembelian</a>
                        <a href="modules/retur_penjualan.php"><i class="fas fa-undo"></i> Retur Penjualan</a>
                        <a href="modules/retur_pembelian.php"><i class="fas fa-undo-alt"></i> Retur Pembelian</a>
                        
                        <div class="menu-header">📈 LAPORAN</div>
                        <a href="laporan/laba_rugi.php"><i class="fas fa-chart-line"></i> Laba Rugi</a>
                        <a href="laporan/stok.php"><i class="fas fa-cubes"></i> Laporan Stok</a>
                        <a href="laporan/penjualan.php"><i class="fas fa-file-invoice"></i> Laporan Penjualan</a>
                        <a href="laporan/export_excel.php"><i class="fas fa-file-excel"></i> Export Excel</a>
                        
                        <div class="menu-header">⚙️ SISTEM</div>
                        <a href="modules/shift.php"><i class="fas fa-clock"></i> Shift Kasir</a>
                        <a href="modules/notifikasi.php"><i class="fas fa-bell"></i> Notifikasi</a>
                        <a href="modules/user.php"><i class="fas fa-users-cog"></i> Manajemen User</a>
                        <a href="modules/backup.php"><i class="fas fa-database"></i> Backup</a>
                        <a href="modules/konfigurasi.php"><i class="fas fa-cog"></i> Konfigurasi</a>
                        <a href="auth/logout.php" style="color:#f44336;"><i class="fas fa-sign-out-alt"></i> Logout</a>
                    </div>
                </div>
            </div>
        </header>

        <!-- Greeting Section -->
        <div class="greeting-section">
            <div>
                <h2>👋 Selamat Datang, <?php echo $_SESSION['nama_lengkap'] ?? 'Guest'; ?>!</h2>
                <div class="greeting-sub">
                    <i class="fas fa-store-alt"></i> Toko Kecil - Sistem Manajemen Toko
                </div>
            </div>
            <div class="greeting-date">
                <i class="fas fa-calendar-alt"></i> <?php echo date('l, d F Y'); ?>
                <span style="margin-left:8px;"><i class="fas fa-clock"></i> <?php echo date('H:i'); ?></span>
            </div>
        </div>

        <!-- Stats Grid - Utama -->
        <div class="stats-grid">
            <div class="stat-card" style="border-left-color: #4CAF50;">
                <div class="stat-icon"><i class="fas fa-boxes"></i></div>
                <div class="stat-info">
                    <span class="stat-label">Total Produk</span>
                    <span class="stat-value"><?php echo $total_produk; ?></span>
                </div>
            </div>
            <div class="stat-card" style="border-left-color: #2196F3;">
                <div class="stat-icon"><i class="fas fa-tags"></i></div>
                <div class="stat-info">
                    <span class="stat-label">Kategori</span>
                    <span class="stat-value"><?php echo $total_kategori; ?></span>
                </div>
            </div>
            <div class="stat-card" style="border-left-color: #FF9800;">
                <div class="stat-icon"><i class="fas fa-truck"></i></div>
                <div class="stat-info">
                    <span class="stat-label">Supplier</span>
                    <span class="stat-value"><?php echo $total_supplier; ?></span>
                </div>
            </div>
            <div class="stat-card" style="border-left-color: #9C27B0;">
                <div class="stat-icon"><i class="fas fa-users"></i></div>
                <div class="stat-info">
                    <span class="stat-label">Pelanggan</span>
                    <span class="stat-value"><?php echo $total_pelanggan; ?></span>
                </div>
            </div>
        </div>

        <!-- Stats Grid - Stok & Transaksi -->
        <div class="stats-grid">
            <div class="stat-card" style="border-left-color: #f44336;">
                <div class="stat-icon"><i class="fas fa-exclamation-triangle"></i></div>
                <div class="stat-info">
                    <span class="stat-label">Stok Menipis</span>
                    <span class="stat-value <?php echo $stok_menipis > 0 ? 'text-danger' : 'text-success'; ?>">
                        <?php echo $stok_menipis; ?>
                    </span>
                </div>
            </div>
            <div class="stat-card" style="border-left-color: #2196F3;">
                <div class="stat-icon"><i class="fas fa-receipt"></i></div>
                <div class="stat-info">
                    <span class="stat-label">Transaksi Hari Ini</span>
                    <span class="stat-value"><?php echo $total_transaksi_hari; ?></span>
                </div>
            </div>
            <div class="stat-card" style="border-left-color: #4CAF50;">
                <div class="stat-icon"><i class="fas fa-shopping-cart"></i></div>
                <div class="stat-info">
                    <span class="stat-label">Penjualan Hari Ini</span>
                    <span class="stat-value"><?php echo rupiah($penjualan_hari); ?></span>
                </div>
            </div>
            <div class="stat-card" style="border-left-color: #FF9800;">
                <div class="stat-icon"><i class="fas fa-arrow-down"></i></div>
                <div class="stat-info">
                    <span class="stat-label">Pembelian Hari Ini</span>
                    <span class="stat-value"><?php echo rupiah($pembelian_hari); ?></span>
                </div>
            </div>
        </div>

        <!-- Stats Grid - Laba -->
        <div class="stats-grid">
            <div class="stat-card" style="border-left-color: #9C27B0;">
                <div class="stat-icon"><i class="fas fa-coins"></i></div>
                <div class="stat-info">
                    <span class="stat-label">Laba Kotor Hari Ini</span>
                    <span class="stat-value"><?php echo rupiah($laba_hari); ?></span>
                </div>
            </div>
            <div class="stat-card" style="border-left-color: #00BCD4;">
                <div class="stat-icon"><i class="fas fa-wallet"></i></div>
                <div class="stat-info">
                    <span class="stat-label">Laba Bersih (Estimasi)</span>
                    <span class="stat-value"><?php echo rupiah($laba_bersih); ?></span>
                </div>
            </div>
            <div class="stat-card" style="border-left-color: <?php echo $shift_aktif ? '#4CAF50' : '#f44336'; ?>;">
                <div class="stat-icon"><i class="fas fa-clock"></i></div>
                <div class="stat-info">
                    <span class="stat-label">Status Shift</span>
                    <span class="stat-value" style="color: <?php echo $shift_aktif ? '#4CAF50' : '#f44336'; ?>; font-size:14px;">
                        <?php echo $shift_aktif ? '🟢 Aktif' : '🔴 Tutup'; ?>
                    </span>
                </div>
            </div>
            <div class="stat-card" style="border-left-color: <?php echo $notif_unread > 0 ? '#f44336' : '#4CAF50'; ?>;">
                <div class="stat-icon"><i class="fas fa-bell"></i></div>
                <div class="stat-info">
                    <span class="stat-label">Notifikasi</span>
                    <span class="stat-value" style="color: <?php echo $notif_unread > 0 ? '#f44336' : '#4CAF50'; ?>; font-size:14px;">
                        <?php echo $notif_unread > 0 ? '🔴 ' . $notif_unread . ' belum dibaca' : '✅ Semua terbaca'; ?>
                    </span>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="quick-actions">
            <a href="modules/penjualan.php" class="quick-btn" style="background:#4CAF50;">
                <i class="fas fa-cash-register"></i>
                <span class="btn-label">Kasir</span>
            </a>
            <a href="modules/pembelian.php" class="quick-btn" style="background:#FF9800;">
                <i class="fas fa-truck"></i>
                <span class="btn-label">Beli</span>
            </a>
            <a href="modules/produk.php" class="quick-btn" style="background:#2196F3;">
                <i class="fas fa-box"></i>
                <span class="btn-label">Produk</span>
            </a>
            <a href="modules/kategori.php" class="quick-btn" style="background:#9C27B0;">
                <i class="fas fa-tags"></i>
                <span class="btn-label">Kategori</span>
            </a>
            <a href="modules/supplier.php" class="quick-btn" style="background:#795548;">
                <i class="fas fa-truck"></i>
                <span class="btn-label">Supplier</span>
            </a>
            <a href="modules/retur_penjualan.php" class="quick-btn" style="background:#f44336;">
                <i class="fas fa-undo"></i>
                <span class="btn-label">Retur Jual</span>
            </a>
            <a href="modules/retur_pembelian.php" class="quick-btn" style="background:#E91E63;">
                <i class="fas fa-undo-alt"></i>
                <span class="btn-label">Retur Beli</span>
            </a>
            <a href="laporan/laba_rugi.php" class="quick-btn" style="background:#00BCD4;">
                <i class="fas fa-chart-line"></i>
                <span class="btn-label">Laba Rugi</span>
            </a>
            <a href="laporan/stok.php" class="quick-btn" style="background:#3F51B5;">
                <i class="fas fa-cubes"></i>
                <span class="btn-label">Stok</span>
            </a>
            <a href="laporan/export_excel.php" class="quick-btn" style="background:#217346;">
                <i class="fas fa-file-excel"></i>
                <span class="btn-label">Export</span>
            </a>
            <a href="modules/shift.php" class="quick-btn" style="background:#FF5722;">
                <i class="fas fa-clock"></i>
                <span class="btn-label">Shift</span>
                <?php if ($shift_aktif): ?>
                <span class="badge-shift">●</span>
                <?php endif; ?>
            </a>
            <a href="modules/notifikasi.php" class="quick-btn" style="background:#607D8B;">
                <i class="fas fa-bell"></i>
                <span class="btn-label">Notifikasi</span>
                <?php if ($notif_unread > 0): ?>
                <span class="badge-notif"><?php echo $notif_unread; ?></span>
                <?php endif; ?>
            </a>
        </div>

        <!-- Charts -->
        <div class="chart-grid-dashboard">
            <div class="chart-box">
                <h4><i class="fas fa-chart-line"></i> Penjualan 7 Hari Terakhir</h4>
                <div class="chart-container">
                    <canvas id="chart7Hari"></canvas>
                </div>
            </div>
            <div class="chart-box">
                <h4><i class="fas fa-chart-bar"></i> Penjualan 6 Bulan Terakhir</h4>
                <div class="chart-container">
                    <canvas id="chart6Bulan"></canvas>
                </div>
            </div>
        </div>

        <!-- Bottom Section: Top Products & Today Transactions -->
        <div class="chart-grid-dashboard">
            <div class="chart-box">
                <h4><i class="fas fa-fire"></i> Top 5 Produk Terlaris Bulan Ini</h4>
                <?php if ($produk_terlaris->num_rows > 0): ?>
                    <?php 
                    $rank_classes = ['gold', 'silver', 'bronze', '', ''];
                    $i = 0;
                    while ($row = $produk_terlaris->fetch_assoc()): 
                    ?>
                    <div class="top-product-item">
                        <div style="display:flex;align-items:center;">
                            <span class="rank <?php echo $rank_classes[$i] ?? ''; ?>"><?php echo $i + 1; ?></span>
                            <span class="product-name"><?php echo $row['nama_produk']; ?></span>
                        </div>
                        <span class="product-info">
                            <?php echo $row['total_terjual']; ?> terjual<br>
                            <span class="amount"><?php echo rupiah($row['total_pendapatan']); ?></span>
                        </span>
                    </div>
                    <?php 
                    $i++;
                    endwhile; 
                    ?>
                <?php else: ?>
                    <p style="text-align:center;color:var(--text-light);padding:20px;">
                        <i class="fas fa-info-circle"></i> Belum ada data penjualan bulan ini
                    </p>
                <?php endif; ?>
            </div>
            <div class="chart-box">
                <h4><i class="fas fa-clock"></i> Transaksi Hari Ini</h4>
                <?php if ($transaksi_hari_ini->num_rows > 0): ?>
                    <?php while ($row = $transaksi_hari_ini->fetch_assoc()): ?>
                    <div class="today-transaction">
                        <div>
                            <span style="font-weight:500;"><?php echo $row['nama_produk']; ?></span>
                            <span class="time"> • <?php echo date('H:i', strtotime($row['created_at'])); ?></span>
                            <span style="font-size:11px;color:var(--text-light);margin-left:4px;">
                                (<?php echo $row['jumlah']; ?>x)
                            </span>
                        </div>
                        <span class="amount"><?php echo rupiah($row['total_bayar']); ?></span>
                    </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p style="text-align:center;color:var(--text-light);padding:20px;">
                        <i class="fas fa-info-circle"></i> Belum ada transaksi hari ini
                    </p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Recent Transactions Table -->
        <div class="section">
            <h3><i class="fas fa-list"></i> 10 Transaksi Terakhir</h3>
            <div class="table-responsive">
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>Invoice</th>
                            <th>Tanggal</th>
                            <th>Produk</th>
                            <th style="text-align:center;">Jml</th>
                            <th style="text-align:right;">Total</th>
                            <th style="text-align:center;">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($penjualan_terakhir->num_rows > 0): ?>
                        <?php while ($row = $penjualan_terakhir->fetch_assoc()): ?>
                        <tr>
                            <td><small><?php echo $row['no_invoice']; ?></small></td>
                            <td><?php echo date('d/m/Y', strtotime($row['tanggal_penjualan'])); ?></td>
                            <td><?php echo $row['nama_produk']; ?></td>
                            <td style="text-align:center;"><?php echo $row['jumlah']; ?></td>
                            <td style="text-align:right;"><?php echo rupiah($row['total_bayar']); ?></td>
                            <td style="text-align:center;">
                                <span class="status-badge success"><?php echo $row['status']; ?></span>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                        <?php else: ?>
                        <tr>
                            <td colspan="6" style="text-align:center;padding:20px;color:var(--text-light);">
                                <i class="fas fa-info-circle"></i> Belum ada transaksi
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Bottom Navigation -->
        <nav class="bottom-nav">
            <a href="index.php" class="active"><i class="fas fa-home"></i><span>Dashboard</span></a>
            <a href="modules/penjualan.php"><i class="fas fa-cash-register"></i><span>Kasir</span></a>
            <a href="modules/pembelian.php"><i class="fas fa-truck"></i><span>Beli</span></a>
            <a href="modules/produk.php"><i class="fas fa-box"></i><span>Produk</span></a>
            <a href="laporan/laba_rugi.php"><i class="fas fa-chart-bar"></i><span>Laporan</span></a>
        </nav>
    </div>

    <script>
        // ============================================
        // CHART 7 HARI
        // ============================================
        new Chart(document.getElementById('chart7Hari'), {
            type: 'line',
            data: {
                labels: <?php echo json_encode($labels_7hari); ?>,
                datasets: [{
                    label: 'Penjualan (Rp)',
                    data: <?php echo json_encode($data_7hari); ?>,
                    borderColor: '#4CAF50',
                    backgroundColor: 'rgba(76, 175, 80, 0.1)',
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: '#4CAF50',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return 'Rp ' + value.toLocaleString('id-ID');
                            }
                        }
                    }
                }
            }
        });

        // ============================================
        // CHART 6 BULAN
        // ============================================
        new Chart(document.getElementById('chart6Bulan'), {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($labels_6bulan); ?>,
                datasets: [{
                    label: 'Penjualan (Rp)',
                    data: <?php echo json_encode($data_6bulan); ?>,
                    backgroundColor: ['rgba(76, 175, 80, 0.6)', 'rgba(33, 150, 243, 0.6)', 'rgba(255, 152, 0, 0.6)', 'rgba(156, 39, 176, 0.6)', 'rgba(244, 67, 54, 0.6)', 'rgba(0, 188, 212, 0.6)'],
                    borderColor: ['#4CAF50', '#2196F3', '#FF9800', '#9C27B0', '#f44336', '#00BCD4'],
                    borderWidth: 2,
                    borderRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return 'Rp ' + value.toLocaleString('id-ID');
                            }
                        }
                    }
                }
            }
        });
    </script>
    <script src="js/script.js"></script>
</body>
</html>