<?php
include 'config.php';
$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $produk_id = $_POST['produk_id'];
    $jumlah = $_POST['jumlah'];
    $harga_jual_saat = $_POST['harga_jual'];
    $total_penjualan = $jumlah * $harga_jual_saat;
    $tanggal = $_POST['tanggal'];
    $pelanggan = $_POST['pelanggan'] ?? 'Umum';

    $stmt = $conn->prepare("INSERT INTO penjualan (produk_id, jumlah, harga_jual_saat, total_penjualan, tanggal_penjualan, pelanggan) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("iidsss", $produk_id, $jumlah, $harga_jual_saat, $total_penjualan, $tanggal, $pelanggan);

    if ($stmt->execute()) {
        $message = '<div class="alert success"><i class="fas fa-check-circle"></i> Penjualan berhasil dicatat!</div>';
    } else {
        $message = '<div class="alert error"><i class="fas fa-exclamation-circle"></i> Gagal: ' . $conn->error . '</div>';
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Penjualan - Toko Kecil</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <header class="header">
            <a href="index.php" class="back-btn"><i class="fas fa-arrow-left"></i></a>
            <h1><i class="fas fa-cash-register"></i> Penjualan</h1>
            <span></span>
        </header>

        <main class="main-content">
            <?php echo $message; ?>

            <form method="POST" class="form-card" id="formPenjualan">
                <div class="form-group">
                    <label><i class="fas fa-box"></i> Pilih Produk</label>
                    <select name="produk_id" id="produkSelect" required>
                        <option value="">-- Pilih Produk --</option>
                        <?php
                        $result = $conn->query("SELECT * FROM produk ORDER BY nama_produk");
                        while ($row = $result->fetch_assoc()):
                        ?>
                        <option value="<?php echo $row['id']; ?>" 
                                data-harga="<?php echo $row['harga_jual']; ?>"
                                data-stok="<?php echo $row['stok']; ?>">
                            <?php echo $row['nama_produk']; ?> - Stok: <?php echo $row['stok']; ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label><i class="fas fa-hashtag"></i> Jumlah</label>
                        <input type="number" name="jumlah" id="jumlah" min="1" required placeholder="0">
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-tag"></i> Harga Jual</label>
                        <input type="number" name="harga_jual" id="hargaJual" required placeholder="0">
                    </div>
                </div>

                <div class="form-group">
                    <label><i class="fas fa-user"></i> Pelanggan</label>
                    <input type="text" name="pelanggan" placeholder="Nama pelanggan (opsional)">
                </div>

                <div class="form-group">
                    <label><i class="fas fa-calendar"></i> Tanggal</label>
                    <input type="date" name="tanggal" value="<?php echo date('Y-m-d'); ?>" required>
                </div>

                <div class="total-display">
                    <span>Total Penjualan</span>
                    <span id="totalDisplay">Rp 0</span>
                </div>

                <button type="submit" class="btn-submit"><i class="fas fa-save"></i> Simpan Penjualan</button>
            </form>

            <!-- Riwayat Penjualan Hari Ini -->
            <section class="section">
                <h3><i class="fas fa-history"></i> Riwayat Hari Ini</h3>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Produk</th>
                                <th>Jumlah</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $result = $conn->query("
                                SELECT p.nama_produk, pen.jumlah, pen.total_penjualan 
                                FROM penjualan pen 
                                JOIN produk p ON pen.produk_id = p.id 
                                WHERE pen.tanggal_penjualan = CURDATE() 
                                ORDER BY pen.created_at DESC LIMIT 10
                            ");
                            while ($row = $result->fetch_assoc()):
                            ?>
                            <tr>
                                <td><?php echo $row['nama_produk']; ?></td>
                                <td><?php echo $row['jumlah']; ?></td>
                                <td>Rp <?php echo number_format($row['total_penjualan'], 0, ',', '.'); ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>

        <nav class="bottom-nav">
            <a href="index.php"><i class="fas fa-home"></i><span>Dashboard</span></a>
            <a href="penjualan.php" class="active"><i class="fas fa-cash-register"></i><span>Penjualan</span></a>
            <a href="pembelian.php"><i class="fas fa-truck"></i><span>Pembelian</span></a>
            <a href="laporan.php"><i class="fas fa-chart-bar"></i><span>Laporan</span></a>
        </nav>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const produkSelect = document.getElementById('produkSelect');
            const hargaJual = document.getElementById('hargaJual');
            const jumlah = document.getElementById('jumlah');
            const totalDisplay = document.getElementById('totalDisplay');

            produkSelect.addEventListener('change', function() {
                const selected = this.options[this.selectedIndex];
                if (selected.value) {
                    hargaJual.value = selected.dataset.harga;
                    hitungTotal();
                }
            });

            jumlah.addEventListener('input', hitungTotal);
            hargaJual.addEventListener('input', hitungTotal);

            function hitungTotal() {
                const jml = parseInt(jumlah.value) || 0;
                const harga = parseInt(hargaJual.value) || 0;
                const total = jml * harga;
                totalDisplay.textContent = 'Rp ' + total.toLocaleString('id-ID');
            }
        });
    </script>
</body>
</html>