<?php
include 'config.php';
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Dashboard - Toko Kecil</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <!-- Header -->
        <header class="header">
            <h1><i class="fas fa-store"></i> Toko Kecil</h1>
            <div class="date-display"><?php echo date('d M Y'); ?></div>
        </header>

        <!-- Navigasi Bottom untuk Mobile -->
        <nav class="bottom-nav">
            <a href="index.php" class="active"><i class="fas fa-home"></i><span>Dashboard</span></a>
            <a href="penjualan.php"><i class="fas fa-cash-register"></i><span>Penjualan</span></a>
            <a href="pembelian.php"><i class="fas fa-truck"></i><span>Pembelian</span></a>
            <a href="laporan.php"><i class="fas fa-chart-bar"></i><span>Laporan</span></a>
        </nav>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Statistik Cards -->
            <div class="stats-grid">
                <?php
                // Total Produk
                $result = $conn->query("SELECT COUNT(*) as total FROM produk");
                $total_produk = $result->fetch_assoc()['total'];

                // Total Penjualan Hari Ini
                $result = $conn->query("SELECT COALESCE(SUM(total_penjualan), 0) as total FROM penjualan WHERE tanggal_penjualan = CURDATE()");
                $penjualan_hari = $result->fetch_assoc()['total'];

                // Total Pembelian Hari Ini
                $result = $conn->query("SELECT COALESCE(SUM(total_harga), 0) as total FROM pembelian WHERE tanggal_pembelian = CURDATE()");
                $pembelian_hari = $result->fetch_assoc()['total'];

                // Keuntungan Hari Ini (estimasi)
                $result = $conn->query("SELECT COALESCE(SUM((p.harga_jual - p.harga_beli) * pen.jumlah), 0) as laba 
                                        FROM penjualan pen 
                                        JOIN produk p ON pen.produk_id = p.id 
                                        WHERE pen.tanggal_penjualan = CURDATE()");
                $laba_hari = $result->fetch_assoc()['laba'];
                ?>
                <div class="stat-card" style="border-left: 4px solid #4CAF50;">
                    <div class="stat-icon"><i class="fas fa-boxes"></i></div>
                    <div class="stat-info">
                        <span class="stat-label">Total Produk</span>
                        <span class="stat-value"><?php echo $total_produk; ?></span>
                    </div>
                </div>
                <div class="stat-card" style="border-left: 4px solid #2196F3;">
                    <div class="stat-icon"><i class="fas fa-shopping-cart"></i></div>
                    <div class="stat-info">
                        <span class="stat-label">Penjualan Hari Ini</span>
                        <span class="stat-value">Rp <?php echo number_format($penjualan_hari, 0, ',', '.'); ?></span>
                    </div>
                </div>
                <div class="stat-card" style="border-left: 4px solid #FF9800;">
                    <div class="stat-icon"><i class="fas fa-arrow-down"></i></div>
                    <div class="stat-info">
                        <span class="stat-label">Pembelian Hari Ini</span>
                        <span class="stat-value">Rp <?php echo number_format($pembelian_hari, 0, ',', '.'); ?></span>
                    </div>
                </div>
                <div class="stat-card" style="border-left: 4px solid #9C27B0;">
                    <div class="stat-icon"><i class="fas fa-coins"></i></div>
                    <div class="stat-info">
                        <span class="stat-label">Keuntungan Hari Ini</span>
                        <span class="stat-value">Rp <?php echo number_format($laba_hari, 0, ',', '.'); ?></span>
                    </div>
                </div>
            </div>

            <!-- Daftar Produk Terbaru -->
            <section class="section">
                <div class="section-header">
                    <h2><i class="fas fa-list"></i> Produk Terbaru</h2>
                    <a href="penjualan.php" class="btn-primary"><i class="fas fa-plus"></i> Jual</a>
                </div>
                <div class="product-grid">
                    <?php
                    $result = $conn->query("SELECT * FROM produk ORDER BY created_at DESC LIMIT 6");
                    while ($row = $result->fetch_assoc()):
                    ?>
                    <div class="product-card">
                        <div class="product-info">
                            <span class="product-name"><?php echo $row['nama_produk']; ?></span>
                            <span class="product-code"><?php echo $row['kode_produk']; ?></span>
                            <div class="product-price">
                                <span>Beli: Rp <?php echo number_format($row['harga_beli'], 0, ',', '.'); ?></span>
                                <span>Jual: Rp <?php echo number_format($row['harga_jual'], 0, ',', '.'); ?></span>
                            </div>
                        </div>
                        <div class="product-stock <?php echo $row['stok'] <= 5 ? 'stok-menipis' : 'stok-aman'; ?>">
                            <i class="fas fa-cube"></i> <?php echo $row['stok']; ?> <?php echo $row['satuan']; ?>
                        </div>
                    </div>
                    <?php endwhile; ?>
                </div>
            </section>
        </main>
    </div>
    <script src="script.js"></script>
</body>
</html>