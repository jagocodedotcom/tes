<?php
include 'config.php';
$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $produk_id = $_POST['produk_id'];
    $jumlah = $_POST['jumlah'];
    $harga_beli_saat = $_POST['harga_beli'];
    $total_harga = $jumlah * $harga_beli_saat;
    $tanggal = $_POST['tanggal'];
    $supplier = $_POST['supplier'] ?? 'Supplier';

    // Update harga beli produk
    $conn->query("UPDATE produk SET harga_beli = $harga_beli_saat WHERE id = $produk_id");

    $stmt = $conn->prepare("INSERT INTO pembelian (produk_id, jumlah, harga_beli_saat, total_harga, tanggal_pembelian, supplier) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("iidsss", $produk_id, $jumlah, $harga_beli_saat, $total_harga, $tanggal, $supplier);

    if ($stmt->execute()) {
        $message = '<div class="alert success"><i class="fas fa-check-circle"></i> Pembelian berhasil dicatat!</div>';
    } else {
        $message = '<div class="alert error"><i class="fas fa-exclamation-circle"></i> Gagal: ' . $conn->error . '</div>';
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Pembelian - Toko Kecil</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <header class="header">
            <a href="index.php" class="back-btn"><i class="fas fa-arrow-left"></i></a>
            <h1><i class="fas fa-truck"></i> Pembelian Stok</h1>
            <span></span>
        </header>

        <main class="main-content">
            <?php echo $message; ?>

            <form method="POST" class="form-card">
                <div class="form-group">
                    <label><i class="fas fa-box"></i> Pilih Produk</label>
                    <select name="produk_id" required>
                        <option value="">-- Pilih Produk --</option>
                        <?php
                        $result = $conn->query("SELECT * FROM produk ORDER BY nama_produk");
                        while ($row = $result->fetch_assoc()):
                        ?>
                        <option value="<?php echo $row['id']; ?>" data-harga="<?php echo $row['harga_beli']; ?>">
                            <?php echo $row['nama_produk']; ?> - Stok: <?php echo $row['stok']; ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label><i class="fas fa-hashtag"></i> Jumlah</label>
                        <input type="number" name="jumlah" min="1" required placeholder="0">
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-tag"></i> Harga Beli</label>
                        <input type="number" name="harga_beli" id="hargaBeli" required placeholder="0">
                    </div>
                </div>

                <div class="form-group">
                    <label><i class="fas fa-building"></i> Supplier</label>
                    <input type="text" name="supplier" placeholder="Nama supplier">
                </div>

                <div class="form-group">
                    <label><i class="fas fa-calendar"></i> Tanggal</label>
                    <input type="date" name="tanggal" value="<?php echo date('Y-m-d'); ?>" required>
                </div>

                <button type="submit" class="btn-submit"><i class="fas fa-save"></i> Simpan Pembelian</button>
            </form>

            <!-- Riwayat Pembelian -->
            <section class="section">
                <h3><i class="fas fa-history"></i> Riwayat Pembelian</h3>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Produk</th>
                                <th>Jumlah</th>
                                <th>Total</th>
                                <th>Supplier</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $result = $conn->query("
                                SELECT p.nama_produk, beli.jumlah, beli.total_harga, beli.supplier 
                                FROM pembelian beli 
                                JOIN produk p ON beli.produk_id = p.id 
                                ORDER BY beli.created_at DESC LIMIT 10
                            ");
                            while ($row = $result->fetch_assoc()):
                            ?>
                            <tr>
                                <td><?php echo $row['nama_produk']; ?></td>
                                <td><?php echo $row['jumlah']; ?></td>
                                <td>Rp <?php echo number_format($row['total_harga'], 0, ',', '.'); ?></td>
                                <td><?php echo $row['supplier']; ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>

        <nav class="bottom-nav">
            <a href="index.php"><i class="fas fa-home"></i><span>Dashboard</span></a>
            <a href="penjualan.php"><i class="fas fa-cash-register"></i><span>Penjualan</span></a>
            <a href="pembelian.php" class="active"><i class="fas fa-truck"></i><span>Pembelian</span></a>
            <a href="laporan.php"><i class="fas fa-chart-bar"></i><span>Laporan</span></a>
        </nav>
    </div>
    <script>
        document.querySelector('select[name="produk_id"]').addEventListener('change', function() {
            const selected = this.options[this.selectedIndex];
            if (selected.value) {
                document.getElementById('hargaBeli').value = selected.dataset.harga;
            }
        });
    </script>
</body>
</html>