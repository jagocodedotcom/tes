<?php
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'toko_kecil';

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

date_default_timezone_set('Asia/Jakarta');
?>