<?php
include 'config.php';

// Ambil data untuk laporan
$bulan = $_GET['bulan'] ?? date('Y-m');
list($tahun, $bulan_angka) = explode('-', $bulan);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Laporan - Toko Kecil</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="container">
        <header class="header">
            <a href="index.php" class="back-btn"><i class="fas fa-arrow-left"></i></a>
            <h1><i class="fas fa-chart-bar"></i> Laporan</h1>
            <span></span>
        </header>

        <main class="main-content">
            <!-- Filter Bulan -->
            <form method="GET" class="filter-form">
                <div class="form-group">
                    <label>Bulan</label>
                    <input type="month" name="bulan" value="<?php echo $bulan; ?>" onchange="this.form.submit()">
                </div>
            </form>

            <!-- Ringkasan -->
            <div class="stats-grid">
                <?php
                // Total Penjualan Bulan Ini
                $result = $conn->query("SELECT COALESCE(SUM(total_penjualan), 0) as total 
                                        FROM penjualan 
                                        WHERE MONTH(tanggal_penjualan) = $bulan_angka AND YEAR(tanggal_penjualan) = $tahun");
                $total_penjualan = $result->fetch_assoc()['total'];

                // Total Pembelian Bulan Ini
                $result = $conn->query("SELECT COALESCE(SUM(total_harga), 0) as total 
                                        FROM pembelian 
                                        WHERE MONTH(tanggal_pembelian) = $bulan_angka AND YEAR(tanggal_pembelian) = $tahun");
                $total_pembelian = $result->fetch_assoc()['total'];

                // HPP = Total Pembelian
                $hpp = $total_pembelian;

                // Laba Kotor
                $laba_kotor = $total_penjualan - $hpp;

                // Margin
                $margin = $total_penjualan > 0 ? ($laba_kotor / $total_penjualan) * 100 : 0;
                ?>
                <div class="stat-card">
                    <span class="stat-label">Total Penjualan</span>
                    <span class="stat-value">Rp <?php echo number_format($total_penjualan, 0, ',', '.'); ?></span>
                </div>
                <div class="stat-card" style="border-left: 4px solid #FF9800;">
                    <span class="stat-label">HPP (Total Pembelian)</span>
                    <span class="stat-value">Rp <?php echo number_format($hpp, 0, ',', '.'); ?></span>
                </div>
                <div class="stat-card" style="border-left: 4px solid #4CAF50;">
                    <span class="stat-label">Laba Kotor</span>
                    <span class="stat-value">Rp <?php echo number_format($laba_kotor, 0, ',', '.'); ?></span>
                </div>
                <div class="stat-card" style="border-left: 4px solid #9C27B0;">
                    <span class="stat-label">Margin Keuntungan</span>
                    <span class="stat-value"><?php echo number_format($margin, 1); ?>%</span>
                </div>
            </div>

            <!-- Grafik Penjualan per Produk -->
            <section class="section">
                <h3><i class="fas fa-chart-pie"></i> Penjualan per Produk</h3>
                <div class="chart-container">
                    <canvas id="produkChart"></canvas>
                </div>
            </section>

            <!-- Detail Produk -->
            <section class="section">
                <h3><i class="fas fa-list"></i> Detail Produk</h3>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Produk</th>
                                <th>Terjual</th>
                                <th>Pendapatan</th>
                                <th>HPP</th>
                                <th>Laba</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $result = $conn->query("
                                SELECT 
                                    p.nama_produk,
                                    COALESCE(SUM(pen.jumlah), 0) as terjual,
                                    COALESCE(SUM(pen.total_penjualan), 0) as pendapatan,
                                    COALESCE(SUM(pen.jumlah * p.harga_beli), 0) as hpp_produk
                                FROM produk p
                                LEFT JOIN penjualan pen ON p.id = pen.produk_id 
                                    AND MONTH(pen.tanggal_penjualan) = $bulan_angka 
                                    AND YEAR(pen.tanggal_penjualan) = $tahun
                                GROUP BY p.id
                                HAVING terjual > 0
                                ORDER BY pendapatan DESC
                            ");
                            while ($row = $result->fetch_assoc()):
                                $laba_produk = $row['pendapatan'] - $row['hpp_produk'];
                            ?>
                            <tr>
                                <td><?php echo $row['nama_produk']; ?></td>
                                <td><?php echo $row['terjual']; ?></td>
                                <td>Rp <?php echo number_format($row['pendapatan'], 0, ',', '.'); ?></td>
                                <td>Rp <?php echo number_format($row['hpp_produk'], 0, ',', '.'); ?></td>
                                <td style="color: <?php echo $laba_produk >= 0 ? '#4CAF50' : '#f44336'; ?>">
                                    Rp <?php echo number_format($laba_produk, 0, ',', '.'); ?>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>

        <nav class="bottom-nav">
            <a href="index.php"><i class="fas fa-home"></i><span>Dashboard</span></a>
            <a href="penjualan.php"><i class="fas fa-cash-register"></i><span>Penjualan</span></a>
            <a href="pembelian.php"><i class="fas fa-truck"></i><span>Pembelian</span></a>
            <a href="laporan.php" class="active"><i class="fas fa-chart-bar"></i><span>Laporan</span></a>
        </nav>
    </div>

    <script>
        // Chart.js untuk grafik
        const ctx = document.getElementById('produkChart').getContext('2d');
        <?php
        $labels = [];
        $data = [];
        $result = $conn->query("
            SELECT p.nama_produk, COALESCE(SUM(pen.total_penjualan), 0) as total
            FROM produk p
            LEFT JOIN penjualan pen ON p.id = pen.produk_id 
                AND MONTH(pen.tanggal_penjualan) = $bulan_angka 
                AND YEAR(pen.tanggal_penjualan) = $tahun
            GROUP BY p.id
            HAVING total > 0
            ORDER BY total DESC
            LIMIT 5
        ");
        while ($row = $result->fetch_assoc()) {
            $labels[] = $row['nama_produk'];
            $data[] = $row['total'];
        }
        ?>
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($labels); ?>,
                datasets: [{
                    label: 'Penjualan (Rp)',
                    data: <?php echo json_encode($data); ?>,
                    backgroundColor: ['#4CAF50', '#2196F3', '#FF9800', '#9C27B0', '#f44336'],
                    borderRadius: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: { display: false }
                }
            }
        });
    </script>
</body>
</html>