-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 07, 2026 at 11:30 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bigshop_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`, `full_name`, `created_at`) VALUES
(1, 'admin', 'admin123', 'Super Administrator', '2026-08-07 01:08:48');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL DEFAULT 1,
  `session_id` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `icon` varchar(50) DEFAULT 'fa-code'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `icon`) VALUES
(1, 'Sistem Informasi', 'sistem-informasi', 'fa-database'),
(2, 'Sistem Pendukung Keputusan (SPK)', 'spk', 'fa-chart-pie'),
(3, 'Sistem Pakar', 'sistem-pakar', 'fa-robot'),
(4, 'Data Mining', 'data-mining', 'fa-magnifying-glass-chart'),
(5, 'Machine Learning', 'machine-learning', 'fa-brain'),
(6, 'Business Intelligence', 'business-intelligence', 'fa-chart-line'),
(7, 'GIS', 'gis', 'fa-map-location-dot'),
(8, 'Internet of Things (IoT)', 'iot', 'fa-microchip'),
(9, 'Enterprise System', 'enterprise-system', 'fa-building'),
(10, 'E-Commerce', 'e-commerce', 'fa-cart-shopping');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `order_id` varchar(50) NOT NULL,
  `session_id` varchar(255) NOT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `customer_wa` varchar(20) DEFAULT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `payment_method` varchar(50) DEFAULT 'Transfer BCA',
  `status` enum('pending','paid','cancelled') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `download_token` varchar(64) DEFAULT NULL,
  `is_downloaded` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` varchar(50) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `old_price` decimal(10,2) DEFAULT NULL,
  `image` varchar(255) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `rating` decimal(2,1) DEFAULT 4.5,
  `is_featured` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `file_source` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `slug`, `description`, `price`, `old_price`, `image`, `category_id`, `rating`, `is_featured`, `created_at`, `file_source`) VALUES
(17, 'SISTEM PENDUKUNG KEPUTUSAN PEMILIHAN SISWA TELADAN DENGAN METODE AHP', 'sistem-pendukung-keputusan-pemilihan-siswa-teladan-dengan-metode-ahp', '<b>📋 DAFTAR MODUL</b>\r\n\r\n<p>Sistem Pendukung Keputusan (SPK) Pemilihan Siswa Teladan menggunakan metode Analytical Hierarchy Process (AHP) terdiri dari delapan modul utama yang saling terintegrasi. Setiap modul dirancang untuk mendukung proses pengelolaan data, perhitungan AHP, hingga menghasilkan keputusan yang objektif dan transparan.</p>\r\n\r\n<b>1. 🔐 LOGIN</b>\r\n\r\n<p>Modul Login berfungsi sebagai gerbang autentikasi pengguna sebelum mengakses sistem. Fitur yang tersedia meliputi autentikasi menggunakan username dan password, validasi keamanan dengan hash password (bcrypt), session management untuk menjaga status login, pengaturan hak akses berdasarkan role (Admin, Pakar, dan User), pencatatan aktivitas login, serta tampilan halaman login yang responsif pada berbagai perangkat.</p>\r\n\r\n<b>2. 📊 DASHBOARD</b>\r\n\r\n<p>Dashboard merupakan halaman utama yang menyajikan ringkasan informasi sistem. Modul ini menampilkan statistik jumlah siswa, jumlah kriteria, jumlah penilaian, dan total data yang telah diranking. Selain itu tersedia informasi siswa peringkat pertama, berbagai grafik analisis seperti Bar Chart, Pie Chart, Radar Chart, dan Line Chart, progress bobot kriteria AHP, daftar lima siswa terbaik, status kelengkapan data, progress tahapan sistem, serta menu Quick Action untuk mengakses seluruh modul dengan cepat.</p>\r\n\r\n<b>3. 📋 KRITERIA (CRUD)</b>\r\n\r\n<p>Modul Kriteria digunakan untuk mengelola seluruh data kriteria penilaian. Pengguna dapat menambahkan, mengubah, menghapus, dan melihat daftar kriteria. Setiap kriteria memiliki kode unik, nama, deskripsi, serta jenis Benefit atau Cost. Sistem juga melakukan validasi agar tidak terjadi duplikasi kode dan memastikan setiap data memenuhi aturan yang telah ditentukan.</p>\r\n\r\n<b>4. 👨‍🎓 SISWA (ALTERNATIF) (CRUD)</b>\r\n\r\n<p>Modul Siswa digunakan untuk mengelola data alternatif yang akan dinilai. Fitur yang tersedia meliputi penambahan data siswa, perubahan data, penghapusan data, serta daftar siswa yang dilengkapi fasilitas pencarian dan pengurutan menggunakan DataTables. Setiap data siswa terdiri dari NIS, nama, kelas, jenis kelamin, alamat, dan nomor telepon dengan validasi NIS yang bersifat unik.</p>\r\n\r\n<b>5. ✏️ PENILAIAN</b>\r\n\r\n<p>Modul Penilaian digunakan untuk memberikan nilai kepada setiap siswa berdasarkan kriteria yang telah ditentukan. Pengguna dapat memilih siswa, memilih kriteria, kemudian memasukkan nilai pada rentang 0 sampai 100. Sistem memastikan bahwa setiap kombinasi siswa dan kriteria hanya memiliki satu nilai sehingga data penilaian tetap konsisten.</p>\r\n\r\n<b>6. ⚖️ PERBANDINGAN AHP</b>\r\n\r\n<p>Modul Perbandingan AHP digunakan untuk menentukan tingkat kepentingan antar kriteria menggunakan metode perbandingan berpasangan berdasarkan Skala Saaty. Sistem secara otomatis melakukan normalisasi matriks, menghitung bobot prioritas, nilai Eigen Value (λmax), Consistency Index (CI), dan Consistency Ratio (CR). Apabila nilai CR kurang dari atau sama dengan 10%, maka hasil perbandingan dinyatakan konsisten dan dapat digunakan dalam proses perankingan.</p>\r\n\r\n<b>7. 🏆 HASIL PERANKINGAN</b>\r\n\r\n<p>Modul Hasil Perankingan menampilkan hasil akhir perhitungan AHP dalam bentuk ranking siswa. Halaman ini menyediakan statistik hasil penilaian, filter berdasarkan kelas, berbagai grafik visualisasi, progress bobot kriteria, tabel ranking lengkap dengan skor akhir dan predikat, detail nilai setiap siswa, serta fasilitas ekspor ke Excel, PDF, dan cetak langsung.</p>\r\n\r\n<b>8. 📤 EXPORT</b>\r\n\r\n<p>Modul Export berfungsi untuk menghasilkan laporan hasil perankingan dalam berbagai format. Pengguna dapat mengekspor data ke file Excel (.xls), membuat laporan PDF berformat A4 landscape menggunakan html2pdf.js, maupun mencetak hasil perankingan secara langsung dengan tampilan yang telah dioptimalkan untuk kebutuhan cetak.</p>\r\n\r\n<b>KESIMPULAN</b>\r\n\r\n<p>Seluruh modul pada Sistem Pendukung Keputusan Pemilihan Siswa Teladan dirancang agar saling terintegrasi mulai dari proses autentikasi, pengelolaan data, penilaian, perhitungan metode AHP, hingga penyajian hasil perankingan dan pembuatan laporan. Dengan adanya modul-modul tersebut, proses pengambilan keputusan menjadi lebih efektif, objektif, transparan, dan mudah dipertanggungjawabkan.</p>\r\n<b>ABSTRAK</b>\r\n\r\n<p>Penelitian ini membahas pengembangan Sistem Pendukung Keputusan (SPK) untuk pemilihan siswa teladan menggunakan metode Analytical Hierarchy Process (AHP). Sistem dibangun berbasis web menggunakan PHP, MySQL, dan Bootstrap sehingga mampu membantu sekolah melakukan penilaian secara objektif, transparan, dan konsisten.</p>\r\n\r\n<p>Metode AHP digunakan untuk menghitung bobot setiap kriteria melalui perbandingan berpasangan sehingga menghasilkan proses penilaian yang lebih akurat dibandingkan metode manual.</p>\r\n\r\n<b>KESIMPULAN ABSTRAK</b>\r\n\r\n<p>Sistem yang dibangun mampu menghasilkan proses pemilihan siswa teladan yang lebih objektif, terukur, dan mudah dipertanggungjawabkan.</p>\r\n\r\n\r\n<b>1. PENDAHULUAN</b>\r\n\r\n<p>Pemilihan siswa teladan di sekolah masih dilakukan secara manual sehingga berpotensi menimbulkan subjektivitas, kurang transparan, serta sulit didokumentasikan. Oleh karena itu dibutuhkan Sistem Pendukung Keputusan berbasis metode AHP untuk membantu proses penilaian.</p>\r\n\r\n<b>KESIMPULAN PENDAHULUAN</b>\r\n\r\n<p>Penerapan Sistem Pendukung Keputusan menggunakan metode AHP menjadi solusi untuk meningkatkan objektivitas, transparansi, dan efisiensi dalam proses pemilihan siswa teladan.</p>\r\n\r\n\r\n<b>2. LANDASAN TEORI</b>\r\n\r\n<p>Landasan teori menjelaskan konsep Sistem Pendukung Keputusan (SPK), komponen penyusunnya, serta metode Analytical Hierarchy Process (AHP) yang digunakan untuk menentukan bobot prioritas melalui perbandingan berpasangan dan pengujian konsistensi.</p>\r\n\r\n<b>KESIMPULAN LANDASAN TEORI</b>\r\n\r\n<p>Metode AHP merupakan metode pengambilan keputusan yang mampu menghasilkan bobot kriteria secara logis dan konsisten sehingga sangat sesuai diterapkan dalam sistem pemilihan siswa teladan.</p>\r\n\r\n\r\n<b>3. METODOLOGI PENELITIAN</b>\r\n\r\n<p>Pengembangan sistem menggunakan metode Waterfall yang terdiri dari analisis kebutuhan, desain sistem, implementasi, pengujian, dan pemeliharaan. Sistem dirancang untuk mengelola data siswa, kriteria, penilaian, hingga menghasilkan peringkat siswa.</p>\r\n\r\n<b>KESIMPULAN METODOLOGI</b>\r\n\r\n<p>Metode Waterfall memberikan tahapan pengembangan yang terstruktur sehingga proses pembangunan sistem dapat dilakukan secara sistematis dan sesuai kebutuhan pengguna.</p>\r\n\r\n\r\n<b>4. PERANCANGAN SISTEM</b>\r\n\r\n<p>Sistem dirancang menggunakan arsitektur berbasis web dengan PHP sebagai backend, MySQL sebagai database, serta Bootstrap sebagai antarmuka pengguna. Database terdiri dari beberapa tabel yang saling berhubungan untuk mengelola seluruh proses penilaian.</p>\r\n\r\n<b>KESIMPULAN PERANCANGAN SISTEM</b>\r\n\r\n<p>Perancangan sistem menghasilkan struktur aplikasi yang terintegrasi sehingga seluruh proses penilaian dapat dikelola secara efektif dan efisien.</p>\r\n\r\n\r\n<b>5. IMPLEMENTASI SISTEM</b>\r\n\r\n<p>Implementasi sistem menghasilkan berbagai modul seperti Login, Dashboard, Data Kriteria, Data Siswa, Penilaian, Perbandingan AHP, dan Hasil Perankingan yang saling terintegrasi.</p>\r\n\r\n<b>KESIMPULAN IMPLEMENTASI</b>\r\n\r\n<p>Seluruh modul berhasil diimplementasikan dan mampu mendukung proses pengelolaan data hingga menghasilkan keputusan secara otomatis.</p>\r\n\r\n\r\n<b>6. PERHITUNGAN METODE AHP</b>\r\n\r\n<p>Perhitungan dilakukan melalui pembentukan matriks perbandingan, normalisasi, perhitungan bobot prioritas, pengujian konsistensi, dan perhitungan skor akhir untuk memperoleh peringkat siswa teladan.</p>\r\n\r\n<b>KESIMPULAN PERHITUNGAN AHP</b>\r\n\r\n<p>Hasil perhitungan menunjukkan nilai Consistency Ratio (CR) sebesar 2,7%, sehingga matriks dinyatakan konsisten dan hasil perankingan dapat dijadikan dasar pengambilan keputusan.</p>\r\n\r\n\r\n<b>7. PENGUJIAN SISTEM</b>\r\n\r\n<p>Pengujian dilakukan terhadap seluruh fungsi sistem, mulai dari proses login, pengelolaan data, perhitungan AHP, hingga proses ekspor laporan. Seluruh fungsi berjalan dengan baik dan menghasilkan kinerja yang cepat.</p>\r\n\r\n<b>KESIMPULAN PENGUJIAN</b>\r\n\r\n<p>Sistem berhasil melewati seluruh proses pengujian fungsional, konsistensi, dan kinerja sehingga layak digunakan sebagai sistem pendukung keputusan pemilihan siswa teladan.</p>\r\n\r\n\r\n<b>8. KESIMPULAN</b>\r\n\r\n<p>Sistem Pendukung Keputusan pemilihan siswa teladan berbasis web menggunakan metode Analytical Hierarchy Process (AHP) berhasil dibangun dan mampu menghasilkan keputusan yang objektif, transparan, serta konsisten. Sistem juga mempermudah pengelolaan data, proses penilaian, dan penyusunan laporan hasil pemilihan.</p>\r\n\r\n<b>KESIMPULAN AKHIR</b>\r\n\r\n<p>Penerapan metode AHP pada Sistem Pendukung Keputusan terbukti mampu meningkatkan kualitas proses pengambilan keputusan dalam pemilihan siswa teladan sehingga menjadi solusi yang efektif bagi sekolah dalam menentukan siswa terbaik secara adil dan terukur.</p>', 250000.00, 150000.00, '1786073687_1786073642388-d5840e46-12e8-43f4-b525-8c667fb28872_1.jpg', 1, 4.5, 0, '2026-08-07 03:32:29', '1786073549_spk_siswa_ahp.zip');

-- --------------------------------------------------------

--
-- Table structure for table `vouchers`
--

CREATE TABLE `vouchers` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `discount_type` enum('fixed','percent') DEFAULT 'percent',
  `discount_value` decimal(10,2) NOT NULL,
  `min_purchase` decimal(10,2) DEFAULT 0.00,
  `expires_at` date DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vouchers`
--

INSERT INTO `vouchers` (`id`, `code`, `discount_type`, `discount_value`, `min_purchase`, `expires_at`, `is_active`) VALUES
(1, 'SUBSCRIBE10', 'percent', 10.00, 50000.00, '2026-12-31', 1),
(2, 'FOLLOW20', 'percent', 20.00, 100000.00, '2026-12-31', 1),
(3, 'WELCOME5', 'fixed', 5000.00, 0.00, '2026-12-31', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `order_id` (`order_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `vouchers`
--
ALTER TABLE `vouchers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `vouchers`
--
ALTER TABLE `vouchers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
