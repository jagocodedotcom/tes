    <!-- FOOTER -->
    <footer style="background: #0A192F; color: #a0aec0; padding: 50px 0 20px; margin-top: 50px;">
        <div class="container">
            <div class="footer-grid" style="display: grid; grid-template-columns: 2fr 1fr 1fr 1.5fr; gap: 40px; border-bottom: 1px solid rgba(255,255,255,0.05); padding-bottom: 40px; margin-bottom: 30px;">
                <div class="f-about"> <a href="index.php" class="logo-area"> 
                <img src="uploads/logo_jagocode.png" alt="BigSoft Logo">
            </a></div>
                <div class="f-col"><h5 style="color:white; font-size:16px; margin-bottom:20px;">Layanan</h5><ul><li style="margin-bottom:12px; font-size:14px; cursor:pointer;">Hubungi CS</li><li>Pusat Bantuan</li></ul></div>
                <div class="f-col"><h5 style="color:white; font-size:16px; margin-bottom:20px;">Tentang</h5><ul><li>Tentang Kami</li><li>Karir</li><li>Blog</li></ul></div>
                <div class="f-col"><h5 style="color:white; font-size:16px; margin-bottom:20px;">Download</h5><a href="#" style="background:#333; color:white; padding:8px 15px; border-radius:8px; font-size:12px;"><i class="fab fa-google-play"></i> Web Store</a></div>
            </div>
            <div style="border-top:1px solid rgba(255,255,255,0.05); padding-top:20px; margin-top:20px; text-align:center; font-size:13px;">
                &copy; 2026 Jagocode.com .
            </div>
        </div>
    </footer>

    <!-- FLOATING WA -->
    <a href="https://wa.me/6281234567890" target="_blank" class="wa-float"><i class="fab fa-whatsapp"></i></a>

    <!-- SCRIPTS -->
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script>
        // Inisialisasi Swiper (jika ada di halaman)
        var swiper = new Swiper(".mySwiper", { autoplay: { delay: 4500 }, loop: true, pagination: { el: ".swiper-pagination", clickable: true } });
    </script>
</body>
</html>