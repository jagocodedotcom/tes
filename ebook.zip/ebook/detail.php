<?php
require 'db_connect.php';

// Ambil slug dari URL (SEO Link)
$slug = isset($_GET['slug']) ? mysqli_real_escape_string($conn, $_GET['slug']) : '';

if (empty($slug)) {
    header("Location: index.php");
    exit;
}

// Query produk berdasarkan slug
$product = $conn->query("SELECT p.*, c.name as cat_name FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE p.slug = '$slug'");

if ($product->num_rows == 0) {
    header("Location: index.php");
    exit;
}

$row = $product->fetch_assoc();

// --- GENERATE META TAG OTOMATIS UNTUK SEO ---

// 1. Meta Title
$meta_title = htmlspecialchars($row['name']) . " - Jagocode.com";

// 2. Meta Description
$clean_desc = strip_tags($row['description']);
$meta_description = substr($clean_desc, 0, 160);
if (strlen($clean_desc) > 160) $meta_description .= "...";

// 3. Meta Keywords (Hashtag)
preg_match_all('/#(\w+)/', $row['description'], $matches);
$meta_keywords = implode(', ', $matches[1]);
if (empty($meta_keywords)) $meta_keywords = htmlspecialchars($row['name']);

// 4. Open Graph Tags
$og_image = "https://" . $_SERVER['HTTP_HOST'] . "/ebook/uploads/" . $row['image'];
if (!file_exists('uploads/'.$row['image'])) $og_image = "https://" . $_SERVER['HTTP_HOST'] . "/ebook/uploads/default.jpg";
$og_url = "https://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

// Format deskripsi
$description = nl2br(htmlspecialchars($row['description']));
$description = preg_replace('/#(\w+)/', '<a href="shop.php?search=%23$1" style="color:#FF6B00; font-weight:bold; text-decoration:none;">#$1</a>', $description);

// Ambil Produk Rekomendasi
$related = $conn->query("SELECT * FROM products WHERE category_id = {$row['category_id']} AND id != {$row['id']} LIMIT 4");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- ===== META TAG SEO ===== -->
    <title><?= $meta_title ?></title>
    <meta name="description" content="<?= $meta_description ?>">
    <meta name="keywords" content="<?= $meta_keywords ?>">
    <meta name="robots" content="index, follow">
    
    <!-- ===== OPEN GRAPH ===== -->
    <meta property="og:title" content="<?= $meta_title ?>">
    <meta property="og:description" content="<?= $meta_description ?>">
    <meta property="og:image" content="<?= $og_image ?>">
    <meta property="og:url" content="<?= $og_url ?>">
    <meta property="og:type" content="article">
    <meta property="og:site_name" content="Jagocode.com">
    
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?= $meta_title ?>">
    <meta name="twitter:description" content="<?= $meta_description ?>">
    <meta name="twitter:image" content="<?= $og_image ?>">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">

    <style>
        /* Global Blog Style */
        .blog-wrapper { max-width: 1100px; margin: 40px auto; background: white; border-radius: 16px; padding: 0; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.08); }
        
        /* Breadcrumb SEO */
        .blog-breadcrumb { padding: 20px 30px 0; font-size: 13px; color: #777; }
        .blog-breadcrumb a { color: #0A192F; text-decoration: none; }
        .blog-breadcrumb a:hover { text-decoration: underline; }
        .blog-breadcrumb span { color: #FF6B00; font-weight: 600; }

        /* Header Artikel */
        .blog-header { padding: 20px 30px 0; }
        .blog-header h1 { font-size: 32px; font-weight: 800; color: #1a1a1a; margin-bottom: 10px; line-height: 1.3; }
        .blog-meta { display: flex; flex-wrap: wrap; gap: 20px; font-size: 14px; color: #666; margin-bottom: 15px; }
        .blog-meta .cat { background: #f1f5f9; padding: 3px 12px; border-radius: 20px; color: #0A192F; font-weight: 600; }
        .blog-meta .rating { color: #f1c40f; }
        .blog-meta .date { color: #999; }

        /* Layout Utama: KIRI (Konten) & KANAN (Sidebar + Gambar) */
        .blog-layout { display: grid; grid-template-columns: 1.5fr 1fr; gap: 40px; padding: 30px; }

        /* KONTEN ARTIKEL (KIRI) */
        .blog-content h2 { font-size: 24px; color: #0A192F; margin-bottom: 20px; border-left: 4px solid #FF6B00; padding-left: 15px; }
        .blog-content p { line-height: 1.8; color: #444; margin-bottom: 20px; font-size: 16px; }
        .blog-content .hashtag-list { margin: 20px 0; }
        .blog-content .hashtag-list span { display: inline-block; background: #f1f5f9; padding: 4px 12px; border-radius: 20px; margin-right: 8px; margin-bottom: 8px; font-size: 13px; font-weight: 600; color: #0A192F; }

        /* SIDEBAR (KANAN) - GAMBAR BESAR & INFO PRODUK */
        .blog-sidebar { 
            background: #f8fafc; 
            border-radius: 16px; 
            padding: 25px; 
            height: fit-content; 
            position: sticky; 
            top: 100px; 
            border: 1px solid #eee;
        }
        
        /* AREA GAMBAR DI SIDEBAR (DIBUAT SANGAT BESAR) */
        .sidebar-gambar {
            width: 100%;
            height: 350px; /* Ukuran sangat besar */
            background: white;
            border-radius: 12px;
            padding: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 20px;
            border: 1px solid #e2e8f0;
            overflow: hidden;
        }
        .sidebar-gambar img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
            transition: transform 0.4s ease;
        }
        /* Efek zoom saat hover gambar sidebar */
        .sidebar-gambar:hover img {
            transform: scale(1.08);
        }

        /* INFO PRODUK DI SIDEBAR */
        .blog-sidebar h3 { font-size: 18px; border-bottom: 2px solid #FF6B00; padding-bottom: 12px; margin-bottom: 15px; color: #0A192F; }
        .sidebar-price { font-size: 28px; font-weight: bold; color: #e74c3c; display: block; margin-bottom: 5px; }
        .sidebar-price del { font-size: 16px; color: #999; font-weight: normal; margin-left: 10px; }
        .sidebar-desc { font-size: 14px; color: #555; line-height: 1.6; margin-bottom: 20px; }
        
        /* TOMBOL AKSI DI SIDEBAR */
        .sidebar-actions { display: flex; flex-direction: column; gap: 10px; }
        .sidebar-actions .btn-cart { background: #FF6B00; color: white; border: none; padding: 14px; border-radius: 8px; font-weight: bold; font-size: 15px; cursor: pointer; transition: 0.2s; width: 100%; }
        .sidebar-actions .btn-cart:hover { background: #e05f00; }
        .sidebar-actions .btn-buy { background: #0A192F; color: white; border: none; padding: 14px; border-radius: 8px; font-weight: bold; font-size: 15px; cursor: pointer; transition: 0.2s; width: 100%; text-align: center; display: block; text-decoration: none; }
        .sidebar-actions .btn-buy:hover { background: #1a2a3f; }

        /* SHARE ARTIKEL */
        .sidebar-share { margin-top: 15px; text-align: center; font-size: 13px; color: #777; border-top: 1px solid #eee; padding-top: 15px; }
        .sidebar-share a { margin: 0 5px; font-size: 18px; }

        /* RELATED POSTS */
        .related-posts { border-top: 1px solid #eee; padding: 30px; background: #fafafa; }
        .related-posts h3 { font-size: 22px; margin-bottom: 20px; color: #0A192F; border-left: 4px solid #FF6B00; padding-left: 15px; }
        .related-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 20px; }
        .related-card { background: white; border-radius: 12px; padding: 15px; text-align: center; transition: 0.3s; border: 1px solid #eee; }
        .related-card:hover { transform: translateY(-5px); box-shadow: 0 10px 20px rgba(0,0,0,0.08); }
        .related-card img { height: 120px; object-fit: contain; width: 100%; background: #f8fafc; border-radius: 8px; padding: 10px; }
        .related-card h4 { font-size: 14px; font-weight: 600; height: 40px; overflow: hidden; margin: 10px 0 5px; }
        .related-card .r-price { color: #e74c3c; font-weight: bold; font-size: 15px; }
        .related-card a { text-decoration: none; color: inherit; }

        /* Responsive */
        @media (max-width: 992px) {
            .blog-layout { grid-template-columns: 1fr; }
            .blog-sidebar { position: static; }
            .sidebar-gambar { height: 280px; }
        }
        @media (max-width: 600px) {
            .blog-header h1 { font-size: 24px; }
            .blog-meta { gap: 10px; font-size: 12px; }
            .sidebar-gambar { height: 220px; }
            .related-grid { grid-template-columns: repeat(2, 1fr); }
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>

    <div class="container">
        <article class="blog-wrapper">
            
            <!-- Breadcrumb -->
            <div class="blog-breadcrumb">
                <a href="index.php">Home</a> / 
                <a href="shop.php?category=<?= $row['category_id'] ?>"><?= $row['cat_name'] ?></a> / 
                <span><?= $row['name'] ?></span>
            </div>
            
            <!-- Header Artikel -->
            <header class="blog-header">
                <h1><?= $row['name'] ?></h1>
                <div class="blog-meta">
                    <span class="cat"><i class="fas fa-tag"></i> <?= $row['cat_name'] ?></span>
                    <span class="rating"><i class="fas fa-star"></i> <?= $row['rating'] ?> / 5.0</span>
                    <span class="date"><i class="far fa-calendar-alt"></i> <?= date('d F Y', strtotime($row['created_at'])) ?></span>
                </div>
            </header>
            
            <!-- Layout Utama: KIRI (Teks) & KANAN (Gambar + Harga) -->
            <div class="blog-layout">
                
                <!-- KOLOM KIRI: Konten Artikel -->
                <div class="blog-content">
                    <h2><i class="fas fa-info-circle" style="color:#FF6B00;"></i> Tentang Produk Ini</h2>
                    
                    <div class="blog-body">
                        <?= $description ?>
                    </div>
                    
                    <div class="hashtag-list">
                        <strong>Tags:</strong>
                        <?php 
                        preg_match_all('/#(\w+)/', $row['description'], $matches);
                        if(!empty($matches[1])) {
                            foreach($matches[1] as $tag) {
                                echo '<span><a href="shop.php?search=%23'.$tag.'" style="color:#0A192F; text-decoration:none;">#'.$tag.'</a></span>';
                            }
                        } else {
                            echo '<span style="background:#eee; color:#999;">Tidak ada tag</span>';
                        }
                        ?>
                    </div>
                </div>
                
                <!-- KOLOM KANAN: Sidebar (Gambar Besar + Info Beli) -->
                <aside class="blog-sidebar">
                    
                    <!-- GAMBAR BESAR DI SIDEBAR -->
                    <div class="sidebar-gambar">
                        <img src="<?php if(file_exists('uploads/'.$row['image'])) { echo 'uploads/'.$row['image']; } else { echo 'https://via.placeholder.com/400?text=No+Image'; } ?>" alt="<?= $row['name'] ?>">
                    </div>

                    <h3><i class="fas fa-shopping-bag" style="color:#FF6B00;"></i> Info Pembelian</h3>
                    
                    <span class="sidebar-price">
                        Rp <?= number_format($row['price'],0,',','.') ?>
                        <?php if($row['old_price']) echo '<del>Rp '.number_format($row['old_price'],0,',','.').'</del>'; ?>
                    </span>
                    
                    <div class="sidebar-desc">
                        <?= substr(strip_tags($row['description']), 0, 100) ?>...
                    </div>
                    
                    <!-- Tombol Aksi -->
                    <div class="sidebar-actions">
                        <button class="btn-cart" onclick="addToCart(<?= $row['id'] ?>)">
                            <i class="fas fa-cart-plus"></i> Masukkan Keranjang
                        </button>
                        <button class="btn-buy" onclick="buyNow(<?= $row['id'] ?>)">
                            <i class="fas fa-bolt"></i> Beli Sekarang
                        </button>
                    </div>
                    
                    <!-- Share -->
                    <div class="sidebar-share">
                        <i class="fas fa-share-alt"></i> Bagikan:
                        <a href="https://wa.me/?text=<?= urlencode($row['name'].' - '.$_SERVER['REQUEST_URI']) ?>" target="_blank" style="color:#25D366;"><i class="fab fa-whatsapp"></i></a>
                        <a href="https://www.facebook.com/sharer/sharer.php?u=<?= urlencode($_SERVER['REQUEST_URI']) ?>" target="_blank" style="color:#1877F2;"><i class="fab fa-facebook"></i></a>
                    </div>
                </aside>
                
            </div>
            
            <!-- Related Posts -->
            <?php if($related->num_rows > 0): ?>
            <div class="related-posts">
                <h3><i class="fas fa-thumbs-up" style="color:#FF6B00;"></i> Produk Rekomendasi Lainnya</h3>
                <div class="related-grid">
                    <?php while($r = $related->fetch_assoc()): ?>
                    <div class="related-card">
                        <a href="detail.php?slug=<?= $r['slug'] ?>">
                            <img src="<?php if(file_exists('uploads/'.$r['image'])) { echo 'uploads/'.$r['image']; } else { echo 'https://via.placeholder.com/200?text=No+Image'; } ?>" alt="<?= $r['name'] ?>">
                            <h4><?= $r['name'] ?></h4>
                            <div class="r-price">Rp <?= number_format($r['price'],0,',','.') ?></div>
                        </a>
                    </div>
                    <?php endwhile; ?>
                </div>
            </div>
            <?php endif; ?>
            
        </article>
    </div>

    <script>
        // Fungsi Tambah ke Keranjang
        function addToCart(productId) {
            fetch('api_cart.php?action=add&id=' + productId)
                .then(response => response.json())
                .then(data => {
                    if(data.status === 'success') {
                        document.getElementById('cartCount').innerText = data.total_items;
                        alert('Produk berhasil ditambahkan ke keranjang!');
                    } else {
                        alert('Gagal menambahkan produk ke keranjang.');
                    }
                })
                .catch(error => console.error('Error:', error));
        }

        // Fungsi Beli Sekarang
        function buyNow(productId) {
            fetch('api_cart.php?action=add&id=' + productId)
                .then(response => response.json())
                .then(data => {
                    if(data.status === 'success') {
                        document.getElementById('cartCount').innerText = data.total_items;
                        window.location.href = 'checkout.php';
                    } else {
                        alert('Gagal memproses pembelian. Silakan coba lagi.');
                    }
                })
                .catch(error => console.error('Error:', error));
        }
    </script>

    <?php include 'footer.php'; ?>
</body>
</html>