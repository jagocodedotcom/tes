<?php
session_start();
require 'db_connect.php';

// Proteksi: Hanya user yang memiliki session keranjang yang bisa melihat pesanan
if (!isset($_SESSION['cart_session'])) {
    $_SESSION['cart_session'] = session_id();
}
$session_id = $_SESSION['cart_session'];

// Ambil semua riwayat pesanan user berdasarkan Session ID
$orders = $conn->query("SELECT * FROM orders WHERE session_id = '$session_id' ORDER BY created_at DESC");
?>

<?php include 'header.php'; ?>

<style>
    .order-container { max-width: 900px; margin: 40px auto; background: white; border-radius: 16px; padding: 30px; box-shadow: 0 10px 30px rgba(0,0,0,0.08); }
    .order-card { border: 1px solid #eee; border-radius: 12px; padding: 20px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px; }
    .status-pending { background: #ffeeba; color: #856404; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: bold; display: inline-block; }
    .status-paid { background: #d4edda; color: #155724; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: bold; display: inline-block; }
    .btn-download { background: #0A192F; color: white; padding: 10px 25px; border-radius: 8px; font-weight: bold; text-decoration: none; display: inline-block; transition: 0.2s; }
    .btn-download:hover { background: #1a2a3f; transform: translateY(-2px); }
    .btn-download.disabled { background: #ccc; cursor: not-allowed; pointer-events: none; }
    @media (max-width: 600px) { .order-card { flex-direction: column; align-items: flex-start; } }
</style>

<div class="container">
    <div class="order-container">
        <h2 style="border-bottom: 2px solid #FF6B00; padding-bottom: 15px; margin-bottom: 25px;">
            <i class="fas fa-box" style="color:#FF6B00;"></i> Riwayat Pesanan & Download Source Code
        </h2>
        <a href="index.php" style="color:#0A192F; font-weight:bold; margin-bottom:20px; display:inline-block;">&larr; Kembali Beranda</a>

        <?php if ($orders->num_rows > 0): ?>
            <?php while($order = $orders->fetch_assoc()): 
                // Ambil nama produk untuk pesanan ini
                $items = $conn->query("SELECT p.name FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = '{$order['order_id']}'");
                $product_names = [];
                while($it = $items->fetch_assoc()) { $product_names[] = $it['name']; }
            ?>
            <div class="order-card">
                <div>
                    <strong>Order ID:</strong> <?= $order['order_id'] ?><br>
                    <span style="font-size:13px; color:#777;">Tanggal: <?= date('d M Y H:i', strtotime($order['created_at'])) ?></span><br>
                    <span style="font-size:13px; color:#333;">Produk: <?= implode(', ', $product_names) ?></span><br>
                    <strong style="color:#e74c3c;">Total: Rp <?= number_format($order['total_amount'],0,',','.') ?></strong>
                </div>
                <div style="text-align: right;">
                    <div style="margin-bottom: 10px;">
                        <?php if($order['status'] == 'pending'): ?>
                            <span class="status-pending">Belum Dibayar</span>
                        <?php elseif($order['status'] == 'paid'): ?>
                            <span class="status-paid">Lunas / Sudah Dibayar</span>
                        <?php endif; ?>
                    </div>
                    
                    <!-- FITUR DOWNLOAD: Hanya muncul jika status PAID -->
                    <?php if($order['status'] == 'paid'): ?>
                        <a href="download.php?token=<?= $order['download_token'] ?>&order_id=<?= $order['order_id'] ?>" class="btn-download" target="_blank">
                            <i class="fas fa-download"></i> Download Source Code
                        </a>
                    <?php else: ?>
                        <a href="#" class="btn-download disabled">
                            <i class="fas fa-lock"></i> Download (Bayar Dulu)
                        </a>
                    <?php endif; ?>
                </div>
            </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div style="text-align:center; padding:40px 0; color:#777;">
                <i class="fas fa-box-open" style="font-size:40px; margin-bottom:15px; display:block;"></i>
                Anda belum melakukan pemesanan.
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include 'footer.php'; ?>