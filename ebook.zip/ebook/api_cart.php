<?php
session_start();
require 'db_connect.php';

// Tentukan Session ID untuk pengguna yang belum login
if (!isset($_SESSION['cart_session'])) {
    $_SESSION['cart_session'] = session_id();
}
$session_id = $_SESSION['cart_session'];

$action = isset($_GET['action']) ? $_GET['action'] : '';

// --- TAMBAH KE KERANJANG ---
if ($action == 'add' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    
    // Cek apakah produk sudah ada di keranjang
    $check = $conn->query("SELECT * FROM cart WHERE product_id = $id AND session_id = '$session_id'");
    if ($check->num_rows > 0) {
        $conn->query("UPDATE cart SET qty = qty + 1 WHERE product_id = $id AND session_id = '$session_id'");
    } else {
        $conn->query("INSERT INTO cart (product_id, qty, session_id) VALUES ($id, 1, '$session_id')");
    }
    
    // Hitung total item di keranjang
    $total = $conn->query("SELECT SUM(qty) as total FROM cart WHERE session_id = '$session_id'")->fetch_assoc()['total'];
    echo json_encode(['status' => 'success', 'message' => 'Produk berhasil ditambahkan!', 'total_items' => $total]);
    exit;
}

// --- HAPUS DARI KERANJANG ---
if ($action == 'remove' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $conn->query("DELETE FROM cart WHERE id = $id AND session_id = '$session_id'");
    header("Location: cart.php");
    exit;
}

// --- UPDATE JUMLAH (QTY) ---
if ($action == 'update' && isset($_GET['id']) && isset($_GET['qty'])) {
    $id = intval($_GET['id']);
    $qty = intval($_GET['qty']);
    if ($qty < 1) $qty = 1;
    $conn->query("UPDATE cart SET qty = $qty WHERE id = $id AND session_id = '$session_id'");
    header("Location: cart.php");
    exit;
}
?>