<?php require 'db_connect.php'; 

// --- LOGIKA FILTER OTOMATIS ---
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';
$category_filter = isset($_GET['category']) ? $_GET['category'] : '';

$sql = "SELECT * FROM products WHERE 1=1";

if (!empty($category_filter)) {
    $sql .= " AND category_id = '" . mysqli_real_escape_string($conn, $category_filter) . "'";
}
if ($filter == 'featured') {
    $sql .= " AND is_featured = 1";
} 
$sql .= " ORDER BY id DESC";
$products = $conn->query($sql);

// Ambil Kategori untuk Menu Filter & Navbar
$categories = $conn->query("SELECT * FROM categories");
$categories_nav = $conn->query("SELECT * FROM categories LIMIT 5");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.5, user-scalable=yes">
    <title>Jagocode.com Solusi Sistem Informasi & IT</title>
    <link rel="icon" type="image/png" href="uploads/ico.png">
    <link rel="shortcut icon" href="uploads/ico.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    
    <style>
        :root { --primary-blue: #0A192F; --accent-orange: #FF6B00; --text-dark: #1a1a1a; --bg-gray: #f4f6f9; --radius-main: 12px; }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        body { background: var(--bg-gray); color: var(--text-dark); padding-bottom: 60px; }
        a { text-decoration: none; color: inherit; transition: 0.3s ease; }
        ul { list-style: none; }
        .container { max-width: 1280px; margin: 0 auto; padding: 0 15px; }

        /* --- HEADER (TINGGI 300px) --- */
        header { background: var(--primary-blue); position: sticky; top: 0; z-index: 1000; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
        .header-inner { 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            height: 100px; /* Header diperbaiki kembali menjadi 300px */
            max-width: 1280px; 
            margin: 0 auto; 
            padding: 0 15px; 
        }
        
        /* LOGO GAMBAR */
        .logo-area { display: flex; align-items: center; }
        .logo-area img { 
            max-height: 220px; /* Logo disesuaikan agar proporsional di dalam header 300px */
            width: auto; 
            object-fit: contain;
        }
        
        /* Menu Utama */
        .main-nav { display: flex; gap: 5px; height: 100%; align-items: center; }
        .main-nav > li { position: relative; height: 100%; display: flex; align-items: center; padding: 0 18px; font-weight: 600; font-size: 15px; color: white; cursor: pointer; transition: 0.3s; }
        .main-nav > li:hover { background: rgba(255,255,255,0.1); }
        .main-nav > li:hover .mega-box { opacity: 1; visibility: visible; transform: translateX(-50%) translateY(0px); }
        .main-nav > li i.fa-chevron-down { font-size: 10px; margin-left: 5px; transition: 0.3s; }
        .main-nav > li:hover i.fa-chevron-down { transform: rotate(180deg); }

        /* Mega Dropdown */
        .mega-box { position: absolute; top: 100%; left: 50%; transform: translateX(-50%) translateY(15px); background: white; width: 650px; padding: 25px; border-radius: var(--radius-main); box-shadow: 0 20px 40px rgba(0,0,0,0.15); opacity: 0; visibility: hidden; transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); border-top: 3px solid var(--accent-orange); display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .mega-col h5 { color: var(--primary-blue); font-size: 15px; border-bottom: 2px solid var(--accent-orange); padding-bottom: 8px; margin-bottom: 12px; display: inline-block; }
        .mega-col ul li { padding: 10px 0; font-size: 14px; color: #555; display: flex; align-items: center; gap: 12px; border-bottom: 1px solid #f5f5f5; transition: 0.2s; }
        .mega-col ul li:last-child { border-bottom: none; }
        .mega-col ul li:hover { color: var(--accent-orange); padding-left: 8px; }
        .mega-col ul li i { color: var(--primary-blue); width: 20px; text-align: center; }

        .header-actions { display: flex; align-items: center; gap: 15px; }
        .btn-login { background: var(--accent-orange); color: white; padding: 8px 20px; border-radius: 30px; font-weight: 700; font-size: 14px; }
        .btn-login:hover { background: #e05f00; transform: scale(1.05); }

        /* Counter Keranjang di Header */
        .cart-header-icon { position: relative; color: white; font-size: 20px; cursor: pointer; display: flex; align-items: center; gap: 5px; }
        .cart-header-icon span { position: absolute; top: -8px; right: -12px; background: #e74c3c; color: white; font-size: 10px; border-radius: 50%; width: 18px; height: 18px; display: flex; justify-content: center; align-items: center; font-weight: bold; }

        /* --- HAMBURGER MENU (RESPONSIVE ANDROID) --- */
        .hamburger { display: none; flex-direction: column; cursor: pointer; padding: 5px; }
        .hamburger span { width: 25px; height: 2px; background: white; border-radius: 2px; transition: 0.3s; margin: 3px 0; }
        .hamburger.active span:nth-child(1) { transform: rotate(45deg) translate(5px, 5px); }
        .hamburger.active span:nth-child(2) { opacity: 0; }
        .hamburger.active span:nth-child(3) { transform: rotate(-45deg) translate(5px, -5px); }

        .mobile-nav { display: none; background: var(--primary-blue); flex-direction: column; padding: 10px 15px; border-top: 1px solid rgba(255,255,255,0.1); }
        .mobile-nav a { color: white; padding: 12px 0; border-bottom: 1px solid rgba(255,255,255,0.05); font-weight: 500; display: flex; align-items: center; gap: 12px; }
        .mobile-nav a:last-child { border-bottom: none; }
        .mobile-nav a:hover { color: var(--accent-orange); padding-left: 10px; }

        /* --- SEARCH BAR --- */
        .search-wrapper { max-width: 700px; margin: 30px auto 20px; }
        .search-float { background: white; padding: 18px 25px; border-radius: 50px; box-shadow: 0 10px 40px rgba(0,0,0,0.15); display: flex; align-items: center; gap: 15px; }
        .search-float input { flex: 1; border: none; padding: 10px; outline: none; font-size: 16px; }
        .search-float button { background: var(--accent-orange); border: none; padding: 12px 30px; border-radius: 30px; color: white; font-weight: bold; cursor: pointer; font-size: 16px; }

        /* --- FILTER BAR --- */
        .filter-bar { background: white; border-radius: var(--radius-main); padding: 15px 20px; margin-bottom: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.03); display: flex; flex-wrap: wrap; gap: 8px; align-items: center; }
        .filter-btn { padding: 6px 16px; border-radius: 20px; font-size: 13px; font-weight: 600; border: 1px solid #ddd; background: white; color: #555; cursor: pointer; transition: 0.2s; }
        .filter-btn:hover { border-color: var(--accent-orange); color: var(--accent-orange); }
        .filter-btn.active { background: var(--accent-orange); color: white; border-color: var(--accent-orange); }

        /* --- GRID PRODUK (GAMBAR DIPERBESAR DENGAN ZOOM) --- */
        .product-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 25px; } /* Card lebih lebar */
        .product-card { background: white; border-radius: var(--radius-main); padding: 20px; text-align: center; position: relative; transition: 0.3s; overflow: hidden; }
        .product-card:hover { transform: translateY(-5px); box-shadow: 0 15px 30px rgba(0,0,0,0.08); }
        .badge { position: absolute; top: 10px; left: 10px; font-size: 11px; padding: 3px 10px; border-radius: 20px; font-weight: bold; background: #e74c3c; color: white; }
        .badge-blue { background: var(--primary-blue); }
        
        /* --- AREA GAMBAR DIPERBESAR --- */
        .p-img { 
            height: 260px; /* Dinaikkan menjadi 260px agar gambar sangat besar */
            display: flex; 
            align-items: center; 
            justify-content: center; 
            margin-bottom: 15px; 
            background: #f8fafc; 
            border-radius: 12px; 
            padding: 15px; 
            border: 1px solid #e2e8f0; 
            overflow: hidden; /* Penting agar zoom tidak keluar kotak */
            position: relative;
        }
        .p-img img { 
            max-height: 100%; 
            max-width: 100%; 
            object-fit: contain; 
            transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1); /* Animasi zoom halus */
        }
        /* --- EFEK ZOOM SAAT KURSOR MENGENAI GAMBAR --- */
        .product-card:hover .p-img img {
            transform: scale(1.2); /* Zoom 1.2x atau 120% */
        }
        
        .p-title { font-size: 15px; font-weight: 600; height: 44px; overflow: hidden; margin-bottom: 5px; }
        .p-cat { font-size: 12px; color: #888; background: #f1f5f9; display: inline-block; padding: 2px 10px; border-radius: 12px; margin-bottom: 5px; }
        .p-price { color: #e74c3c; font-weight: bold; font-size: 17px; }
        .p-price del { color: #999; font-size: 13px; font-weight: normal; margin-left: 5px; }
        
        /* --- TOMBOL AKSI --- */
        .card-actions { display: flex; gap: 10px; margin-top: 12px; align-items: center; }
        .btn-detail { flex: 1; background: white; color: var(--primary-blue); border: 2px solid var(--primary-blue); padding: 10px 0; border-radius: 8px; cursor: pointer; font-weight: 700; font-size: 13px; transition: all 0.3s ease; text-align: center; display: block; text-decoration: none; }
        .btn-detail:hover { background: var(--primary-blue); color: white; transform: translateY(-2px); box-shadow: 0 4px 10px rgba(10, 25, 47, 0.2); }
        .btn-cart-add { flex: 1; background: var(--accent-orange); color: white; border: none; padding: 10px 0; border-radius: 8px; cursor: pointer; font-weight: 700; font-size: 13px; transition: all 0.3s ease; }
        .btn-cart-add:hover { background: #e05f00; transform: translateY(-2px); box-shadow: 0 4px 10px rgba(255, 107, 0, 0.3); }

        /* Responsive Mobile Tombol */
        @media (max-width: 600px) {
            .card-actions { flex-direction: column; gap: 6px; }
            .btn-detail, .btn-cart-add { width: 100%; padding: 12px 0; font-size: 14px; }
        }

        /* --- FOOTER & WA --- */
        footer { background: #0A192F; color: #a0aec0; padding: 50px 0 20px; margin-top: 50px; }
        .footer-grid { display: grid; grid-template-columns: 2fr 1fr 1fr 1.5fr; gap: 40px; border-bottom: 1px solid rgba(255,255,255,0.05); padding-bottom: 40px; }
        .wa-float { position: fixed; bottom: 20px; right: 20px; background: #25D366; color: white; width: 60px; height: 60px; border-radius: 50%; display: flex; justify-content: center; align-items: center; font-size: 30px; box-shadow: 0 4px 15px rgba(37, 211, 102, 0.4); z-index: 9999; animation: pulseWA 2s infinite; }
        @keyframes pulseWA { 0% { box-shadow: 0 0 0 0 rgba(37, 211, 102, 0.7); } 70% { box-shadow: 0 0 0 15px rgba(37, 211, 102, 0); } }

        /* --- RESPONSIVE ANDROID --- */
        @media (max-width: 1024px) { 
            .product-grid { grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); }
        }
        @media (max-width: 768px) {
            /* 1. Header Mobile (Tinggi menyesuaikan agar logo tidak terlalu besar) */
            .header-inner { height: 80px; padding: 0 10px; }
            .logo-area img { max-height: 60px; }
            .main-nav { display: none !important; } .hamburger { display: flex; } .btn-login { display: none; }
            .cart-header-icon { font-size: 18px; }
            .cart-header-icon span { width: 15px; height: 15px; font-size: 8px; top: -5px; right: -8px; }

            /* 2. Search Mobile */
            .search-wrapper { max-width: 95%; margin: 15px auto 15px; }
            .search-float { border-radius: 12px; flex-direction: column; padding: 12px 15px; gap: 8px; }
            .search-float input { width: 100%; border-bottom: 1px solid #eee; padding: 8px 0; font-size: 14px; } 
            .search-float button { width: 100%; border-radius: 8px; padding: 10px; font-size: 14px; }

            /* 3. Grid Produk Mobile */
            .product-grid { grid-template-columns: repeat(2, 1fr); gap: 12px; }
            .product-card { padding: 15px; }
            .p-img { height: 180px; } /* Tetap besar meski di HP */
            .p-img img { transform: scale(1); } /* Reset zoom di HP agar tidak terpotong */
            .product-card:hover .p-img img { transform: scale(1.1); } /* Zoom lebih kecil di HP */
            .p-title { font-size: 13px; height: 36px; }
            .p-price { font-size: 14px; }
            
            /* 4. Filter Bar Mobile */
            .filter-bar { padding: 10px 15px; gap: 5px; }
            .filter-btn { font-size: 12px; padding: 4px 12px; }

            /* 5. Footer Mobile */
            .footer-grid { grid-template-columns: 1fr; gap: 20px; }
            .f-bottom { font-size: 11px; }
        }
    </style>
</head>
<body>

    <!-- HEADER 300px dengan LOGO GAMBAR -->
    <header>
        <div class="header-inner">
            <a href="index.php" class="logo-area"> 
                <img src="uploads/logo_jagocode.png" alt="Jagocode.com Logo">
            </a>
            
            <!-- Desktop Menu -->
            <ul class="main-nav">
                <li><a href="index.php">Beranda</a></li>
                <li>
                    <span><i class="fas fa-layer-group"></i> Kategori IT <i class="fas fa-chevron-down"></i></span>
                    <div class="mega-box">
                        <div class="mega-col">
                            <h5>Sistem & Data</h5>
                            <ul>
                                <?php 
                                $cat1 = $conn->query("SELECT * FROM categories LIMIT 5");
                                while($c = $cat1->fetch_assoc()) {
                                    echo "<li><a href='index.php?category={$c['id']}'><i class='fas {$c['icon']}'></i> {$c['name']}</a></li>";
                                }
                                ?>
                            </ul>
                        </div>
                        <div class="mega-col">
                            <h5>Kecerdasan & Bisnis</h5>
                            <ul>
                                <?php 
                                $cat2 = $conn->query("SELECT * FROM categories LIMIT 5 OFFSET 5");
                                while($c = $cat2->fetch_assoc()) {
                                    echo "<li><a href='index.php?category={$c['id']}'><i class='fas {$c['icon']}'></i> {$c['name']}</a></li>";
                                }
                                ?>
                            </ul>
                        </div>
                    </div>
                </li>
                <li><a href="shop.php"><i class="fas fa-store"></i> Katalog</a></li>
                <li><a href="my-orders.php"><i class="fas fa-box"></i> My Order</a></li>
                <li><a href="cart.php"><i class="fas fa-shopping-cart"></i> Keranjang</a></li>
                <li><a href="faq.php"><i class="fas fa-question-circle"></i> Bantuan</a></li>
            </ul>
            
            <!-- Header Actions -->
            <div class="header-actions">
                <a href="cart.php" class="cart-header-icon">
                    <i class="fas fa-shopping-cart"></i>
                    <span id="cartCount">0</span>
                </a>
                <!-- <a href="#" class="btn-login"><i class="fas fa-user"></i> Login</a> -->
                
                <!-- Tombol Hamburger (Mobile) -->
                <div class="hamburger" onclick="toggleMobileMenu(this)">
                    <span></span><span></span><span></span>
                </div>
            </div>
        </div>
        
        <!-- Mobile Menu Dropdown -->
        <div class="mobile-nav" id="mobileMenu">
            <a href="index.php"><i class="fas fa-home"></i> Beranda</a>
            <a href="#"><i class="fas fa-layer-group"></i> Kategori IT</a>
            <a href="shop.php"><i class="fas fa-store"></i> Katalog</a>
            <a href="my-orders.php" style="color:#FF6B00;"><i class="fas fa-box"></i> My Order</a>
            <a href="cart.php"><i class="fas fa-shopping-cart"></i> Keranjang</a>
            <a href="faq.php"><i class="fas fa-question-circle"></i> Bantuan</a>
        </div>
    </header>

    <!-- SEARCH BAR -->
    <div class="container">
        <div class="search-wrapper">
            <form action="shop.php" method="GET" class="search-float">
                <input type="text" name="search" placeholder="Cari sistem, metode, atau aplikasi..." value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
                <button type="submit"><i class="fas fa-search"></i> Cari</button>
            </form>
        </div>
    </div>

    <!-- FILTER -->
    <div class="container">
        <div class="filter-bar">
            <span class="label" style="font-weight:bold; margin-right:5px;">Semua Kategori:</span>
            <a href="index.php" class="filter-btn <?php echo (empty($category_filter) && $filter == 'all') ? 'active' : ''; ?>">Semua Produk</a>
            <a href="index.php?filter=featured" class="filter-btn <?php echo ($filter == 'featured') ? 'active' : ''; ?>"><i class="fas fa-crown"></i> Unggulan</a>
            
            <?php 
            $categories->data_seek(0);
            while($cat = $categories->fetch_assoc()): ?>
            <a href="index.php?category=<?= $cat['id'] ?>" class="filter-btn <?php echo ($category_filter == $cat['id']) ? 'active' : ''; ?>">
                <i class="fas <?= $cat['icon'] ?>"></i> <?= $cat['name'] ?>
            </a>
            <?php endwhile; ?>
        </div>
    </div>

    <!-- GRID PRODUK (GAMBAR DIPERBESAR + ZOOM SAAT HOVER) -->
    <div class="container">
        <div class="section-header" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
            <h3>
                <?php 
                    if($filter == 'featured') echo '<i class="fas fa-crown" style="color:#FF6B00;"></i> Produk Unggulan';
                    elseif(!empty($category_filter)) {
                        $cat_name = $conn->query("SELECT name FROM categories WHERE id=$category_filter")->fetch_assoc();
                        echo '<i class="fas fa-tag" style="color:#FF6B00;"></i> Kategori: '.$cat_name['name'];
                    } else echo '<i class="fas fa-th-large" style="color:#FF6B00;"></i> Semua Solusi IT';
                ?>
            </h3>
            <span style="font-size:13px; color:#777;">Menampilkan <?= $products->num_rows ?> produk</span>
        </div>
        
        <div class="product-grid">
            <?php if($products->num_rows > 0): ?>
                <?php while($row = $products->fetch_assoc()): 
                    $cat_res = $conn->query("SELECT name FROM categories WHERE id = {$row['category_id']}");
                    $cat_row = $cat_res->fetch_assoc();
                ?>
                <div class="product-card">
                    <?php if($row['is_featured'] == 1) echo '<span class="badge badge-blue">Best Software</span>'; ?>
                    <div class="p-img">
                        <img src="<?php if(file_exists('uploads/'.$row['image'])) { echo 'uploads/'.$row['image']; } else { echo 'https://via.placeholder.com/300?text=Produk+IT'; } ?>" alt="<?= $row['name'] ?>">
                    </div>
                    <div class="p-cat"><?= $cat_row['name'] ?></div>
                    <div class="p-title"><?= $row['name'] ?></div>
                    <div style="font-size:12px; color:#777; margin-bottom:5px; height:36px; overflow:hidden;"><?= substr($row['description'], 0, 50) ?>...</div>
                    <div class="p-price">
                        Rp <?= number_format($row['price'],0,',','.') ?> 
                        <?php if($row['old_price']) echo "<del>Rp ".number_format($row['old_price'],0,',','.')."</del>"; ?>
                    </div>
                    
                    <!-- TOMBOL AKSI -->
                    <div class="card-actions">
                        <a href="detail.php?slug=<?= $row['slug'] ?>" class="btn-detail">
                            <i class="fas fa-eye"></i> Lihat Detail
                        </a>
                        <button class="btn-cart-add" onclick="addToCart(<?= $row['id'] ?>)">
                            <i class="fas fa-shopping-cart"></i> Keranjang
                        </button>
                    </div>
                </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div style="grid-column:1/-1; text-align:center; padding:40px; background:white; border-radius:12px; color:#777;">
                    <i class="fas fa-folder-open" style="font-size:40px; margin-bottom:10px; display:block;"></i>
                    Belum ada produk untuk kategori ini.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <a href="https://wa.me/6281234567890" target="_blank" class="wa-float"><i class="fab fa-whatsapp"></i></a>

    <footer>
        <div class="container">
            <div class="footer-grid">
                <div class="f-about">
                    <h5 style="color:#FF6B00; font-size:24px;"> 
                        <a href="index.php" style="text-decoration:none; color:inherit;">
                            <img src="uploads/logo_jagocode.png" alt="Jagocode.com Logo" style="max-height:50px; width:auto;">
                        </a>
                    </h5>
                    <p>Penyedia solusi Sistem Informasi, SPK, dan Kecerdasan Buatan.</p>
                </div>
                <div class="f-col"><h5>Layanan</h5><ul><li>Hubungi CS</li><li>Pusat Bantuan</li><li>Cek Progres</li></ul></div>
                <div class="f-col"><h5>Tentang</h5><ul><li>Tentang Kami</li><li>Karir</li><li>Blog</li></ul></div>
                <div class="f-col"><h5>Download</h5><a href="#" style="background:#333; color:white; padding:8px 15px; border-radius:8px; font-size:12px;"><i class="fab fa-google-play"></i> Play Store</a></div>
            </div>
            <div class="f-bottom" style="border-top:1px solid rgba(255,255,255,0.05); padding-top:20px; margin-top:20px; text-align:center; font-size:13px;">
                &copy; 2026 Jagocode.com.
            </div>
        </div>
    </footer>

    <script>
        // --- FUNGSI TAMBAH KE KERANJANG (AJAX) ---
        function addToCart(productId) {
            fetch('api_cart.php?action=add&id=' + productId)
                .then(response => response.json())
                .then(data => {
                    if(data.status === 'success') {
                        document.getElementById('cartCount').innerText = data.total_items;
                        alert('Produk berhasil ditambahkan ke keranjang!');
                    } else {
                        alert('Gagal menambahkan produk ke keranjang.');
                    }
                })
                .catch(error => console.error('Error:', error));
        }

        // --- FUNGSI TOGGLE MOBILE MENU (DENGAN ANIMASI) ---
        function toggleMobileMenu(element) {
            var menu = document.getElementById('mobileMenu');
            if (menu.style.display === 'flex') {
                menu.style.display = 'none';
                element.classList.remove('active');
            } else {
                menu.style.display = 'flex';
                element.classList.add('active');
            }
        }
    </script>
</body>
</html>