<?php include 'header.php'; ?>
<div class="container" style="max-width: 800px; margin: 40px auto; background: white; border-radius: 12px; padding: 30px;">
    <h2 style="border-bottom: 2px solid #FF6B00; padding-bottom: 15px; margin-bottom: 25px;">
        <i class="fas fa-question-circle" style="color:#FF6B00;"></i> Pusat Bantuan
    </h2>
    <div style="margin-bottom: 20px; border-bottom: 1px solid #eee; padding-bottom: 15px;">
        <h4 style="color: #0A192F;">Bagaimana cara membeli produk?</h4>
        <p style="color: #555; margin-top: 5px;">Anda dapat mengklik tombol "Keranjang" pada produk yang diinginkan, lalu lanjutkan ke halaman checkout untuk melakukan pembayaran.</p>
    </div>
    <div style="margin-bottom: 20px; border-bottom: 1px solid #eee; padding-bottom: 15px;">
        <h4 style="color: #0A192F;">Bagaimana cara mendapatkan source code?</h4>
        <p style="color: #555; margin-top: 5px;">Setelah admin menandai pesanan Anda sebagai "LUNAS", Anda dapat mengunduh file source code di halaman "My Order".</p>
    </div>
    <div style="margin-bottom: 20px; border-bottom: 1px solid #eee; padding-bottom: 15px;">
        <h4 style="color: #0A192F;">Saya lupa Session ID / pindah perangkat, bagaimana?</h4>
        <p style="color: #555; margin-top: 5px;">Silakan hubungi admin melalui WhatsApp untuk meminta kirim ulang link download Anda.</p>
    </div>
    <div style="margin-top: 20px; text-align: center;">
        <a href="https://wa.me/6281234567890" target="_blank" style="background: #25D366; color: white; padding: 10px 25px; border-radius: 30px; font-weight: bold; display: inline-block; text-decoration: none;">
            <i class="fab fa-whatsapp"></i> Hubungi Admin via WhatsApp
        </a>
    </div>
</div>
<?php include 'footer.php'; ?>