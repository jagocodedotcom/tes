<?php
require 'db_connect.php';

// Logika Download Publik (Tanpa Login, Tanpa Sidebar)
if (isset($_GET['token']) && isset($_GET['order_id'])) {
    $token = $_GET['token'];
    $order_id = $_GET['order_id'];
    
    // 1. Cek validitas token, status PAID, dan belum didownload
    $check = $conn->query("SELECT o.id, o.status, o.is_downloaded, oi.product_id, p.file_source 
                           FROM orders o 
                           JOIN order_items oi ON o.order_id = oi.order_id 
                           JOIN products p ON oi.product_id = p.id 
                           WHERE o.download_token = '$token' AND o.order_id = '$order_id'");
    
    if ($check->num_rows > 0) {
        $row = $check->fetch_assoc();
        
        // 2. Jika status paid DAN belum didownload
        if ($row['status'] == 'paid' && $row['is_downloaded'] == 0) {
            
            // 3. Tandai sudah didownload (hanya 1x)
            $conn->query("UPDATE orders SET is_downloaded = 1 WHERE id = {$row['id']}");
            
            // 4. Tentukan path file yang benar (Cross-Platform Windows/Linux)
            // Menggunakan __DIR__ untuk memastikan path absolut
            $file_name = $row['file_source'];
            $file_path = __DIR__ . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'source' . DIRECTORY_SEPARATOR . $file_name;
            
            // Debugging (Hapus baris ini setelah berhasil)
            // echo "Mencari file di: " . $file_path; exit;

            // 5. Cek apakah file benar-benar ada di server
            if (file_exists($file_path)) {
                // Set header untuk download
                header('Content-Description: File Transfer');
                header('Content-Type: application/octet-stream');
                header('Content-Disposition: attachment; filename="' . $file_name . '"');
                header('Expires: 0');
                header('Cache-Control: must-revalidate');
                header('Pragma: public');
                header('Content-Length: ' . filesize($file_path));
                
                // Bersihkan buffer output sebelum membaca file
                ob_clean();
                flush();
                
                // Baca file dan kirim ke browser
                readfile($file_path);
                exit;
            } else {
                die("<h3 style='text-align:center; font-family:sans-serif; color:#e74c3c; margin-top:50px;'>File source code tidak ditemukan di server.<br>Path: " . htmlspecialchars($file_path) . "</h3>");
            }
        } else {
            die("<h3 style='text-align:center; font-family:sans-serif; color:#e74c3c; margin-top:50px;'>Anda sudah pernah mendownload file ini sebelumnya, atau status pembayaran belum Lunas.</h3>");
        }
    } else {
        die("<h3 style='text-align:center; font-family:sans-serif; color:#e74c3c; margin-top:50px;'>Token tidak valid atau link download sudah kadaluarsa.</h3>");
    }
} else {
    // Jika user mengakses file ini tanpa parameter, arahkan ke halaman utama
    header("Location: index.php");
    exit;
}
?>