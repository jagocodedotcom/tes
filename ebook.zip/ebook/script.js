const modal = document.getElementById("productModal");
const imageInput = document.getElementById("imageInput");
const imagePreview = document.getElementById("imagePreview");
const previewImg = document.getElementById("previewImg");

// --- PREVIEW GAMBAR SAAT DIPILIH ---
imageInput.addEventListener("change", function() {
    const file = this.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            previewImg.src = e.target.result;
            imagePreview.style.display = "block";
        }
        reader.readAsDataURL(file);
    } else {
        imagePreview.style.display = "none";
    }
});

// --- BUKA MODAL (TAMBAH) ---
function openModal() {
    modal.style.display = "flex";
    document.getElementById("modalTitle").innerText = "Tambah Produk Baru";
    document.getElementById("edit_id").value = "";
    document.getElementById("name").value = "";
    document.getElementById("price").value = "";
    document.getElementById("old_price").value = "";
    document.getElementById("description").value = "";
    document.getElementById("rating").value = "4.5";
    document.getElementById("is_featured").checked = false;
    
    // Reset input file dan preview
    imageInput.value = "";
    imagePreview.style.display = "none";
    previewImg.src = "";
}

// --- BUKA MODAL (EDIT) ---
function editProduct(data) {
    modal.style.display = "flex";
    document.getElementById("modalTitle").innerText = "Edit Produk";
    document.getElementById("edit_id").value = data.id;
    document.getElementById("name").value = data.name;
    document.getElementById("price").value = data.price;
    document.getElementById("old_price").value = data.old_price || "";
    document.getElementById("category_id").value = data.category_id;
    document.getElementById("description").value = data.description;
    document.getElementById("rating").value = data.rating;
    document.getElementById("is_featured").checked = data.is_featured == 1;

    // Reset input file & preview (karena saat edit, user harus upload ulang jika ingin ganti)
    imageInput.value = "";
    imagePreview.style.display = "none";
    previewImg.src = "";
}

// --- TUTUP MODAL ---
function closeModal() {
    modal.style.display = "none";
}

// Tutup modal saat klik di luar area form
window.onclick = function(event) {
    if (event.target == modal) {
        closeModal();
    }
}