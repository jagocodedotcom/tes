<?php require 'db_connect.php'; 

// --- LOGIKA FILTER, SORTING, HARGA, DAN PENCARIAN ---
$category_filter = isset($_GET['category']) ? intval($_GET['category']) : 0;
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'newest';
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';
$min_price = isset($_GET['min_price']) ? intval($_GET['min_price']) : 0;
$max_price = isset($_GET['max_price']) ? intval($_GET['max_price']) : 20000000;

$sql = "SELECT * FROM products WHERE 1=1";

if ($category_filter > 0) $sql .= " AND category_id = $category_filter";
if ($min_price > 0) $sql .= " AND price >= $min_price";
if ($max_price < 20000000) $sql .= " AND price <= $max_price";
if (!empty($search)) $sql .= " AND (name LIKE '%$search%' OR description LIKE '%$search%')";

if ($sort == 'price_asc') $sql .= " ORDER BY price ASC";
elseif ($sort == 'price_desc') $sql .= " ORDER BY price DESC";
else $sql .= " ORDER BY id DESC";

$products = $conn->query($sql);
$categories = $conn->query("SELECT * FROM categories");
?>
<?php include 'header.php'; ?>

<!-- TAMBAHAN CSS KHUSUS SHOP.PHP -->
<style>
    .shop-layout { display: flex; gap: 25px; margin-top: 20px; align-items: flex-start; }
    .shop-sidebar { width: 280px; background: white; padding: 25px; border-radius: 12px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); position: sticky; top: 90px; height: fit-content; max-height: 80vh; overflow-y: auto; }
    .shop-sidebar h4 { font-size: 16px; font-weight: 700; border-bottom: 2px solid #FF6B00; padding-bottom: 12px; margin-bottom: 20px; display: flex; align-items: center; gap: 10px; }
    .sidebar-filter li { padding: 10px 12px; border-radius: 8px; cursor: pointer; font-size: 14px; color: #555; display: flex; justify-content: space-between; transition: 0.2s; border: 1px solid transparent; margin-bottom: 5px; }
    .sidebar-filter li:hover { background: #f8fafc; color: #FF6B00; border-color: #eee; }
    .sidebar-filter li.active { background: #FF6B00; color: white; border-color: #FF6B00; }
    .sidebar-filter li.active span { color: white; }
    .sidebar-search { display: flex; border: 1px solid #ddd; border-radius: 8px; overflow: hidden; margin-bottom: 20px; }
    .sidebar-search input { flex: 1; border: none; padding: 10px 12px; outline: none; font-size: 14px; }
    .sidebar-search button { background: #FF6B00; border: none; padding: 0 15px; color: white; cursor: pointer; }
    .shop-header { display: flex; justify-content: space-between; align-items: center; padding: 15px 20px; background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.03); margin-bottom: 25px; flex-wrap: wrap; gap: 15px; }
    .shop-header h3 { font-size: 20px; font-weight: 700; margin: 0; }
    .shop-header .breadcrumb { font-size: 13px; color: #777; }
    .shop-header .breadcrumb span { color: #FF6B00; font-weight: 600; }
    .shop-header select { padding: 8px 15px; border-radius: 8px; border: 1px solid #ddd; font-size: 14px; background: white; cursor: pointer; outline: none; }
    .shop-header select:focus { border-color: #FF6B00; }
    .shop-content { flex: 1; }
    .product-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(230px, 1fr)); gap: 20px; }
    .product-card { background: white; border-radius: 12px; padding: 20px; text-align: center; position: relative; transition: 0.3s; border: 1px solid transparent; }
    .product-card:hover { transform: translateY(-5px); box-shadow: 0 15px 30px rgba(0,0,0,0.08); border-color: #eee; }
    .badge { position: absolute; top: 10px; left: 10px; font-size: 11px; padding: 3px 10px; border-radius: 20px; font-weight: bold; background: #e74c3c; color: white; }
    .badge-blue { background: #0A192F; }
    .p-img { height: 140px; display: flex; align-items: center; justify-content: center; margin-bottom: 15px; background: #f8fafc; border-radius: 8px; padding: 10px; }
    .p-img img { max-height: 100%; max-width: 100%; object-fit: contain; }
    .p-title { font-size: 15px; font-weight: 600; height: 44px; overflow: hidden; margin-bottom: 5px; color: #1a1a1a; }
    .p-cat { font-size: 12px; color: #888; background: #f1f5f9; display: inline-block; padding: 2px 10px; border-radius: 12px; margin-bottom: 5px; }
    .p-price { color: #e74c3c; font-weight: bold; font-size: 17px; margin-top: 5px; }
    .p-price del { color: #999; font-size: 13px; font-weight: normal; margin-left: 8px; }
    
    /* Action Buttons Baru */
    .btn-action { margin-top: 15px; background: #f0f4f8; color: #0A192F; border: none; padding: 10px 0; width: 100%; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 14px; transition: 0.2s; }
    .btn-action:hover { background: #0A192F; color: white; }
    
    .empty-state { grid-column: 1 / -1; text-align: center; padding: 60px 20px; background: white; border-radius: 12px; color: #777; }
    .empty-state i { font-size: 50px; color: #ddd; margin-bottom: 15px; display: block; }

    @media (max-width: 1024px) {
        .shop-layout { flex-direction: column; }
        .shop-sidebar { width: 100%; position: static; max-height: none; }
        .shop-sidebar .sidebar-filter { display: flex; flex-wrap: wrap; gap: 8px; }
        .shop-sidebar .sidebar-filter li { flex: 1 1 calc(50% - 8px); justify-content: center; }
    }
    @media (max-width: 600px) {
        .shop-header { flex-direction: column; align-items: flex-start; }
        .product-grid { grid-template-columns: repeat(2, 1fr); gap: 12px; }
    }
</style>

<div class="container" style="margin-top: 30px;">
    
    <div class="shop-header">
        <div>
            <h3><i class="fas fa-th-large" style="color:#FF6B00; margin-right:8px;"></i> Katalog Produk</h3>
            <div class="breadcrumb">
                Home / Katalog 
                <?php if(!empty($search)): ?> / Pencarian: "<span><?= htmlspecialchars($search) ?></span>" <?php endif; ?>
                <?php if($min_price > 0 || $max_price < 20000000): ?> / Harga: Rp <?= number_format($min_price,0,',','.') ?> - Rp <?= number_format($max_price,0,',','.') ?> <?php endif; ?>
            </div>
        </div>
        <div>
            <form method="GET" style="display:flex; align-items:center; gap:10px;">
                <input type="hidden" name="category" value="<?= $category_filter ?>">
                <input type="hidden" name="search" value="<?= htmlspecialchars($search) ?>">
                <input type="hidden" name="min_price" value="<?= $min_price ?>">
                <input type="hidden" name="max_price" value="<?= $max_price ?>">
                
                <label for="sort" style="font-size:14px; font-weight:600; color:#555;">Urutkan:</label>
                <select name="sort" id="sort" onchange="this.form.submit()">
                    <option value="newest" <?= ($sort == 'newest') ? 'selected' : '' ?>>Terbaru</option>
                    <option value="price_asc" <?= ($sort == 'price_asc') ? 'selected' : '' ?>>Termurah</option>
                    <option value="price_desc" <?= ($sort == 'price_desc') ? 'selected' : '' ?>>Termahal</option>
                </select>
            </form>
        </div>
    </div>

    <div class="shop-layout">
        <aside class="shop-sidebar">
            <form method="GET" class="sidebar-search">
                <input type="text" name="search" placeholder="Cari produk..." value="<?= htmlspecialchars($search) ?>">
                <button type="submit"><i class="fas fa-search"></i></button>
            </form>
            <h4><i class="fas fa-filter"></i> Filter Kategori</h4>
            <ul class="sidebar-filter">
                <li onclick="window.location.href='shop.php'" class="<?= ($category_filter == 0) ? 'active' : '' ?>">Semua Kategori</li>
                <?php while($cat = $categories->fetch_assoc()): ?>
                <li onclick="window.location.href='shop.php?category=<?= $cat['id'] ?>'" class="<?= ($category_filter == $cat['id']) ? 'active' : '' ?>"><?= $cat['name'] ?></li>
                <?php endwhile; ?>
            </ul>
            <h4 style="margin-top:25px;"><i class="fas fa-tag"></i> Filter Harga</h4>
            <div class="price-range-wrapper">
                <input type="range" id="priceRange" min="0" max="20000000" step="500000" value="<?= $max_price ?>" oninput="updatePriceFilter(this.value)" style="width:100%;">
                <div class="price-label"><span>Rp 0</span><span id="displayMaxPrice">Rp <?= number_format($max_price,0,',','.') ?></span></div>
            </div>
            <a href="shop.php" style="display:block; text-align:center; margin-top:15px; padding:8px; background:#f8fafc; border-radius:8px; font-size:13px; font-weight:600; color:#555;">Reset Filter</a>
        </aside>

        <div class="shop-content">
            <div class="product-grid">
                <?php if($products->num_rows > 0): ?>
                    <?php while($row = $products->fetch_assoc()): ?>
                    <div class="product-card">
                        <?php if($row['is_featured'] == 1) echo '<span class="badge badge-blue">Best Seller</span>'; ?>
                        <div class="p-img">
                            <img src="<?php if(file_exists('uploads/'.$row['image'])) { echo 'uploads/'.$row['image']; } else { echo 'https://via.placeholder.com/200?text=Produk+IT'; } ?>" alt="<?= $row['name'] ?>">
                        </div>
                        <div class="p-cat"><?= $conn->query("SELECT name FROM categories WHERE id={$row['category_id']}")->fetch_assoc()['name'] ?></div>
                        <div class="p-title"><?= $row['name'] ?></div>
                        <div style="color:#f1c40f; font-size:13px; margin:5px 0;"><i class="fas fa-star"></i> <?= $row['rating'] ?></div>
                        <div class="p-price">
                            Rp <?= number_format($row['price'],0,',','.') ?> 
                            <?php if($row['old_price']) echo "<del>Rp ".number_format($row['old_price'],0,',','.')."</del>"; ?>
                        </div>
                        
                        <!-- ACTION BUTTONS (SUDAH DIPERBAIKI) -->
                        <div style="display:flex; gap:8px; margin-top:12px;">
                            <a href="detail.php?slug=<?= $row['slug'] ?>" style="flex:1; text-decoration:none;">
                                <button class="btn-action"><i class="fas fa-info-circle"></i> Lihat Detail</button>
                            </a>
                            <button class="btn-action" style="background:#FF6B00; color:white; flex:1;" onclick="addToCart(<?= $row['id'] ?>)">
                                <i class="fas fa-cart-plus"></i> Keranjang
                            </button>
                        </div>
                    </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-box-open"></i>
                        <h4>Produk Tidak Ditemukan</h4>
                        <p style="color:#555;">Maaf, tidak ada produk yang sesuai dengan filter atau pencarian Anda.</p>
                        <a href="shop.php" style="display:inline-block; margin-top:15px; padding:8px 20px; background:#FF6B00; color:white; border-radius:8px; font-weight:bold;">Lihat Semua Produk</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- SCRIPT FILTER HARGA & ACTION BUTTONS -->
<script>
    function updatePriceFilter(value) {
        const formattedPrice = new Intl.NumberFormat('id-ID', {style: 'currency', currency: 'IDR', minimumFractionDigits: 0}).format(value);
        document.getElementById('displayMaxPrice').innerText = formattedPrice;
        
        // Buat form tersembunyi untuk submit otomatis
        const form = document.createElement('form');
        form.method = 'GET';
        form.action = 'shop.php';
        
        // Tambahkan semua filter yang ada saat ini
        const params = {
            category: '<?= $category_filter ?>',
            search: '<?= htmlspecialchars($search) ?>',
            sort: '<?= $sort ?>',
            min_price: '0',
            max_price: value
        };
        
        for(const key in params) {
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = key;
            input.value = params[key];
            form.appendChild(input);
        }
        
        document.body.appendChild(form);
        form.submit();
    }

    // Fungsi Tambah ke Keranjang
    function addToCart(productId) {
        fetch('api_cart.php?action=add&id=' + productId)
            .then(response => response.json())
            .then(data => {
                if(data.status === 'success') {
                    document.getElementById('cartCount').innerText = data.total_items;
                    alert('Produk berhasil ditambahkan ke keranjang!');
                } else {
                    alert('Gagal menambahkan produk ke keranjang.');
                }
            })
            .catch(error => console.error('Error:', error));
    }
</script>

<?php include 'footer.php'; ?>