<?php
// Pastikan koneksi database tersedia jika header dipanggil
if(!isset($conn)) {
    require 'db_connect.php';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.5, user-scalable=yes">
    <title>jagocode.com - Solusi Sistem Informasi & IT</title>
     <link rel="icon" type="image/png" href="uploads/ico.png">
    <link rel="shortcut icon" href="uploads/ico.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    
    <style>
        :root { --primary-blue: #0A192F; --accent-orange: #FF6B00; --text-dark: #1a1a1a; --bg-gray: #f4f6f9; --radius-main: 12px; }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        body { background: var(--bg-gray); color: var(--text-dark); padding-bottom: 60px; }
        a { text-decoration: none; color: inherit; transition: 0.3s ease; }
        ul { list-style: none; }
        .container { max-width: 1280px; margin: 0 auto; padding: 0 15px; }

        /* --- HEADER --- */
        header { background: var(--primary-blue); position: sticky; top: 0; z-index: 1000; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
        .header-inner { display: flex; justify-content: space-between; align-items: center; height: 70px; max-width: 1280px; margin: 0 auto; padding: 0 15px; }
        .logo-area { display: flex; align-items: center; gap: 10px; font-size: 24px; font-weight: 800; color: white; }
        .logo-area i { background: var(--accent-orange); padding: 8px; border-radius: 8px; color: white; }
        
        /* Menu Hover */
        .main-nav { display: flex; gap: 5px; height: 100%; align-items: center; }
        .main-nav > li { position: relative; height: 100%; display: flex; align-items: center; padding: 0 18px; font-weight: 600; font-size: 15px; color: white; cursor: pointer; transition: 0.3s; }
        .main-nav > li:hover { background: rgba(255,255,255,0.1); }
        .main-nav > li:hover .mega-box { opacity: 1; visibility: visible; transform: translateX(-50%) translateY(0px); }
        .main-nav > li i.fa-chevron-down { font-size: 10px; margin-left: 5px; transition: 0.3s; }
        .main-nav > li:hover i.fa-chevron-down { transform: rotate(180deg); }

        /* Sub Menu Kategori IT */
        .mega-box { position: absolute; top: 70px; left: 50%; transform: translateX(-50%) translateY(15px); background: white; width: 650px; padding: 25px; border-radius: var(--radius-main); box-shadow: 0 20px 40px rgba(0,0,0,0.15); opacity: 0; visibility: hidden; transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); border-top: 3px solid var(--accent-orange); display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .mega-col h5 { color: var(--primary-blue); font-size: 15px; border-bottom: 2px solid var(--accent-orange); padding-bottom: 8px; margin-bottom: 12px; display: inline-block; }
        .mega-col ul li { padding: 10px 0; font-size: 14px; color: #555; display: flex; align-items: center; gap: 12px; border-bottom: 1px solid #f5f5f5; transition: 0.2s; }
        .mega-col ul li:last-child { border-bottom: none; }
        .mega-col ul li:hover { color: var(--accent-orange); padding-left: 8px; }
        .mega-col ul li i { color: var(--primary-blue); width: 20px; text-align: center; }

        .header-actions { display: flex; align-items: center; gap: 15px; }
        .btn-login { background: var(--accent-orange); color: white; padding: 8px 20px; border-radius: 30px; font-weight: 700; font-size: 14px; }
        .btn-login:hover { background: #e05f00; transform: scale(1.05); }

        /* Mobile */
        .hamburger { display: none; flex-direction: column; cursor: pointer; gap: 5px; }
        .hamburger span { width: 25px; height: 3px; background: white; border-radius: 2px; }
        .mobile-nav { display: none; background: var(--primary-blue); flex-direction: column; padding: 10px 15px; border-top: 1px solid rgba(255,255,255,0.1); }
        .mobile-nav a { color: white; padding: 12px 0; border-bottom: 1px solid rgba(255,255,255,0.05); font-weight: 500; }
        .mobile-nav a:hover { color: var(--accent-orange); }

        @media (max-width: 768px) {
            .main-nav { display: none; } .hamburger { display: flex; } .btn-login { display: none; }
            .header-inner { height: 60px; }
        }
    </style>
</head>
<body>

    <!-- HEADER -->
    <header>
        <div class="header-inner">
             <a href="index.php" class="logo-area"> 
                <img src="uploads/logo_jagocode.png" alt="Jagocode.com Logo">
            </a>
            
            <ul class="main-nav">
                <li><a href="index.php">Beranda</a></li>
                <li>
                    <span><i class="fas fa-layer-group"></i> Kategori IT <i class="fas fa-chevron-down"></i></span>
                    <div class="mega-box">
                        <div class="mega-col">
                            <h5>Sistem & Data</h5>
                            <ul>
                                <?php 
                                if(isset($conn)) {
                                    $cat1 = $conn->query("SELECT * FROM categories LIMIT 5");
                                    while($c = $cat1->fetch_assoc()) {
                                        echo "<li><a href='shop.php?category={$c['id']}'><i class='fas {$c['icon']}'></i> {$c['name']}</a></li>";
                                    }
                                }
                                ?>
                            </ul>
                        </div>
                        <div class="mega-col">
                            <h5>Kecerdasan & Bisnis</h5>
                            <ul>
                                <?php 
                                if(isset($conn)) {
                                    $cat2 = $conn->query("SELECT * FROM categories LIMIT 5 OFFSET 5");
                                    while($c = $cat2->fetch_assoc()) {
                                        echo "<li><a href='shop.php?category={$c['id']}'><i class='fas {$c['icon']}'></i> {$c['name']}</a></li>";
                                    }
                                }
                                ?>
                            </ul>
                        </div>
                    </div>
                </li>
                <li><a href="shop.php"><i class="fas fa-store"></i> Katalog Produk</a></li>
               <li><a href="my-orders.php"><i class="fas fa-box"></i> My Order</a></li>
                 <li><a href="cart.php"><i class="fas fa-shopping-cart"></i> Keranjang</a></li>
    <!-- Tambahkan ini untuk user percaya -->
    <li><a href="faq.php"><i class="fas fa-question-circle"></i> Bantuan</a></li>
            </ul>
            
            <!-- <div class="header-actions">
                <a href="#" class="btn-login"><i class="fas fa-user"></i> Login</a>
                <div class="hamburger" onclick="document.getElementById('mobileMenu').style.display = (document.getElementById('mobileMenu').style.display === 'flex') ? 'none' : 'flex';">
                    <span></span><span></span><span></span>
                </div>
            </div> -->
        </div>
        <div class="mobile-nav" id="mobileMenu">
            <a href="index.php">Beranda</a>
            <a href="shop.php">Katalog</a>
           
        </div>
    </header>