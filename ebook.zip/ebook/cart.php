<?php
session_start();
require 'db_connect.php';

// --- CEK SESSION KERANJANG ---
$session_id = $_SESSION['cart_session'];

// Ambil data keranjang dari database
$items = $conn->query("SELECT c.*, p.name, p.price, p.old_price, p.image FROM cart c JOIN products p ON c.product_id = p.id WHERE c.session_id = '$session_id'");

// Hitung Subtotal & Total Item
$subtotal = 0;
$total_items = 0;
while ($row = $items->fetch_assoc()) {
    $subtotal += ($row['price'] * $row['qty']);
    $total_items += $row['qty'];
}
$items->data_seek(0); // Reset pointer query

// --- LOGIKA VOUCHER (Subscribe / Follow) ---
$discount = 0;
$voucher_error = '';
if (isset($_POST['apply_voucher'])) {
    $code = mysqli_real_escape_string($conn, $_POST['voucher_code']);
    // Query validasi voucher (aktif dan belum kadaluarsa)
    $voucher = $conn->query("SELECT * FROM vouchers WHERE code = '$code' AND is_active = 1 AND (expires_at IS NULL OR expires_at >= CURDATE())");
    
    if ($voucher->num_rows > 0) {
        $v_data = $voucher->fetch_assoc();
        if ($subtotal >= $v_data['min_purchase']) {
            // Hitung diskon berdasarkan tipe (persen atau nominal)
            if ($v_data['discount_type'] == 'percent') {
                $discount = $subtotal * ($v_data['discount_value'] / 100);
            } else {
                $discount = $v_data['discount_value'];
            }
            if ($discount > $subtotal) $discount = $subtotal; // Diskon tidak boleh melebihi total
            $_SESSION['applied_voucher'] = $code;
            $_SESSION['discount_amount'] = $discount;
        } else {
            $voucher_error = "Minimal pembelian Rp " . number_format($v_data['min_purchase'],0,',','.');
        }
    } else {
        $voucher_error = "Kode voucher tidak valid atau sudah kadaluarsa.";
    }
}

// --- RESET VOUCHER ---
if (isset($_POST['remove_voucher'])) {
    unset($_SESSION['applied_voucher']);
    unset($_SESSION['discount_amount']);
    header("Location: cart.php");
    exit;
}

// Ambil diskon dari session (jika ada)
if (isset($_SESSION['applied_voucher'])) {
    $discount = $_SESSION['discount_amount'];
    $applied_code = $_SESSION['applied_voucher'];
}
$grand_total = $subtotal - $discount;
?>

<?php include 'header.php'; ?>

<!-- CSS KHUSUS UNTUK HALAMAN KERANJANG -->
<style>
    .cart-wrapper { max-width: 1100px; margin: 40px auto; background: white; border-radius: 16px; padding: 30px; box-shadow: 0 10px 30px rgba(0,0,0,0.08); }
    .cart-wrapper h2 { font-size: 24px; border-bottom: 2px solid #FF6B00; padding-bottom: 15px; margin-bottom: 25px; display: flex; align-items: center; gap: 10px; color: #1a1a1a; }
    .cart-layout { display: grid; grid-template-columns: 2fr 1fr; gap: 30px; }
    
    /* --- DAFTAR PRODUK --- */
    .cart-item { display: flex; align-items: center; padding: 15px 0; border-bottom: 1px solid #eee; gap: 15px; }
    .cart-item:last-child { border-bottom: none; }
    .cart-item img { width: 80px; height: 80px; object-fit: contain; background: #f8fafc; border-radius: 8px; padding: 5px; border: 1px solid #eee; }
    .item-info { flex: 1; }
    .item-info h4 { margin: 0 0 5px; font-size: 16px; color: #1a1a1a; }
    .item-info .price { color: #e74c3c; font-weight: bold; font-size: 15px; }
    .item-info .price del { color: #999; font-size: 13px; margin-left: 5px; }
    .item-actions { display: flex; align-items: center; gap: 10px; }
    .item-actions input { width: 45px; text-align: center; padding: 5px; border: 1px solid #ddd; border-radius: 4px; font-weight: bold; background: #f9f9f9; }
    .item-actions a { color: #555; text-decoration: none; font-size: 16px; transition: 0.2s; }
    .item-actions a:hover { color: #e74c3c; transform: scale(1.1); }
    .item-actions .btn-remove { color: #e74c3c; font-size: 14px; margin-left: 5px; }
    
    /* --- RINGKASAN BELANJA --- */
    .summary { background: #f8fafc; padding: 25px; border-radius: 12px; height: fit-content; border: 1px solid #eee; }
    .summary h4 { font-size: 18px; border-bottom: 1px solid #ddd; padding-bottom: 12px; margin-bottom: 15px; color: #1a1a1a; }
    .summary-row { display: flex; justify-content: space-between; padding: 8px 0; font-size: 14px; color: #555; }
    .summary-row.total { font-weight: bold; font-size: 20px; border-top: 2px solid #0A192F; padding-top: 15px; margin-top: 10px; color: #1a1a1a; }
    .summary-row.discount { color: #27ae60; font-weight: 600; }
    
    /* --- VOUCHER BOX --- */
    .voucher-box { display: flex; gap: 10px; margin: 15px 0; }
    .voucher-box input { flex: 1; padding: 10px 12px; border: 1px solid #ddd; border-radius: 8px; outline: none; font-size: 14px; }
    .voucher-box input:focus { border-color: #FF6B00; }
    .voucher-box button { background: #FF6B00; color: white; border: none; padding: 10px 20px; border-radius: 8px; cursor: pointer; font-weight: bold; transition: 0.2s; }
    .voucher-box button:hover { background: #e05f00; }
    .voucher-box button.btn-remove-voucher { background: #e74c3c; }
    .voucher-box button.btn-remove-voucher:hover { background: #c0392b; }
    
    .error-msg { color: #e74c3c; font-size: 13px; margin-top: 5px; display: block; }
    .success-msg { color: #27ae60; font-size: 13px; margin-top: 5px; display: block; }
    
    /* --- TOMBOL CHECKOUT --- */
    .btn-checkout { width: 100%; background: #0A192F; color: white; border: none; padding: 15px; border-radius: 10px; font-size: 18px; cursor: pointer; margin-top: 20px; font-weight: bold; transition: 0.2s; }
    .btn-checkout:hover { background: #1a2a3f; transform: scale(1.02); }
    
    /* --- KONDISI KOSONG --- */
    .empty-cart { text-align: center; padding: 60px 20px; color: #777; }
    .empty-cart i { font-size: 60px; color: #ddd; margin-bottom: 15px; display: block; }
    .empty-cart a { display: inline-block; margin-top: 15px; padding: 10px 30px; background: #FF6B00; color: white; border-radius: 30px; font-weight: bold; }

    /* --- RESPONSIVE --- */
    @media (max-width: 992px) {
        .cart-layout { grid-template-columns: 1fr; }
        .summary { margin-top: 20px; }
    }
    @media (max-width: 600px) {
        .cart-item { flex-wrap: wrap; }
        .item-info { width: 100%; margin-bottom: 10px; }
        .item-actions { width: 100%; justify-content: space-between; }
        .voucher-box { flex-direction: column; }
        .voucher-box button { width: 100%; }
    }
</style>

<div class="container">
    <div class="cart-wrapper">
        <h2><i class="fas fa-shopping-cart" style="color:#FF6B00;"></i> Keranjang Belanja</h2>
        
        <!-- Tombol Kembali -->
        <a href="index.php" style="color:#0A192F; font-weight:600; margin-bottom:20px; display:inline-block; font-size:14px;">
            <i class="fas fa-arrow-left"></i> Lanjut Belanja
        </a>
        
        <div class="cart-layout">
            
            <!-- KOLOM KIRI: DAFTAR PRODUK -->
            <div class="cart-items">
                <?php if ($total_items > 0): ?>
                    <?php while($row = $items->fetch_assoc()): ?>
                    <div class="cart-item">
                        <img src="<?php if(file_exists('uploads/'.$row['image'])) { echo 'uploads/'.$row['image']; } else { echo 'https://via.placeholder.com/200?text=No+Image'; } ?>" alt="<?= $row['name'] ?>">
                        <div class="item-info">
                            <h4><?= $row['name'] ?></h4>
                            <div class="price">
                                Rp <?= number_format($row['price'],0,',','.') ?>
                                <?php if($row['old_price']): ?>
                                <del>Rp <?= number_format($row['old_price'],0,',','.') ?></del>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="item-actions">
                            <!-- Tombol Kurang Jumlah -->
                            <a href="api_cart.php?action=update&id=<?= $row['id'] ?>&qty=<?= $row['qty']-1 ?>"><i class="fas fa-minus-circle"></i></a>
                            <input type="text" value="<?= $row['qty'] ?>" readonly>
                            <!-- Tombol Tambah Jumlah -->
                            <a href="api_cart.php?action=update&id=<?= $row['id'] ?>&qty=<?= $row['qty']+1 ?>"><i class="fas fa-plus-circle"></i></a>
                            <!-- Tombol Hapus Item -->
                            <a href="api_cart.php?action=remove&id=<?= $row['id'] ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus item ini?')" class="btn-remove">
                                <i class="fas fa-trash-alt"></i>
                            </a>
                        </div>
                    </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="empty-cart">
                        <i class="fas fa-shopping-basket"></i>
                        <h4>Keranjang Belanja Kosong</h4>
                        <p>Yuk, belanja produk IT favorit Anda sekarang!</p>
                        <a href="shop.php">Mulai Belanja</a>
                    </div>
                <?php endif; ?>
            </div>

            <!-- KOLOM KANAN: RINGKASAN & VOUCHER -->
            <div class="summary">
                <h4>Ringkasan Belanja</h4>
                <div class="summary-row">
                    <span>Subtotal (<?= $total_items ?> item)</span>
                    <span>Rp <?= number_format($subtotal,0,',','.') ?></span>
                </div>
                
                <!-- FORM VOUCHER -->
                <form method="POST">
                    <div class="voucher-box">
                        <input type="text" name="voucher_code" placeholder="Masukkan kode voucher (contoh: SUBSCRIBE10)" value="<?= isset($applied_code) ? $applied_code : '' ?>">
                        <?php if(isset($applied_code)): ?>
                            <button type="submit" name="remove_voucher" class="btn-remove-voucher"><i class="fas fa-times"></i> Hapus</button>
                        <?php else: ?>
                            <button type="submit" name="apply_voucher">Pakai Voucher</button>
                        <?php endif; ?>
                    </div>
                    <?php if(!empty($voucher_error)): ?>
                        <span class="error-msg"><i class="fas fa-exclamation-circle"></i> <?= $voucher_error ?></span>
                    <?php endif; ?>
                    <?php if(isset($applied_code)): ?>
                        <span class="success-msg"><i class="fas fa-check-circle"></i> Voucher "<?= $applied_code ?>" berhasil digunakan!</span>
                    <?php endif; ?>
                </form>

                <!-- PERHITUNGAN DISKON -->
                <?php if($discount > 0): ?>
                <div class="summary-row discount">
                    <span>Diskon Voucher</span>
                    <span>- Rp <?= number_format($discount,0,',','.') ?></span>
                </div>
                <?php endif; ?>
                
                <div class="summary-row total">
                    <span>Total Bayar</span>
                    <span>Rp <?= number_format($grand_total,0,',','.') ?></span>
                </div>
                
                <!-- TOMBOL CHECKOUT -->
               <a href="checkout.php">
    <button class="btn-checkout"><i class="fas fa-credit-card"></i> Lanjut ke Pembayaran</button>
</a>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>