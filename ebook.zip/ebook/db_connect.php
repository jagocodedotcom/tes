<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'bigshop_db';

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("Koneksi database gagal: " . $conn->connect_error);
}

// --- FUNGSI UPLOAD GAMBAR ---
function uploadImage($file) {
    $targetDir = "uploads/";
    // Pastikan folder uploads ada
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0777, true);
    }

    // Cek apakah ada file yang diupload
    if (!empty($file['name'])) {
        $fileName = time() . "_" . basename($file["name"]); // Beri nama unik dengan timestamp
        $targetFile = $targetDir . $fileName;
        
        // Pindahkan file dari temporary ke folder uploads
        if (move_uploaded_file($file["tmp_name"], $targetFile)) {
            return $fileName; // Kembalikan nama file
        }
    }
    return 'default.jpg'; // Jika gagal atau tidak ada gambar, pakai default
}
// --- FUNGSI UPLOAD FILE SOURCE CODE ---
function uploadSourceFile($file) {
    $targetDir = "uploads/source/";
    // Buat folder jika belum ada
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0777, true);
    }

    if (!empty($file['name'])) {
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        // Hanya izinkan zip/rar
        if(in_array($ext, ['zip', 'rar', 'pdf'])) {
            $fileName = time() . "_" . basename($file["name"]);
            $targetFile = $targetDir . $fileName;
            if (move_uploaded_file($file["tmp_name"], $targetFile)) {
                return $fileName;
            }
        }
    }
    return NULL;
}
?>