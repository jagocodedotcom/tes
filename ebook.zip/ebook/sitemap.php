<?php require 'db_connect.php'; 
$products = $conn->query("SELECT * FROM products ORDER BY id DESC");
?>
<?php include 'header.php'; ?>

<style>
    .sitemap-wrapper { max-width: 900px; margin: 40px auto; background: white; border-radius: 16px; padding: 30px; box-shadow: 0 10px 30px rgba(0,0,0,0.08); }
    .sitemap-wrapper h2 { border-bottom: 2px solid #FF6B00; padding-bottom: 15px; margin-bottom: 25px; }
    .sitemap-list { list-style: none; padding: 0; }
    .sitemap-list li { padding: 12px 0; border-bottom: 1px solid #f5f5f5; display: flex; justify-content: space-between; align-items: center; }
    .sitemap-list li:last-child { border-bottom: none; }
    .sitemap-list a { color: #0A192F; font-weight: 600; text-decoration: none; }
    .sitemap-list a:hover { color: #FF6B00; }
    .sitemap-list .date { font-size: 13px; color: #777; }
</style>

<div class="container">
    <div class="sitemap-wrapper">
        <h2><i class="fas fa-sitemap" style="color:#FF6B00;"></i> Sitemap Produk & Blog</h2>
        <ul class="sitemap-list">
            <?php while($row = $products->fetch_assoc()): ?>
            <li>
                <a href="detail.php?slug=<?= $row['slug'] ?>">
                    <i class="fas fa-file-code" style="color:#0A192F;"></i> <?= $row['name'] ?>
                </a>
                <span class="date"><?= date('d M Y', strtotime($row['created_at'])) ?></span>
            </li>
            <?php endwhile; ?>
        </ul>
    </div>
</div>

<?php include 'footer.php'; ?>