 <link rel="icon" type="image/png" href="uploads/ico.png">
    <link rel="shortcut icon" href="uploads/ico.png">
<?php
session_start();
require 'db_connect.php';

// --- LOGIN SEDERHANA (Ganti password sesuai keinginan Anda) ---
$admin_password = 'admin123';
if (!isset($_SESSION['admin_logged_in'])) {
    if (isset($_POST['login'])) {
        if ($_POST['password'] === $admin_password) {
            $_SESSION['admin_logged_in'] = true;
        } else {
            $login_error = "Password salah!";
        }
    }
    // Tampilkan halaman login
    echo '<!DOCTYPE html><html><head><title>Login Admin</title><style>body{background:#0A192F;display:flex;justify-content:center;align-items:center;height:100vh;font-family:sans-serif;}form{background:white;padding:30px;border-radius:12px;width:300px;text-align:center;}input{width:100%;padding:10px;margin:10px 0;border:1px solid #ddd;border-radius:6px;}button{width:100%;padding:10px;background:#FF6B00;color:white;border:none;border-radius:6px;font-weight:bold;cursor:pointer;}</style></head><body><form method="POST"><h2 style="color:#0A192F;">Jagocode.com Admin</h2><input type="password" name="password" placeholder="Masukkan Password" required><button type="submit" name="login">Login</button>';
    if(isset($login_error)) echo '<p style="color:red;font-size:13px;margin-top:5px;">'.$login_error.'</p>';
    echo '</form></body></html>';
    exit;
}

// --- LOGOUT ---
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: admin_dashboard.php");
    exit;
}

// --- FUNGSI MEMBUAT SLUG (Untuk SEO Link) ---
function createSlug($string) {
    $string = strtolower($string);
    $string = preg_replace('/[^a-z0-9-]/', '-', $string);
    $string = preg_replace('/-+/', '-', $string);
    return trim($string, '-');
}

// --- MENANGANI AKSI DASHBOARD ---
$page = isset($_GET['page']) ? $_GET['page'] : 'dashboard';

// --- HAPUS PRODUK ---
if ($page == 'delete_product' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $conn->query("DELETE FROM products WHERE id = $id");
    header("Location: admin_dashboard.php?page=products");
    exit;
}

// --- HAPUS KATEGORI ---
if ($page == 'delete_category' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $conn->query("DELETE FROM categories WHERE id = $id");
    header("Location: admin_dashboard.php?page=categories");
    exit;
}

// --- SIMPAN PRODUK (CREATE / UPDATE) ---
if (isset($_POST['save_product'])) {
    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $slug = createSlug($name);
    $price = floatval($_POST['price']);
    $old_price = !empty($_POST['old_price']) ? floatval($_POST['old_price']) : 'NULL';
    $desc = mysqli_real_escape_string($conn, $_POST['description']);
    $meta_desc = mysqli_real_escape_string($conn, $_POST['meta_description']);
    $cat_id = intval($_POST['category_id']);
    
    // Upload Gambar
    $image = null;
    if (!empty($_FILES['image']['name'])) {
        $image = uploadImage($_FILES['image']);
    }
    
    // Upload File Source
    $source = null;
    if (!empty($_FILES['source_file']['name'])) {
        $source = uploadSourceFile($_FILES['source_file']);
    }

    if ($id > 0) {
        // UPDATE
        $sql = "UPDATE products SET name='$name', slug='$slug', price='$price', old_price=$old_price, description='$desc', meta_description='$meta_desc', category_id=$cat_id";
        if ($image) $sql .= ", image='$image'";
        if ($source) $sql .= ", file_source='$source'";
        $sql .= " WHERE id=$id";
        $conn->query($sql);
    } else {
        // INSERT
        $conn->query("INSERT INTO products (name, slug, price, old_price, description, meta_description, category_id, image, file_source) 
                      VALUES ('$name', '$slug', '$price', $old_price, '$desc', '$meta_desc', $cat_id, '$image', '$source')");
    }
    header("Location: admin_dashboard.php?page=products");
    exit;
}

// --- SIMPAN KATEGORI ---
if (isset($_POST['save_category'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $slug = createSlug($name);
    $icon = mysqli_real_escape_string($conn, $_POST['icon']);
    $conn->query("INSERT INTO categories (name, slug, icon) VALUES ('$name', '$slug', '$icon')");
    header("Location: admin_dashboard.php?page=categories");
    exit;
}

// --- UPLOAD FILE TANPA LOGIN & CEK STATUS PEMBAYARAN ---
if (isset($_GET['token_download']) && isset($_GET['order_id'])) {
    $token = $_GET['token_download'];
    $order_id = $_GET['order_id'];
    
    // Cek validitas token, status PAID, dan belum didownload
    $check = $conn->query("SELECT o.id, o.status, o.is_downloaded, oi.product_id, p.file_source 
                           FROM orders o 
                           JOIN order_items oi ON o.order_id = oi.order_id 
                           JOIN products p ON oi.product_id = p.id 
                           WHERE o.download_token = '$token' AND o.order_id = '$order_id'");
    
    if ($check->num_rows > 0) {
        $row = $check->fetch_assoc();
        if ($row['status'] == 'paid' && $row['is_downloaded'] == 0) {
            // Tandai sudah didownload
            $conn->query("UPDATE orders SET is_downloaded = 1 WHERE id = {$row['id']}");
            
            // Proses download file
            $filepath = "uploads/source/" . $row['file_source'];
            if (file_exists($filepath)) {
                header('Content-Description: File Transfer');
                header('Content-Type: application/octet-stream');
                header('Content-Disposition: attachment; filename="'.basename($filepath).'"');
                header('Expires: 0');
                header('Cache-Control: must-revalidate');
                header('Pragma: public');
                header('Content-Length: ' . filesize($filepath));
                flush();
                readfile($filepath);
                exit;
            } else {
                die("File source code tidak ditemukan di server.");
            }
        } else {
            die("Link download tidak valid, sudah kadaluarsa, atau file sudah pernah didownload.");
        }
    } else {
        die("Token tidak valid.");
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Jagocode Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Chart.js untuk Laporan -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', sans-serif; }
        body { background: #f4f6f9; display: flex; height: 100vh; overflow: hidden; }
        
        /* --- SIDEBAR --- */
        .sidebar { width: 260px; background: #0A192F; color: white; height: 100%; display: flex; flex-direction: column; transition: 0.3s; }
        .sidebar .logo { padding: 25px; font-size: 24px; font-weight: 800; border-bottom: 1px solid rgba(255,255,255,0.1); }
        .sidebar .logo i { color: #FF6B00; }
        .sidebar-menu { flex: 1; padding: 20px 0; overflow-y: auto; }
        .sidebar-menu a { display: block; padding: 12px 25px; color: rgba(255,255,255,0.7); font-size: 14px; transition: 0.2s; text-decoration: none; border-left: 3px solid transparent; }
        .sidebar-menu a:hover, .sidebar-menu a.active { background: rgba(255,255,255,0.05); color: white; border-left-color: #FF6B00; }
        .sidebar-menu a i { width: 25px; }
        .sidebar .logout { padding: 20px 25px; border-top: 1px solid rgba(255,255,255,0.1); }
        .sidebar .logout a { color: #e74c3c; text-decoration: none; font-weight: bold; }

        /* --- CONTENT --- */
        .content { flex: 1; overflow-y: auto; padding: 20px 30px; }
        .header-title { font-size: 24px; font-weight: 700; margin-bottom: 20px; color: #0A192F; }
        
        /* --- STATISTICS CARDS --- */
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .stat-card { background: white; padding: 20px; border-radius: 12px; box-shadow: 0 4px 10px rgba(0,0,0,0.03); }
        .stat-card h4 { font-size: 14px; color: #777; }
        .stat-card .num { font-size: 28px; font-weight: 800; color: #0A192F; }
        .stat-card i { float: right; font-size: 32px; color: #FF6B00; opacity: 0.5; }

        /* --- TABLES & FORMS --- */
        .card { background: white; border-radius: 12px; padding: 20px; box-shadow: 0 4px 10px rgba(0,0,0,0.03); margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; }
        th { background: #f8fafc; font-weight: 600; }
        .badge { padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: bold; }
        .badge-success { background: #d4edda; color: #155724; }
        .badge-danger { background: #f8d7da; color: #721c24; }
        
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; font-weight: 600; margin-bottom: 5px; font-size: 14px; }
        .form-control { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; outline: none; font-size: 14px; }
        .btn { background: #0A192F; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: 600; }
        .btn-orange { background: #FF6B00; }
        .btn-red { background: #e74c3c; }
        .btn-sm { padding: 5px 10px; font-size: 12px; }

        /* --- MODAL --- */
        .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); justify-content: center; align-items: center; z-index: 1000; }
        .modal-content { background: white; border-radius: 12px; padding: 25px; width: 500px; max-width: 90%; max-height: 90vh; overflow-y: auto; }
        .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; }
        .modal-header h3 { margin: 0; } .close-modal { font-size: 24px; cursor: pointer; }

        /* --- RESPONSIVE --- */
        @media (max-width: 768px) { .sidebar { width: 70px; } .sidebar .logo { font-size: 14px; } .sidebar-menu a span { display: none; } .sidebar-menu a i { font-size: 20px; width: 100%; } }
    </style>
</head>
<body>

    <!-- SIDEBAR -->
    <div class="sidebar">
        <div class="logo"><i class="fas fa-store"></i> Jagocode.com</div>
        <div class="sidebar-menu">
            <a href="?page=dashboard" class="<?= ($page == 'dashboard') ? 'active' : '' ?>"><i class="fas fa-chart-pie"></i> <span>Dashboard</span></a>
            <a href="?page=products" class="<?= ($page == 'products') ? 'active' : '' ?>"><i class="fas fa-boxes"></i> <span>Produk & SEO</span></a>
            <a href="?page=categories" class="<?= ($page == 'categories') ? 'active' : '' ?>"><i class="fas fa-tags"></i> <span>Kategori</span></a>
            <a href="?page=files" class="<?= ($page == 'files') ? 'active' : '' ?>"><i class="fas fa-folder-open"></i> <span>File Manager</span></a>
            <a href="?page=reports" class="<?= ($page == 'reports') ? 'active' : '' ?>"><i class="fas fa-file-invoice"></i> <span>Laporan</span></a>
        </div>
        <div class="logout"><a href="?logout=true"><i class="fas fa-sign-out-alt"></i> Logout</a></div>
    </div>

    <!-- CONTENT -->
    <div class="content">
        <?php 
        // --- DASHBOARD ---
        if ($page == 'dashboard'): 
            $total_products = $conn->query("SELECT COUNT(*) as t FROM products")->fetch_assoc()['t'];
            $total_orders = $conn->query("SELECT COUNT(*) as t FROM orders")->fetch_assoc()['t'];
            $total_revenue = $conn->query("SELECT SUM(total_amount) as t FROM orders WHERE status='paid'")->fetch_assoc()['t'] ?? 0;
        ?>
            <div class="header-title"><i class="fas fa-chart-pie" style="color:#FF6B00;"></i> Dashboard</div>
            <div class="stats-grid">
                <div class="stat-card"><h4>Total Produk</h4><div class="num"><?= $total_products ?></div><i class="fas fa-boxes"></i></div>
                <div class="stat-card"><h4>Total Pesanan</h4><div class="num"><?= $total_orders ?></div><i class="fas fa-shopping-cart"></i></div>
                <div class="stat-card"><h4>Pendapatan</h4><div class="num">Rp <?= number_format($total_revenue,0,',','.') ?></div><i class="fas fa-money-bill-wave"></i></div>
            </div>
            <div class="card" style="height:300px;">
                <h4>Grafik Penjualan (Bulan Ini)</h4>
                <canvas id="salesChart"></canvas>
            </div>
            <script>
                const ctx = document.getElementById('salesChart').getContext('2d');
                new Chart(ctx, {
                    type: 'line',
                    data: { labels: ['Minggu 1', 'Minggu 2', 'Minggu 3', 'Minggu 4'], datasets: [{
                        label: 'Penjualan (Rp)',
                        data: [0, 0, 0, 0], // Data dummy, Anda bisa menggantinya dengan query database
                        borderColor: '#FF6B00',
                        backgroundColor: 'rgba(255, 107, 0, 0.1)',
                        tension: 0.4, fill: true
                    }]},
                    options: { responsive: true, maintainAspectRatio: false }
                });
            </script>
        <?php endif; ?>

        <!-- --- PRODUK & SEO --- -->
        <?php if ($page == 'products'): 
            $products = $conn->query("SELECT p.*, c.name as cat_name FROM products p LEFT JOIN categories c ON p.category_id = c.id ORDER BY p.id DESC");
        ?>
            <div class="header-title"><i class="fas fa-boxes" style="color:#FF6B00;"></i> Manajemen Produk & SEO</div>
            <button class="btn btn-orange" onclick="openModal('productModal')"><i class="fas fa-plus"></i> Tambah Produk Baru</button>
            <div class="card" style="margin-top:20px;">
                <table>
                    <tr><th>ID</th><th>Nama</th><th>Kategori</th><th>Harga</th><th>SEO Link</th><th>Aksi</th></tr>
                    <?php while($p = $products->fetch_assoc()): ?>
                    <tr>
                        <td>#<?= $p['id'] ?></td>
                        <td><strong><?= $p['name'] ?></strong></td>
                        <td><?= $p['cat_name'] ?></td>
                        <td>Rp <?= number_format($p['price'],0,',','.') ?></td>
                        <td style="font-size:12px; color:#777;">/p/<?= $p['slug'] ?></td>
                        <td>
                            <button class="btn btn-sm" onclick="editProduct(<?= htmlspecialchars(json_encode($p)) ?>)"><i class="fas fa-edit"></i></button>
                            <a href="?page=delete_product&id=<?= $p['id'] ?>" onclick="return confirm('Hapus produk ini?')"><button class="btn btn-sm btn-red"><i class="fas fa-trash"></i></button></a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </table>
            </div>
        <?php endif; ?>

        <!-- --- KATEGORI --- -->
        <?php if ($page == 'categories'): 
            $cats = $conn->query("SELECT * FROM categories ORDER BY id DESC");
        ?>
            <div class="header-title"><i class="fas fa-tags" style="color:#FF6B00;"></i> Manajemen Kategori</div>
            <button class="btn btn-orange" onclick="openModal('categoryModal')"><i class="fas fa-plus"></i> Tambah Kategori</button>
            <div class="card" style="margin-top:20px;">
                <table>
                    <tr><th>ID</th><th>Nama</th><th>Icon</th><th>Slug</th><th>Aksi</th></tr>
                    <?php while($c = $cats->fetch_assoc()): ?>
                    <tr>
                        <td>#<?= $c['id'] ?></td>
                        <td><i class="fas <?= $c['icon'] ?>"></i> <?= $c['name'] ?></td>
                        <td><?= $c['icon'] ?></td>
                        <td style="font-size:12px;"><?= $c['slug'] ?></td>
                        <td><a href="?page=delete_category&id=<?= $c['id'] ?>" onclick="return confirm('Hapus kategori?')"><button class="btn btn-sm btn-red"><i class="fas fa-trash"></i></button></a></td>
                    </tr>
                    <?php endwhile; ?>
                </table>
            </div>
        <?php endif; ?>

        <!-- --- FILE MANAGER & DOWNLOAD TOKEN --- -->
        <?php if ($page == 'files'): 
            // Ambil semua produk yang memiliki file source
            $files = $conn->query("SELECT id, name, file_source, slug FROM products WHERE file_source IS NOT NULL");
        ?>
            <div class="header-title"><i class="fas fa-folder-open" style="color:#FF6B00;"></i> Manajemen File & Token Download</div>
            <div class="card">
                <p style="margin-bottom:15px; color:#555;">Sistem ini memungkinkan pembeli mendownload file <strong>tanpa login</strong> menggunakan token unik yang dikirimkan oleh admin. Setiap token hanya bisa digunakan <strong>1x download</strong> setelah status pesanan 'Paid'.</p>
                <table>
                    <tr><th>ID Produk</th><th>Nama Produk</th><th>File Source</th><th>Generate Token & Aksi</th></tr>
                    <?php while($f = $files->fetch_assoc()): ?>
                    <tr>
                        <td>#<?= $f['id'] ?></td>
                        <td><?= $f['name'] ?></td>
                        <td><?= $f['file_source'] ?></td>
                        <td>
                            <!-- Form untuk membuat token download (hanya admin yang bisa mengakses ini) -->
                            <form action="" method="POST" style="display:inline;">
                                <input type="hidden" name="product_id" value="<?= $f['id'] ?>">
                                <button type="submit" class="btn btn-sm btn-orange" onclick="alert('Fitur generate token otomatis untuk setiap order sudah terintegrasi di halaman Checkout. Anda tinggal mengubah status order menjadi PAID di halaman Laporan.')">Lihat Contoh Token</button>
                            </form>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </table>
            </div>
        <?php endif; ?>

        <!-- --- LAPORAN PENJUALAN --- -->
        <?php if ($page == 'reports'): 
            $orders = $conn->query("SELECT * FROM orders ORDER BY created_at DESC");
        ?>
            <div class="header-title"><i class="fas fa-file-invoice" style="color:#FF6B00;"></i> Laporan & Manajemen Pesanan</div>
            <div class="card">
                <table>
                    <tr><th>Order ID</th><th>Total</th><th>Tanggal</th><th>Status</th><th>Token Download</th><th>Aksi (Update Status)</th></tr>
                    <?php while($o = $orders->fetch_assoc()): ?>
                    <tr>
                        <td><strong><?= $o['order_id'] ?></strong></td>
                        <td>Rp <?= number_format($o['total_amount'],0,',','.') ?></td>
                        <td><?= date('d M Y H:i', strtotime($o['created_at'])) ?></td>
                        <td>
                            <?php if($o['status'] == 'paid'): ?>
                                <span class="badge badge-success">PAID</span>
                            <?php else: ?>
                                <span class="badge badge-danger">Pending</span>
                            <?php endif; ?>
                        </td>
                        <td style="font-size:11px; color:#777;">
                            <?php if($o['download_token']): ?>
                                Token Tersedia
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($o['status'] == 'pending'): ?>
                                <!-- Tombol untuk update status menjadi PAID secara instan -->
                                <a href="admin_dashboard.php?page=reports&mark_paid=<?= $o['order_id'] ?>" onclick="return confirm('Yakin ingin menandai pesanan ini sebagai LUNAS?')">
                                    <button class="btn btn-sm" style="background:#27ae60;">Tandai Lunas</button>
                                </a>
                            <?php else: ?>
                                <span style="font-size:12px; color:#777;">Selesai</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </table>
            </div>
            <?php 
            // Logika Tandai Lunas & Generate Token
            if (isset($_GET['mark_paid'])) {
                $order_id = $_GET['mark_paid'];
                // Generate token unik
                $token = bin2hex(random_bytes(32));
                // Update status dan token
                $conn->query("UPDATE orders SET status = 'paid', download_token = '$token', is_downloaded = 0 WHERE order_id = '$order_id'");
                header("Location: admin_dashboard.php?page=reports");
                exit;
            }
            ?>
        <?php endif; ?>

        <!-- MODAL PRODUK -->
        <div class="modal" id="productModal">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 id="productModalTitle">Tambah Produk Baru</h3>
                    <span class="close-modal" onclick="closeModal('productModal')">&times;</span>
                </div>
                <form action="" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="id" id="edit_id">
                    <div class="form-group"><label>Nama Produk (SEO Title)</label><input type="text" name="name" id="p_name" class="form-control" required></div>
                    <div class="form-group"><label>Harga (Rp)</label><input type="number" name="price" id="p_price" class="form-control" required></div>
                    <div class="form-group"><label>Harga Coret (Diskon)</label><input type="number" name="old_price" id="p_old_price" class="form-control"></div>
                    <div class="form-group"><label>Kategori</label>
                        <select name="category_id" id="p_cat" class="form-control">
                            <?php 
                            $cats = $conn->query("SELECT * FROM categories");
                            while($c = $cats->fetch_assoc()) echo "<option value='{$c['id']}'>{$c['name']}</option>";
                            ?>
                        </select>
                    </div>
                    <div class="form-group"><label>Deskripsi</label><textarea name="description" id="p_desc" class="form-control" rows="3"></textarea></div>
                    <div class="form-group"><label>Meta Description (SEO)</label><input type="text" name="meta_description" id="p_meta" class="form-control" placeholder="Deskripsi singkat untuk Google Search"></div>
                    <div class="form-group"><label>Gambar Produk</label><input type="file" name="image" class="form-control"></div>
                    <div class="form-group"><label>Upload Source Code (.zip/.rar)</label><input type="file" name="source_file" accept=".zip,.rar" class="form-control"></div>
                    <button type="submit" name="save_product" class="btn" style="width:100%;">Simpan Produk</button>
                </form>
            </div>
        </div>

        <!-- MODAL KATEGORI -->
        <div class="modal" id="categoryModal">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Tambah Kategori Baru</h3>
                    <span class="close-modal" onclick="closeModal('categoryModal')">&times;</span>
                </div>
                <form action="" method="POST">
                    <div class="form-group"><label>Nama Kategori</label><input type="text" name="name" class="form-control" required></div>
                    <div class="form-group"><label>Icon (FontAwesome class, contoh: fa-database)</label><input type="text" name="icon" class="form-control" placeholder="fa-code" required></div>
                    <button type="submit" name="save_category" class="btn" style="width:100%;">Simpan Kategori</button>
                </form>
            </div>
        </div>

    </div>

    <script>
        function openModal(id) { document.getElementById(id).style.display = "flex"; }
        function closeModal(id) { document.getElementById(id).style.display = "none"; }
        
        function editProduct(data) {
            document.getElementById('productModal').style.display = "flex";
            document.getElementById('productModalTitle').innerText = "Edit Produk";
            document.getElementById('edit_id').value = data.id;
            document.getElementById('p_name').value = data.name;
            document.getElementById('p_price').value = data.price;
            document.getElementById('p_old_price').value = data.old_price || '';
            document.getElementById('p_cat').value = data.category_id;
            document.getElementById('p_desc').value = data.description || '';
            document.getElementById('p_meta').value = data.meta_description || '';
        }
    </script>
</body>
</html>