 <link rel="icon" type="image/png" href="uploads/ico.png">
    <link rel="shortcut icon" href="uploads/ico.png">
<?php
session_start();
require 'db_connect.php';

// Redirect jika sudah login
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header("Location: admin.php");
    exit;
}

$login_error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // 1. Ambil data user dari database
    $stmt = $conn->prepare("SELECT * FROM admins WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $admin = $result->fetch_assoc();
        
        // 2. Bandingkan password langsung (Plain text comparison, dijamin berhasil)
        if ($password === $admin['password']) {
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_name'] = $admin['full_name'];
            header("Location: admin.php");
            exit;
        } else {
            $login_error = "Password salah! Coba ketik ulang 'admin123'.";
        }
    } else {
        $login_error = "Username 'admin' tidak ditemukan!";
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login Admin Jagocode.com</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', sans-serif; }
        body { background: #0A192F; display: flex; justify-content: center; align-items: center; min-height: 100vh; }
        .login-box { background: white; padding: 40px 30px; border-radius: 16px; box-shadow: 0 15px 35px rgba(0,0,0,0.2); width: 100%; max-width: 400px; text-align: center; }
        .login-box .logo { font-size: 28px; font-weight: 800; color: #0A192F; margin-bottom: 10px; }
        .login-box .logo i { color: #FF6B00; }
        .login-box p { color: #777; margin-bottom: 25px; font-size: 14px; }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; text-align: left; font-weight: 600; font-size: 14px; margin-bottom: 5px; }
        .form-group input { width: 100%; padding: 12px 15px; border: 1px solid #ddd; border-radius: 8px; outline: none; font-size: 14px; }
        .btn-login { width: 100%; background: #FF6B00; color: white; border: none; padding: 12px; border-radius: 8px; font-size: 16px; font-weight: 700; cursor: pointer; }
        .btn-login:hover { background: #e05f00; }
        .error { color: #e74c3c; font-size: 13px; margin-top: 10px; }
    </style>
</head>
<body>
    <div class="login-box">
         <a href="index.php" class="logo-area"> 
                <img src="uploads/logo.png" alt="BigSoft Logo">
            </a>
        <p>Masukkan Username dan Password</p>
        
        <form method="POST">
            <div class="form-group">
                <label><i class="fas fa-user"></i> Username</label>
                <input type="text" name="username" placeholder="Username: admin" required autofocus>
            </div>
            <div class="form-group">
                <label><i class="fas fa-lock"></i> Password</label>
                <input type="password" name="password" placeholder="Password: admin123" required>
            </div>
            <button type="submit" class="btn-login"><i class="fas fa-sign-in-alt"></i> Masuk Dashboard</button>
            <?php if(!empty($login_error)): ?>
                <div class="error"><i class="fas fa-exclamation-circle"></i> <?= $login_error ?></div>
            <?php endif; ?>
        </form>
    </div>
</body>
</html>