<?php
session_start();
require 'db_connect.php';
$session_id = $_SESSION['cart_session'];
$items = $conn->query("SELECT c.*, p.name, p.price, p.image FROM cart c JOIN products p ON c.product_id = p.id WHERE c.session_id = '$session_id'");
if ($items->num_rows == 0) { header("Location: shop.php"); exit; }
$subtotal = 0; 
while ($row = $items->fetch_assoc()) $subtotal += ($row['price'] * $row['qty']);
$items->data_seek(0);
$discount = isset($_SESSION['discount_amount']) ? $_SESSION['discount_amount'] : 0;
$grand_total = $subtotal - $discount;

// Simpan pesanan ke database
$check_order = $conn->query("SELECT * FROM orders WHERE session_id = '$session_id' AND status = 'pending'");
if ($check_order->num_rows == 0) {
    $order_id = 'BIGSOFT-' . date('Ymd') . '-' . rand(100, 999);
    $conn->query("INSERT INTO orders (order_id, session_id, total_amount, status) VALUES ('$order_id', '$session_id', '$grand_total', 'pending')");
    while($row = $items->fetch_assoc()) {
        $pid = $row['product_id']; $qty = $row['qty']; $price = $row['price'];
        $conn->query("INSERT INTO order_items (order_id, product_id, qty, price) VALUES ('$order_id', '$pid', '$qty', '$price')");
    }
} else {
    $order_data = $check_order->fetch_assoc();
    $order_id = $order_data['order_id'];
}
$_SESSION['current_order_id'] = $order_id;
?>
<?php include 'header.php'; ?>

<style>
    .checkout-wrapper { max-width: 900px; margin: 40px auto; background: white; border-radius: 12px; padding: 30px; }
    .payment-method { border: 2px solid #eee; border-radius: 12px; padding: 15px; margin-bottom: 15px; cursor: pointer; display: flex; align-items: center; gap: 15px; }
    .payment-method:hover, .payment-method.active { border-color: #FF6B00; background: #fff8f0; }
    .bank-details, .qris-details { display: none; background: #f8fafc; padding: 15px; border-radius: 8px; margin-top: 10px; }
    .bank-details.active, .qris-details.active { display: block; }
    .qris-details img { width: 180px; height: 180px; border: 1px solid #ddd; border-radius: 12px; padding: 10px; background: white; }
    .note-box { background: #fff3cd; border: 1px solid #ffc107; border-radius: 8px; padding: 15px; margin-top: 20px; color: #856404; }
    .btn-confirm { width: 100%; background: #25D366; color: white; border: none; padding: 15px; border-radius: 10px; font-size: 18px; cursor: pointer; margin-top: 20px; font-weight: bold; display: flex; justify-content: center; gap: 10px; }
    @media(max-width:768px){ .checkout-wrapper{grid-template-columns:1fr;} }
</style>

<div class="container">
    <div class="checkout-wrapper">
        <h2 style="border-bottom:2px solid #FF6B00; padding-bottom:15px;"><i class="fas fa-credit-card" style="color:#FF6B00;"></i> Konfirmasi Pesanan</h2>
        <div style="display:grid; grid-template-columns:1.5fr 1fr; gap:30px;">
            <div>
                <h4>Ringkasan Pesanan</h4>
                <?php while($row = $items->fetch_assoc()): ?>
                <div style="display:flex; justify-content:space-between; padding:10px 0; border-bottom:1px solid #eee;">
                    <span><?= $row['name'] ?> x <?= $row['qty'] ?></span>
                    <span style="font-weight:bold;">Rp <?= number_format($row['price']*$row['qty'],0,',','.') ?></span>
                </div>
                <?php endwhile; ?>
                <div style="margin-top:20px; padding-top:15px; border-top:2px solid #0A192F; font-weight:bold; font-size:18px; display:flex; justify-content:space-between;">
                    <span>Total Bayar</span>
                    <span>Rp <?= number_format($grand_total,0,',','.') ?></span>
                </div>
            </div>
            <div>
                <h4>Pilih Pembayaran</h4>
                <div class="payment-method active" onclick="selectPay('bca')">
                    <i class="fas fa-university" style="font-size:30px;"></i>
                    <div><h5>Transfer BCA</h5><p style="color:#777; font-size:13px;">Rekening bank</p></div>
                </div>
                <div class="bank-details active" id="bcaDetail">
                    <p><strong>Bank:</strong> BCA</p>
                    <p><strong>No. Rek:</strong> 8888 1234 5678</p>
                    <p><strong>Atas Nama:</strong> PT BigSoft</p>
                </div>
                <div class="payment-method" onclick="selectPay('qris')">
                    <i class="fas fa-qrcode" style="font-size:30px;"></i>
                    <div><h5>QRIS</h5><p style="color:#777; font-size:13px;">Scan QR via GoPay/OVO/Dana</p></div>
                </div>
                <div class="qris-details" id="qrisDetail">
                    <img src="https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=BigSoft-<?= $order_id ?>">
                    <p style="font-size:13px; color:#777; margin-top:5px;">Scan QR di atas</p>
                </div>
                <div class="note-box">
                    <strong><i class="fas fa-info-circle"></i> Catatan:</strong><br>
                    Kirim bukti transfer ke WA <strong>089528833845</strong> untuk mendapatkan Source Code.
                </div>
                <a href="https://wa.me/6289528833845?text=Halo%20BigSoft!%20Saya%20telah%20transfer%20untuk%20Order%20ID:%20<?= $order_id ?>%0ATotal:%20Rp%20<?= number_format($grand_total,0,',','.') ?>%0A%0ABerikut%20bukti%20transfer%20saya:" target="_blank">
                    <button class="btn-confirm"><i class="fab fa-whatsapp"></i> Kirim Bukti via WA</button>
                </a>
            </div>
        </div>
    </div>
</div>

<script>
function selectPay(m) {
    document.querySelectorAll('.payment-method').forEach(e=>e.classList.remove('active'));
    document.querySelectorAll('.bank-details, .qris-details').forEach(e=>e.classList.remove('active'));
    if(m=='bca'){ document.querySelector('.payment-method').classList.add('active'); document.getElementById('bcaDetail').classList.add('active'); }
    else { document.querySelectorAll('.payment-method')[1].classList.add('active'); document.getElementById('qrisDetail').classList.add('active'); }
}
</script>

<?php include 'footer.php'; ?>