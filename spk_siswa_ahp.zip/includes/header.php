<?php
// ============================================
// HEADER - SPK SISWA TELADAN AHP
// ============================================

// Cek session
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Cek login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Load config
if (!defined('BASE_URL')) {
    require_once __DIR__ . '/../config/database.php';
}

// Ambil informasi user
$user_name = $_SESSION['nama_lengkap'] ?? 'User';
$user_role = $_SESSION['role'] ?? 'user';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo APP_NAME; ?></title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- DataTables -->
    <link href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    
    <style>
        /* ===== SIDEBAR ===== */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: 70px;
            background: #2c3e7a;
            color: white;
            transition: width 0.3s ease;
            z-index: 1030;
            overflow: hidden;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            display: flex;
            flex-direction: column;
        }
        .sidebar:hover { width: 260px; }
        .sidebar-header {
            padding: 20px 15px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            display: flex;
            align-items: center;
            gap: 10px;
            flex-shrink: 0;
        }
        .sidebar-header h4 {
            white-space: nowrap;
            margin: 0;
            font-size: 18px;
        }
        .sidebar-header small { display: none; font-size: 11px; opacity: 0.7; }
        .sidebar:hover .sidebar-header small { display: block; }
        .sidebar-menu { padding: 15px 0; flex: 1; overflow-y: auto; }
        .menu-label {
            padding: 10px 20px;
            font-size: 10px;
            text-transform: uppercase;
            color: rgba(255,255,255,0.4);
            letter-spacing: 1px;
            display: none;
            font-weight: 600;
        }
        .sidebar:hover .menu-label { display: block; }
        .menu-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 12px 20px;
            color: rgba(255,255,255,0.7);
            text-decoration: none;
            transition: all 0.3s ease;
            white-space: nowrap;
            border-left: 3px solid transparent;
            cursor: pointer;
        }
        .menu-item:hover, .menu-item.active {
            background: rgba(255,255,255,0.1);
            color: white;
            border-left-color: #f8b739;
        }
        .menu-item i { font-size: 20px; width: 24px; text-align: center; }
        .menu-item span { display: none; }
        .sidebar:hover .menu-item span { display: inline; }
        .sidebar-footer {
            padding: 15px;
            border-top: 1px solid rgba(255,255,255,0.1);
            flex-shrink: 0;
        }
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 10px;
        }
        .user-info i { font-size: 32px; }
        .user-info div { overflow: hidden; }
        .user-info strong {
            display: block;
            font-size: 13px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .user-info small { font-size: 11px; opacity: 0.6; }
        
        /* ===== MAIN CONTENT ===== */
        .main-content {
            margin-left: 70px;
            min-height: 100vh;
            transition: margin-left 0.3s ease;
            display: flex;
            flex-direction: column;
        }
        .content { padding: 20px; flex: 1; }
        
        /* ===== STAT CARD ===== */
        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 20px 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            border-left: 4px solid #2c3e7a;
        }
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.12);
        }
        .stat-card .stat-icon { font-size: 32px; opacity: 0.3; }
        .stat-card .stat-number { font-size: 28px; font-weight: 700; color: #2c3e7a; }
        .stat-card .stat-label { color: #6c757d; font-size: 14px; }
        
        /* ===== TABLE ===== */
        .table-container {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
        }
        .table thead th {
            background: #2c3e7a;
            color: white;
            border: none;
            padding: 12px 15px;
            font-weight: 600;
        }
        .table tbody tr:hover { background: #f8f9ff; }
        
        /* ===== FOOTER ===== */
        .footer {
            padding: 15px 20px;
            background: white;
            border-top: 1px solid #e9ecef;
            margin-top: 20px;
        }
        
        /* ===== RESPONSIVE ===== */
        @media (max-width: 768px) {
            .sidebar { width: 60px; }
            .sidebar:hover { width: 240px; }
            .main-content { margin-left: 60px; }
            .stat-card .stat-number { font-size: 20px; }
        }
        
        /* ===== FADE IN ===== */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .fade-in { animation: fadeIn 0.5s ease; }
        
        /* ===== SCROLLBAR ===== */
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: #f1f1f1; }
        ::-webkit-scrollbar-thumb { background: #4a6ba8; border-radius: 3px; }
        ::-webkit-scrollbar-thumb:hover { background: #2c3e7a; }
        
        /* ===== BADGE ===== */
        .badge-status { padding: 5px 12px; border-radius: 20px; font-weight: 600; font-size: 12px; }
        .badge-benefit { background: #d4edda; color: #155724; }
        .badge-cost { background: #f8d7da; color: #721c24; }
        
        /* ===== STICKY NAVBAR ===== */
        .sticky-top { position: sticky; top: 0; z-index: 1020; }
        .btn-link { text-decoration: none; }
    </style>
</head>
<body>
    <div class="wrapper">
        <?php include 'sidebar.php'; ?>
        
        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Navbar -->
            <nav class="navbar navbar-expand-lg navbar-light bg-white border-bottom sticky-top">
                <div class="container-fluid">
                    <button class="btn btn-link" id="sidebarToggle" type="button">
                        <i class="fas fa-bars"></i>
                    </button>
                    
                    <div class="d-flex align-items-center ms-auto">
                        <span class="text-muted me-3 d-none d-md-block">
                            <i class="fas fa-clock"></i> <?php echo date('d F Y'); ?>
                        </span>
                        
                        <div class="dropdown">
                            <a href="#" class="d-flex align-items-center text-decoration-none dropdown-toggle" 
                               data-bs-toggle="dropdown">
                                <i class="fas fa-user-circle fa-2x text-primary"></i>
                                <span class="d-none d-md-block ms-2">
                                    <strong><?php echo htmlspecialchars($user_name); ?></strong>
                                    <small class="d-block text-muted"><?php echo htmlspecialchars($user_role); ?></small>
                                </span>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="#">
                                    <i class="fas fa-user"></i> Profile
                                </a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item text-danger" href="logout.php">
                                    <i class="fas fa-sign-out-alt"></i> Logout
                                </a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </nav>

            <!-- Content Area -->
            <div class="content p-3 p-md-4">
                <div class="container-fluid">
                    <?php if (isset($_SESSION['flash_message'])): ?>
                        <div class="alert alert-<?php echo $_SESSION['flash_type'] ?? 'info'; ?> alert-dismissible fade show">
                            <i class="fas fa-<?php echo $_SESSION['flash_icon'] ?? 'info-circle'; ?>"></i>
                            <?php echo $_SESSION['flash_message']; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                        <?php unset($_SESSION['flash_message'], $_SESSION['flash_type'], $_SESSION['flash_icon']); ?>
                    <?php endif; ?>