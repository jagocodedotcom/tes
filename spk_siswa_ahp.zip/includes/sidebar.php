<?php
// ============================================
// SIDEBAR - SPK SISWA TELADAN AHP
// ============================================

// Load config jika belum
if (!defined('BASE_URL')) {
    require_once __DIR__ . '/../config/database.php';
}

// Ambil nama file saat ini untuk active menu
$current_page = basename($_SERVER['PHP_SELF']);
$current_path = $_SERVER['PHP_SELF'];

// Fungsi untuk cek active menu
function isActiveMenu($patterns) {
    $current = $_SERVER['PHP_SELF'];
    foreach ((array)$patterns as $pattern) {
        if (strpos($current, $pattern) !== false) {
            return 'active';
        }
    }
    return '';
}

// Gunakan BASE_URL atau relative path
$base = defined('BASE_URL') ? BASE_URL : '';
?>
<!-- Sidebar -->
<nav class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <h4 class="text-white mb-0">
            <i class="fas fa-graduation-cap"></i> 
            <span class="d-none d-lg-inline">SPK AHP</span>
        </h4>
        <small class="text-white-50 d-none d-lg-block">Siswa Teladan</small>
    </div>
    
    <div class="sidebar-menu">
        <div class="menu-label d-none d-lg-block">MENU UTAMA</div>
        <a href="<?php echo $base; ?>/index.php" class="menu-item <?php echo $current_page == 'index.php' ? 'active' : ''; ?>">
            <i class="fas fa-home"></i>
            <span class="d-none d-lg-inline">Dashboard</span>
        </a>
        
        <div class="menu-label d-none d-lg-block">MASTER DATA</div>
        <a href="<?php echo $base; ?>/modules/kriteria/index.php" class="menu-item <?php echo isActiveMenu('kriteria'); ?>">
            <i class="fas fa-list"></i>
            <span class="d-none d-lg-inline">Kriteria</span>
        </a>
        <a href="<?php echo $base; ?>/modules/alternatif/index.php" class="menu-item <?php echo isActiveMenu('alternatif'); ?>">
            <i class="fas fa-users"></i>
            <span class="d-none d-lg-inline">Siswa</span>
        </a>
        
        <div class="menu-label d-none d-lg-block">PROSES AHP</div>
        <a href="<?php echo $base; ?>/modules/penilaian/index.php" class="menu-item <?php echo isActiveMenu('penilaian'); ?>">
            <i class="fas fa-edit"></i>
            <span class="d-none d-lg-inline">Penilaian</span>
        </a>
        <a href="<?php echo $base; ?>/modules/perbandingan/index.php" class="menu-item <?php echo isActiveMenu('perbandingan'); ?>">
            <i class="fas fa-balance-scale"></i>
            <span class="d-none d-lg-inline">Perbandingan</span>
        </a>
        
        <div class="menu-label d-none d-lg-block">HASIL</div>
        <a href="<?php echo $base; ?>/modules/hasil/index.php" class="menu-item <?php echo isActiveMenu('hasil'); ?>">
            <i class="fas fa-trophy"></i>
            <span class="d-none d-lg-inline">Perankingan</span>
        </a>
    </div>
    
    <div class="sidebar-footer d-none d-lg-block">
        <div class="user-info">
            <i class="fas fa-user-circle fa-2x"></i>
            <div>
                <strong><?php echo htmlspecialchars($_SESSION['nama_lengkap'] ?? 'User'); ?></strong>
                <small class="d-block text-white-50"><?php echo htmlspecialchars($_SESSION['role'] ?? 'user'); ?></small>
            </div>
        </div>
        <a href="<?php echo $base; ?>/logout.php" class="btn btn-danger btn-sm w-100" 
           onclick="return confirm('Yakin ingin logout?')">
            <i class="fas fa-sign-out-alt"></i> Logout
        </a>
    </div>
</nav>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Toggle sidebar
    const toggleBtn = document.getElementById('sidebarToggle');
    const sidebar = document.getElementById('sidebar');
    
    if (toggleBtn) {
        toggleBtn.addEventListener('click', function(e) {
            e.preventDefault();
            sidebar.classList.toggle('active');
            document.querySelector('.main-content').classList.toggle('active');
        });
    }
});
</script>