<?php
// ============================================
// FOOTER - SPK SISWA TELADAN AHP
// by jagocode.com
// ============================================
?>
                </div>
            </div>
            
            <!-- ============================================ -->
            <!-- FOOTER -->
            <!-- ============================================ -->
            <footer class="footer">
                <div class="container-fluid">
                    <div class="row align-items-center">
                        <div class="col-md-4">
                            <span>&copy; <?php echo date('Y'); ?> <?php echo APP_NAME; ?></span>
                        </div>
                        <div class="col-md-4 text-center">
                            <span class="text-muted">
                                <i class="fas fa-code"></i> 
                                Developed by 
                                <a href="https://jagocode.com" target="_blank" class="text-decoration-none fw-bold" style="color:#6f42c1;">
                                    JagoCode.com
                                </a>
                            </span>
                        </div>
                        <div class="col-md-4 text-end">
                            <span>
                                <i class="fas fa-version"></i> v1.0
                                <span class="text-muted ms-2">
                                    <i class="fas fa-heart text-danger"></i>
                                </span>
                            </span>
                        </div>
                    </div>
                    <div class="row mt-2">
                        <div class="col-12 text-center">
                            <small class="text-muted">
                                <i class="fas fa-info-circle"></i> 
                                Sistem Pendukung Keputusan Pemilihan Siswa Teladan dengan Metode AHP
                            </small>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>

    <!-- ============================================ -->
    <!-- SCRIPTS -->
    <!-- ============================================ -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
    <script>
    $(document).ready(function(){
        // ==========================================
        // DATATABLE
        // ==========================================
        if($.fn.DataTable){
            $('.table-datatable').DataTable({
                language: {
                    url: "//cdn.datatables.net/plug-ins/1.13.4/i18n/id.json"
                },
                pageLength: 10,
                responsive: true
            });
        }
        
        // ==========================================
        // TOOLTIP
        // ==========================================
        $('[data-bs-toggle="tooltip"]').tooltip();
        
        // ==========================================
        // AUTO HIDE ALERT
        // ==========================================
        setTimeout(function(){
            $('.alert').fadeOut('slow');
        }, 5000);
        
        // ==========================================
        // CONFIRM DELETE
        // ==========================================
        $('.btn-delete').on('click', function(e){
            if(!confirm('Apakah Anda yakin ingin menghapus data ini?')){
                e.preventDefault();
            }
        });
        
        // ==========================================
        // SIDEBAR TOGGLE
        // ==========================================
        $('#sidebarToggle').on('click', function(e){
            e.preventDefault();
            $('#sidebar').toggleClass('active');
            $('.main-content').toggleClass('active');
        });
        
        // ==========================================
        // TAHUN OTOMATIS DI FOOTER
        // ==========================================
        var year = new Date().getFullYear();
        $('.footer-year').text(year);
    });
    </script>
    
    <!-- ============================================ -->
    <!-- KREDENSIAL JAGOCODE.COM -->
    <!-- ============================================ -->
    <style>
        .footer {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            border-top: 3px solid #6f42c1;
            padding: 20px 0;
            margin-top: 30px;
        }
        .footer a:hover {
            color: #6f42c1 !important;
            text-decoration: underline !important;
        }
        .footer .text-muted {
            color: #6c757d !important;
        }
        .footer .fa-heart {
            animation: heartbeat 1.5s ease-in-out infinite;
        }
        @keyframes heartbeat {
            0% { transform: scale(1); }
            50% { transform: scale(1.2); }
            100% { transform: scale(1); }
        }
    </style>
</body>
</html>