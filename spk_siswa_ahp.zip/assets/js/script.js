// ============================================
// SCRIPT JS - SPK SISWA TELADAN AHP
// ============================================

$(document).ready(function() {
    
    // ===== SIDEBAR TOGGLE =====
    $('#sidebarToggle').on('click', function(e) {
        e.preventDefault();
        $('#sidebar').toggleClass('active');
        $('.main-content').toggleClass('active');
    });

    // ===== DATATABLES =====
    if ($.fn.DataTable) {
        $('.table-datatable').DataTable({
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.13.4/i18n/id.json"
            },
            "pageLength": 10,
            "responsive": true
        });
    }

    // ===== TOOLTIP =====
    $('[data-bs-toggle="tooltip"]').tooltip();

    // ===== AUTO HIDE ALERT =====
    setTimeout(function() {
        $('.alert').fadeOut('slow');
    }, 5000);

    // ===== CONFIRM DELETE =====
    $('.btn-delete').on('click', function(e) {
        if (!confirm('Apakah Anda yakin ingin menghapus data ini?')) {
            e.preventDefault();
        }
    });

    // ===== VALIDASI FORM =====
    $('.form-validate').on('submit', function(e) {
        let valid = true;
        $(this).find('input[required], select[required], textarea[required]').each(function() {
            if (!$(this).val()) {
                $(this).addClass('is-invalid');
                valid = false;
            } else {
                $(this).removeClass('is-invalid');
            }
        });
        if (!valid) {
            e.preventDefault();
            alert('Harap lengkapi semua field yang wajib diisi!');
        }
    });

    // ===== PERBANDINGAN KRITERIA =====
    // Auto calculate for pairwise comparison
    $('.pairwise-select').on('change', function() {
        let value = parseFloat($(this).val());
        let id1 = $(this).data('id1');
        let id2 = $(this).data('id2');
        
        if (value && !isNaN(value)) {
            // Inverse value for the opposite comparison
            let inverse = 1 / value;
            let inverseSelect = $(`[data-id1="${id2}"][data-id2="${id1}"]`);
            if (inverseSelect.length) {
                inverseSelect.val(inverse);
            }
        }
    });

    // ===== CHART =====
    window.createChart = function(ctx, type, data, options) {
        return new Chart(ctx, {
            type: type,
            data: data,
            options: options || {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    }
                }
            }
        });
    };

    // ===== EXPORT DATA =====
    window.exportTable = function(tableId, filename) {
        let table = document.getElementById(tableId);
        let html = table.outerHTML;
        let blob = new Blob([html], {type: 'application/vnd.ms-excel'});
        let url = URL.createObjectURL(blob);
        let a = document.createElement('a');
        a.href = url;
        a.download = filename + '.xls';
        a.click();
        URL.revokeObjectURL(url);
    };

    // ===== PRINT =====
    window.printTable = function(elementId) {
        let printContents = document.getElementById(elementId).innerHTML;
        let originalContents = document.body.innerHTML;
        document.body.innerHTML = printContents;
        window.print();
        document.body.innerHTML = originalContents;
        location.reload();
    };

});

// ===== FUNGSI GLOBAL =====
function formatRupiah(angka) {
    let rupiah = '';
    let angkarev = angka.toString().split('').reverse().join('');
    for (let i = 0; i < angkarev.length; i++) {
        if (i % 3 === 0) rupiah += angkarev.substr(i, 3) + '.';
    }
    return 'Rp ' + rupiah.split('', rupiah.length - 1).reverse().join('');
}

function formatNumber(num) {
    return num.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
}

function getStatusBadge(status) {
    let badges = {
        'active': '<span class="badge bg-success">Active</span>',
        'inactive': '<span class="badge bg-secondary">Inactive</span>',
        'pending': '<span class="badge bg-warning">Pending</span>',
        'benefit': '<span class="badge-status badge-benefit">Benefit</span>',
        'cost': '<span class="badge-status badge-cost">Cost</span>'
    };
    return badges[status] || '<span class="badge bg-secondary">' + status + '</span>';
}