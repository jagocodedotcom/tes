-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 29, 2026 at 06:25 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spk_siswa_ahp`
--

-- --------------------------------------------------------

--
-- Table structure for table `alternatif`
--

CREATE TABLE `alternatif` (
  `id_alternatif` int(11) NOT NULL,
  `nis` varchar(20) NOT NULL,
  `nama_siswa` varchar(100) NOT NULL,
  `kelas` varchar(10) NOT NULL,
  `jenis_kelamin` enum('L','P') DEFAULT 'L',
  `alamat` text DEFAULT NULL,
  `no_hp` varchar(15) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `alternatif`
--

INSERT INTO `alternatif` (`id_alternatif`, `nis`, `nama_siswa`, `kelas`, `jenis_kelamin`, `alamat`, `no_hp`, `created_at`, `updated_at`) VALUES
(4, '2024001', 'Ahmad Fauzi', '9A', 'L', 'Jl. Merdeka No.1, Jakarta', '081234567801', '2026-07-29 02:42:22', '2026-07-29 02:42:22'),
(5, '2024002', 'Budi Santoso', '9A', 'L', 'Jl. Sudirman No.2, Jakarta', '081234567802', '2026-07-29 02:42:22', '2026-07-29 02:42:22'),
(6, '2024003', 'Citra Dewi', '9B', 'P', 'Jl. Thamrin No.3, Jakarta', '081234567803', '2026-07-29 02:42:22', '2026-07-29 02:42:22'),
(7, '2024004', 'Dian Purnama', '9B', 'P', 'Jl. Gatot Subroto No.4, Jakarta', '081234567804', '2026-07-29 02:42:22', '2026-07-29 02:42:22'),
(8, '2024005', 'Eko Prasetyo', '9C', 'L', 'Jl. Kuningan No.5, Jakarta', '081234567805', '2026-07-29 02:42:22', '2026-07-29 02:42:22'),
(9, '2024006', 'Fitriani', '9C', 'P', 'Jl. MH Thamrin No.6, Jakarta', '081234567806', '2026-07-29 02:42:22', '2026-07-29 02:42:22'),
(10, '2024007', 'Gilang Ramadhan', '9A', 'L', 'Jl. Rasuna Said No.7, Jakarta', '081234567807', '2026-07-29 02:42:22', '2026-07-29 02:42:22'),
(11, '2024008', 'Hana Kusuma', '9B', 'P', 'Jl. Cikini No.8, Jakarta', '081234567808', '2026-07-29 02:42:22', '2026-07-29 02:42:22'),
(12, '2024009', 'Ikhsan Maulana', '9C', 'L', 'Jl. Menteng No.9, Jakarta', '081234567809', '2026-07-29 02:42:22', '2026-07-29 02:42:22'),
(13, '2024010', 'Jihan Fadhila', '9A', 'P', 'Jl. Kebon Sirih No.10, Jakarta', '081234567810', '2026-07-29 02:42:22', '2026-07-29 02:42:22'),
(14, '2024011', 'Krisna Wijaya', '9B', 'L', 'Jl. Cipete No.11, Jakarta', '081234567811', '2026-07-29 02:42:22', '2026-07-29 02:42:22'),
(15, '2024012', 'Larasati', '9C', 'P', 'Jl. Kemang No.12, Jakarta', '081234567812', '2026-07-29 02:42:22', '2026-07-29 02:42:22'),
(16, '2024013', 'Muhammad Rizki', '9A', 'L', 'Jl. Pasar Minggu No.13, Jakarta', '081234567813', '2026-07-29 02:42:22', '2026-07-29 02:42:22'),
(17, '2024014', 'Nadia Azzahra', '9B', 'P', 'Jl. Tebet No.14, Jakarta', '081234567814', '2026-07-29 02:42:22', '2026-07-29 02:42:22'),
(18, '2024015', 'Omar Hakim', '9C', 'L', 'Jl. Pancoran No.15, Jakarta', '081234567815', '2026-07-29 02:42:22', '2026-07-29 02:42:22'),
(19, '2024016', 'Putri Melati', '9A', 'P', 'Jl. Kunir No.16, Jakarta', '081234567816', '2026-07-29 02:42:22', '2026-07-29 02:42:22'),
(20, '2024017', 'Rafi Ahmad', '9B', 'L', 'Jl. Mangga Besar No.17, Jakarta', '081234567817', '2026-07-29 02:42:22', '2026-07-29 02:42:22'),
(21, '2024018', 'Siti Rahma', '9C', 'P', 'Jl. Pasar Baru No.18, Jakarta', '081234567818', '2026-07-29 02:42:22', '2026-07-29 02:42:22'),
(22, '2024019', 'Taufik Hidayat', '9A', 'L', 'Jl. Senen No.19, Jakarta', '081234567819', '2026-07-29 02:42:22', '2026-07-29 02:42:22'),
(23, '2024020', 'Utami Sari', '9B', 'P', 'Jl. Johar No.20, Jakarta', '081234567820', '2026-07-29 02:42:22', '2026-07-29 02:42:22');

-- --------------------------------------------------------

--
-- Table structure for table `hasil_akhir`
--

CREATE TABLE `hasil_akhir` (
  `id_hasil` int(11) NOT NULL,
  `id_alternatif` int(11) NOT NULL,
  `skor_akhir` float NOT NULL,
  `ranking` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hasil_akhir`
--

INSERT INTO `hasil_akhir` (`id_hasil`, `id_alternatif`, `skor_akhir`, `ranking`, `created_at`, `updated_at`) VALUES
(1, 6, 0.964166, 1, '2026-07-29 02:48:35', '2026-07-29 02:48:35'),
(2, 15, 0.949541, 2, '2026-07-29 02:48:35', '2026-07-29 02:48:35'),
(3, 18, 0.937043, 3, '2026-07-29 02:48:35', '2026-07-29 02:48:35'),
(4, 8, 0.934524, 4, '2026-07-29 02:48:35', '2026-07-29 02:48:35'),
(5, 19, 0.928777, 5, '2026-07-29 02:48:35', '2026-07-29 02:48:35'),
(6, 10, 0.92828, 6, '2026-07-29 02:48:35', '2026-07-29 02:48:35'),
(7, 5, 0.924765, 7, '2026-07-29 02:48:35', '2026-07-29 02:48:35'),
(8, 4, 0.920393, 8, '2026-07-29 02:48:35', '2026-07-29 02:48:35'),
(9, 14, 0.918534, 9, '2026-07-29 02:48:35', '2026-07-29 02:48:35'),
(10, 17, 0.917102, 10, '2026-07-29 02:48:35', '2026-07-29 02:48:35'),
(11, 13, 0.914653, 11, '2026-07-29 02:48:35', '2026-07-29 02:48:35'),
(12, 20, 0.913527, 12, '2026-07-29 02:48:35', '2026-07-29 02:48:35'),
(13, 11, 0.909785, 13, '2026-07-29 02:48:35', '2026-07-29 02:48:35'),
(14, 12, 0.907125, 14, '2026-07-29 02:48:35', '2026-07-29 02:48:35'),
(15, 9, 0.907049, 15, '2026-07-29 02:48:35', '2026-07-29 02:48:35'),
(16, 16, 0.903029, 16, '2026-07-29 02:48:35', '2026-07-29 02:48:35'),
(17, 7, 0.880451, 17, '2026-07-29 02:48:35', '2026-07-29 02:48:35'),
(18, 21, 0, 18, '2026-07-29 02:48:35', '2026-07-29 02:48:35'),
(19, 22, 0, 19, '2026-07-29 02:48:35', '2026-07-29 02:48:35'),
(20, 22, 0, 19, '2026-07-29 02:48:35', '2026-07-29 02:48:35');

-- --------------------------------------------------------

--
-- Table structure for table `kriteria`
--

CREATE TABLE `kriteria` (
  `id_kriteria` int(11) NOT NULL,
  `kode_kriteria` varchar(10) NOT NULL,
  `nama_kriteria` varchar(100) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `bobot` float DEFAULT 0,
  `jenis` varchar(20) DEFAULT 'benefit',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kriteria`
--

INSERT INTO `kriteria` (`id_kriteria`, `kode_kriteria`, `nama_kriteria`, `deskripsi`, `bobot`, `jenis`, `created_at`, `updated_at`) VALUES
(1, 'C1', 'Prestasi Akademik', 'Nilai rata-rata rapor semester', 0.2, 'benefit', '2026-07-29 02:04:29', '2026-07-29 02:48:23'),
(2, 'C2', 'Prestasi Non-Akademik', 'Juara lomba, ekstrakurikuler, dll', 0.2, 'benefit', '2026-07-29 02:04:29', '2026-07-29 02:48:23'),
(3, 'C3', 'Sikap/Perilaku', 'Kedisiplinan, sopan santun, etika', 0.2, 'benefit', '2026-07-29 02:04:29', '2026-07-29 02:48:23'),
(4, 'C4', 'Kehadiran', 'Tingkat kehadiran di sekolah', 0.2, 'benefit', '2026-07-29 02:04:29', '2026-07-29 02:48:23'),
(5, 'C5', 'Keterlibatan Sosial', 'Kegiatan sosial, organisasi', 0.2, 'benefit', '2026-07-29 02:04:29', '2026-07-29 02:48:23');

-- --------------------------------------------------------

--
-- Table structure for table `log_aktivitas`
--

CREATE TABLE `log_aktivitas` (
  `id_log` int(11) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `aktivitas` varchar(255) DEFAULT NULL,
  `deskripsi` text DEFAULT NULL,
  `ip_address` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `matriks_perbandingan`
--

CREATE TABLE `matriks_perbandingan` (
  `id_matriks` int(11) NOT NULL,
  `id_kriteria_1` int(11) NOT NULL,
  `id_kriteria_2` int(11) NOT NULL,
  `nilai` float NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `matriks_perbandingan`
--

INSERT INTO `matriks_perbandingan` (`id_matriks`, `id_kriteria_1`, `id_kriteria_2`, `nilai`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 1, '2026-07-29 02:48:23', '2026-07-29 02:48:23'),
(2, 1, 2, 1, '2026-07-29 02:48:23', '2026-07-29 02:48:23'),
(3, 1, 3, 1, '2026-07-29 02:48:23', '2026-07-29 02:48:23'),
(4, 1, 4, 1, '2026-07-29 02:48:23', '2026-07-29 02:48:23'),
(5, 1, 5, 1, '2026-07-29 02:48:23', '2026-07-29 02:48:23'),
(6, 2, 1, 1, '2026-07-29 02:48:23', '2026-07-29 02:48:23'),
(7, 2, 2, 1, '2026-07-29 02:48:23', '2026-07-29 02:48:23'),
(8, 2, 3, 1, '2026-07-29 02:48:23', '2026-07-29 02:48:23'),
(9, 2, 4, 1, '2026-07-29 02:48:23', '2026-07-29 02:48:23'),
(10, 2, 5, 1, '2026-07-29 02:48:23', '2026-07-29 02:48:23'),
(11, 3, 1, 1, '2026-07-29 02:48:23', '2026-07-29 02:48:23'),
(12, 3, 2, 1, '2026-07-29 02:48:23', '2026-07-29 02:48:23'),
(13, 3, 3, 1, '2026-07-29 02:48:23', '2026-07-29 02:48:23'),
(14, 3, 4, 1, '2026-07-29 02:48:23', '2026-07-29 02:48:23'),
(15, 3, 5, 1, '2026-07-29 02:48:23', '2026-07-29 02:48:23'),
(16, 4, 1, 1, '2026-07-29 02:48:23', '2026-07-29 02:48:23'),
(17, 4, 2, 1, '2026-07-29 02:48:23', '2026-07-29 02:48:23'),
(18, 4, 3, 1, '2026-07-29 02:48:23', '2026-07-29 02:48:23'),
(19, 4, 4, 1, '2026-07-29 02:48:23', '2026-07-29 02:48:23'),
(20, 4, 5, 1, '2026-07-29 02:48:23', '2026-07-29 02:48:23'),
(21, 5, 1, 1, '2026-07-29 02:48:23', '2026-07-29 02:48:23'),
(22, 5, 2, 1, '2026-07-29 02:48:23', '2026-07-29 02:48:23'),
(23, 5, 3, 1, '2026-07-29 02:48:23', '2026-07-29 02:48:23'),
(24, 5, 4, 1, '2026-07-29 02:48:23', '2026-07-29 02:48:23'),
(25, 5, 5, 1, '2026-07-29 02:48:23', '2026-07-29 02:48:23');

-- --------------------------------------------------------

--
-- Table structure for table `nilai_alternatif`
--

CREATE TABLE `nilai_alternatif` (
  `id_nilai` int(11) NOT NULL,
  `id_alternatif` int(11) NOT NULL,
  `id_kriteria` int(11) NOT NULL,
  `nilai` float NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `nilai_alternatif`
--

INSERT INTO `nilai_alternatif` (`id_nilai`, `id_alternatif`, `id_kriteria`, `nilai`, `created_at`, `updated_at`) VALUES
(1, 4, 1, 85, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(2, 5, 1, 90, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(3, 6, 1, 87, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(4, 7, 1, 93, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(5, 8, 1, 82, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(6, 9, 1, 91, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(7, 10, 1, 89, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(8, 11, 1, 86, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(9, 12, 1, 94, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(10, 13, 1, 81, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(11, 14, 1, 88, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(12, 15, 1, 92, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(13, 16, 1, 84, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(14, 17, 1, 90, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(15, 18, 1, 87, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(16, 19, 1, 93, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(17, 20, 1, 86, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(21, 4, 2, 92, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(22, 5, 2, 88, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(23, 6, 2, 95, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(24, 7, 2, 75, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(25, 8, 2, 86, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(26, 9, 2, 91, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(27, 10, 2, 84, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(28, 11, 2, 89, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(29, 12, 2, 78, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(30, 13, 2, 93, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(31, 14, 2, 85, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(32, 15, 2, 90, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(33, 16, 2, 82, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(34, 17, 2, 88, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(35, 18, 2, 94, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(36, 19, 2, 80, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(37, 20, 2, 87, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(41, 4, 3, 92, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(42, 5, 3, 80, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(43, 6, 3, 95, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(44, 7, 3, 87, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(45, 8, 3, 90, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(46, 9, 3, 83, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(47, 10, 3, 91, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(48, 11, 3, 86, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(49, 12, 3, 89, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(50, 13, 3, 92, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(51, 14, 3, 84, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(52, 15, 3, 88, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(53, 16, 3, 90, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(54, 17, 3, 85, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(55, 18, 3, 93, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(56, 19, 3, 87, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(57, 20, 3, 91, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(61, 4, 4, 98, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(62, 5, 4, 88, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(63, 6, 4, 92, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(64, 7, 4, 80, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(65, 8, 4, 95, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(66, 9, 4, 87, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(67, 10, 4, 91, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(68, 11, 4, 84, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(69, 12, 4, 89, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(70, 13, 4, 93, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(71, 14, 4, 86, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(72, 15, 4, 92, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(73, 16, 4, 88, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(74, 17, 4, 94, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(75, 18, 4, 85, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(76, 19, 4, 90, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(77, 20, 4, 87, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(81, 4, 5, 70, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(82, 5, 5, 92, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(83, 6, 5, 88, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(84, 7, 5, 82, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(85, 8, 5, 90, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(86, 9, 5, 78, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(87, 10, 5, 85, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(88, 11, 5, 86, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(89, 12, 5, 80, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(90, 13, 5, 75, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(91, 14, 5, 92, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(92, 15, 5, 88, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(93, 16, 5, 84, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(94, 17, 5, 78, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(95, 18, 5, 85, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(96, 19, 5, 90, '2026-07-29 02:43:40', '2026-07-29 02:43:40'),
(97, 20, 5, 82, '2026-07-29 02:43:40', '2026-07-29 02:43:40');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `role` enum('admin','pakar','user') DEFAULT 'user',
  `foto` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_user`, `username`, `password`, `nama_lengkap`, `email`, `role`, `foto`, `created_at`, `updated_at`) VALUES
(1, 'admin', '$2y$10$EZDpVgOZUd8rR/GGJgU66O2pxdYpSdzvUEh1q1CHwI.NDVSO5rXIm', 'Administrator', 'admin@spk.com', 'admin', NULL, '2026-07-29 02:22:30', '2026-07-29 02:22:30'),
(2, 'pakar1', '$2y$10$EZDpVgOZUd8rR/GGJgU66O2pxdYpSdzvUEh1q1CHwI.NDVSO5rXIm', 'Guru Pakar', 'pakar@spk.com', 'pakar', NULL, '2026-07-29 02:22:30', '2026-07-29 02:22:30'),
(3, 'user1', '$2y$10$EZDpVgOZUd8rR/GGJgU66O2pxdYpSdzvUEh1q1CHwI.NDVSO5rXIm', 'User Biasa', 'user@spk.com', 'user', NULL, '2026-07-29 02:22:30', '2026-07-29 02:22:30');

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_dashboard`
-- (See below for the actual view)
--
CREATE TABLE `v_dashboard` (
`total_siswa` bigint(21)
,`total_kriteria` bigint(21)
,`total_user` bigint(21)
,`sudah_dinilai` bigint(21)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_hasil_perankingan`
-- (See below for the actual view)
--
CREATE TABLE `v_hasil_perankingan` (
`id_alternatif` int(11)
,`nis` varchar(20)
,`nama_siswa` varchar(100)
,`kelas` varchar(10)
,`skor_akhir` float
,`ranking` int(11)
,`tanggal_penilaian` timestamp
);

-- --------------------------------------------------------

--
-- Structure for view `v_dashboard`
--
DROP TABLE IF EXISTS `v_dashboard`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_dashboard`  AS SELECT (select count(0) from `alternatif`) AS `total_siswa`, (select count(0) from `kriteria`) AS `total_kriteria`, (select count(0) from `users`) AS `total_user`, (select count(0) from `hasil_akhir` where `hasil_akhir`.`ranking` = 1) AS `sudah_dinilai` ;

-- --------------------------------------------------------

--
-- Structure for view `v_hasil_perankingan`
--
DROP TABLE IF EXISTS `v_hasil_perankingan`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_hasil_perankingan`  AS SELECT `a`.`id_alternatif` AS `id_alternatif`, `a`.`nis` AS `nis`, `a`.`nama_siswa` AS `nama_siswa`, `a`.`kelas` AS `kelas`, `h`.`skor_akhir` AS `skor_akhir`, `h`.`ranking` AS `ranking`, `h`.`created_at` AS `tanggal_penilaian` FROM (`alternatif` `a` left join `hasil_akhir` `h` on(`a`.`id_alternatif` = `h`.`id_alternatif`)) WHERE `h`.`ranking` is not null ORDER BY `h`.`ranking` ASC ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alternatif`
--
ALTER TABLE `alternatif`
  ADD PRIMARY KEY (`id_alternatif`),
  ADD UNIQUE KEY `nis` (`nis`);

--
-- Indexes for table `hasil_akhir`
--
ALTER TABLE `hasil_akhir`
  ADD PRIMARY KEY (`id_hasil`),
  ADD KEY `id_alternatif` (`id_alternatif`);

--
-- Indexes for table `kriteria`
--
ALTER TABLE `kriteria`
  ADD PRIMARY KEY (`id_kriteria`),
  ADD UNIQUE KEY `kode_kriteria` (`kode_kriteria`);

--
-- Indexes for table `log_aktivitas`
--
ALTER TABLE `log_aktivitas`
  ADD PRIMARY KEY (`id_log`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `matriks_perbandingan`
--
ALTER TABLE `matriks_perbandingan`
  ADD PRIMARY KEY (`id_matriks`),
  ADD UNIQUE KEY `unique_pairwise` (`id_kriteria_1`,`id_kriteria_2`),
  ADD KEY `id_kriteria_2` (`id_kriteria_2`);

--
-- Indexes for table `nilai_alternatif`
--
ALTER TABLE `nilai_alternatif`
  ADD PRIMARY KEY (`id_nilai`),
  ADD UNIQUE KEY `unique_penilaian` (`id_alternatif`,`id_kriteria`),
  ADD KEY `id_kriteria` (`id_kriteria`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alternatif`
--
ALTER TABLE `alternatif`
  MODIFY `id_alternatif` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `hasil_akhir`
--
ALTER TABLE `hasil_akhir`
  MODIFY `id_hasil` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `kriteria`
--
ALTER TABLE `kriteria`
  MODIFY `id_kriteria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `log_aktivitas`
--
ALTER TABLE `log_aktivitas`
  MODIFY `id_log` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `matriks_perbandingan`
--
ALTER TABLE `matriks_perbandingan`
  MODIFY `id_matriks` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `nilai_alternatif`
--
ALTER TABLE `nilai_alternatif`
  MODIFY `id_nilai` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `hasil_akhir`
--
ALTER TABLE `hasil_akhir`
  ADD CONSTRAINT `hasil_akhir_ibfk_1` FOREIGN KEY (`id_alternatif`) REFERENCES `alternatif` (`id_alternatif`) ON DELETE CASCADE;

--
-- Constraints for table `log_aktivitas`
--
ALTER TABLE `log_aktivitas`
  ADD CONSTRAINT `log_aktivitas_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`) ON DELETE SET NULL;

--
-- Constraints for table `matriks_perbandingan`
--
ALTER TABLE `matriks_perbandingan`
  ADD CONSTRAINT `matriks_perbandingan_ibfk_1` FOREIGN KEY (`id_kriteria_1`) REFERENCES `kriteria` (`id_kriteria`) ON DELETE CASCADE,
  ADD CONSTRAINT `matriks_perbandingan_ibfk_2` FOREIGN KEY (`id_kriteria_2`) REFERENCES `kriteria` (`id_kriteria`) ON DELETE CASCADE;

--
-- Constraints for table `nilai_alternatif`
--
ALTER TABLE `nilai_alternatif`
  ADD CONSTRAINT `nilai_alternatif_ibfk_1` FOREIGN KEY (`id_alternatif`) REFERENCES `alternatif` (`id_alternatif`) ON DELETE CASCADE,
  ADD CONSTRAINT `nilai_alternatif_ibfk_2` FOREIGN KEY (`id_kriteria`) REFERENCES `kriteria` (`id_kriteria`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
