<?php
// ============================================
// RESET PASSWORD - SPK SISWA TELADAN AHP
// ============================================

require_once 'config/database.php';

// Password baru: 12345678
$password_baru = '12345678';
$hash = password_hash($password_baru, PASSWORD_DEFAULT);

echo "<h3>Reset Password User</h3>";
echo "<hr>";

// ============================================
// 1. Hapus data terkait terlebih dahulu
// ============================================

// Hapus log aktivitas terlebih dahulu (karena foreign key)
$db->query("TRUNCATE TABLE log_aktivitas");
echo "✅ Tabel log_aktivitas dikosongkan<br>";

// Hapus hasil_akhir
$db->query("TRUNCATE TABLE hasil_akhir");
echo "✅ Tabel hasil_akhir dikosongkan<br>";

// Hapus matriks_perbandingan
$db->query("TRUNCATE TABLE matriks_perbandingan");
echo "✅ Tabel matriks_perbandingan dikosongkan<br>";

// Hapus nilai_alternatif
$db->query("TRUNCATE TABLE nilai_alternatif");
echo "✅ Tabel nilai_alternatif dikosongkan<br>";

// Hapus data di alternatif (opsional - jika ingin reset semua)
// $db->query("TRUNCATE TABLE alternatif");
// echo "✅ Tabel alternatif dikosongkan<br>";

// Hapus data di kriteria (opsional - jika ingin reset semua)
// $db->query("TRUNCATE TABLE kriteria");
// echo "✅ Tabel kriteria dikosongkan<br>";

// ============================================
// 2. Reset users dengan cara DELETE (bukan TRUNCATE)
// ============================================

// Hapus semua user (menggunakan DELETE karena TRUNCATE tidak bisa karena foreign key)
$db->query("DELETE FROM users");
echo "✅ Tabel users dikosongkan<br>";

// Reset auto increment
$db->query("ALTER TABLE users AUTO_INCREMENT = 1");
echo "✅ Auto increment users direset<br>";

// ============================================
// 3. Buat user baru
// ============================================

$sql = "INSERT INTO users (username, password, nama_lengkap, email, role) VALUES
('admin', '$hash', 'Administrator', 'admin@spk.com', 'admin'),
('pakar1', '$hash', 'Guru Pakar', 'pakar@spk.com', 'pakar'),
('user1', '$hash', 'User Biasa', 'user@spk.com', 'user')";

if ($db->query($sql)) {
    echo "✅ User berhasil dibuat!<br>";
    echo "<hr>";
    echo "<h4>Akun Baru:</h4>";
    echo "<table border='1' cellpadding='8' style='border-collapse: collapse;'>";
    echo "<tr style='background:#2c3e7a;color:white;'>";
    echo "<th>Username</th><th>Password</th><th>Role</th></tr>";
    echo "<tr><td>admin</td><td>12345678</td><td>Admin</td></tr>";
    echo "<tr><td>pakar1</td><td>12345678</td><td>Pakar</td></tr>";
    echo "<tr><td>user1</td><td>12345678</td><td>User</td></tr>";
    echo "</table>";
    echo "<hr>";
    echo "<a href='login.php' style='display:inline-block;padding:10px 20px;background:#2c3e7a;color:white;text-decoration:none;border-radius:8px;'>Login Sekarang</a>";
} else {
    echo "❌ Gagal membuat user: " . $db->error . "<br>";
}
?>