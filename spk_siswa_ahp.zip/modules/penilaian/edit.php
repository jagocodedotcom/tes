<?php
require_once '../../config/database.php';
session_start();
include '../../includes/header.php';

// Cek ID
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$data = getRow("SELECT * FROM nilai_alternatif WHERE id_nilai = $id");

if (!$data) {
    $_SESSION['flash_message'] = 'Data penilaian tidak ditemukan!';
    $_SESSION['flash_type'] = 'danger';
    $_SESSION['flash_icon'] = 'exclamation-circle';
    header('Location: index.php');
    exit;
}

// Ambil data untuk dropdown
$kriteria = getAll("SELECT * FROM kriteria ORDER BY id_kriteria ASC");
$siswa = getAll("SELECT * FROM alternatif ORDER BY nama_siswa ASC");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_siswa = (int)$_POST['id_alternatif'];
    $id_kriteria = (int)$_POST['id_kriteria'];
    $nilai = (float)$_POST['nilai'];
    
    // Cek apakah sudah ada penilaian untuk siswa dan kriteria ini (kecuali dirinya sendiri)
    $check = getRow("SELECT id_nilai FROM nilai_alternatif 
                     WHERE id_alternatif = $id_siswa AND id_kriteria = $id_kriteria 
                     AND id_nilai != $id");
    
    if ($check) {
        $_SESSION['flash_message'] = 'Penilaian untuk siswa dan kriteria ini sudah ada!';
        $_SESSION['flash_type'] = 'danger';
        $_SESSION['flash_icon'] = 'exclamation-circle';
    } else {
        $sql = "UPDATE nilai_alternatif SET 
                id_alternatif = $id_siswa,
                id_kriteria = $id_kriteria,
                nilai = $nilai
                WHERE id_nilai = $id";
        
        if (updateData($sql)) {
            $_SESSION['flash_message'] = 'Penilaian berhasil diupdate!';
            $_SESSION['flash_type'] = 'success';
            $_SESSION['flash_icon'] = 'check-circle';
            header('Location: index.php');
            exit;
        } else {
            $_SESSION['flash_message'] = 'Gagal mengupdate penilaian!';
            $_SESSION['flash_type'] = 'danger';
            $_SESSION['flash_icon'] = 'exclamation-circle';
        }
    }
}
?>
<div class="fade-in">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold text-primary mb-0">
                <i class="fas fa-edit"></i> Edit Penilaian
            </h4>
            <small class="text-muted">Edit nilai siswa untuk kriteria tertentu</small>
        </div>
        <a href="index.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Kembali
        </a>
    </div>

    <div class="card">
        <div class="card-body">
            <form method="POST" class="form-validate">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Siswa <span class="text-danger">*</span></label>
                            <select name="id_alternatif" class="form-select" required>
                                <option value="">-- Pilih Siswa --</option>
                                <?php foreach ($siswa as $row): ?>
                                <option value="<?php echo $row['id_alternatif']; ?>" 
                                    <?php echo $row['id_alternatif'] == $data['id_alternatif'] ? 'selected' : ''; ?>>
                                    <?php echo $row['nis'] . ' - ' . $row['nama_siswa']; ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Kriteria <span class="text-danger">*</span></label>
                            <select name="id_kriteria" class="form-select" required>
                                <option value="">-- Pilih Kriteria --</option>
                                <?php foreach ($kriteria as $row): ?>
                                <option value="<?php echo $row['id_kriteria']; ?>"
                                    <?php echo $row['id_kriteria'] == $data['id_kriteria'] ? 'selected' : ''; ?>>
                                    <?php echo $row['kode_kriteria'] . ' - ' . $row['nama_kriteria']; ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Nilai <span class="text-danger">*</span></label>
                            <input type="number" name="nilai" class="form-control" 
                                   step="0.01" min="0" max="100" 
                                   value="<?php echo $data['nilai']; ?>" required>
                            <small class="text-muted">Masukkan nilai antara 0 - 100</small>
                        </div>
                    </div>
                </div>
                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Update
                    </button>
                    <a href="index.php" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Batal
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php include '../../includes/footer.php'; ?>