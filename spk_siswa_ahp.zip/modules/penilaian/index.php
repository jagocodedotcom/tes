<?php
require_once '../../config/database.php';
session_start();
if(!isset($_SESSION['user_id'])){header('Location: ../../login.php');exit;}
if(isset($_GET['action'])&&$_GET['action']=='delete'&&isset($_GET['id'])){
$id=(int)$_GET['id'];
$sql="DELETE FROM nilai_alternatif WHERE id_nilai=$id";
if(deleteData($sql)){$_SESSION['flash_message']='Penilaian berhasil dihapus!';$_SESSION['flash_type']='success';$_SESSION['flash_icon']='check-circle';}
else{$_SESSION['flash_message']='Gagal menghapus penilaian!';$_SESSION['flash_type']='danger';$_SESSION['flash_icon']='exclamation-circle';}
header('Location: index.php');exit;
}
include '../../includes/header.php';
$penilaian=getAll("SELECT n.*,a.nama_siswa,a.nis,k.nama_kriteria,k.kode_kriteria FROM nilai_alternatif n JOIN alternatif a ON n.id_alternatif=a.id_alternatif JOIN kriteria k ON n.id_kriteria=k.id_kriteria ORDER BY n.id_alternatif,n.id_kriteria");
?>
<div class="fade-in">
<div class="d-flex justify-content-between align-items-center mb-4">
<div><h4 class="fw-bold text-primary mb-0"><i class="fas fa-edit"></i> Input Penilaian</h4><small class="text-muted">Input nilai siswa untuk setiap kriteria</small></div>
<a href="tambah.php" class="btn btn-primary"><i class="fas fa-plus"></i> Tambah Penilaian</a>
</div>
<div class="table-container">
<div class="table-responsive">
<table class="table table-datatable table-hover" id="tablePenilaian">
<thead><tr><th width="50">No</th><th>NIS</th><th>Nama Siswa</th><th>Kriteria</th><th>Nilai</th><th width="100">Aksi</th></tr></thead>
<tbody><?php $no=1;foreach($penilaian as $row): ?>
<tr><td><?php echo $no++; ?></td><td><strong><?php echo htmlspecialchars($row['nis']); ?></strong></td><td><?php echo htmlspecialchars($row['nama_siswa']); ?></td><td><?php echo htmlspecialchars($row['kode_kriteria'].' - '.$row['nama_kriteria']); ?></td><td><?php echo number_format($row['nilai'],2); ?></td>
<td><a href="?action=delete&id=<?php echo $row['id_nilai']; ?>" class="btn btn-danger btn-sm btn-delete"><i class="fas fa-trash"></i></a></td></tr>
<?php endforeach; ?></tbody>
</table>
</div>
</div>
</div>
<script>$(document).ready(function(){$('#tablePenilaian').DataTable({language:{url:"//cdn.datatables.net/plug-ins/1.13.4/i18n/id.json"},pageLength:10});});</script>
<?php include '../../includes/footer.php'; ?>