<?php
require_once '../../config/database.php';
session_start();

// Cek apakah ada ID
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['flash_message'] = 'ID penilaian tidak ditemukan!';
    $_SESSION['flash_type'] = 'danger';
    $_SESSION['flash_icon'] = 'exclamation-circle';
    header('Location: index.php');
    exit;
}

$id = (int)$_GET['id'];

// Hapus penilaian
$sql = "DELETE FROM nilai_alternatif WHERE id_nilai = $id";
if (deleteData($sql)) {
    $_SESSION['flash_message'] = 'Penilaian berhasil dihapus!';
    $_SESSION['flash_type'] = 'success';
    $_SESSION['flash_icon'] = 'check-circle';
} else {
    $_SESSION['flash_message'] = 'Gagal menghapus penilaian!';
    $_SESSION['flash_type'] = 'danger';
    $_SESSION['flash_icon'] = 'exclamation-circle';
}

header('Location: index.php');
exit;
?>