<?php
require_once '../../config/database.php';
session_start();
if(!isset($_SESSION['user_id'])){header('Location: ../../login.php');exit;}
$kriteria=getAll("SELECT * FROM kriteria ORDER BY id_kriteria ASC");
$siswa=getAll("SELECT * FROM alternatif ORDER BY nama_siswa ASC");
if($_SERVER['REQUEST_METHOD']=='POST'){
$id_siswa=(int)$_POST['id_alternatif'];
$id_kriteria=(int)$_POST['id_kriteria'];
$nilai=(float)$_POST['nilai'];
$check=getRow("SELECT id_nilai FROM nilai_alternatif WHERE id_alternatif=$id_siswa AND id_kriteria=$id_kriteria");
if($check){$_SESSION['flash_message']='Penilaian untuk siswa dan kriteria ini sudah ada!';$_SESSION['flash_type']='danger';$_SESSION['flash_icon']='exclamation-circle';}
else{
$sql="INSERT INTO nilai_alternatif (id_alternatif,id_kriteria,nilai) VALUES ($id_siswa,$id_kriteria,$nilai)";
if(insertData($sql)){$_SESSION['flash_message']='Penilaian berhasil ditambahkan!';$_SESSION['flash_type']='success';$_SESSION['flash_icon']='check-circle';header('Location: index.php');exit;}
else{$_SESSION['flash_message']='Gagal menambahkan penilaian!';$_SESSION['flash_type']='danger';$_SESSION['flash_icon']='exclamation-circle';}
}
}
include '../../includes/header.php';
?>
<div class="fade-in">
<div class="d-flex justify-content-between align-items-center mb-4">
<div><h4 class="fw-bold text-primary mb-0"><i class="fas fa-plus-circle"></i> Tambah Penilaian</h4><small class="text-muted">Input nilai siswa untuk kriteria tertentu</small></div>
<a href="index.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Kembali</a>
</div>
<div class="card"><div class="card-body">
<form method="POST">
<div class="row">
<div class="col-md-6"><div class="mb-3"><label class="form-label fw-bold">Siswa <span class="text-danger">*</span></label>
<select name="id_alternatif" class="form-select" required><option value="">-- Pilih Siswa --</option>
<?php foreach($siswa as $row): ?><option value="<?php echo $row['id_alternatif']; ?>"><?php echo $row['nis'].' - '.$row['nama_siswa']; ?></option><?php endforeach; ?>
</select></div></div>
<div class="col-md-6"><div class="mb-3"><label class="form-label fw-bold">Kriteria <span class="text-danger">*</span></label>
<select name="id_kriteria" class="form-select" required><option value="">-- Pilih Kriteria --</option>
<?php foreach($kriteria as $row): ?><option value="<?php echo $row['id_kriteria']; ?>"><?php echo $row['kode_kriteria'].' - '.$row['nama_kriteria']; ?></option><?php endforeach; ?>
</select></div></div>
<div class="col-md-6"><div class="mb-3"><label class="form-label fw-bold">Nilai <span class="text-danger">*</span></label>
<input type="number" name="nilai" class="form-control" step="0.01" min="0" max="100" placeholder="0 - 100" required>
<small class="text-muted">Masukkan nilai antara 0 - 100</small></div></div>
</div>
<div class="d-flex gap-2">
<button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Simpan</button>
<a href="index.php" class="btn btn-secondary"><i class="fas fa-times"></i> Batal</a>
</div>
</form>
</div></div>
</div>
<?php include '../../includes/footer.php'; ?>