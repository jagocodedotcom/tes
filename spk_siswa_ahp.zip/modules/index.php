<?php
require_once '../../config/database.php';
session_start();
include '../../includes/header.php';

// ============================================
// PROSES PERHITUNGAN RANKING
// ============================================

function hitungRanking() {
    global $db;
    
    // 1. Ambil bobot kriteria
    $kriteria = getAll("SELECT id_kriteria, bobot FROM kriteria WHERE bobot > 0 ORDER BY id_kriteria");
    if (empty($kriteria)) {
        return ['error' => 'Bobot kriteria belum dihitung. Lakukan perbandingan kriteria terlebih dahulu!'];
    }
    
    // 2. Ambil nilai alternatif
    $siswa = getAll("SELECT * FROM alternatif ORDER BY id_alternatif");
    if (empty($siswa)) {
        return ['error' => 'Tidak ada data siswa!'];
    }
    
    // 3. Hitung skor untuk setiap siswa
    $hasil = [];
    foreach ($siswa as $s) {
        $total = 0;
        $nilai_detail = [];
        foreach ($kriteria as $k) {
            $nilai = getRow("SELECT nilai FROM nilai_alternatif 
                            WHERE id_alternatif = {$s['id_alternatif']} 
                            AND id_kriteria = {$k['id_kriteria']}");
            $nilai_val = $nilai ? (float)$nilai['nilai'] : 0;
            
            // Normalisasi nilai (0-1)
            $max_nilai = getRow("SELECT MAX(nilai) as max FROM nilai_alternatif 
                                WHERE id_kriteria = {$k['id_kriteria']}");
            $max_val = $max_nilai ? (float)$max_nilai['max'] : 1;
            $nilai_normal = ($max_val > 0) ? $nilai_val / $max_val : 0;
            
            $total += $k['bobot'] * $nilai_normal;
            $nilai_detail[] = [
                'id_kriteria' => $k['id_kriteria'],
                'nilai' => $nilai_val,
                'normal' => $nilai_normal,
                'bobot' => $k['bobot']
            ];
        }
        $hasil[] = [
            'id_alternatif' => $s['id_alternatif'],
            'nis' => $s['nis'],
            'nama_siswa' => $s['nama_siswa'],
            'kelas' => $s['kelas'],
            'skor' => $total,
            'detail' => $nilai_detail
        ];
    }
    
    // 4. Urutkan berdasarkan skor tertinggi
    usort($hasil, function($a, $b) {
        return $b['skor'] <=> $a['skor'];
    });
    
    // 5. Beri ranking
    foreach ($hasil as $i => &$h) {
        $h['ranking'] = $i + 1;
    }
    
    // 6. Simpan ke tabel hasil_akhir
    $db->query("TRUNCATE TABLE hasil_akhir");
    foreach ($hasil as $h) {
        $sql = "INSERT INTO hasil_akhir (id_alternatif, skor_akhir, ranking) 
                VALUES ({$h['id_alternatif']}, {$h['skor']}, {$h['ranking']})";
        $db->query($sql);
    }
    
    return ['success' => true, 'hasil' => $hasil];
}

// Proses hitung ranking
if (isset($_GET['action']) && $_GET['action'] == 'hitung') {
    $result = hitungRanking();
    if (isset($result['error'])) {
        $_SESSION['flash_message'] = $result['error'];
        $_SESSION['flash_type'] = 'danger';
        $_SESSION['flash_icon'] = 'exclamation-circle';
    } else {
        $_SESSION['flash_message'] = 'Perhitungan ranking berhasil dilakukan!';
        $_SESSION['flash_type'] = 'success';
        $_SESSION['flash_icon'] = 'check-circle';
    }
    header('Location: index.php');
    exit;
}

// Ambil hasil
$hasil = getAll("SELECT * FROM v_hasil_perankingan ORDER BY ranking ASC");
$total = count($hasil);
$kriteria = getAll("SELECT * FROM kriteria ORDER BY id_kriteria");
$bobot_kriteria = getAll("SELECT kode_kriteria, nama_kriteria, bobot FROM kriteria WHERE bobot > 0 ORDER BY id_kriteria");
?>
<div class="fade-in">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold text-primary mb-0">
                <i class="fas fa-trophy"></i> Hasil Perankingan
            </h4>
            <small class="text-muted">Hasil akhir pemilihan siswa teladan menggunakan AHP</small>
        </div>
        <div>
            <a href="?action=hitung" class="btn btn-primary me-2">
                <i class="fas fa-calculator"></i> Hitung Ranking
            </a>
            <a href="javascript:void(0)" class="btn btn-success" onclick="exportTable('tableHasil', 'perankingan_siswa')">
                <i class="fas fa-file-excel"></i> Export Excel
            </a>
        </div>
    </div>

    <!-- Bobot Kriteria -->
    <div class="card mb-4">
        <div class="card-header bg-light">
            <h6 class="fw-bold mb-0"><i class="fas fa-list"></i> Bobot Kriteria</h6>
        </div>
        <div class="card-body">
            <div class="row">
                <?php foreach ($bobot_kriteria as $k): ?>
                <div class="col-md-3 col-6">
                    <div class="text-center p-2">
                        <div class="fw-bold"><?php echo $k['kode_kriteria']; ?></div>
                        <div class="text-muted small"><?php echo $k['nama_kriteria']; ?></div>
                        <div class="progress mt-1" style="height: 20px;">
                            <div class="progress-bar bg-primary" style="width: <?php echo ($k['bobot'] * 100); ?>%;">
                                <?php echo number_format($k['bobot'] * 100, 2); ?>%
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- Hasil Ranking -->
    <div class="table-container" id="tableHasil">
        <div class="table-responsive">
            <table class="table table-hover" id="tableRanking">
                <thead>
                    <tr>
                        <th width="50">Rank</th>
                        <th>NIS</th>
                        <th>Nama Siswa</th>
                        <th>Kelas</th>
                        <th>Skor Akhir</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($hasil)): ?>
                    <tr>
                        <td colspan="6" class="text-center text-muted py-4">
                            <i class="fas fa-info-circle fa-2x d-block mb-2"></i>
                            <p>Belum ada data ranking. Klik tombol "Hitung Ranking" untuk memproses.</p>
                        </td>
                    </tr>
                    <?php else: ?>
                    <?php foreach ($hasil as $row): ?>
                    <tr>
                        <td>
                            <?php if ($row['ranking'] == 1): ?>
                                <span class="badge bg-warning text-dark" style="font-size: 16px;">🥇</span>
                            <?php elseif ($row['ranking'] == 2): ?>
                                <span class="badge bg-secondary" style="font-size: 16px;">🥈</span>
                            <?php elseif ($row['ranking'] == 3): ?>
                                <span class="badge bg-danger" style="font-size: 16px;">🥉</span>
                            <?php else: ?>
                                <span class="badge bg-light text-dark">#<?php echo $row['ranking']; ?></span>
                            <?php endif; ?>
                        </td>
                        <td><strong><?php echo $row['nis']; ?></strong></td>
                        <td><?php echo $row['nama_siswa']; ?></td>
                        <td><?php echo $row['kelas']; ?></td>
                        <td>
                            <div class="d-flex align-items-center">
                                <div class="progress flex-grow-1 me-2" style="height: 8px;">
                                    <div class="progress-bar bg-primary" style="width: <?php echo ($row['skor_akhir'] / ($hasil[0]['skor_akhir'] ?? 1)) * 100; ?>%;"></div>
                                </div>
                                <span class="fw-bold"><?php echo number_format($row['skor_akhir'], 4); ?></span>
                            </div>
                        </td>
                        <td>
                            <?php if ($row['ranking'] == 1): ?>
                                <span class="badge bg-success">🏆 Siswa Teladan</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">Alternatif</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Chart Hasil -->
    <?php if (!empty($hasil)): ?>
    <div class="card mt-4">
        <div class="card-header bg-light">
            <h6 class="fw-bold mb-0"><i class="fas fa-chart-bar"></i> Grafik Perbandingan Skor</h6>
        </div>
        <div class="card-body">
            <canvas id="chartHasil" height="300"></canvas>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const ctx = document.getElementById('chartHasil').getContext('2d');
        const labels = <?php echo json_encode(array_column($hasil, 'nama_siswa')); ?>;
        const data = <?php echo json_encode(array_column($hasil, 'skor_akhir')); ?>;
        const colors = data.map((v, i) => i === 0 ? '#f8b739' : '#2c3e7a');
        
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Skor Akhir',
                    data: data,
                    backgroundColor: colors,
                    borderColor: colors.map(c => c),
                    borderWidth: 2,
                    borderRadius: 8
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return 'Skor: ' + context.parsed.y.toFixed(4);
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return value.toFixed(2);
                            }
                        }
                    }
                }
            }
        });
    });
    </script>
    <?php endif; ?>
</div>

<?php include '../../includes/footer.php'; ?>