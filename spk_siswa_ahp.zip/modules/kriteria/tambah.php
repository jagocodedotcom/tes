<?php
// ============================================
// TAMBAH KRITERIA - SPK SISWA TELADAN AHP
// ============================================

require_once '../../config/database.php';
session_start();

// Cek login
if (!isset($_SESSION['user_id'])) {
    header('Location: ../../login.php');
    exit;
}

// Proses Tambah
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $kode = escape($_POST['kode_kriteria']);
    $nama = escape($_POST['nama_kriteria']);
    $deskripsi = escape($_POST['deskripsi'] ?? '');
    $jenis = escape($_POST['jenis']);
    
    // Cek kode sudah ada
    $check = getRow("SELECT id_kriteria FROM kriteria WHERE kode_kriteria = '$kode'");
    if ($check) {
        $_SESSION['flash_message'] = 'Kode kriteria sudah digunakan!';
        $_SESSION['flash_type'] = 'danger';
        $_SESSION['flash_icon'] = 'exclamation-circle';
    } else {
        $sql = "INSERT INTO kriteria (kode_kriteria, nama_kriteria, deskripsi, jenis) 
                VALUES ('$kode', '$nama', '$deskripsi', '$jenis')";
        
        if (insertData($sql)) {
            $_SESSION['flash_message'] = 'Kriteria berhasil ditambahkan!';
            $_SESSION['flash_type'] = 'success';
            $_SESSION['flash_icon'] = 'check-circle';
            header('Location: index.php');
            exit;
        } else {
            $_SESSION['flash_message'] = 'Gagal menambahkan kriteria!';
            $_SESSION['flash_type'] = 'danger';
            $_SESSION['flash_icon'] = 'exclamation-circle';
        }
    }
}

include '../../includes/header.php';
?>
<div class="fade-in">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold text-primary mb-0">
                <i class="fas fa-plus-circle"></i> Tambah Kriteria
            </h4>
            <small class="text-muted">Tambahkan kriteria baru untuk penilaian</small>
        </div>
        <a href="index.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Kembali
        </a>
    </div>

    <div class="card">
        <div class="card-body">
            <form method="POST">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Kode Kriteria <span class="text-danger">*</span></label>
                            <input type="text" name="kode_kriteria" class="form-control" 
                                   placeholder="Contoh: C1, C2, ..." required>
                            <small class="text-muted">Kode harus unik, contoh: C1, C2, C3</small>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Jenis <span class="text-danger">*</span></label>
                            <select name="jenis" class="form-select" required>
                                <option value="benefit">Benefit (Semakin tinggi semakin baik)</option>
                                <option value="cost">Cost (Semakin rendah semakin baik)</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Nama Kriteria <span class="text-danger">*</span></label>
                            <input type="text" name="nama_kriteria" class="form-control" 
                                   placeholder="Contoh: Prestasi Akademik" required>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Deskripsi</label>
                            <textarea name="deskripsi" class="form-control" rows="3" 
                                      placeholder="Deskripsi kriteria..."></textarea>
                        </div>
                    </div>
                </div>
                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Simpan
                    </button>
                    <a href="index.php" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Batal
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php include '../../includes/footer.php'; ?>