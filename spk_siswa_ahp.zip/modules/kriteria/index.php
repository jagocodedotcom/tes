<?php
// ============================================
// KRITERIA - SPK SISWA TELADAN AHP
// ============================================

require_once '../../config/database.php';
session_start();

// Cek login
if (!isset($_SESSION['user_id'])) {
    header('Location: ../../login.php');
    exit;
}

// Proses Hapus
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    
    // Cek apakah kriteria digunakan di penilaian
    $check = getRow("SELECT id_nilai FROM nilai_alternatif WHERE id_kriteria = $id LIMIT 1");
    if ($check) {
        $_SESSION['flash_message'] = 'Kriteria tidak dapat dihapus karena sudah digunakan dalam penilaian!';
        $_SESSION['flash_type'] = 'danger';
        $_SESSION['flash_icon'] = 'exclamation-circle';
    } else {
        $sql = "DELETE FROM kriteria WHERE id_kriteria = $id";
        if (deleteData($sql)) {
            $_SESSION['flash_message'] = 'Kriteria berhasil dihapus!';
            $_SESSION['flash_type'] = 'success';
            $_SESSION['flash_icon'] = 'check-circle';
        } else {
            $_SESSION['flash_message'] = 'Gagal menghapus kriteria!';
            $_SESSION['flash_type'] = 'danger';
            $_SESSION['flash_icon'] = 'exclamation-circle';
        }
    }
    header('Location: index.php');
    exit;
}

include '../../includes/header.php';

// Ambil Data
$kriteria = getAll("SELECT * FROM kriteria ORDER BY id_kriteria ASC");
?>
<div class="fade-in">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold text-primary mb-0">
                <i class="fas fa-list"></i> Data Kriteria
            </h4>
            <small class="text-muted">Manajemen kriteria penilaian siswa</small>
        </div>
        <a href="tambah.php" class="btn btn-primary">
            <i class="fas fa-plus"></i> Tambah Kriteria
        </a>
    </div>

    <div class="table-container">
        <div class="table-responsive">
            <table class="table table-datatable table-hover" id="tableKriteria">
                <thead>
                    <tr>
                        <th width="50">No</th>
                        <th>Kode</th>
                        <th>Nama Kriteria</th>
                        <th>Deskripsi</th>
                        <th>Jenis</th>
                        <th width="150">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; foreach ($kriteria as $row): ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><strong><?php echo htmlspecialchars($row['kode_kriteria']); ?></strong></td>
                        <td><?php echo htmlspecialchars($row['nama_kriteria']); ?></td>
                        <td><?php echo htmlspecialchars($row['deskripsi'] ?? '-'); ?></td>
                        <td>
                            <span class="badge-status <?php echo $row['jenis'] == 'benefit' ? 'badge-benefit' : 'badge-cost'; ?>">
                                <?php echo ucfirst($row['jenis']); ?>
                            </span>
                        </td>
                        <td>
                            <a href="edit.php?id=<?php echo $row['id_kriteria']; ?>" class="btn btn-warning btn-sm">
                                <i class="fas fa-edit"></i>
                            </a>
                            <a href="?action=delete&id=<?php echo $row['id_kriteria']; ?>" 
                               class="btn btn-danger btn-sm btn-delete"
                               onclick="return confirm('Yakin hapus kriteria ini?')">
                                <i class="fas fa-trash"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#tableKriteria').DataTable({
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.13.4/i18n/id.json"
        },
        "pageLength": 10
    });
});
</script>

<?php include '../../includes/footer.php'; ?>