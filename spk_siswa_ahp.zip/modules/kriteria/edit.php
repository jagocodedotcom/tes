<?php
// ============================================
// EDIT KRITERIA - SPK SISWA TELADAN AHP
// ============================================

require_once '../../config/database.php';
session_start();

// Cek login
if (!isset($_SESSION['user_id'])) {
    header('Location: ../../login.php');
    exit;
}

// Cek ID
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$data = getRow("SELECT * FROM kriteria WHERE id_kriteria = $id");

if (!$data) {
    $_SESSION['flash_message'] = 'Data tidak ditemukan!';
    $_SESSION['flash_type'] = 'danger';
    $_SESSION['flash_icon'] = 'exclamation-circle';
    header('Location: index.php');
    exit;
}

// Proses Update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $kode = escape($_POST['kode_kriteria']);
    $nama = escape($_POST['nama_kriteria']);
    $deskripsi = escape($_POST['deskripsi'] ?? '');
    $jenis = escape($_POST['jenis']);
    
    // Cek kode sudah ada (kecuali dirinya sendiri)
    $check = getRow("SELECT id_kriteria FROM kriteria WHERE kode_kriteria = '$kode' AND id_kriteria != $id");
    if ($check) {
        $_SESSION['flash_message'] = 'Kode kriteria sudah digunakan!';
        $_SESSION['flash_type'] = 'danger';
        $_SESSION['flash_icon'] = 'exclamation-circle';
    } else {
        $sql = "UPDATE kriteria SET 
                kode_kriteria = '$kode',
                nama_kriteria = '$nama',
                deskripsi = '$deskripsi',
                jenis = '$jenis'
                WHERE id_kriteria = $id";
        
        if (updateData($sql)) {
            $_SESSION['flash_message'] = 'Kriteria berhasil diupdate!';
            $_SESSION['flash_type'] = 'success';
            $_SESSION['flash_icon'] = 'check-circle';
            header('Location: index.php');
            exit;
        } else {
            $_SESSION['flash_message'] = 'Gagal mengupdate kriteria!';
            $_SESSION['flash_type'] = 'danger';
            $_SESSION['flash_icon'] = 'exclamation-circle';
        }
    }
}

include '../../includes/header.php';
?>
<div class="fade-in">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold text-primary mb-0">
                <i class="fas fa-edit"></i> Edit Kriteria
            </h4>
            <small class="text-muted">Edit data kriteria yang sudah ada</small>
        </div>
        <a href="index.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Kembali
        </a>
    </div>

    <div class="card">
        <div class="card-body">
            <form method="POST">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Kode Kriteria <span class="text-danger">*</span></label>
                            <input type="text" name="kode_kriteria" class="form-control" 
                                   value="<?php echo htmlspecialchars($data['kode_kriteria']); ?>" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Jenis <span class="text-danger">*</span></label>
                            <select name="jenis" class="form-select" required>
                                <option value="benefit" <?php echo $data['jenis'] == 'benefit' ? 'selected' : ''; ?>>Benefit</option>
                                <option value="cost" <?php echo $data['jenis'] == 'cost' ? 'selected' : ''; ?>>Cost</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Nama Kriteria <span class="text-danger">*</span></label>
                            <input type="text" name="nama_kriteria" class="form-control" 
                                   value="<?php echo htmlspecialchars($data['nama_kriteria']); ?>" required>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Deskripsi</label>
                            <textarea name="deskripsi" class="form-control" rows="3"><?php echo htmlspecialchars($data['deskripsi']); ?></textarea>
                        </div>
                    </div>
                </div>
                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Update
                    </button>
                    <a href="index.php" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Batal
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php include '../../includes/footer.php'; ?>