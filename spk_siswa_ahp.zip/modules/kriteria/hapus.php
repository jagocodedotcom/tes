<?php
require_once '../../config/database.php';
session_start();

// Cek apakah ada ID
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['flash_message'] = 'ID kriteria tidak ditemukan!';
    $_SESSION['flash_type'] = 'danger';
    $_SESSION['flash_icon'] = 'exclamation-circle';
    header('Location: index.php');
    exit;
}

$id = (int)$_GET['id'];

// Cek apakah kriteria digunakan di penilaian
$check = getRow("SELECT id_nilai FROM nilai_alternatif WHERE id_kriteria = $id LIMIT 1");
if ($check) {
    $_SESSION['flash_message'] = 'Kriteria tidak dapat dihapus karena sudah digunakan dalam penilaian!';
    $_SESSION['flash_type'] = 'danger';
    $_SESSION['flash_icon'] = 'exclamation-circle';
    header('Location: index.php');
    exit;
}

// Hapus kriteria
$sql = "DELETE FROM kriteria WHERE id_kriteria = $id";
if (deleteData($sql)) {
    $_SESSION['flash_message'] = 'Kriteria berhasil dihapus!';
    $_SESSION['flash_type'] = 'success';
    $_SESSION['flash_icon'] = 'check-circle';
} else {
    $_SESSION['flash_message'] = 'Gagal menghapus kriteria!';
    $_SESSION['flash_type'] = 'danger';
    $_SESSION['flash_icon'] = 'exclamation-circle';
}

header('Location: index.php');
exit;
?>