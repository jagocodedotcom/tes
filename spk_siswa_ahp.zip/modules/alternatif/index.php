<?php
require_once '../../config/database.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: ../../login.php');
    exit;
}

if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $check = getRow("SELECT id_nilai FROM nilai_alternatif WHERE id_alternatif = $id LIMIT 1");
    if ($check) {
        $_SESSION['flash_message'] = 'Siswa tidak dapat dihapus karena sudah memiliki penilaian!';
        $_SESSION['flash_type'] = 'danger';
        $_SESSION['flash_icon'] = 'exclamation-circle';
    } else {
        $sql = "DELETE FROM alternatif WHERE id_alternatif = $id";
        if (deleteData($sql)) {
            $_SESSION['flash_message'] = 'Siswa berhasil dihapus!';
            $_SESSION['flash_type'] = 'success';
            $_SESSION['flash_icon'] = 'check-circle';
        } else {
            $_SESSION['flash_message'] = 'Gagal menghapus siswa!';
            $_SESSION['flash_type'] = 'danger';
            $_SESSION['flash_icon'] = 'exclamation-circle';
        }
    }
    header('Location: index.php');
    exit;
}

include '../../includes/header.php';
$siswa = getAll("SELECT * FROM alternatif ORDER BY id_alternatif ASC");
?>
<div class="fade-in">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold text-primary mb-0"><i class="fas fa-users"></i> Data Siswa</h4>
            <small class="text-muted">Manajemen data siswa sebagai alternatif</small>
        </div>
        <a href="tambah.php" class="btn btn-primary"><i class="fas fa-plus"></i> Tambah Siswa</a>
    </div>
    <div class="table-container">
        <div class="table-responsive">
            <table class="table table-datatable table-hover" id="tableSiswa">
                <thead><tr><th>No</th><th>NIS</th><th>Nama Siswa</th><th>Kelas</th><th>JK</th><th>No HP</th><th>Aksi</th></tr></thead>
                <tbody>
                    <?php $no=1; foreach($siswa as $row): ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><strong><?php echo htmlspecialchars($row['nis']); ?></strong></td>
                        <td><?php echo htmlspecialchars($row['nama_siswa']); ?></td>
                        <td><?php echo htmlspecialchars($row['kelas']); ?></td>
                        <td><?php echo $row['jenis_kelamin'] == 'L' ? 'Laki-laki' : 'Perempuan'; ?></td>
                        <td><?php echo htmlspecialchars($row['no_hp'] ?? '-'); ?></td>
                        <td>
                            <a href="edit.php?id=<?php echo $row['id_alternatif']; ?>" class="btn btn-warning btn-sm"><i class="fas fa-edit"></i></a>
                            <a href="?action=delete&id=<?php echo $row['id_alternatif']; ?>" class="btn btn-danger btn-sm btn-delete"><i class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script>
$(document).ready(function(){
    $('#tableSiswa').DataTable({language:{url:"//cdn.datatables.net/plug-ins/1.13.4/i18n/id.json"},pageLength:10});
});
</script>
<?php include '../../includes/footer.php'; ?>