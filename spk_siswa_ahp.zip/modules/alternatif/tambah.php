<?php
// ============================================
// TAMBAH SISWA - SPK SISWA TELADAN AHP
// ============================================

require_once '../../config/database.php';
session_start();

// Cek login
if (!isset($_SESSION['user_id'])) {
    header('Location: ../../login.php');
    exit;
}

// Proses Tambah
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nis = escape($_POST['nis']);
    $nama = escape($_POST['nama_siswa']);
    $kelas = escape($_POST['kelas']);
    $jk = escape($_POST['jenis_kelamin']);
    $alamat = escape($_POST['alamat'] ?? '');
    $no_hp = escape($_POST['no_hp'] ?? '');
    
    $check = getRow("SELECT id_alternatif FROM alternatif WHERE nis = '$nis'");
    if ($check) {
        $_SESSION['flash_message'] = 'NIS sudah digunakan!';
        $_SESSION['flash_type'] = 'danger';
        $_SESSION['flash_icon'] = 'exclamation-circle';
    } else {
        $sql = "INSERT INTO alternatif (nis, nama_siswa, kelas, jenis_kelamin, alamat, no_hp) 
                VALUES ('$nis', '$nama', '$kelas', '$jk', '$alamat', '$no_hp')";
        if (insertData($sql)) {
            $_SESSION['flash_message'] = 'Siswa berhasil ditambahkan!';
            $_SESSION['flash_type'] = 'success';
            $_SESSION['flash_icon'] = 'check-circle';
            header('Location: index.php');
            exit;
        } else {
            $_SESSION['flash_message'] = 'Gagal menambahkan siswa!';
            $_SESSION['flash_type'] = 'danger';
            $_SESSION['flash_icon'] = 'exclamation-circle';
        }
    }
}

include '../../includes/header.php';
?>
<div class="fade-in">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold text-primary mb-0"><i class="fas fa-user-plus"></i> Tambah Siswa</h4>
            <small class="text-muted">Tambahkan data siswa baru</small>
        </div>
        <a href="index.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Kembali</a>
    </div>
    <div class="card">
        <div class="card-body">
            <form method="POST">
                <div class="row">
                    <div class="col-md-6"><div class="mb-3"><label class="form-label fw-bold">NIS <span class="text-danger">*</span></label><input type="text" name="nis" class="form-control" placeholder="Nomor Induk Siswa" required></div></div>
                    <div class="col-md-6"><div class="mb-3"><label class="form-label fw-bold">Nama Siswa <span class="text-danger">*</span></label><input type="text" name="nama_siswa" class="form-control" placeholder="Nama lengkap" required></div></div>
                    <div class="col-md-4"><div class="mb-3"><label class="form-label fw-bold">Kelas <span class="text-danger">*</span></label><input type="text" name="kelas" class="form-control" placeholder="Contoh: 9A" required></div></div>
                    <div class="col-md-4"><div class="mb-3"><label class="form-label fw-bold">Jenis Kelamin <span class="text-danger">*</span></label><select name="jenis_kelamin" class="form-select" required><option value="L">Laki-laki</option><option value="P">Perempuan</option></select></div></div>
                    <div class="col-md-4"><div class="mb-3"><label class="form-label fw-bold">No HP</label><input type="text" name="no_hp" class="form-control" placeholder="08xxxxxxxxxx"></div></div>
                    <div class="col-12"><div class="mb-3"><label class="form-label fw-bold">Alamat</label><textarea name="alamat" class="form-control" rows="2" placeholder="Alamat siswa"></textarea></div></div>
                </div>
                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Simpan</button>
                    <a href="index.php" class="btn btn-secondary"><i class="fas fa-times"></i> Batal</a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php include '../../includes/footer.php'; ?>