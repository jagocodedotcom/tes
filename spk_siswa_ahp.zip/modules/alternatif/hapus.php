<?php
require_once '../../config/database.php';
session_start();

// Cek apakah ada ID
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['flash_message'] = 'ID siswa tidak ditemukan!';
    $_SESSION['flash_type'] = 'danger';
    $_SESSION['flash_icon'] = 'exclamation-circle';
    header('Location: index.php');
    exit;
}

$id = (int)$_GET['id'];

// Cek apakah siswa sudah memiliki penilaian
$check = getRow("SELECT id_nilai FROM nilai_alternatif WHERE id_alternatif = $id LIMIT 1");
if ($check) {
    $_SESSION['flash_message'] = 'Siswa tidak dapat dihapus karena sudah memiliki penilaian!';
    $_SESSION['flash_type'] = 'danger';
    $_SESSION['flash_icon'] = 'exclamation-circle';
    header('Location: index.php');
    exit;
}

// Hapus siswa
$sql = "DELETE FROM alternatif WHERE id_alternatif = $id";
if (deleteData($sql)) {
    $_SESSION['flash_message'] = 'Siswa berhasil dihapus!';
    $_SESSION['flash_type'] = 'success';
    $_SESSION['flash_icon'] = 'check-circle';
} else {
    $_SESSION['flash_message'] = 'Gagal menghapus siswa!';
    $_SESSION['flash_type'] = 'danger';
    $_SESSION['flash_icon'] = 'exclamation-circle';
}

header('Location: index.php');
exit;
?>