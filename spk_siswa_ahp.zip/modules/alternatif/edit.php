<?php
require_once '../../config/database.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: ../../login.php');
    exit;
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$data = getRow("SELECT * FROM alternatif WHERE id_alternatif = $id");

if (!$data) {
    $_SESSION['flash_message'] = 'Data tidak ditemukan!';
    $_SESSION['flash_type'] = 'danger';
    $_SESSION['flash_icon'] = 'exclamation-circle';
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nis = escape($_POST['nis']);
    $nama = escape($_POST['nama_siswa']);
    $kelas = escape($_POST['kelas']);
    $jk = escape($_POST['jenis_kelamin']);
    $alamat = escape($_POST['alamat'] ?? '');
    $no_hp = escape($_POST['no_hp'] ?? '');
    
    $check = getRow("SELECT id_alternatif FROM alternatif WHERE nis = '$nis' AND id_alternatif != $id");
    if ($check) {
        $_SESSION['flash_message'] = 'NIS sudah digunakan!';
        $_SESSION['flash_type'] = 'danger';
        $_SESSION['flash_icon'] = 'exclamation-circle';
    } else {
        $sql = "UPDATE alternatif SET nis='$nis', nama_siswa='$nama', kelas='$kelas', jenis_kelamin='$jk', alamat='$alamat', no_hp='$no_hp' WHERE id_alternatif=$id";
        if (updateData($sql)) {
            $_SESSION['flash_message'] = 'Siswa berhasil diupdate!';
            $_SESSION['flash_type'] = 'success';
            $_SESSION['flash_icon'] = 'check-circle';
            header('Location: index.php');
            exit;
        } else {
            $_SESSION['flash_message'] = 'Gagal mengupdate siswa!';
            $_SESSION['flash_type'] = 'danger';
            $_SESSION['flash_icon'] = 'exclamation-circle';
        }
    }
}

include '../../includes/header.php';
?>
<div class="fade-in">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold text-primary mb-0"><i class="fas fa-edit"></i> Edit Siswa</h4>
            <small class="text-muted">Edit data siswa yang sudah ada</small>
        </div>
        <a href="index.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Kembali</a>
    </div>
    <div class="card">
        <div class="card-body">
            <form method="POST">
                <div class="row">
                    <div class="col-md-6"><div class="mb-3"><label class="form-label fw-bold">NIS <span class="text-danger">*</span></label><input type="text" name="nis" class="form-control" value="<?php echo htmlspecialchars($data['nis']); ?>" required></div></div>
                    <div class="col-md-6"><div class="mb-3"><label class="form-label fw-bold">Nama Siswa <span class="text-danger">*</span></label><input type="text" name="nama_siswa" class="form-control" value="<?php echo htmlspecialchars($data['nama_siswa']); ?>" required></div></div>
                    <div class="col-md-4"><div class="mb-3"><label class="form-label fw-bold">Kelas <span class="text-danger">*</span></label><input type="text" name="kelas" class="form-control" value="<?php echo htmlspecialchars($data['kelas']); ?>" required></div></div>
                    <div class="col-md-4"><div class="mb-3"><label class="form-label fw-bold">Jenis Kelamin <span class="text-danger">*</span></label><select name="jenis_kelamin" class="form-select" required><option value="L" <?php echo $data['jenis_kelamin']=='L'?'selected':''; ?>>Laki-laki</option><option value="P" <?php echo $data['jenis_kelamin']=='P'?'selected':''; ?>>Perempuan</option></select></div></div>
                    <div class="col-md-4"><div class="mb-3"><label class="form-label fw-bold">No HP</label><input type="text" name="no_hp" class="form-control" value="<?php echo htmlspecialchars($data['no_hp']); ?>"></div></div>
                    <div class="col-12"><div class="mb-3"><label class="form-label fw-bold">Alamat</label><textarea name="alamat" class="form-control" rows="2"><?php echo htmlspecialchars($data['alamat']); ?></textarea></div></div>
                </div>
                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Update</button>
                    <a href="index.php" class="btn btn-secondary"><i class="fas fa-times"></i> Batal</a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php include '../../includes/footer.php'; ?>