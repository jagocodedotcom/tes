<?php
require_once '../../config/database.php';
session_start();
if(!isset($_SESSION['user_id'])){header('Location: ../../login.php');exit;}

// ============================================
// FUNGSI AHP
// ============================================
function hitungAHP(){
global $db;
$kriteria=getAll("SELECT * FROM kriteria ORDER BY id_kriteria ASC");
$n=count($kriteria);
if($n<2){return ['error'=>'Minimal 2 kriteria untuk AHP'];}
$matriks=[];
foreach($kriteria as $k1){
foreach($kriteria as $k2){
$sql="SELECT nilai FROM matriks_perbandingan WHERE id_kriteria_1={$k1['id_kriteria']} AND id_kriteria_2={$k2['id_kriteria']}";
$r=query($sql);
if($r&&$r->num_rows>0){$row=$r->fetch_assoc();$matriks[$k1['id_kriteria']][$k2['id_kriteria']]=(float)$row['nilai'];}
else{$matriks[$k1['id_kriteria']][$k2['id_kriteria']]=1;}
}
}
$normalisasi=[];
foreach($kriteria as $k2){
$total=0;
foreach($kriteria as $k1){$total+=$matriks[$k1['id_kriteria']][$k2['id_kriteria']];}
foreach($kriteria as $k1){$normalisasi[$k1['id_kriteria']][$k2['id_kriteria']]=$matriks[$k1['id_kriteria']][$k2['id_kriteria']]/$total;}
}
$bobot=[];
foreach($kriteria as $k1){
$total=0;
foreach($kriteria as $k2){$total+=$normalisasi[$k1['id_kriteria']][$k2['id_kriteria']];}
$bobot[$k1['id_kriteria']]=$total/$n;
}
foreach($bobot as $id=>$b){$db->query("UPDATE kriteria SET bobot=$b WHERE id_kriteria=$id");}
$lambda_max=0;
$weights_by_id=[];
foreach($kriteria as $k){$weights_by_id[$k['id_kriteria']]=$bobot[$k['id_kriteria']];}
foreach($kriteria as $k1){
$total=0;
foreach($kriteria as $k2){$total+=$matriks[$k1['id_kriteria']][$k2['id_kriteria']]*$weights_by_id[$k2['id_kriteria']];}
$lambda_max+=$total/$weights_by_id[$k1['id_kriteria']];
}
$lambda_max=$lambda_max/$n;
$ci=($lambda_max-$n)/($n-1);
$ri_values=[1=>0,2=>0,3=>0.58,4=>0.90,5=>1.12,6=>1.24,7=>1.32,8=>1.41,9=>1.45,10=>1.49];
$ri=isset($ri_values[$n])?$ri_values[$n]:1.49;
$cr=($ri>0)?$ci/$ri:0;
$_SESSION['ahp_hasil']=['bobot'=>$bobot,'lambda_max'=>$lambda_max,'ci'=>$ci,'cr'=>$cr,'konsisten'=>$cr<=0.1];
return ['success'=>true,'bobot'=>$bobot,'lambda_max'=>$lambda_max,'ci'=>$ci,'cr'=>$cr,'konsisten'=>$cr<=0.1];
}

// ============================================
// EKSEKUSI
// ============================================
$result=hitungAHP();
if(isset($result['error'])){
$_SESSION['flash_message']=$result['error'];
$_SESSION['flash_type']='danger';
$_SESSION['flash_icon']='exclamation-circle';
}elseif($result['success']){
$_SESSION['flash_message']='Proses AHP berhasil! CR = '.number_format($result['cr'],4).($result['konsisten']?' ✅ Konsisten':' ❌ Tidak Konsisten');
$_SESSION['flash_type']=$result['konsisten']?'success':'warning';
$_SESSION['flash_icon']=$result['konsisten']?'check-circle':'exclamation-triangle';
$_SESSION['ahp_hasil']=$result;
}else{
$_SESSION['flash_message']='Gagal memproses AHP!';
$_SESSION['flash_type']='danger';
$_SESSION['flash_icon']='exclamation-circle';
}
header('Location: index.php');
exit;
?>