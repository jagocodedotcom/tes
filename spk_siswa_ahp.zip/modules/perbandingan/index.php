<?php
require_once '../../config/database.php';
session_start();
if(!isset($_SESSION['user_id'])){header('Location: ../../login.php');exit;}

// ============================================
// PROSES RESET
// ============================================
if(isset($_GET['action'])&&$_GET['action']=='reset'){
$db->query("TRUNCATE TABLE matriks_perbandingan");
$db->query("UPDATE kriteria SET bobot=0");
$db->query("TRUNCATE TABLE hasil_akhir");
$_SESSION['flash_message']='Data perbandingan berhasil direset!';
$_SESSION['flash_type']='success';
$_SESSION['flash_icon']='check-circle';
header('Location: index.php');
exit;
}

// ============================================
// PROSES SIMPAN PERBANDINGAN
// ============================================
if($_SERVER['REQUEST_METHOD']=='POST'&&isset($_POST['save'])){
$db->query("TRUNCATE TABLE matriks_perbandingan");
$kriteria=getAll("SELECT id_kriteria FROM kriteria ORDER BY id_kriteria ASC");
$total=count($kriteria);
for($i=0;$i<$total;$i++){
for($j=0;$j<$total;$j++){
$id1=$kriteria[$i]['id_kriteria'];
$id2=$kriteria[$j]['id_kriteria'];
if($id1==$id2){
$nilai=1;
}else{
$key="pairwise_{$id1}_{$id2}";
$nilai=isset($_POST[$key])?(float)$_POST[$key]:1;
}
$db->query("INSERT INTO matriks_perbandingan (id_kriteria_1,id_kriteria_2,nilai) VALUES ($id1,$id2,$nilai)");
}
}
$_SESSION['flash_message']='Data perbandingan berhasil disimpan!';
$_SESSION['flash_type']='success';
$_SESSION['flash_icon']='check-circle';
header('Location: proses.php');
exit;
}

// ============================================
// AMBIL DATA
// ============================================
$kriteria=getAll("SELECT * FROM kriteria ORDER BY id_kriteria ASC");
$matriks=[];
foreach($kriteria as $k1){
foreach($kriteria as $k2){
$sql="SELECT nilai FROM matriks_perbandingan WHERE id_kriteria_1={$k1['id_kriteria']} AND id_kriteria_2={$k2['id_kriteria']}";
$r=query($sql);
if($r&&$r->num_rows>0){
$row=$r->fetch_assoc();
$matriks[$k1['id_kriteria']][$k2['id_kriteria']]=$row['nilai'];
}else{
$matriks[$k1['id_kriteria']][$k2['id_kriteria']]=($k1['id_kriteria']==$k2['id_kriteria'])?1:0;
}
}
}

// ============================================
// INCLUDE HEADER (SETELAH SEMUA PROSES)
// ============================================
include '../../includes/header.php';
?>

<div class="fade-in">
<div class="d-flex justify-content-between align-items-center mb-4">
<div>
<h4 class="fw-bold text-primary mb-0"><i class="fas fa-balance-scale"></i> Perbandingan Kriteria AHP</h4>
<small class="text-muted">Input perbandingan berpasangan antar kriteria</small>
</div>
<div>
<a href="?action=reset" class="btn btn-danger btn-delete me-2" onclick="return confirm('Yakin reset semua data perbandingan?')"><i class="fas fa-trash"></i> Reset</a>
<a href="../hasil/index.php" class="btn btn-success"><i class="fas fa-trophy"></i> Lihat Hasil</a>
</div>
</div>

<div class="card">
<div class="card-body">
<div class="alert alert-info">
<i class="fas fa-info-circle"></i> <strong>Skala Perbandingan Saaty:</strong>
<ul class="mb-0 mt-2">
<li><strong>1</strong> = Kedua elemen sama penting</li>
<li><strong>3</strong> = Elemen satu sedikit lebih penting dari lainnya</li>
<li><strong>5</strong> = Elemen satu lebih penting dari lainnya</li>
<li><strong>7</strong> = Elemen satu sangat lebih penting dari lainnya</li>
<li><strong>9</strong> = Elemen satu mutlak lebih penting dari lainnya</li>
<li><strong>2,4,6,8</strong> = Nilai tengah antara dua penilaian</li>
</ul>
</div>

<form method="POST">
<div class="table-responsive">
<table class="table table-bordered text-center">
<thead>
<tr>
<th width="150">Kriteria</th>
<?php foreach($kriteria as $k): ?>
<th><?php echo $k['kode_kriteria']; ?></th>
<?php endforeach; ?>
</tr>
</thead>
<tbody>
<?php foreach($kriteria as $k1): ?>
<tr>
<td><strong><?php echo $k1['kode_kriteria'].' - '.$k1['nama_kriteria']; ?></strong></td>
<?php foreach($kriteria as $k2): ?>
<td>
<?php if($k1['id_kriteria']==$k2['id_kriteria']): ?>
<span class="badge bg-secondary">1</span>
<input type="hidden" name="pairwise_<?php echo $k1['id_kriteria']; ?>_<?php echo $k2['id_kriteria']; ?>" value="1">
<?php elseif($k1['id_kriteria']<$k2['id_kriteria']): ?>
<?php 
$val=isset($matriks[$k1['id_kriteria']][$k2['id_kriteria']])?$matriks[$k1['id_kriteria']][$k2['id_kriteria']]:1;
?>
<select name="pairwise_<?php echo $k1['id_kriteria']; ?>_<?php echo $k2['id_kriteria']; ?>" 
class="form-select form-select-sm pairwise-select"
data-id1="<?php echo $k1['id_kriteria']; ?>"
data-id2="<?php echo $k2['id_kriteria']; ?>">
<option value="1" <?php echo $val==1?'selected':''; ?>>1</option>
<option value="2" <?php echo $val==2?'selected':''; ?>>2</option>
<option value="3" <?php echo $val==3?'selected':''; ?>>3</option>
<option value="4" <?php echo $val==4?'selected':''; ?>>4</option>
<option value="5" <?php echo $val==5?'selected':''; ?>>5</option>
<option value="6" <?php echo $val==6?'selected':''; ?>>6</option>
<option value="7" <?php echo $val==7?'selected':''; ?>>7</option>
<option value="8" <?php echo $val==8?'selected':''; ?>>8</option>
<option value="9" <?php echo $val==9?'selected':''; ?>>9</option>
</select>
<?php else: ?>
<?php 
$val=isset($matriks[$k1['id_kriteria']][$k2['id_kriteria']])?$matriks[$k1['id_kriteria']][$k2['id_kriteria']]:1;
$display=($val>0)?round(1/$val,2):1;
?>
<span class="text-muted">1/<?php echo $display; ?></span>
<input type="hidden" name="pairwise_<?php echo $k1['id_kriteria']; ?>_<?php echo $k2['id_kriteria']; ?>" value="<?php echo $display; ?>">
<?php endif; ?>
</td>
<?php endforeach; ?>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>

<div class="d-flex gap-2 mt-3">
<button type="submit" name="save" class="btn btn-primary"><i class="fas fa-save"></i> Simpan & Proses AHP</button>
<a href="javascript:void(0)" class="btn btn-secondary" onclick="location.reload()"><i class="fas fa-sync"></i> Refresh</a>
</div>
</form>
</div>
</div>
</div>

<script>
$(document).ready(function(){
$('.pairwise-select').on('change',function(){
var value=parseFloat($(this).val());
var id1=$(this).data('id1');
var id2=$(this).data('id2');
if(value&&!isNaN(value)&&value>0){
var inverse=1/value;
var inverseInput=$('[data-id1="'+id2+'"][data-id2="'+id1+'"]');
if(inverseInput.length){
inverseInput.val(inverse);
var displaySpan=inverseInput.closest('td').find('.text-muted');
if(displaySpan.length){
displaySpan.text('1/'+inverse.toFixed(2));
}
}
}
});
});
</script>

<?php include '../../includes/footer.php'; ?>