<?php
require_once '../../config/database.php';
session_start();
if(!isset($_SESSION['user_id'])){header('Location: ../../login.php');exit;}

// ============================================
// PROSES PERHITUNGAN RANKING
// ============================================
function hitungRanking(){
global $db;
$kriteria=getAll("SELECT id_kriteria,bobot FROM kriteria WHERE bobot>0 ORDER BY id_kriteria");
if(empty($kriteria)){return ['error'=>'Bobot kriteria belum dihitung. Lakukan perbandingan kriteria terlebih dahulu!'];}
$siswa=getAll("SELECT * FROM alternatif ORDER BY id_alternatif");
if(empty($siswa)){return ['error'=>'Tidak ada data siswa!'];}
$hasil=[];
foreach($siswa as $s){
$total=0;
$nilai_detail=[];
foreach($kriteria as $k){
$nilai=getRow("SELECT nilai FROM nilai_alternatif WHERE id_alternatif={$s['id_alternatif']} AND id_kriteria={$k['id_kriteria']}");
$nilai_val=$nilai?(float)$nilai['nilai']:0;
$max_nilai=getRow("SELECT MAX(nilai) as max FROM nilai_alternatif WHERE id_kriteria={$k['id_kriteria']}");
$max_val=$max_nilai?(float)$max_nilai['max']:1;
$nilai_normal=($max_val>0)?$nilai_val/$max_val:0;
$total+=$k['bobot']*$nilai_normal;
$nilai_detail[]=['id_kriteria'=>$k['id_kriteria'],'nilai'=>$nilai_val,'normal'=>$nilai_normal,'bobot'=>$k['bobot']];
}
$hasil[]=['id_alternatif'=>$s['id_alternatif'],'nis'=>$s['nis'],'nama_siswa'=>$s['nama_siswa'],'kelas'=>$s['kelas'],'skor'=>$total,'detail'=>$nilai_detail];
}
usort($hasil,function($a,$b){return $b['skor']<=>$a['skor'];});
foreach($hasil as $i=>&$h){$h['ranking']=$i+1;}
$db->query("TRUNCATE TABLE hasil_akhir");
foreach($hasil as $h){$sql="INSERT INTO hasil_akhir (id_alternatif,skor_akhir,ranking) VALUES ({$h['id_alternatif']},{$h['skor']},{$h['ranking']})";$db->query($sql);}
return ['success'=>true,'hasil'=>$hasil];
}

// Proses hitung ranking
if(isset($_GET['action'])&&$_GET['action']=='hitung'){
$result=hitungRanking();
if(isset($result['error'])){$_SESSION['flash_message']=$result['error'];$_SESSION['flash_type']='danger';$_SESSION['flash_icon']='exclamation-circle';}
else{$_SESSION['flash_message']='Perhitungan ranking berhasil dilakukan!';$_SESSION['flash_type']='success';$_SESSION['flash_icon']='check-circle';}
header('Location: index.php');exit;
}

include '../../includes/header.php';

// Ambil hasil
$hasil=getAll("SELECT * FROM v_hasil_perankingan ORDER BY ranking ASC");
$bobot_kriteria=getAll("SELECT kode_kriteria,nama_kriteria,bobot FROM kriteria WHERE bobot>0 ORDER BY bobot DESC");
$total_siswa=count($hasil);
$juara1=!empty($hasil)?$hasil[0]:null;

// Data untuk chart
$chart_labels=[];
$chart_data=[];
$chart_colors=[];
$color_palette=['#f8b739','#2c3e7a','#28a745','#dc3545','#17a2b8','#6f42c1','#fd7e14','#20c997','#e83e8c','#6c757d','#343a40','#6610f2','#d63384','#0dcaf0','#198754'];
foreach($hasil as $i=>$row){
$chart_labels[]=$row['nama_siswa'];
$chart_data[]=round($row['skor_akhir'],4);
$chart_colors[]=$color_palette[$i%count($color_palette)];
}

// Data untuk chart kriteria
$kriteria_all=getAll("SELECT * FROM kriteria ORDER BY id_kriteria");
$chart_kriteria_labels=[];
$chart_kriteria_data=[];
foreach($kriteria_all as $k){
$chart_kriteria_labels[]=$k['kode_kriteria'].' - '.$k['nama_kriteria'];
$avg=getRow("SELECT AVG(nilai) as avg FROM nilai_alternatif WHERE id_kriteria={$k['id_kriteria']}");
$chart_kriteria_data[]=round($avg['avg']??0,2);
}

// Data untuk Radar Chart (5 siswa terbaik)
$top5=array_slice($hasil,0,5);
$radar_labels=['Akademik','Non-Akademik','Sikap','Kehadiran','Sosial'];
$radar_datasets=[];
$radar_colors=['#f8b739','#2c3e7a','#28a745','#dc3545','#17a2b8'];
foreach($top5 as $i=>$row){
$id=$row['id_alternatif'];
$nilai=[];
foreach($kriteria_all as $k){
$n=getRow("SELECT nilai FROM nilai_alternatif WHERE id_alternatif=$id AND id_kriteria={$k['id_kriteria']}");
$nilai[]=$n?(float)$n['nilai']:0;
}
$radar_datasets[]=[
'label'=>$row['nama_siswa'].' (#' . ($i+1) . ')',
'data'=>$nilai,
'backgroundColor'=> $radar_colors[$i].'33',
'borderColor'=>$radar_colors[$i],
'pointBackgroundColor'=>$radar_colors[$i],
'borderWidth'=>2
];
}

// Data untuk filter kelas
$kelas_list=getAll("SELECT DISTINCT kelas FROM alternatif ORDER BY kelas");
?>
<div class="fade-in">

<!-- ============================================ -->
<!-- HEADER -->
<!-- ============================================ -->
<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
<div>
<h4 class="fw-bold text-primary mb-0"><i class="fas fa-trophy"></i> Hasil Perankingan</h4>
<small class="text-muted">Hasil akhir pemilihan siswa teladan menggunakan metode AHP</small>
</div>
<div class="d-flex flex-wrap gap-2">
<a href="?action=hitung" class="btn btn-primary" onclick="return confirm('Hitung ulang ranking?')">
<i class="fas fa-calculator"></i> Hitung Ranking
</a>
<a href="javascript:void(0)" class="btn btn-success" onclick="exportExcel()">
<i class="fas fa-file-excel"></i> Export Excel
</a>
<a href="javascript:void(0)" class="btn btn-danger" onclick="exportPDF()">
<i class="fas fa-file-pdf"></i> Export PDF
</a>
<a href="javascript:void(0)" class="btn btn-info" onclick="window.print()">
<i class="fas fa-print"></i> Print
</a>
</div>
</div>

<!-- ============================================ -->
<!-- STATISTIK CARD -->
<!-- ============================================ -->
<div class="row g-4 mb-4">
<div class="col-md-3 col-6">
<div class="stat-card text-center">
<div class="stat-number"><?php echo $total_siswa; ?></div>
<div class="stat-label"><i class="fas fa-users me-1"></i> Total Siswa</div>
</div>
</div>
<div class="col-md-3 col-6">
<div class="stat-card text-center" style="border-left-color:#28a745;">
<div class="stat-number"><?php echo !empty($hasil)?number_format($hasil[0]['skor_akhir'],4):'0'; ?></div>
<div class="stat-label"><i class="fas fa-star me-1 text-warning"></i> Skor Tertinggi</div>
</div>
</div>
<div class="col-md-3 col-6">
<div class="stat-card text-center" style="border-left-color:#ffc107;">
<div class="stat-number"><?php echo !empty($juara1)?htmlspecialchars($juara1['nama_siswa']):'-'; ?></div>
<div class="stat-label"><i class="fas fa-trophy me-1 text-warning"></i> Juara 1</div>
</div>
</div>
<div class="col-md-3 col-6">
<div class="stat-card text-center" style="border-left-color:#17a2b8;">
<div class="stat-number"><?php echo count($bobot_kriteria); ?></div>
<div class="stat-label"><i class="fas fa-list me-1"></i> Total Kriteria</div>
</div>
</div>
</div>

<!-- ============================================ -->
<!-- FILTER KELAS -->
<!-- ============================================ -->
<div class="card mb-4">
<div class="card-body d-flex flex-wrap align-items-center gap-3">
<label class="fw-bold mb-0"><i class="fas fa-filter"></i> Filter Kelas:</label>
<select class="form-select form-select-sm" id="filterKelas" style="width:150px;">
<option value="">Semua Kelas</option>
<?php foreach($kelas_list as $k): ?>
<option value="<?php echo htmlspecialchars($k['kelas']); ?>"><?php echo htmlspecialchars($k['kelas']); ?></option>
<?php endforeach; ?>
</select>
<button class="btn btn-sm btn-primary" onclick="filterByClass()"><i class="fas fa-search"></i> Filter</button>
<button class="btn btn-sm btn-secondary" onclick="resetFilter()"><i class="fas fa-undo"></i> Reset</button>
<span class="text-muted small ms-auto" id="infoFilter">Menampilkan semua data</span>
</div>
</div>

<!-- ============================================ -->
<!-- JUARA 1 BANNER -->
<!-- ============================================ -->
<?php if($juara1): ?>
<div class="card mb-4" style="background:linear-gradient(135deg,#f8b739,#f5a623);border:none;">
<div class="card-body text-white">
<div class="row align-items-center">
<div class="col-auto">
<i class="fas fa-crown fa-4x"></i>
</div>
<div class="col">
<h5 class="mb-0 fw-bold">🏆 SISWA TELADAN TERBAIK</h5>
<h2 class="mb-0 fw-bold"><?php echo htmlspecialchars($juara1['nama_siswa']); ?></h2>
<p class="mb-0">Kelas <?php echo htmlspecialchars($juara1['kelas']); ?> | NIS: <?php echo htmlspecialchars($juara1['nis']); ?> | Skor: <?php echo number_format($juara1['skor_akhir'],4); ?></p>
</div>
<div class="col-auto ms-auto">
<span class="badge bg-light text-dark fs-5 p-3">#1</span>
</div>
</div>
</div>
</div>
<?php endif; ?>

<!-- ============================================ -->
<!-- GRAFIK PERBANDINGAN SKOR (Chart.js) -->
<!-- ============================================ -->
<div class="row g-4 mb-4">
<div class="col-lg-8">
<div class="table-container">
<h6 class="fw-bold mb-3"><i class="fas fa-chart-bar"></i> Grafik Perbandingan Skor Siswa</h6>
<div style="position:relative;height:400px;">
<canvas id="chartSkor"></canvas>
</div>
</div>
</div>
<div class="col-lg-4">
<div class="table-container">
<h6 class="fw-bold mb-3"><i class="fas fa-chart-pie"></i> Distribusi Skor</h6>
<div style="position:relative;height:300px;">
<canvas id="chartPie"></canvas>
</div>
</div>
</div>
</div>

<!-- ============================================ -->
<!-- GRAFIK RADAR (5 SISWA TERBAIK) -->
<!-- ============================================ -->
<?php if(count($top5)>1): ?>
<div class="row g-4 mb-4">
<div class="col-12">
<div class="table-container">
<h6 class="fw-bold mb-3"><i class="fas fa-chart-radar"></i> Perbandingan Nilai 5 Siswa Terbaik</h6>
<div style="position:relative;height:350px;">
<canvas id="chartRadar"></canvas>
</div>
</div>
</div>
</div>
<?php endif; ?>

<!-- ============================================ -->
<!-- GRAFIK RATA-RATA NILAI PER KRITERIA -->
<!-- ============================================ -->
<div class="row g-4 mb-4">
<div class="col-12">
<div class="table-container">
<h6 class="fw-bold mb-3"><i class="fas fa-chart-line"></i> Rata-rata Nilai per Kriteria</h6>
<div style="position:relative;height:300px;">
<canvas id="chartKriteria"></canvas>
</div>
</div>
</div>
</div>

<!-- ============================================ -->
<!-- BOBOT KRITERIA -->
<!-- ============================================ -->
<div class="card mb-4">
<div class="card-header bg-light">
<h6 class="fw-bold mb-0"><i class="fas fa-list"></i> Bobot Kriteria AHP</h6>
</div>
<div class="card-body">
<div class="row">
<?php foreach($bobot_kriteria as $k): ?>
<div class="col-md-2 col-4 mb-3">
<div class="text-center p-2">
<div class="fw-bold"><?php echo $k['kode_kriteria']; ?></div>
<div class="text-muted small"><?php echo substr($k['nama_kriteria'],0,15).(strlen($k['nama_kriteria'])>15?'...':''); ?></div>
<div class="progress mt-1" style="height:25px;">
<div class="progress-bar bg-primary" style="width:<?php echo ($k['bobot']*100); ?>%;">
<?php echo number_format($k['bobot']*100,1); ?>%
</div>
</div>
</div>
</div>
<?php endforeach; ?>
</div>
</div>
</div>

<!-- ============================================ -->
<!-- TABEL HASIL RANKING -->
<!-- ============================================ -->
<div class="table-container" id="tableHasil">
<h6 class="fw-bold mb-3"><i class="fas fa-table"></i> Tabel Perankingan Siswa</h6>
<div class="table-responsive">
<table class="table table-hover" id="tableRanking">
<thead>
<tr>
<th width="60">Rank</th>
<th>NIS</th>
<th>Nama Siswa</th>
<th>Kelas</th>
<th width="150">Skor Akhir</th>
<th>Predikat</th>
<th width="80">Aksi</th>
</tr>
</thead>
<tbody>
<?php if(empty($hasil)): ?>
<tr>
<td colspan="7" class="text-center text-muted py-4">
<i class="fas fa-info-circle fa-2x d-block mb-2"></i>
<p>Belum ada data ranking. Klik tombol "Hitung Ranking" untuk memproses.</p>
</td>
</tr>
<?php else: ?>
<?php foreach($hasil as $row): ?>
<tr class="rank-<?php echo $row['ranking']; ?>">
<td class="text-center">
<?php if($row['ranking']==1): ?>
<span class="badge bg-warning text-dark" style="font-size:18px;padding:8px 12px;">🥇</span>
<?php elseif($row['ranking']==2): ?>
<span class="badge bg-secondary" style="font-size:18px;padding:8px 12px;">🥈</span>
<?php elseif($row['ranking']==3): ?>
<span class="badge bg-danger" style="font-size:18px;padding:8px 12px;">🥉</span>
<?php else: ?>
<span class="badge bg-light text-dark">#<?php echo $row['ranking']; ?></span>
<?php endif; ?>
</td>
<td><strong><?php echo htmlspecialchars($row['nis']); ?></strong></td>
<td><?php echo htmlspecialchars($row['nama_siswa']); ?></td>
<td><?php echo htmlspecialchars($row['kelas']); ?></td>
<td>
<div class="d-flex align-items-center">
<div class="progress flex-grow-1 me-2" style="height:10px;">
<div class="progress-bar bg-primary" style="width:<?php echo ($row['skor_akhir']/($hasil[0]['skor_akhir']??1))*100; ?>%;"></div>
</div>
<span class="fw-bold"><?php echo number_format($row['skor_akhir'],4); ?></span>
</div>
</td>
<td>
<?php if($row['ranking']==1): ?>
<span class="badge bg-warning text-dark">🏆 Siswa Teladan</span>
<?php elseif($row['ranking']<=3): ?>
<span class="badge bg-success">⭐ Juara</span>
<?php else: ?>
<span class="badge bg-secondary">Alternatif</span>
<?php endif; ?>
</td>
<td>
<button class="btn btn-info btn-sm btn-detail" 
        onclick="showDetail(<?php echo $row['id_alternatif']; ?>, '<?php echo addslashes($row['nama_siswa']); ?>')">
<i class="fas fa-eye"></i> Detail
</button>
</td>
</tr>
<?php endforeach; ?>
<?php endif; ?>
</tbody>
</table>
</div>
</div>

</div>

<!-- ============================================ -->
<!-- MODAL DETAIL SISWA -->
<!-- ============================================ -->
<div class="modal fade" id="modalDetail" tabindex="-1" aria-hidden="true">
<div class="modal-dialog modal-lg">
<div class="modal-content">
<div class="modal-header bg-primary text-white">
<h5 class="modal-title"><i class="fas fa-user"></i> Detail Nilai Siswa</h5>
<button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
</div>
<div class="modal-body" id="detailContent">
<div class="text-center py-4">
<div class="spinner-border text-primary"></div>
<p class="mt-2">Memuat data...</p>
</div>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
</div>
</div>
</div>
</div>
<!-- ============================================ -->
<!-- SCRIPTS -->
<!-- ============================================ -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
<script>
// ==========================================
// FUNGSI SHOW DETAIL - PALING SIMPLE
// ==========================================
function showDetail(id, nama) {
    console.log('Show detail - ID:', id, 'Nama:', nama);
    
    if (!id || id == 0) {
        alert('ID tidak valid!');
        return;
    }
    
    // Tampilkan loading di modal
    document.getElementById('detailContent').innerHTML = 
        '<div class="text-center py-4">' +
        '<div class="spinner-border text-primary" role="status">' +
        '<span class="visually-hidden">Loading...</span></div>' +
        '<p class="mt-2">Memuat data ' + nama + '...</p></div>';
    
    // Buka modal
    var modal = new bootstrap.Modal(document.getElementById('modalDetail'));
    modal.show();
    
    // Ambil data via AJAX
    var xhr = new XMLHttpRequest();
    xhr.open('GET', 'detail_siswa.php?id=' + id, true);
    xhr.timeout = 10000;
    
    xhr.onload = function() {
        if (xhr.status === 200) {
            document.getElementById('detailContent').innerHTML = xhr.responseText;
        } else {
            document.getElementById('detailContent').innerHTML = 
                '<div class="alert alert-danger text-center py-4">' +
                '<i class="fas fa-exclamation-circle fa-3x d-block mb-3"></i>' +
                '<h5>Gagal memuat data!</h5>' +
                '<p class="mb-0">Error: ' + xhr.status + '</p>' +
                '</div>';
        }
    };
    
    xhr.onerror = function() {
        document.getElementById('detailContent').innerHTML = 
            '<div class="alert alert-danger text-center py-4">' +
            '<i class="fas fa-exclamation-circle fa-3x d-block mb-3"></i>' +
            '<h5>Gagal memuat data!</h5>' +
            '<p class="mb-0">Terjadi kesalahan koneksi.</p>' +
            '</div>';
    };
    
    xhr.ontimeout = function() {
        document.getElementById('detailContent').innerHTML = 
            '<div class="alert alert-warning text-center py-4">' +
            '<i class="fas fa-clock fa-3x d-block mb-3"></i>' +
            '<h5>Waktu habis!</h5>' +
            '<p class="mb-0">Server terlalu lama merespon.</p>' +
            '</div>';
    };
    
    xhr.send();
}

// ==========================================
// FILTER KELAS
// ==========================================
function filterByClass() {
    var kelas = document.getElementById('filterKelas').value;
    var table = $('#tableRanking').DataTable();
    var info = document.getElementById('infoFilter');
    
    if (kelas) {
        table.column(3).search(kelas).draw();
        info.innerHTML = 'Menampilkan data kelas <strong>' + kelas + '</strong>';
    } else {
        alert('Pilih kelas terlebih dahulu!');
    }
}

function resetFilter() {
    document.getElementById('filterKelas').value = '';
    $('#tableRanking').DataTable().column(3).search('').draw();
    document.getElementById('infoFilter').innerHTML = 'Menampilkan semua data';
}

// ==========================================
// EXPORT EXCEL
// ==========================================
function exportExcel() {
    var table = document.getElementById('tableHasil');
    var html = table.outerHTML;
    var blob = new Blob([html], {type: 'application/vnd.ms-excel'});
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = 'perankingan_siswa.xls';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

// ==========================================
// EXPORT PDF
// ==========================================
function exportPDF() {
    var element = document.getElementById('tableHasil');
    var opt = {
        margin:        [10, 10, 10, 10],
        filename:     'perankingan_siswa.pdf',
        image:        { type: 'jpeg', quality: 0.98 },
        html2canvas:  { scale: 2 },
        jsPDF:        { unit: 'mm', format: 'a4', orientation: 'landscape' }
    };
    html2pdf().set(opt).from(element).save();
}

// ==========================================
// DATATABLE
// ==========================================
$(document).ready(function() {
    if ($.fn.DataTable) {
        $('#tableRanking').DataTable({
            language: {
                url: "//cdn.datatables.net/plug-ins/1.13.4/i18n/id.json"
            },
            pageLength: 10,
            ordering: false,
            columnDefs: [
                { targets: 6, orderable: false }
            ]
        });
    }
});

// ==========================================
// CHART.JS - GRAFIK
// ==========================================
document.addEventListener('DOMContentLoaded', function() {
    
    // 1. GRAFIK SKOR SISWA (Bar Chart)
    var ctx1 = document.getElementById('chartSkor');
    if (ctx1) {
        var labels = <?php echo json_encode($chart_labels); ?>;
        var data = <?php echo json_encode($chart_data); ?>;
        var colors = <?php echo json_encode($chart_colors); ?>;
        
        new Chart(ctx1.getContext('2d'), {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Skor Akhir',
                    data: data,
                    backgroundColor: colors.map(function(c) { return c + '80'; }),
                    borderColor: colors,
                    borderWidth: 2,
                    borderRadius: 6,
                    barPercentage: 0.7
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return 'Skor: ' + context.parsed.y.toFixed(4);
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return value.toFixed(2);
                            }
                        }
                    }
                }
            }
        });
    }

    // 2. GRAFIK PIE (Distribusi)
    var ctx2 = document.getElementById('chartPie');
    if (ctx2) {
        var pieData = <?php echo json_encode($chart_data); ?>;
        var pieLabels = <?php echo json_encode($chart_labels); ?>;
        var pieColors = <?php echo json_encode($chart_colors); ?>;
        
        new Chart(ctx2.getContext('2d'), {
            type: 'doughnut',
            data: {
                labels: pieLabels,
                datasets: [{
                    data: pieData,
                    backgroundColor: pieColors.map(function(c) { return c + '90'; }),
                    borderColor: pieColors,
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            font: { size: 10 },
                            boxWidth: 12
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                var total = context.dataset.data.reduce(function(a,b){return a+b;},0);
                                var percentage = ((context.parsed / total) * 100).toFixed(1);
                                return context.label + ': ' + context.parsed.toFixed(4) + ' (' + percentage + '%)';
                            }
                        }
                    }
                }
            }
        });
    }

    // 3. GRAFIK RADAR (5 Siswa Terbaik)
    <?php if(count($top5)>1): ?>
    var ctxRadar = document.getElementById('chartRadar');
    if (ctxRadar) {
        var radarLabels = <?php echo json_encode($radar_labels); ?>;
        var radarDatasets = <?php echo json_encode($radar_datasets); ?>;
        
        new Chart(ctxRadar.getContext('2d'), {
            type: 'radar',
            data: {
                labels: radarLabels,
                datasets: radarDatasets
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    r: {
                        beginAtZero: true,
                        max: 100,
                        ticks: {
                            stepSize: 20
                        }
                    }
                },
                plugins: {
                    legend: {
                        position: 'top',
                        labels: {
                            font: { size: 11 }
                        }
                    }
                }
            }
        });
    }
    <?php endif; ?>

    // 4. GRAFIK RATA-RATA NILAI PER KRITERIA
    var ctx3 = document.getElementById('chartKriteria');
    if (ctx3) {
        var kriteriaLabels = <?php echo json_encode($chart_kriteria_labels); ?>;
        var kriteriaData = <?php echo json_encode($chart_kriteria_data); ?>;
        
        new Chart(ctx3.getContext('2d'), {
            type: 'line',
            data: {
                labels: kriteriaLabels,
                datasets: [{
                    label: 'Rata-rata Nilai',
                    data: kriteriaData,
                    backgroundColor: 'rgba(44,62,122,0.2)',
                    borderColor: '#2c3e7a',
                    borderWidth: 3,
                    pointBackgroundColor: '#2c3e7a',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 6,
                    fill: true,
                    tension: 0.3
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: true },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return 'Rata-rata: ' + context.parsed.y.toFixed(2);
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        ticks: {
                            callback: function(value) {
                                return value.toFixed(0);
                            }
                        }
                    }
                }
            }
        });
    }

});
</script>
<!-- ============================================ -->
<!-- SCRIPTS -->
<!-- ============================================ -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    
    // ==========================================
    // 1. GRAFIK SKOR SISWA (Bar Chart)
    // ==========================================
    var ctx1 = document.getElementById('chartSkor').getContext('2d');
    var labels = <?php echo json_encode($chart_labels); ?>;
    var data = <?php echo json_encode($chart_data); ?>;
    var colors = <?php echo json_encode($chart_colors); ?>;
    
    new Chart(ctx1, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Skor Akhir',
                data: data,
                backgroundColor: colors.map(function(c) { return c + '80'; }),
                borderColor: colors,
                borderWidth: 2,
                borderRadius: 6,
                barPercentage: 0.7
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return 'Skor: ' + context.parsed.y.toFixed(4);
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return value.toFixed(2);
                        }
                    }
                }
            }
        }
    });

    // ==========================================
    // 2. GRAFIK PIE (Distribusi)
    // ==========================================
    var ctx2 = document.getElementById('chartPie').getContext('2d');
    var pieData = <?php echo json_encode($chart_data); ?>;
    var pieLabels = <?php echo json_encode($chart_labels); ?>;
    var pieColors = <?php echo json_encode($chart_colors); ?>;
    
    new Chart(ctx2, {
        type: 'doughnut',
        data: {
            labels: pieLabels,
            datasets: [{
                data: pieData,
                backgroundColor: pieColors.map(function(c) { return c + '90'; }),
                borderColor: pieColors,
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        font: { size: 10 },
                        boxWidth: 12
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            var total = context.dataset.data.reduce(function(a,b){return a+b;},0);
                            var percentage = ((context.parsed / total) * 100).toFixed(1);
                            return context.label + ': ' + context.parsed.toFixed(4) + ' (' + percentage + '%)';
                        }
                    }
                }
            }
        }
    });

    // ==========================================
    // 3. GRAFIK RADAR (5 Siswa Terbaik)
    // ==========================================
    <?php if(count($top5)>1): ?>
    var ctxRadar = document.getElementById('chartRadar').getContext('2d');
    var radarLabels = <?php echo json_encode($radar_labels); ?>;
    var radarDatasets = <?php echo json_encode($radar_datasets); ?>;
    
    new Chart(ctxRadar, {
        type: 'radar',
        data: {
            labels: radarLabels,
            datasets: radarDatasets
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                r: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        stepSize: 20
                    }
                }
            },
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        font: { size: 11 }
                    }
                }
            }
        }
    });
    <?php endif; ?>

    // ==========================================
    // 4. GRAFIK RATA-RATA NILAI PER KRITERIA
    // ==========================================
    var ctx3 = document.getElementById('chartKriteria').getContext('2d');
    var kriteriaLabels = <?php echo json_encode($chart_kriteria_labels); ?>;
    var kriteriaData = <?php echo json_encode($chart_kriteria_data); ?>;
    
    new Chart(ctx3, {
        type: 'line',
        data: {
            labels: kriteriaLabels,
            datasets: [{
                label: 'Rata-rata Nilai',
                data: kriteriaData,
                backgroundColor: 'rgba(44,62,122,0.2)',
                borderColor: '#2c3e7a',
                borderWidth: 3,
                pointBackgroundColor: '#2c3e7a',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 6,
                fill: true,
                tension: 0.3
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: true },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return 'Rata-rata: ' + context.parsed.y.toFixed(2);
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        callback: function(value) {
                            return value.toFixed(0);
                        }
                    }
                }
            }
        }
    });

});

// ==========================================
// FILTER KELAS
// ==========================================
function filterByClass() {
    var kelas = document.getElementById('filterKelas').value;
    var table = $('#tableRanking').DataTable();
    var info = document.getElementById('infoFilter');
    
    if (kelas) {
        table.column(3).search(kelas).draw();
        info.innerHTML = 'Menampilkan data kelas <strong>' + kelas + '</strong>';
    } else {
        alert('Pilih kelas terlebih dahulu!');
    }
}

function resetFilter() {
    document.getElementById('filterKelas').value = '';
    $('#tableRanking').DataTable().column(3).search('').draw();
    document.getElementById('infoFilter').innerHTML = 'Menampilkan semua data';
}

// ==========================================
// DETAIL SISWA (AJAX)
// ==========================================
$(document).ready(function() {
    // Event delegation untuk tombol detail
    $(document).on('click', '.btn-detail', function(e) {
        e.preventDefault();
        
        var id = $(this).data('id');
        var nama = $(this).data('nama') || 'Siswa';
        
        if (!id || id == 0) {
            alert('ID tidak valid!');
            return;
        }
        
        // Tampilkan loading
        $('#detailContent').html(
            '<div class="text-center py-4">' +
            '<div class="spinner-border text-primary" role="status">' +
            '<span class="visually-hidden">Loading...</span></div>' +
            '<p class="mt-2">Memuat data ' + nama + '...</p></div>'
        );
        
        // Buka modal
        $('#modalDetail').modal('show');
        
        // Ambil data via AJAX
        $.ajax({
            url: 'detail_siswa.php',
            type: 'GET',
            data: { id: id },
            dataType: 'html',
            timeout: 10000,
            success: function(response) {
                $('#detailContent').html(response);
            },
            error: function(xhr, status, error) {
                console.log('AJAX Error:', status, error);
                $('#detailContent').html(
                    '<div class="alert alert-danger text-center py-4">' +
                    '<i class="fas fa-exclamation-circle fa-3x d-block mb-3"></i>' +
                    '<h5>Gagal memuat data!</h5>' +
                    '<p class="mb-0">Error: ' + error + '</p>' +
                    '<small class="text-muted">Silakan coba lagi atau refresh halaman.</small>' +
                    '</div>'
                );
            }
        });
    });

    // ==========================================
    // DATATABLE
    // ==========================================
    if ($.fn.DataTable) {
        $('#tableRanking').DataTable({
            language: {
                url: "//cdn.datatables.net/plug-ins/1.13.4/i18n/id.json"
            },
            pageLength: 10,
            ordering: false,
            columnDefs: [
                { targets: 6, orderable: false }
            ]
        });
    }
});

// ==========================================
// EXPORT EXCEL
// ==========================================
function exportExcel() {
    var table = document.getElementById('tableHasil');
    var html = table.outerHTML;
    var blob = new Blob([html], {type: 'application/vnd.ms-excel'});
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = 'perankingan_siswa.xls';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

// ==========================================
// EXPORT PDF
// ==========================================
function exportPDF() {
    var element = document.getElementById('tableHasil');
    var opt = {
        margin:        [10, 10, 10, 10],
        filename:     'perankingan_siswa.pdf',
        image:        { type: 'jpeg', quality: 0.98 },
        html2canvas:  { scale: 2 },
        jsPDF:        { unit: 'mm', format: 'a4', orientation: 'landscape' }
    };
    html2pdf().set(opt).from(element).save();
}
</script>

<!-- ============================================ -->
<!-- STYLE TAMBAHAN -->
<!-- ============================================ -->
<style>
.rank-1 { background-color: #fff8e1 !important; }
.rank-2 { background-color: #f5f5f5 !important; }
.rank-3 { background-color: #fce4ec !important; }
.btn-detail { padding: 2px 8px; font-size: 12px; }
.stat-card { transition: transform 0.3s ease; }
.stat-card:hover { transform: translateY(-5px); }
</style>

<?php include '../../includes/footer.php'; ?>