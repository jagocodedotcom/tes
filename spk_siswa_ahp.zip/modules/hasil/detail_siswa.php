<?php
// ============================================
// DETAIL SISWA - VERSI SEDERHANA
// ============================================

require_once '../../config/database.php';
session_start();

// Cek login
if(!isset($_SESSION['user_id'])){
    echo '<div class="alert alert-danger">Akses ditolak! Silakan login terlebih dahulu.</div>';
    exit;
}

// Ambil ID dari GET
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Jika ID tidak valid
if($id == 0){
    echo '<div class="alert alert-warning">
            <i class="fas fa-exclamation-triangle"></i> 
            <strong>ID tidak valid!</strong> 
            <p class="mb-0">Parameter ID tidak diterima dengan benar.</p>
          </div>';
    exit;
}

// Ambil data siswa
$siswa = getRow("SELECT * FROM alternatif WHERE id_alternatif = $id");
if(!$siswa){
    echo '<div class="alert alert-danger">
            <i class="fas fa-exclamation-circle"></i> 
            <strong>Data tidak ditemukan!</strong> 
            <p class="mb-0">Siswa tidak ditemukan di database.</p>
          </div>';
    exit;
}

// Ambil nilai per kriteria
$nilai = getAll("SELECT k.kode_kriteria, k.nama_kriteria, n.nilai, k.bobot 
                 FROM nilai_alternatif n 
                 JOIN kriteria k ON n.id_kriteria = k.id_kriteria 
                 WHERE n.id_alternatif = $id 
                 ORDER BY k.id_kriteria");

// Ambil ranking
$ranking = getRow("SELECT ranking, skor_akhir FROM hasil_akhir WHERE id_alternatif = $id");
$rank = $ranking ? $ranking['ranking'] : '-';
$skor = $ranking ? (float)$ranking['skor_akhir'] : 0;

// Jika tidak ada nilai
if(empty($nilai)){
    echo '<div class="alert alert-warning">
            <i class="fas fa-info-circle"></i> 
            <strong>Belum ada penilaian!</strong> 
            <p class="mb-0">Siswa ini belum memiliki data penilaian.</p>
          </div>';
    exit;
}

// Cari max nilai per kriteria untuk normalisasi
$max_nilai = [];
foreach($nilai as $n){
    $max = getRow("SELECT MAX(nilai) as max FROM nilai_alternatif WHERE id_kriteria = (SELECT id_kriteria FROM kriteria WHERE kode_kriteria = '{$n['kode_kriteria']}')");
    $max_nilai[$n['kode_kriteria']] = $max ? (float)$max['max'] : 1;
}
?>
<div class="row">
    <div class="col-md-12">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
            <div>
                <h5 class="fw-bold text-primary">
                    <i class="fas fa-user-graduate"></i> 
                    <?php echo htmlspecialchars($siswa['nama_siswa']); ?>
                </h5>
                <p class="text-muted mb-0">
                    NIS: <?php echo htmlspecialchars($siswa['nis']); ?> | 
                    Kelas: <?php echo htmlspecialchars($siswa['kelas']); ?>
                </p>
                <p class="text-muted mb-0">
                    Ranking: <strong>#<?php echo $rank; ?></strong> | 
                    Skor: <strong><?php echo number_format($skor, 4); ?></strong>
                </p>
            </div>
            <div>
                <?php if($rank == 1): ?>
                    <span class="badge bg-warning text-dark fs-5 p-2">🏆 Juara 1</span>
                <?php elseif($rank == 2): ?>
                    <span class="badge bg-secondary text-white fs-5 p-2">🥈 Juara 2</span>
                <?php elseif($rank == 3): ?>
                    <span class="badge bg-danger text-white fs-5 p-2">🥉 Juara 3</span>
                <?php elseif($rank > 3 && $rank <= 10): ?>
                    <span class="badge bg-success text-white fs-5 p-2">⭐ Top 10</span>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Tabel Nilai -->
        <div class="table-responsive">
            <table class="table table-bordered table-hover table-striped">
                <thead class="table-primary">
                    <tr>
                        <th>Kode</th>
                        <th>Kriteria</th>
                        <th>Nilai</th>
                        <th>Max</th>
                        <th>Normalisasi</th>
                        <th>Bobot</th>
                        <th>Kontribusi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $total_kontribusi = 0;
                    foreach($nilai as $n): 
                        $max = $max_nilai[$n['kode_kriteria']] ?? 1;
                        $normal = $max > 0 ? round($n['nilai'] / $max, 4) : 0;
                        $kontribusi = round($n['bobot'] * $normal, 4);
                        $total_kontribusi += $kontribusi;
                    ?>
                    <tr>
                        <td class="text-center"><strong><?php echo $n['kode_kriteria']; ?></strong></td>
                        <td><?php echo htmlspecialchars($n['nama_kriteria']); ?></td>
                        <td class="text-center fw-bold"><?php echo number_format($n['nilai'], 2); ?></td>
                        <td class="text-center"><?php echo number_format($max, 2); ?></td>
                        <td class="text-center"><?php echo number_format($normal, 4); ?></td>
                        <td class="text-center"><?php echo number_format($n['bobot'], 3); ?></td>
                        <td>
                            <div class="d-flex align-items-center">
                                <div class="progress flex-grow-1 me-2" style="height:8px;">
                                    <div class="progress-bar bg-primary" style="width:<?php echo ($skor > 0) ? min(($kontribusi / $skor) * 100, 100) : 0; ?>%;"></div>
                                </div>
                                <span class="small text-nowrap"><?php echo number_format($kontribusi, 4); ?></span>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot class="table-secondary">
                    <tr>
                        <td colspan="6" class="text-end fw-bold">Total Skor:</td>
                        <td class="text-center fw-bold text-primary"><?php echo number_format($total_kontribusi, 4); ?></td>
                    </tr>
                </tfoot>
            </table>
        </div>
        
        <!-- Predikat -->
        <div class="mt-3 p-3 bg-light rounded">
            <div class="d-flex flex-wrap align-items-center gap-2">
                <strong>Predikat:</strong>
                <?php if($rank == 1): ?>
                    <span class="badge bg-warning text-dark fs-6 p-2">🏆 SISWA TELADAN TERBAIK</span>
                <?php elseif($rank <= 3): ?>
                    <span class="badge bg-success fs-6 p-2">⭐ JUARA</span>
                <?php elseif($rank <= 10): ?>
                    <span class="badge bg-info fs-6 p-2">📊 TOP 10</span>
                <?php else: ?>
                    <span class="badge bg-secondary fs-6 p-2">ALTERNATIF</span>
                <?php endif; ?>
            </div>
            
            <?php if($rank == 1): ?>
            <div class="mt-2">
                <i class="fas fa-info-circle text-warning"></i>
                <small class="text-muted">Selamat! Siswa ini terpilih sebagai Siswa Teladan Terbaik.</small>
            </div>
            <?php endif; ?>
        </div>
        
        <!-- Tombol Tutup -->
        <div class="mt-3 text-end">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                <i class="fas fa-times"></i> Tutup
            </button>
        </div>
    </div>
</div>