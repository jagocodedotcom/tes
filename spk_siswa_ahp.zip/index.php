<?php
require_once 'config/database.php';
session_start();
if(!isset($_SESSION['user_id'])){header('Location: login.php');exit;}
include 'includes/header.php';

// ============================================
// AMBIL DATA STATISTIK
// ============================================
$total_siswa = getRow("SELECT COUNT(*) as total FROM alternatif")['total'] ?? 0;
$total_kriteria = getRow("SELECT COUNT(*) as total FROM kriteria")['total'] ?? 0;
$total_penilaian = getRow("SELECT COUNT(*) as total FROM nilai_alternatif")['total'] ?? 0;
$total_ranking = getRow("SELECT COUNT(*) as total FROM hasil_akhir")['total'] ?? 0;
$total_user = getRow("SELECT COUNT(*) as total FROM users")['total'] ?? 0;

// Ambil juara 1
$juara1 = getRow("SELECT a.nama_siswa, a.kelas, a.nis, h.skor_akhir 
                  FROM hasil_akhir h 
                  JOIN alternatif a ON h.id_alternatif = a.id_alternatif 
                  WHERE h.ranking = 1") ?? null;

// Ambil 5 siswa terbaik
$top5 = getAll("SELECT a.nama_siswa, a.kelas, h.skor_akhir, h.ranking 
                FROM hasil_akhir h 
                JOIN alternatif a ON h.id_alternatif = a.id_alternatif 
                ORDER BY h.ranking ASC LIMIT 5");

// Ambil bobot kriteria
$bobot = getAll("SELECT kode_kriteria, nama_kriteria, bobot FROM kriteria WHERE bobot > 0 ORDER BY bobot DESC");

// Cek status data
$status_data = [
    'siswa' => $total_siswa > 0,
    'kriteria' => $total_kriteria > 0,
    'penilaian' => $total_penilaian > 0,
    'bobot' => count($bobot) > 0,
    'ranking' => $total_ranking > 0
];

// Hitung progress
$step_selesai = 0;
$step_total = 5;
if($status_data['siswa']) $step_selesai++;
if($status_data['kriteria']) $step_selesai++;
if($status_data['penilaian']) $step_selesai++;
if($status_data['bobot']) $step_selesai++;
if($status_data['ranking']) $step_selesai++;
$progress = round(($step_selesai / $step_total) * 100);

// Cek matriks perbandingan
$matriks_count = getRow("SELECT COUNT(*) as total FROM matriks_perbandingan")['total'] ?? 0;
$status_data['matriks'] = $matriks_count > 0;
?>
<div class="fade-in">

<!-- ============================================ -->
<!-- HEADER -->
<!-- ============================================ -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h4 class="fw-bold text-primary mb-0">
            <i class="fas fa-home"></i> Dashboard
        </h4>
        <small class="text-muted">Selamat datang, <?php echo htmlspecialchars($_SESSION['nama_lengkap']); ?></small>
    </div>
    <div>
        <span class="badge bg-primary p-2">
            <i class="fas fa-calendar"></i> <?php echo date('d F Y'); ?>
        </span>
    </div>
</div>

<!-- ============================================ -->
<!-- STATISTIK CARD -->
<!-- ============================================ -->
<div class="row g-4 mb-4">
    <div class="col-lg-3 col-md-6">
        <div class="stat-card">
            <div class="row align-items-center">
                <div class="col-8">
                    <div class="stat-number"><?php echo number_format($total_siswa); ?></div>
                    <div class="stat-label"><i class="fas fa-users me-1"></i> Total Siswa</div>
                </div>
                <div class="col-4 text-end">
                    <i class="fas fa-users stat-icon"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="stat-card" style="border-left-color: #28a745;">
            <div class="row align-items-center">
                <div class="col-8">
                    <div class="stat-number"><?php echo number_format($total_kriteria); ?></div>
                    <div class="stat-label"><i class="fas fa-list me-1"></i> Total Kriteria</div>
                </div>
                <div class="col-4 text-end">
                    <i class="fas fa-list stat-icon" style="color:#28a745;"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="stat-card" style="border-left-color: #ffc107;">
            <div class="row align-items-center">
                <div class="col-8">
                    <div class="stat-number"><?php echo number_format($total_penilaian); ?></div>
                    <div class="stat-label"><i class="fas fa-edit me-1"></i> Total Penilaian</div>
                </div>
                <div class="col-4 text-end">
                    <i class="fas fa-edit stat-icon" style="color:#ffc107;"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="stat-card" style="border-left-color: #17a2b8;">
            <div class="row align-items-center">
                <div class="col-8">
                    <div class="stat-number"><?php echo number_format($total_ranking); ?></div>
                    <div class="stat-label"><i class="fas fa-trophy me-1"></i> Sudah Diranking</div>
                </div>
                <div class="col-4 text-end">
                    <i class="fas fa-trophy stat-icon" style="color:#17a2b8;"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- JUARA 1 BANNER -->
<!-- ============================================ -->
<?php if($juara1): ?>
<div class="card mb-4" style="background:linear-gradient(135deg,#f8b739,#f5a623);border:none;">
    <div class="card-body text-white">
        <div class="row align-items-center">
            <div class="col-auto">
                <i class="fas fa-crown fa-4x"></i>
            </div>
            <div class="col">
                <h5 class="mb-0 fw-bold">🏆 SISWA TELADAN TERBAIK</h5>
                <h2 class="mb-0 fw-bold"><?php echo htmlspecialchars($juara1['nama_siswa']); ?></h2>
                <p class="mb-0">
                    Kelas <?php echo htmlspecialchars($juara1['kelas']); ?> | 
                    NIS: <?php echo htmlspecialchars($juara1['nis']); ?> | 
                    Skor: <?php echo number_format($juara1['skor_akhir'], 4); ?>
                </p>
            </div>
            <div class="col-auto ms-auto">
                <span class="badge bg-light text-dark fs-5 p-3">#1</span>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- ============================================ -->
<!-- RINGKASAN DATA -->
<!-- ============================================ -->
<div class="row g-4 mb-4">
    <div class="col-lg-6">

        
        <div class="table-container">
            <h6 class="fw-bold mb-3"><i class="fas fa-database"></i> Ringkasan Data</h6>
            <div class="table-responsive">
                <table class="table table-bordered">

                    <tbody>
                        <tr>
                            <td><i class="fas fa-users text-primary"></i> <strong>Siswa</strong></td>
                            <td class="text-end"><?php echo number_format($total_siswa); ?> orang</td>
                            <td>
                                <?php if($total_siswa > 0): ?>
                                    <span class="badge bg-success"><i class="fas fa-check"></i> Terisi</span>
                                <?php else: ?>
                                    <span class="badge bg-danger"><i class="fas fa-times"></i> Kosong</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr><!-- Di bagian header atau quick action -->
<button class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#modalAHP">
    <i class="fas fa-book"></i> Step by Step AHP
</button>
                            <td><i class="fas fa-list text-success"></i> <strong>Kriteria</strong></td>
                            <td class="text-end"><?php echo number_format($total_kriteria); ?> kriteria</td>
                            <td>
                                <?php if($total_kriteria > 0): ?>
                                    <span class="badge bg-success"><i class="fas fa-check"></i> Terisi</span>
                                <?php else: ?>
                                    <span class="badge bg-danger"><i class="fas fa-times"></i> Kosong</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td><i class="fas fa-edit text-warning"></i> <strong>Penilaian</strong></td>
                            <td class="text-end"><?php echo number_format($total_penilaian); ?> data</td>
                            <td>
                                <?php if($total_penilaian > 0): ?>
                                    <span class="badge bg-success"><i class="fas fa-check"></i> Terisi</span>
                                <?php else: ?>
                                    <span class="badge bg-danger"><i class="fas fa-times"></i> Kosong</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td><i class="fas fa-balance-scale text-info"></i> <strong>Perbandingan (Matriks)</strong></td>
                            <td class="text-end"><?php echo number_format($matriks_count); ?> data</td>
                            <td>
                                <?php if($matriks_count > 0): ?>
                                    <span class="badge bg-success"><i class="fas fa-check"></i> Terisi</span>
                                <?php else: ?>
                                    <span class="badge bg-danger"><i class="fas fa-times"></i> Kosong</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td><i class="fas fa-trophy text-danger"></i> <strong>Hasil Ranking</strong></td>
                            <td class="text-end"><?php echo number_format($total_ranking); ?> siswa</td>
                            <td>
                                <?php if($total_ranking > 0): ?>
                                    <span class="badge bg-success"><i class="fas fa-check"></i> Selesai</span>
                                <?php else: ?>
                                    <span class="badge bg-warning"><i class="fas fa-clock"></i> Belum</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <div class="col-lg-6">
        <div class="table-container">
            <h6 class="fw-bold mb-3"><i class="fas fa-chart-pie"></i> Progress Sistem</h6>
            <div class="text-center mb-3">
                <div style="position:relative;display:inline-block;">
                    <canvas id="progressChart" width="150" height="150"></canvas>
                    <div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);font-size:24px;font-weight:700;color:#1a2744;">
                        <?php echo $progress; ?>%
                    </div>
                </div>
                <p class="text-muted small mt-2"><?php echo $step_selesai; ?> dari <?php echo $step_total; ?> langkah selesai</p>
            </div>
            
            <!-- Step by Step -->
            <div class="mt-3">
                <h6 class="fw-bold mb-3"><i class="fas fa-list-ol"></i> Step by Step</h6>
                
                <!-- Step 1: Input Siswa -->
                <div class="d-flex align-items-center mb-2 p-2 rounded <?php echo $status_data['siswa'] ? 'bg-light' : 'bg-light'; ?>">
                    <div class="me-3">
                        <span class="badge <?php echo $status_data['siswa'] ? 'bg-success' : 'bg-secondary'; ?>" style="width:30px;height:30px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:14px;">
                            1
                        </span>
                    </div>
                    <div class="flex-grow-1">
                        <strong>Input Data Siswa</strong>
                        <small class="d-block text-muted">Masukkan data siswa yang akan dinilai</small>
                    </div>
                    <div>
                        <?php if($status_data['siswa']): ?>
                            <span class="badge bg-success"><i class="fas fa-check"></i> <?php echo $total_siswa; ?> siswa</span>
                            <a href="modules/alternatif/index.php" class="btn btn-sm btn-primary ms-2"><i class="fas fa-eye"></i></a>
                        <?php else: ?>
                            <span class="badge bg-secondary"><i class="fas fa-clock"></i> Belum</span>
                            <a href="modules/alternatif/tambah.php" class="btn btn-sm btn-primary ms-2"><i class="fas fa-plus"></i></a>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Step 2: Input Kriteria -->
                <div class="d-flex align-items-center mb-2 p-2 rounded <?php echo $status_data['kriteria'] ? 'bg-light' : 'bg-light'; ?>">
                    <div class="me-3">
                        <span class="badge <?php echo $status_data['kriteria'] ? 'bg-success' : 'bg-secondary'; ?>" style="width:30px;height:30px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:14px;">
                            2
                        </span>
                    </div>
                    <div class="flex-grow-1">
                        <strong>Input Kriteria Penilaian</strong>
                        <small class="d-block text-muted">Tentukan kriteria yang akan digunakan</small>
                    </div>
                    <div>
                        <?php if($status_data['kriteria']): ?>
                            <span class="badge bg-success"><i class="fas fa-check"></i> <?php echo $total_kriteria; ?> kriteria</span>
                            <a href="modules/kriteria/index.php" class="btn btn-sm btn-primary ms-2"><i class="fas fa-eye"></i></a>
                        <?php else: ?>
                            <span class="badge bg-secondary"><i class="fas fa-clock"></i> Belum</span>
                            <a href="modules/kriteria/tambah.php" class="btn btn-sm btn-primary ms-2"><i class="fas fa-plus"></i></a>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Step 3: Perbandingan Kriteria (AHP) -->
                <div class="d-flex align-items-center mb-2 p-2 rounded <?php echo $status_data['matriks'] ? 'bg-light' : 'bg-light'; ?>">
                    <div class="me-3">
                        <span class="badge <?php echo $status_data['matriks'] ? 'bg-success' : 'bg-secondary'; ?>" style="width:30px;height:30px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:14px;">
                            3
                        </span>
                    </div>
                    <div class="flex-grow-1">
                        <strong>Perbandingan Kriteria (AHP)</strong>
                        <small class="d-block text-muted">Lakukan perbandingan berpasangan antar kriteria</small>
                    </div>
                    <div>
                        <?php if($status_data['matriks']): ?>
                            <span class="badge bg-success"><i class="fas fa-check"></i> <?php echo $matriks_count; ?> data</span>
                            <a href="modules/perbandingan/index.php" class="btn btn-sm btn-primary ms-2"><i class="fas fa-eye"></i></a>
                        <?php else: ?>
                            <span class="badge bg-secondary"><i class="fas fa-clock"></i> Belum</span>
                            <a href="modules/perbandingan/index.php" class="btn btn-sm btn-primary ms-2"><i class="fas fa-arrow-right"></i></a>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Step 4: Input Penilaian -->
                <div class="d-flex align-items-center mb-2 p-2 rounded <?php echo $status_data['penilaian'] ? 'bg-light' : 'bg-light'; ?>">
                    <div class="me-3">
                        <span class="badge <?php echo $status_data['penilaian'] ? 'bg-success' : 'bg-secondary'; ?>" style="width:30px;height:30px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:14px;">
                            4
                        </span>
                    </div>
                    <div class="flex-grow-1">
                        <strong>Input Penilaian Siswa</strong>
                        <small class="d-block text-muted">Masukkan nilai setiap siswa untuk setiap kriteria</small>
                    </div>
                    <div>
                        <?php if($status_data['penilaian']): ?>
                            <span class="badge bg-success"><i class="fas fa-check"></i> <?php echo $total_penilaian; ?> data</span>
                            <a href="modules/penilaian/index.php" class="btn btn-sm btn-primary ms-2"><i class="fas fa-eye"></i></a>
                        <?php else: ?>
                            <span class="badge bg-secondary"><i class="fas fa-clock"></i> Belum</span>
                            <a href="modules/penilaian/tambah.php" class="btn btn-sm btn-primary ms-2"><i class="fas fa-plus"></i></a>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Step 5: Hitung Ranking -->
                <div class="d-flex align-items-center mb-2 p-2 rounded <?php echo $status_data['ranking'] ? 'bg-light' : 'bg-light'; ?>">
                    <div class="me-3">
                        <span class="badge <?php echo $status_data['ranking'] ? 'bg-success' : 'bg-secondary'; ?>" style="width:30px;height:30px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:14px;">
                            5
                        </span>
                    </div>
                    <div class="flex-grow-1">
                        <strong>Hitung & Lihat Ranking</strong>
                        <small class="d-block text-muted">Proses AHP dan lihat hasil perankingan</small>
                    </div>
                    <div>
                        <?php if($status_data['ranking']): ?>
                            <span class="badge bg-success"><i class="fas fa-check"></i> <?php echo $total_ranking; ?> siswa</span>
                            <a href="modules/hasil/index.php" class="btn btn-sm btn-primary ms-2"><i class="fas fa-eye"></i></a>
                        <?php else: ?>
                            <span class="badge bg-secondary"><i class="fas fa-clock"></i> Belum</span>
                            <a href="modules/hasil/index.php" class="btn btn-sm btn-primary ms-2"><i class="fas fa-arrow-right"></i></a>
                        <?php endif; ?>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- TOP 5 SISWA & BOBOT KRITERIA -->
<!-- ============================================ -->
<div class="row g-4">
    <div class="col-lg-6">
        <div class="table-container">
            <h6 class="fw-bold mb-3"><i class="fas fa-trophy"></i> Top 5 Siswa Terbaik</h6>
            <?php if(!empty($top5)): ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Rank</th>
                            <th>Nama Siswa</th>
                            <th>Kelas</th>
                            <th>Skor</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($top5 as $row): ?>
                        <tr>
                            <td>
                                <?php if($row['ranking']==1): ?>🥇
                                <?php elseif($row['ranking']==2): ?>🥈
                                <?php elseif($row['ranking']==3): ?>🥉
                                <?php else: ?>#<?php echo $row['ranking']; ?>
                                <?php endif; ?>
                            </td>
                            <td><?php echo htmlspecialchars($row['nama_siswa']); ?></td>
                            <td><?php echo htmlspecialchars($row['kelas']); ?></td>
                            <td><?php echo number_format($row['skor_akhir'], 4); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="text-center text-muted py-3">
                <i class="fas fa-info-circle"></i> Belum ada data ranking.
                <a href="modules/hasil/index.php?action=hitung" class="btn btn-sm btn-primary ms-2">Hitung Ranking</a>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="col-lg-6">
        <div class="table-container">
            <h6 class="fw-bold mb-3"><i class="fas fa-weight"></i> Bobot Kriteria AHP</h6>
            <?php if(!empty($bobot)): ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Kode</th>
                            <th>Kriteria</th>
                            <th>Bobot</th>
                            <th>Persentase</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($bobot as $row): ?>
                        <tr>
                            <td><strong><?php echo $row['kode_kriteria']; ?></strong></td>
                            <td><?php echo htmlspecialchars($row['nama_kriteria']); ?></td>
                            <td><?php echo number_format($row['bobot'], 3); ?></td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="progress flex-grow-1 me-2" style="height:8px;">
                                        <div class="progress-bar bg-primary" style="width:<?php echo $row['bobot']*100; ?>%;"></div>
                                    </div>
                                    <span><?php echo number_format($row['bobot']*100, 1); ?>%</span>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="text-center text-muted py-3">
                <i class="fas fa-info-circle"></i> Belum ada bobot kriteria.
                <a href="modules/perbandingan/index.php" class="btn btn-sm btn-primary ms-2">Buat Perbandingan</a>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- QUICK ACTION -->
<!-- ============================================ -->
<div class="row g-3 mt-3">
    <div class="col-md-2 col-4">
        <a href="modules/alternatif/tambah.php" class="btn btn-primary w-100 py-3">
            <i class="fas fa-user-plus"></i><br>
            <small>Tambah Siswa</small>
        </a>
    </div>
    <div class="col-md-2 col-4">
        <a href="modules/kriteria/tambah.php" class="btn btn-success w-100 py-3">
            <i class="fas fa-plus-circle"></i><br>
            <small>Tambah Kriteria</small>
        </a>
    </div>
    <div class="col-md-2 col-4">
        <a href="modules/penilaian/tambah.php" class="btn btn-warning w-100 py-3">
            <i class="fas fa-edit"></i><br>
            <small>Input Nilai</small>
        </a>
    </div>
    <div class="col-md-2 col-4">
        <a href="modules/perbandingan/index.php" class="btn btn-info w-100 py-3">
            <i class="fas fa-balance-scale"></i><br>
            <small>Perbandingan</small>
        </a>
    </div>
    <div class="col-md-2 col-4">
        <a href="modules/hasil/index.php" class="btn btn-danger w-100 py-3">
            <i class="fas fa-trophy"></i><br>
            <small>Lihat Hasil</small>
        </a>
    </div>
    <div class="col-md-2 col-4">
        <a href="modules/hasil/index.php?action=hitung" class="btn btn-secondary w-100 py-3">
            <i class="fas fa-calculator"></i><br>
            <small>Hitung Ranking</small>
        </a>
    </div>
</div>

</div>
<!-- ============================================ -->
<!-- MODAL STEP BY STEP AHP -->
<!-- ============================================ -->
<div class="modal fade" id="modalAHP" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title"><i class="fas fa-book"></i> Step by Step Metode AHP</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" style="max-height:70vh;overflow-y:auto;">
                
                <!-- ============================================ -->
                <!-- STEP 1: PEMAHAMAN DASAR AHP -->
                <!-- ============================================ -->
                <div class="card mb-4 border-primary">
                    <div class="card-header bg-primary text-white">
                        <h6 class="mb-0 fw-bold"><span class="badge bg-light text-primary me-2">1</span> Pengertian AHP</h6>
                    </div>
                    <div class="card-body">
                        <p><strong>AHP (Analytical Hierarchy Process)</strong> adalah metode pengambilan keputusan yang dikembangkan oleh <strong>Thomas L. Saaty</strong> pada tahun 1970.</p>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="alert alert-info">
                                    <strong>📌 Tujuan AHP:</strong>
                                    <ul class="mb-0">
                                        <li>Memecahkan masalah kompleks menjadi struktur hierarki</li>
                                        <li>Membandingkan kriteria secara berpasangan</li>
                                        <li>Menghasilkan bobot kepentingan yang objektif</li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="alert alert-success">
                                    <strong>✅ Keunggulan AHP:</strong>
                                    <ul class="mb-0">
                                        <li>Mengukur konsistensi penilaian</li>
                                        <li>Menggabungkan data kualitatif & kuantitatif</li>
                                        <li>Hasil dapat dipertanggungjawabkan</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ============================================ -->
                <!-- STEP 2: STRUKTUR HIERARKI -->
                <!-- ============================================ -->
                <div class="card mb-4 border-success">
                    <div class="card-header bg-success text-white">
                        <h6 class="mb-0 fw-bold"><span class="badge bg-light text-success me-2">2</span> Struktur Hierarki</h6>
                    </div>
                    <div class="card-body">
                        <p>Struktur hierarki AHP terdiri dari 3 tingkatan:</p>
                        <div class="row text-center">
                            <div class="col-md-4">
                                <div class="p-3 bg-light rounded">
                                    <h5 class="fw-bold text-primary">🎯 Tujuan</h5>
                                    <p class="mb-0"><small>Pemilihan Siswa Teladan</small></p>
                                </div>
                                <div class="text-center my-2">⬇</div>
                            </div>
                            <div class="col-md-4">
                                <div class="p-3 bg-light rounded">
                                    <h5 class="fw-bold text-success">📋 Kriteria</h5>
                                    <p class="mb-0">
                                        <small>
                                            C1: Akademik<br>
                                            C2: Non-Akademik<br>
                                            C3: Sikap<br>
                                            C4: Kehadiran<br>
                                            C5: Sosial
                                        </small>
                                    </p>
                                </div>
                                <div class="text-center my-2">⬇</div>
                            </div>
                            <div class="col-md-4">
                                <div class="p-3 bg-light rounded">
                                    <h5 class="fw-bold text-warning">👨‍🎓 Alternatif</h5>
                                    <p class="mb-0"><small>20 Siswa yang dinilai</small></p>
                                </div>
                            </div>
                        </div>
                        <div class="alert alert-secondary mt-3">
                            <strong>💡 Contoh di Sistem Ini:</strong>
                            <ul class="mb-0">
                                <li><strong>Tujuan:</strong> Memilih Siswa Teladan Terbaik</li>
                                <li><strong>Kriteria:</strong> 5 kriteria (Akademik, Non-Akademik, Sikap, Kehadiran, Sosial)</li>
                                <li><strong>Alternatif:</strong> 20 siswa yang mendaftar</li>
                            </ul>
                        </div>
                    </div>
                </div>

                <!-- ============================================ -->
                <!-- STEP 3: SKALA PERBANDINGAN SAATY -->
                <!-- ============================================ -->
                <div class="card mb-4 border-warning">
                    <div class="card-header bg-warning text-dark">
                        <h6 class="mb-0 fw-bold"><span class="badge bg-dark text-warning me-2">3</span> Skala Perbandingan Saaty</h6>
                    </div>
                    <div class="card-body">
                        <p>Skala 1-9 digunakan untuk menilai tingkat kepentingan:</p>
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover">
                                <thead class="table-warning">
                                    <tr>
                                        <th>Nilai</th>
                                        <th>Keterangan</th>
                                        <th>Contoh Penerapan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="text-center fw-bold">1</td>
                                        <td>Kedua elemen <strong>sama penting</strong></td>
                                        <td>Akademik = Non-Akademik</td>
                                    </tr>
                                    <tr>
                                        <td class="text-center fw-bold">3</td>
                                        <td>Elemen satu <strong>sedikit lebih penting</strong></td>
                                        <td>Akademik 3x > Non-Akademik</td>
                                    </tr>
                                    <tr>
                                        <td class="text-center fw-bold">5</td>
                                        <td>Elemen satu <strong>lebih penting</strong></td>
                                        <td>Akademik 5x > Sikap</td>
                                    </tr>
                                    <tr>
                                        <td class="text-center fw-bold">7</td>
                                        <td>Elemen satu <strong>sangat lebih penting</strong></td>
                                        <td>Akademik 7x > Sosial</td>
                                    </tr>
                                    <tr>
                                        <td class="text-center fw-bold">9</td>
                                        <td>Elemen satu <strong>mutlak lebih penting</strong></td>
                                        <td>Akademik 9x > Sikap</td>
                                    </tr>
                                    <tr>
                                        <td class="text-center fw-bold">2,4,6,8</td>
                                        <td>Nilai <strong>tengah</strong> antara dua penilaian</td>
                                        <td>Akademik 4x > Non-Akademik</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="alert alert-info">
                            <strong>📝 Catatan:</strong> Jika C1 3x lebih penting dari C2, maka C2 1/3 dari C1 (reciprocal).
                        </div>
                    </div>
                </div>

                <!-- ============================================ -->
                <!-- STEP 4: MATRIKS PERBANDINGAN -->
                <!-- ============================================ -->
                <div class="card mb-4 border-info">
                    <div class="card-header bg-info text-white">
                        <h6 class="mb-0 fw-bold"><span class="badge bg-light text-info me-2">4</span> Matriks Perbandingan Berpasangan</h6>
                    </div>
                    <div class="card-body">
                        <p>Membandingkan setiap pasangan kriteria (n × n matriks):</p>
                        <div class="table-responsive">
                            <table class="table table-bordered text-center">
                                <thead class="table-info">
                                    <tr>
                                        <th>Kriteria</th>
                                        <th>C1</th>
                                        <th>C2</th>
                                        <th>C3</th>
                                        <th>C4</th>
                                        <th>C5</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><strong>C1</strong></td>
                                        <td>1</td>
                                        <td>3</td>
                                        <td>5</td>
                                        <td>2</td>
                                        <td>4</td>
                                    </tr>
                                    <tr>
                                        <td><strong>C2</strong></td>
                                        <td>1/3</td>
                                        <td>1</td>
                                        <td>4</td>
                                        <td>1/2</td>
                                        <td>2</td>
                                    </tr>
                                    <tr>
                                        <td><strong>C3</strong></td>
                                        <td>1/5</td>
                                        <td>1/4</td>
                                        <td>1</td>
                                        <td>1/4</td>
                                        <td>1/2</td>
                                    </tr>
                                    <tr>
                                        <td><strong>C4</strong></td>
                                        <td>1/2</td>
                                        <td>2</td>
                                        <td>4</td>
                                        <td>1</td>
                                        <td>3</td>
                                    </tr>
                                    <tr>
                                        <td><strong>C5</strong></td>
                                        <td>1/4</td>
                                        <td>1/2</td>
                                        <td>2</td>
                                        <td>1/3</td>
                                        <td>1</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="alert alert-secondary">
                            <strong>🔍 Cara Membaca:</strong>
                            <ul class="mb-0">
                                <li><strong>C1 vs C2 = 3</strong> → C1 3x lebih penting dari C2</li>
                                <li><strong>C2 vs C1 = 1/3</strong> → C2 1/3 dari C1 (reciprocal)</li>
                                <li><strong>Diagonal = 1</strong> → Kriteria dibandingkan dengan dirinya sendiri</li>
                            </ul>
                        </div>
                    </div>
                </div>

                <!-- ============================================ -->
                <!-- STEP 5: NORMALISASI & BOBOT -->
                <!-- ============================================ -->
                <div class="card mb-4 border-danger">
                    <div class="card-header bg-danger text-white">
                        <h6 class="mb-0 fw-bold"><span class="badge bg-light text-danger me-2">5</span> Normalisasi & Perhitungan Bobot</h6>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <h6 class="fw-bold">📊 Matriks Normalisasi</h6>
                                <div class="table-responsive">
                                    <table class="table table-bordered text-center table-sm">
                                        <thead class="table-danger">
                                            <tr><th></th><th>C1</th><th>C2</th><th>C3</th><th>C4</th><th>C5</th><th>Bobot</th></tr>
                                        </thead>
                                        <tbody>
                                            <tr><td><strong>C1</strong></td><td>0.43</td><td>0.44</td><td>0.33</td><td>0.49</td><td>0.38</td><td><strong>0.414</strong></td></tr>
                                            <tr><td><strong>C2</strong></td><td>0.14</td><td>0.15</td><td>0.20</td><td>0.12</td><td>0.19</td><td><strong>0.160</strong></td></tr>
                                            <tr><td><strong>C3</strong></td><td>0.09</td><td>0.05</td><td>0.07</td><td>0.06</td><td>0.05</td><td><strong>0.064</strong></td></tr>
                                            <tr><td><strong>C4</strong></td><td>0.22</td><td>0.29</td><td>0.27</td><td>0.24</td><td>0.29</td><td><strong>0.262</strong></td></tr>
                                            <tr><td><strong>C5</strong></td><td>0.11</td><td>0.07</td><td>0.13</td><td>0.08</td><td>0.10</td><td><strong>0.098</strong></td></tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <h6 class="fw-bold">📈 Hasil Bobot Kriteria</h6>
                                <div class="mt-3">
                                    <div class="mb-2">
                                        <strong>C1 - Akademik</strong>
                                        <div class="progress" style="height:25px;">
                                            <div class="progress-bar bg-primary" style="width:41.4%;">41.4%</div>
                                        </div>
                                    </div>
                                    <div class="mb-2">
                                        <strong>C2 - Non-Akademik</strong>
                                        <div class="progress" style="height:25px;">
                                            <div class="progress-bar bg-success" style="width:16.0%;">16.0%</div>
                                        </div>
                                    </div>
                                    <div class="mb-2">
                                        <strong>C3 - Sikap</strong>
                                        <div class="progress" style="height:25px;">
                                            <div class="progress-bar bg-warning" style="width:6.4%;">6.4%</div>
                                        </div>
                                    </div>
                                    <div class="mb-2">
                                        <strong>C4 - Kehadiran</strong>
                                        <div class="progress" style="height:25px;">
                                            <div class="progress-bar bg-info" style="width:26.2%;">26.2%</div>
                                        </div>
                                    </div>
                                    <div class="mb-2">
                                        <strong>C5 - Sosial</strong>
                                        <div class="progress" style="height:25px;">
                                            <div class="progress-bar bg-danger" style="width:9.8%;">9.8%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="alert alert-success mt-3">
                            <strong>📝 Rumus Normalisasi:</strong>
                            <code>Nilai Normalisasi = Nilai / Jumlah Kolom</code><br>
                            <strong>Rumus Bobot:</strong>
                            <code>Bobot = Rata-rata per Baris</code>
                        </div>
                    </div>
                </div>

                <!-- ============================================ -->
                <!-- STEP 6: UJI KONSISTENSI -->
                <!-- ============================================ -->
                <div class="card mb-4 border-dark">
                    <div class="card-header bg-dark text-white">
                        <h6 class="mb-0 fw-bold"><span class="badge bg-light text-dark me-2">6</span> Uji Konsistensi (Consistency Ratio)</h6>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <h6 class="fw-bold">📋 Rumus Uji Konsistensi</h6>
                                <div class="p-3 bg-light rounded">
                                    <p><strong>λmax (Eigen Value Maksimum):</strong></p>
                                    <code>λmax = Σ (Total Baris × Bobot) / Bobot</code>
                                    <hr>
                                    <p><strong>CI (Consistency Index):</strong></p>
                                    <code>CI = (λmax - n) / (n - 1)</code>
                                    <hr>
                                    <p><strong>CR (Consistency Ratio):</strong></p>
                                    <code>CR = CI / RI</code>
                                    <hr>
                                    <p><strong>Syarat:</strong> CR ≤ 0.1 (10%) → <span class="text-success">KONSISTEN ✅</span></p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <h6 class="fw-bold">📊 Tabel Random Index (RI)</h6>
                                <div class="table-responsive">
                                    <table class="table table-bordered text-center">
                                        <thead class="table-dark">
                                            <tr>
                                                <th>n</th>
                                                <th>1</th><th>2</th><th>3</th><th>4</th><th>5</th>
                                                <th>6</th><th>7</th><th>8</th><th>9</th><th>10</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td><strong>RI</strong></td>
                                                <td>0</td><td>0</td><td>0.58</td><td>0.90</td><td>1.12</td>
                                                <td>1.24</td><td>1.32</td><td>1.41</td><td>1.45</td><td>1.49</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="alert alert-success mt-2">
                                    <strong>✅ Contoh di Sistem Ini:</strong>
                                    <ul class="mb-0">
                                        <li>λmax = 5.12</li>
                                        <li>CI = (5.12 - 5) / (5 - 1) = 0.03</li>
                                        <li>CR = 0.03 / 1.12 = <strong>0.027 = 2.7%</strong></li>
                                        <li><span class="badge bg-success">KONSISTEN ✅ (CR ≤ 10%)</span></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ============================================ -->
                <!-- STEP 7: PERHITUNGAN SKOR & RANKING -->
                <!-- ============================================ -->
                <div class="card mb-4 border-purple" style="border-color:#6f42c1;">
                    <div class="card-header" style="background:#6f42c1;color:white;">
                        <h6 class="mb-0 fw-bold"><span class="badge bg-light text-purple me-2" style="color:#6f42c1;">7</span> Perhitungan Skor & Ranking</h6>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <h6 class="fw-bold">📋 Rumus Skor Akhir</h6>
                                <div class="p-3 bg-light rounded">
                                    <code>
                                        Skor = Σ (Bobot Kriteria × Nilai Normalisasi)
                                    </code>
                                    <hr>
                                    <p><strong>Contoh Perhitungan:</strong></p>
                                    <table class="table table-sm table-bordered">
                                        <thead>
                                            <tr><th>Kriteria</th><th>Bobot</th><th>Nilai</th><th>Normalisasi</th><th>Kontribusi</th></tr>
                                        </thead>
                                        <tbody>
                                            <tr><td>C1</td><td>0.414</td><td>92</td><td>0.95</td><td>0.393</td></tr>
                                            <tr><td>C2</td><td>0.160</td><td>85</td><td>0.87</td><td>0.139</td></tr>
                                            <tr><td>C3</td><td>0.064</td><td>90</td><td>0.95</td><td>0.061</td></tr>
                                            <tr><td>C4</td><td>0.262</td><td>95</td><td>0.97</td><td>0.254</td></tr>
                                            <tr><td>C5</td><td>0.098</td><td>75</td><td>0.81</td><td>0.079</td></tr>
                                            <tr class="table-success"><td colspan="4"><strong>Total Skor</strong></td><td><strong>0.926</strong></td></tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <h6 class="fw-bold">🏆 Hasil Ranking</h6>
                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <thead class="table-warning">
                                            <tr>
                                                <th>Rank</th>
                                                <th>Nama</th>
                                                <th>Skor</th>
                                                <th>Predikat</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr class="table-warning">
                                                <td>🥇 1</td>
                                                <td>Citra Dewi</td>
                                                <td>0.9264</td>
                                                <td><span class="badge bg-warning">🏆 Teladan</span></td>
                                            </tr>
                                            <tr class="table-light">
                                                <td>🥈 2</td>
                                                <td>Gilang Ramadhan</td>
                                                <td>0.8912</td>
                                                <td><span class="badge bg-success">⭐ Juara</span></td>
                                            </tr>
                                            <tr class="table-light">
                                                <td>🥉 3</td>
                                                <td>Larasati</td>
                                                <td>0.8756</td>
                                                <td><span class="badge bg-success">⭐ Juara</span></td>
                                            </tr>
                                            <tr>
                                                <td>4</td>
                                                <td>Ahmad Fauzi</td>
                                                <td>0.8543</td>
                                                <td><span class="badge bg-secondary">Alternatif</span></td>
                                            </tr>
                                            <tr>
                                                <td>5</td>
                                                <td>Taufik Hidayat</td>
                                                <td>0.8432</td>
                                                <td><span class="badge bg-secondary">Alternatif</span></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="alert alert-info mt-2">
                                    <strong>📝 Kesimpulan:</strong>
                                    Siswa dengan skor tertinggi terpilih sebagai <strong>Siswa Teladan</strong>.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ============================================ -->
                <!-- STEP 8: PENERAPAN DI SISTEM -->
                <!-- ============================================ -->
                <div class="card mb-4 border-success">
                    <div class="card-header bg-success text-white">
                        <h6 class="mb-0 fw-bold"><span class="badge bg-light text-success me-2">8</span> Penerapan di Sistem Ini</h6>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="card h-100">
                                    <div class="card-body text-center">
                                        <i class="fas fa-users fa-3x text-primary mb-2"></i>
                                        <h6>1. Input Data</h6>
                                        <p class="small text-muted">Masukkan data siswa dan kriteria</p>
                                        <a href="modules/alternatif/index.php" class="btn btn-sm btn-primary">Ke Modul</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card h-100">
                                    <div class="card-body text-center">
                                        <i class="fas fa-balance-scale fa-3x text-success mb-2"></i>
                                        <h6>2. Perbandingan AHP</h6>
                                        <p class="small text-muted">Lakukan perbandingan kriteria</p>
                                        <a href="modules/perbandingan/index.php" class="btn btn-sm btn-success">Ke Modul</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card h-100">
                                    <div class="card-body text-center">
                                        <i class="fas fa-trophy fa-3x text-warning mb-2"></i>
                                        <h6>3. Lihat Hasil</h6>
                                        <p class="small text-muted">Lihat perankingan siswa</p>
                                        <a href="modules/hasil/index.php" class="btn btn-sm btn-warning">Ke Modul</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" onclick="window.print()">
                    <i class="fas fa-print"></i> Cetak
                </button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    <i class="fas fa-times"></i> Tutup
                </button>
            </div>
        </div>
    </div>
</div>
<!-- ============================================ -->
<!-- SCRIPT CHART.JS -->
<!-- ============================================ -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Progress Chart (Doughnut)
    var ctx = document.getElementById('progressChart').getContext('2d');
    var progress = <?php echo $progress; ?>;
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            datasets: [{
                data: [progress, 100 - progress],
                backgroundColor: ['#28a745', '#e9ecef'],
                borderWidth: 0
            }]
        },
        options: {
            cutout: '70%',
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: { display: false }
            }
        }
    });
});
</script>

<?php include 'includes/footer.php'; ?>