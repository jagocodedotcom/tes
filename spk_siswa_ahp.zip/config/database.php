<?php
// ============================================
// KONFIGURASI DATABASE
// ============================================

// Pengaturan Database
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'spk_siswa_ahp');

// ============================================
// PENGATURAN URL - DIPAKSAKAN MANUAL
// ============================================
// Ganti dengan URL folder Anda
define('BASE_URL', 'http://localhost/spk_siswa_ahp');
define('APP_NAME', 'SPK Siswa Teladan AHP');

// ============================================
// KONEKSI DATABASE
// ============================================
$db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($db->connect_error) {
    die("Koneksi gagal: " . $db->connect_error);
}

$db->set_charset("utf8mb4");

// ============================================
// FUNGSI DATABASE
// ============================================
function query($sql) {
    global $db;
    return $db->query($sql);
}

function getRow($sql) {
    $result = query($sql);
    if ($result && $result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    return null;
}

function getAll($sql) {
    $result = query($sql);
    if ($result) {
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    return [];
}

function insertData($sql) {
    global $db;
    if ($db->query($sql)) {
        return $db->insert_id;
    }
    return false;
}

function updateData($sql) {
    global $db;
    return $db->query($sql);
}

function deleteData($sql) {
    global $db;
    return $db->query($sql);
}

function escape($str) {
    global $db;
    return $db->real_escape_string($str);
}

function sanitize($str) {
    return htmlspecialchars(strip_tags(trim($str)));
}
?>