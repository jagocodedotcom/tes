<?php
// ======================================================
// SIDEBAR - RAPI & CLEAN VERSION
// ======================================================

// Default values jika session belum set
if(!isset($_SESSION['user_role'])) {
    $_SESSION['user_role'] = 'admin';
    $_SESSION['user_fullname'] = 'Administrator';
}

$userRole = $_SESSION['user_role'];
$userFullname = $_SESSION['user_fullname'];

// Fungsi untuk menentukan warna badge role
function getRoleBadgeColor($role) {
    $colors = [
        'admin' => 'danger',
        'admin_gudang' => 'info',
        'admin_produksi' => 'warning',
        'qc' => 'success',
        'fg_admin' => 'primary'
    ];
    return isset($colors[$role]) ? $colors[$role] : 'secondary';
}
?>
<div id="sidebar-wrapper" class="bg-dark text-white">
    <!-- LOGO -->
    <div class="sidebar-heading text-center py-4 primary-text fs-4 fw-bold text-uppercase border-bottom">
        <i class="fas fa-industry me-2"></i>MPS
    </div>
    
    <!-- MENU -->
    <div class="list-group list-group-flush">
        <!-- Dashboard -->
        <!-- <a href="index.php?page=dashboard" class="list-group-item list-group-item-action bg-transparent text-white">
            <i class="fas fa-tachometer-alt me-2"></i>Dashboard
        </a> -->
        
        <!-- Master Data -->
   <!--      <a href="#masterMenu" class="list-group-item list-group-item-action bg-transparent text-white" data-bs-toggle="collapse">
            <i class="fas fa-database me-2"></i>Master Data 
            <i class="fas fa-chevron-down float-end"></i>
        </a> -->
        <div class="collapse show" id="masterMenu">
            <a href="index.php?page=customers" class="list-group-item list-group-item-action bg-transparent text-white ps-5">
                <i class="fas fa-users me-2"></i>Customers
            </a>
            <a href="index.php?page=suppliers" class="list-group-item list-group-item-action bg-transparent text-white ps-5">
                <i class="fas fa-truck me-2"></i>Suppliers
            </a>
            <a href="index.php?page=products" class="list-group-item list-group-item-action bg-transparent text-white ps-5">
                <i class="fas fa-box me-2"></i>Products
            </a>
            <a href="index.php?page=materials" class="list-group-item list-group-item-action bg-transparent text-white ps-5">
                <i class="fas fa-cubes me-2"></i>Materials
            </a>
           <!--  <a href="index.php?page=users" class="list-group-item list-group-item-action bg-transparent text-white ps-5">
                <i class="fas fa-user-cog me-2"></i>Users
            </a> -->
          <!--   <a href="index.php?page=warehouses" class="list-group-item list-group-item-action bg-transparent text-white ps-5">
                <i class="fas fa-warehouse me-2"></i>Warehouses
            </a>
            <a href="index.php?page=loading_docks" class="list-group-item list-group-item-action bg-transparent text-white ps-5">
                <i class="fas fa-anchor me-2"></i>Loading Docks
            </a> -->
        </div>
        
        <!-- Purchasing -->
       <!--  <a href="#purchaseMenu" class="list-group-item list-group-item-action bg-transparent text-white" data-bs-toggle="collapse">
            <i class="fas fa-shopping-cart me-2"></i>Purchasing 
            <i class="fas fa-chevron-down float-end"></i>
        </a> -->
        <div class="collapse show" id="purchaseMenu">
            <a href="index.php?page=purchase_orders" class="list-group-item list-group-item-action bg-transparent text-white ps-5">
                <i class="fas fa-file-invoice me-2"></i>Purchase Orders
            </a>
            <a href="index.php?page=material_receipts" class="list-group-item list-group-item-action bg-transparent text-white ps-5">
                <i class="fas fa-clipboard-check me-2"></i>Material Receipts
            </a>
        </div>
        
        <!-- Production -->
      <!--   <a href="#productionMenu" class="list-group-item list-group-item-action bg-transparent text-white" data-bs-toggle="collapse">
            <i class="fas fa-cogs me-2"></i>Production 
            <i class="fas fa-chevron-down float-end"></i>
        </a> -->
        <div class="collapse show" id="productionMenu">
            <a href="index.php?page=customer_pos" class="list-group-item list-group-item-action bg-transparent text-white ps-5">
                <i class="fas fa-file-invoice me-2"></i>Sales Orders
            </a>
            <a href="index.php?page=production_orders" class="list-group-item list-group-item-action bg-transparent text-white ps-5">
                <i class="fas fa-tasks me-2"></i>Work Orders
            </a>
            <a href="index.php?page=material_transfers" class="list-group-item list-group-item-action bg-transparent text-white ps-5">
                <i class="fas fa-arrow-right me-2"></i>Material Transfers
            </a>
            <a href="index.php?page=production_results" class="list-group-item list-group-item-action bg-transparent text-white ps-5">
                <i class="fas fa-chart-bar me-2"></i>Production Results
            </a>
            <a href="index.php?page=qc_inspections" class="list-group-item list-group-item-action bg-transparent text-white ps-5">
                <i class="fas fa-check-double me-2"></i>QC Inspections
            </a>
        </div>
        
        <!-- Finished Goods -->
    <!--     <a href="#fgMenu" class="list-group-item list-group-item-action bg-transparent text-white" data-bs-toggle="collapse">
            <i class="fas fa-boxes me-2"></i>Finished Goods 
            <i class="fas fa-chevron-down float-end"></i>
        </a> -->
        <div class="collapse show" id="fgMenu">
            <a href="index.php?page=fg_receipts" class="list-group-item list-group-item-action bg-transparent text-white ps-5">
                <i class="fas fa-clipboard-check me-2"></i>FG Receipts
            </a>
            <a href="index.php?page=fg_stock" class="list-group-item list-group-item-action bg-transparent text-white ps-5">
                <i class="fas fa-warehouse me-2"></i>FG Stock
            </a>
        </div>
        
        <!-- Inventory -->
       <!--  <a href="#inventoryMenu" class="list-group-item list-group-item-action bg-transparent text-white" data-bs-toggle="collapse">
            <i class="fas fa-chart-pie me-2"></i>Inventory 
            <i class="fas fa-chevron-down float-end"></i>
        </a> -->
        <div class="collapse show" id="inventoryMenu">
            <a href="index.php?page=inventory_transactions" class="list-group-item list-group-item-action bg-transparent text-white ps-5">
                <i class="fas fa-list me-2"></i>Transactions
            </a>
            <a href="index.php?page=material_stock" class="list-group-item list-group-item-action bg-transparent text-white ps-5">
                <i class="fas fa-cubes me-2"></i>Stock Material
            </a>
        <!--     <a href="index.php?page=fg_stock" class="list-group-item list-group-item-action bg-transparent text-white ps-5">
                <i class="fas fa-boxes me-2"></i>Stock FG
            </a> -->
        </div>
    </div>
    
    <!-- FOOTER - USER INFO & LOGOUT -->
    <div class="border-top px-3 py-2">
        <div class="d-flex align-items-center">
            <i class="fas fa-user-circle fa-2x me-2 text-primary"></i>
            <div>
                <small class="d-block text-white-50">Logged in as</small>
                <span class="fw-bold text-white"><?= htmlspecialchars($userFullname) ?></span>
                <br>
                <span class="badge bg-<?= getRoleBadgeColor($userRole) ?>">
                    <?= strtoupper(str_replace('_', ' ', $userRole)) ?>
                </span>
            </div>
        </div>
        <a href="logout.php" class="btn btn-danger btn-sm w-100 mt-2" onclick="return confirm('Yakin ingin logout?')">
            <i class="fas fa-sign-out-alt me-2"></i>Logout
        </a>
    </div>
</div>