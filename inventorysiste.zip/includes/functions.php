<?php
// ======================================================
// FUNCTIONS HELPER
// ======================================================

// ======================================================
// FORMAT FUNCTIONS
// ======================================================

function formatRupiah($amount) {
    return 'Rp ' . number_format($amount, 0, ',', '.');
}

function formatDate($date) {
    return date('d/m/Y', strtotime($date));
}

function formatDateTime($datetime) {
    return date('d/m/Y H:i', strtotime($datetime));
}

// ======================================================
// BADGE FUNCTIONS
// ======================================================

function getStatusBadge($status) {
    $badges = [
        'Open' => 'primary',
        'Running' => 'info',
        'Partial' => 'warning',
        'Completed' => 'success',
        'Cancelled' => 'danger',
        'Draft' => 'secondary',
        'Submitted' => 'info',
        'Approved' => 'success',
        'Stored' => 'success',
        'Reserved' => 'warning',
        'Delivered' => 'info',
        'Production' => 'info',
        'Pending' => 'warning',
        'Inspected' => 'success',
        'Rework' => 'warning',
        'Rejected' => 'danger',
        'Issued' => 'info',
        'Received' => 'success',
        'Critical' => 'danger',
        'Warning' => 'warning',
        'Safe' => 'success'
    ];
    
    $class = isset($badges[$status]) ? $badges[$status] : 'secondary';
    return '<span class="badge bg-' . $class . '">' . $status . '</span>';
}

function getPriorityBadge($priority) {
    $badges = [
        'Urgent' => 'danger',
        'High' => 'warning',
        'Medium' => 'info',
        'Low' => 'secondary'
    ];
    $class = isset($badges[$priority]) ? $badges[$priority] : 'secondary';
    return '<span class="badge bg-' . $class . '">' . $priority . '</span>';
}

function getShiftLabel($shift) {
    $labels = [
        'Shift 1' => 'Shift 1 (08:00-16:00)',
        'Shift 2' => 'Shift 2 (16:00-00:00)',
        'Shift 3' => 'Shift 3 (00:00-08:00)'
    ];
    return isset($labels[$shift]) ? $labels[$shift] : $shift;
}

// ======================================================
// STOCK FUNCTIONS
// ======================================================

function getStockStatus($available, $minStock) {
    if ($available <= 0) return 'Critical';
    if ($available <= $minStock) return 'Critical';
    if ($available <= $minStock * 1.5) return 'Warning';
    return 'Safe';
}

function getStockStatusClass($available, $minStock) {
    $status = getStockStatus($available, $minStock);
    $classes = [
        'Critical' => 'danger',
        'Warning' => 'warning',
        'Safe' => 'success'
    ];
    return isset($classes[$status]) ? $classes[$status] : 'secondary';
}

// ======================================================
// DATE FUNCTIONS
// ======================================================

function daysRemaining($date) {
    if (!$date) return '-';
    $now = new DateTime();
    $target = new DateTime($date);
    $diff = $now->diff($target);
    $days = (int)$diff->format('%r%a');
    
    if ($days < 0) return '<span class="text-danger">Expired</span>';
    if ($days == 0) return '<span class="text-warning">Today</span>';
    return $days . ' hari';
}

function getProgressBar($percentage) {
    $color = 'success';
    if ($percentage < 30) $color = 'danger';
    else if ($percentage < 70) $color = 'warning';
    
    return '
        <div class="progress" style="height: 20px;">
            <div class="progress-bar bg-' . $color . '" 
                 role="progressbar" 
                 style="width: ' . $percentage . '%;" 
                 aria-valuenow="' . $percentage . '" 
                 aria-valuemin="0" 
                 aria-valuemax="100">
                ' . number_format($percentage, 1) . '%
            </div>
        </div>
    ';
}

// ======================================================
// URL & NAVIGATION FUNCTIONS
// ======================================================

function isActive($page, $currentPage) {
    return ($page == $currentPage) ? 'active' : '';
}

function isActiveParent($pages, $currentPage) {
    return in_array($currentPage, $pages) ? 'show' : '';
}

function url($page, $action = '', $params = []) {
    $url = 'index.php?page=' . $page;
    if($action) {
        $url .= '&action=' . $action;
    }
    foreach($params as $key => $value) {
        $url .= '&' . $key . '=' . $value;
    }
    return $url;
}

function redirect($page, $action = '', $params = []) {
    header('Location: ' . url($page, $action, $params));
    exit;
}

// ======================================================
// JSON RESPONSE
// ======================================================

function jsonResponse($data) {
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}
?>