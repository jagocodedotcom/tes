    </div> <!-- /page-content-wrapper -->
</div> <!-- /wrapper -->

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- Custom JS -->
<script>
// Toggle sidebar on mobile
document.addEventListener('DOMContentLoaded', function() {
    // Handle sidebar collapse
    const sidebarToggle = document.querySelector('.sidebar-toggle');
    if(sidebarToggle) {
        sidebarToggle.addEventListener('click', function() {
            document.querySelector('#sidebar-wrapper').classList.toggle('toggled');
        });
    }
});
</script>
</body>
</html>