<?php
// ======================================================
// HEADER - START SESSION
// ======================================================

// Start session jika belum
if(session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Cek login - redirect jika belum login
$current_page = basename($_SERVER['PHP_SELF']);

// Jika belum login dan bukan di halaman login, redirect ke login
if(!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    if($current_page != 'login.php' && $current_page != 'logout.php') {
        header('Location: login.php');
        exit;
    }
}

// Jika sudah login dan berada di halaman login, redirect ke dashboard
if(isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    if($current_page == 'login.php') {
        header('Location: index.php');
        exit;
    }
}

// Set default jika ada data yang hilang (hanya jika sudah login)
if(isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    if(!isset($_SESSION['user_role'])) {
        $_SESSION['user_role'] = 'admin';
        $_SESSION['username'] = 'Admin';
        $_SESSION['user_fullname'] = 'Administrator';
        $_SESSION['user_email'] = 'admin@company.com';
    }
}

// ======================================================
// HAPUS: define('BASE_URL', ''); 
// BASE_URL SUDAH DITENTUKAN DI INDEX.PHP
// ======================================================
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Sistem Manajemen Produksi</title>
    
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>
    <div class="d-flex" id="wrapper">