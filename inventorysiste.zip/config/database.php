<?php
// ======================================================
// KONFIGURASI DATABASE
// ======================================================

define('DB_HOST', 'localhost');
define('DB_NAME', 'inventory_db');
define('DB_USER', 'root');
define('DB_PASS', '');

// Koneksi Database dengan PDO
try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Koneksi database gagal: " . $e->getMessage());
}

// Fungsi untuk menjalankan query
function query($sql, $params = []) {
    global $pdo;
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt;
}

// Fungsi untuk mendapatkan satu baris data
function fetchOne($sql, $params = []) {
    return query($sql, $params)->fetch();
}

// Fungsi untuk mendapatkan semua data
function fetchAll($sql, $params = []) {
    return query($sql, $params)->fetchAll();
}

// Fungsi untuk mendapatkan count
function fetchCount($sql, $params = []) {
    return query($sql, $params)->fetchColumn();
}
?>