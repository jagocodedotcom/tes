<?php
// ======================================================
// ROUTER UTAMA - SISTEM MANAJEMEN PRODUKSI
// ======================================================

// ======================================================
// 1. OUTPUT BUFFERING
// ======================================================
ob_start();

// ======================================================
// 2. SESSION
// ======================================================
if(session_status() == PHP_SESSION_NONE) {
    session_start();
}

// ======================================================
// 3. CEK LOGIN
// ======================================================
$current_page = basename($_SERVER['PHP_SELF']);

// 3a. Jika belum login, redirect ke login
if(!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    if($current_page != 'login.php') {
        header('Location: login.php');
        exit;
    }
}

// 3b. Jika sudah login di halaman login, redirect ke dashboard
if(isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    if($current_page == 'login.php') {
        header('Location: index.php');
        exit;
    }
}

// ======================================================
// 4. REQUIRE FILE
// ======================================================
require_once 'config/database.php';
require_once 'includes/functions.php';

// ======================================================
// 5. KONFIGURASI
// ======================================================
define('BASE_URL', '');

// ======================================================
// 6. GET PAGE & ACTION
// ======================================================
$page   = isset($_GET['page'])   ? $_GET['page']   : 'dashboard';
$action = isset($_GET['action']) ? $_GET['action'] : 'index';

// ======================================================
// 7. VALIDASI PAGE
// ======================================================
$allowedPages = [
    // Master Data
    'customers', 'suppliers', 'products', 'materials', 
    'users', 'warehouses', 'loading_docks',
    
    // Purchasing
    'purchase_orders', 'material_receipts',
    
    // Production
    'customer_pos', 'production_orders', 
    'material_transfers', 'production_results',
    
    // QC
    'qc_inspections',
    
    // Finished Goods
    'fg_receipts',
    
    // Inventory
    'inventory_transactions', 'material_stock', 'fg_stock',
    
    // Dashboard
    'dashboard'
];

if(!in_array($page, $allowedPages)) {
    $page = 'dashboard';
}

// ======================================================
// 8. INCLUDE HEADER & SIDEBAR
// ======================================================
include 'includes/header.php';
include 'includes/sidebar.php';

// ======================================================
// 9. LOAD PAGE
// ======================================================
$fileLoaded = false;

// 9a. Cek di folder pages/{page}/{action}.php
$file1 = 'pages/' . $page . '/' . $action . '.php';
if(file_exists($file1)) {
    include $file1;
    $fileLoaded = true;
}

// 9b. Cek di folder pages/{page}/index.php (untuk action=index)
if(!$fileLoaded && $action == 'index') {
    $file2 = 'pages/' . $page . '/index.php';
    if(file_exists($file2)) {
        include $file2;
        $fileLoaded = true;
    }
}

// 9c. Cek di folder pages/{page}.php (file tunggal)
if(!$fileLoaded) {
    $file3 = 'pages/' . $page . '.php';
    if(file_exists($file3)) {
        include $file3;
        $fileLoaded = true;
    }
}

// 9d. Jika tidak ditemukan, tampilkan error
if(!$fileLoaded) {
    echo '<div class="p-4">';
    echo '  <div class="alert alert-danger">';
    echo '    <h5><i class="fas fa-exclamation-triangle me-2"></i>Page Not Found!</h5>';
    echo '    <p>Module <strong>' . htmlspecialchars($page) . '</strong> tidak ditemukan.</p>';
    echo '    <hr>';
    echo '    <p class="mb-0">Pastikan folder <code>pages/' . $page . '/</code> ada dan berisi file <code>' . $action . '.php</code></p>';
    echo '  </div>';
    echo '</div>';
}

// ======================================================
// 10. INCLUDE FOOTER & FLUSH OUTPUT
// ======================================================
include 'includes/footer.php';

// ======================================================
// 11. AKHIRI OUTPUT BUFFERING
// ======================================================
ob_end_flush();
?>