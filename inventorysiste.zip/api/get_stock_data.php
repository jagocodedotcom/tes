<?php
require_once '../config/database.php';

$type = isset($_GET['type']) ? $_GET['type'] : 'material';

if($type == 'material') {
    $data = fetchAll("
        SELECT 
            m.MaterialCode AS Code,
            m.MaterialName AS Name,
            s.QtyOnHand,
            s.QtyReserved,
            s.QtyAvailable,
            m.MinStock,
            m.MaxStock
        FROM material_stock s
        JOIN materials m ON s.MaterialID = m.MaterialID
        ORDER BY m.MaterialName
    ");
} else {
    $data = fetchAll("
        SELECT 
            p.ProductCode AS Code,
            p.ProductName AS Name,
            s.QtyOnHand,
            s.QtyReserved,
            s.QtyAvailable,
            s.BatchNo,
            s.BinLocation
        FROM stock_fg s
        JOIN products p ON s.ProductID = p.ProductID
        ORDER BY p.ProductName
    ");
}

jsonResponse([
    'success' => true,
    'type' => $type,
    'data' => $data
]);
?>