<?php
require_once '../config/database.php';

$codes = fetchAll("SELECT MaterialCode FROM materials ORDER BY MaterialCode");

$result = [];
foreach($codes as $row) {
    $result[] = $row['MaterialCode'];
}

header('Content-Type: application/json');
echo json_encode(['codes' => $result]);
?>