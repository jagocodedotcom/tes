<?php
require_once '../config/database.php';
require_once '../includes/functions.php';

// Data Summary
$summary = fetchOne("
    SELECT 
        (SELECT COUNT(*) FROM customers WHERE Status = 1) AS total_customers,
        (SELECT COUNT(*) FROM suppliers WHERE Status = 1) AS total_suppliers,
        (SELECT COUNT(*) FROM products WHERE Active = 1) AS total_products,
        (SELECT COUNT(*) FROM materials WHERE Active = 1) AS total_materials,
        (SELECT COUNT(*) FROM purchase_orders WHERE Status NOT IN ('Completed', 'Cancelled')) AS active_po,
        (SELECT COUNT(*) FROM customer_pos WHERE Status NOT IN ('Completed', 'Cancelled')) AS active_so,
        (SELECT COUNT(*) FROM production_orders WHERE Status NOT IN ('Completed', 'Cancelled')) AS active_wo,
        (SELECT COUNT(*) FROM users WHERE IsActive = 1) AS total_users
");

// Stock Summary
$stockSummary = fetchAll("
    SELECT 
        'Material' AS Type,
        SUM(QtyOnHand) AS TotalStock,
        SUM(QtyAvailable) AS TotalAvailable
    FROM material_stock
    UNION ALL
    SELECT 
        'FG' AS Type,
        SUM(QtyOnHand) AS TotalStock,
        SUM(QtyAvailable) AS TotalAvailable
    FROM stock_fg
");

// Critical Stock
$criticalStock = fetchAll("
    SELECT 
        m.MaterialCode,
        m.MaterialName,
        COALESCE(s.QtyAvailable, 0) AS AvailableStock,
        m.MinStock
    FROM materials m
    LEFT JOIN material_stock s ON m.MaterialID = s.MaterialID
    WHERE m.Active = 1
    HAVING AvailableStock <= m.MinStock
    LIMIT 10
");

// Recent Transactions
$recentTransactions = fetchAll("
    SELECT 
        TransactionDate,
        TransactionType,
        COALESCE(MaterialID, ProductID) AS ItemID,
        QtyIn,
        QtyOut
    FROM inventory_transactions
    ORDER BY TransactionDate DESC
    LIMIT 10
");

jsonResponse([
    'success' => true,
    'summary' => $summary,
    'stock_summary' => $stockSummary,
    'critical_stock' => $criticalStock,
    'recent_transactions' => $recentTransactions
]);
?>