<?php
require_once '../config/database.php';

// Production Trend Last 30 Days
$data = fetchAll("
    SELECT 
        DATE(ProductionDate) AS Date,
        SUM(QtyProduced) AS TotalProduced
    FROM production_results
    WHERE ProductionDate >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
    GROUP BY DATE(ProductionDate)
    ORDER BY Date
");

$labels = [];
$values = [];

foreach($data as $row) {
    $labels[] = date('d M', strtotime($row['Date']));
    $values[] = (float)$row['TotalProduced'];
}

// If no data, fill with zeros
if(empty($labels)) {
    for($i = 29; $i >= 0; $i--) {
        $labels[] = date('d M', strtotime("-$i days"));
        $values[] = 0;
    }
}

jsonResponse([
    'labels' => $labels,
    'values' => $values
]);
?>