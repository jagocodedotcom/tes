<?php
// ======================================================
// LOGIN PAGE - DENGAN VALIDASI LENGKAP
// ======================================================

session_start();

// Jika sudah login, redirect ke dashboard
if(isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    header('Location: index.php');
    exit;
}

// Proses Login
if(isset($_POST['login'])) {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $role = $_POST['role'];
    
    // ======================================================
    // VALIDASI 1: Cek username tidak boleh kosong
    // ======================================================
    if(empty($username)) {
        $error = "Username tidak boleh kosong!";
    }
    // ======================================================
    // VALIDASI 2: Cek password tidak boleh kosong
    // ======================================================
    elseif(empty($password)) {
        $error = "Password tidak boleh kosong!";
    }
    // ======================================================
    // VALIDASI 3: Cek username terdaftar
    // ======================================================
    else {
        // Data user valid (simulasi database)
        $validUsers = [
            'admin' => [
                'password' => 'admin123', 
                'fullname' => 'Administrator', 
                'email' => 'admin@company.com',
                'role' => 'admin'
            ],
            'gudang' => [
                'password' => 'gudang123', 
                'fullname' => 'Budi Warehouse', 
                'email' => 'budi@company.com',
                'role' => 'admin_gudang'
            ],
            'produksi' => [
                'password' => 'produksi123', 
                'fullname' => 'Siti Production', 
                'email' => 'siti@company.com',
                'role' => 'admin_produksi'
            ],
            'qc' => [
                'password' => 'qc123', 
                'fullname' => 'Rina QC', 
                'email' => 'rina@company.com',
                'role' => 'qc'
            ],
            'fg' => [
                'password' => 'fg123', 
                'fullname' => 'Agus FG', 
                'email' => 'agus@company.com',
                'role' => 'fg_admin'
            ]
        ];
        
        // ======================================================
        // VALIDASI 3a: Cek apakah username terdaftar
        // ======================================================
        if(!isset($validUsers[$username])) {
            $error = "Username tidak terdaftar! Silakan periksa kembali username Anda.";
        }
        // ======================================================
        // VALIDASI 3b: Cek apakah password sesuai
        // ======================================================
        elseif($validUsers[$username]['password'] !== $password) {
            $error = "Password salah! Silakan coba lagi.";
        }
        // ======================================================
        // VALIDASI 3c: Cek apakah role sesuai dengan user
        // ======================================================
        elseif($validUsers[$username]['role'] !== $role) {
            $error = "Role tidak sesuai! User '" . $username . "' memiliki role: " . strtoupper(str_replace('_', ' ', $validUsers[$username]['role']));
        }
        // ======================================================
        // VALIDASI BERHASIL - Login sukses
        // ======================================================
        else {
            $_SESSION['user_role'] = $role;
            $_SESSION['username'] = $username;
            $_SESSION['user_fullname'] = $validUsers[$username]['fullname'];
            $_SESSION['user_email'] = $validUsers[$username]['email'];
            $_SESSION['logged_in'] = true;
            $_SESSION['login_time'] = date('Y-m-d H:i:s');
            
            header('Location: index.php');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - MPS System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #1a1a2e, #16213e, #0f3460);
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .login-card {
            background: rgba(255,255,255,0.05);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.5);
            border: 1px solid rgba(255,255,255,0.1);
            width: 100%;
            max-width: 420px;
            animation: fadeInUp 0.5s ease;
        }
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        .login-card .logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .login-card .logo i {
            font-size: 48px;
            color: #0d6efd;
            background: rgba(13, 110, 253, 0.1);
            padding: 20px;
            border-radius: 50%;
        }
        .login-card .logo h3 {
            color: #fff;
            margin-top: 15px;
            font-weight: 600;
        }
        .login-card .logo p {
            color: rgba(255,255,255,0.6);
            font-size: 14px;
        }
        .form-control, .form-select {
            background: rgba(255,255,255,0.1);
            border: 1px solid rgba(255,255,255,0.2);
            color: #fff;
            border-radius: 10px;
            padding: 12px 15px;
            transition: all 0.3s;
        }
        .form-control:focus, .form-select:focus {
            background: rgba(255,255,255,0.15);
            border-color: #0d6efd;
            box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
            color: #fff;
        }
        .form-control::placeholder {
            color: rgba(255,255,255,0.5);
        }
        .form-label {
            color: rgba(255,255,255,0.8);
            font-weight: 500;
        }
        .btn-login {
            background: linear-gradient(135deg, #0d6efd, #0a58ca);
            border: none;
            border-radius: 10px;
            padding: 12px;
            font-weight: 600;
            font-size: 16px;
            transition: all 0.3s;
        }
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(13, 110, 253, 0.4);
        }
        .btn-login:active {
            transform: translateY(0);
        }
        .alert {
            border-radius: 10px;
            padding: 12px 15px;
        }
        .alert-danger {
            background: rgba(220, 53, 69, 0.2);
            border: 1px solid rgba(220, 53, 69, 0.3);
            color: #ff6b6b;
        }
        .alert-success {
            background: rgba(40, 167, 69, 0.2);
            border: 1px solid rgba(40, 167, 69, 0.3);
            color: #5cb85c;
        }
        .alert-warning {
            background: rgba(255, 193, 7, 0.2);
            border: 1px solid rgba(255, 193, 7, 0.3);
            color: #ffc107;
        }
        .text-muted-custom {
            color: rgba(255,255,255,0.4);
            font-size: 12px;
        }
        .form-text {
            color: rgba(255,255,255,0.4);
            font-size: 11px;
        }
        /* Styling untuk pesan error di bawah input */
        .invalid-feedback-custom {
            color: #ff6b6b;
            font-size: 12px;
            margin-top: 5px;
            display: block;
        }
        .is-invalid {
            border-color: #ff6b6b !important;
        }
        .is-invalid:focus {
            box-shadow: 0 0 0 0.25rem rgba(220, 53, 69, 0.25) !important;
        }
        .credential-box {
            background: rgba(255,255,255,0.05);
            border-radius: 10px;
            padding: 10px 15px;
            margin-top: 10px;
        }
        .credential-box small {
            color: rgba(255,255,255,0.5);
            font-size: 11px;
        }
        .credential-box .badge-credential {
            background: rgba(13, 110, 253, 0.2);
            color: #0d6efd;
            padding: 2px 8px;
            border-radius: 5px;
            font-size: 11px;
        }
    </style>
</head>
<body>
    <div class="login-card">
        <div class="logo">
            <i class="fas fa-industry"></i>
            <h3>MPS System</h3>
            <p>Manufacturing Production System</p>
        </div>
        
        <!-- ============================================ -->
        <!-- PESAN ERROR / SUKSES -->
        <!-- ============================================ -->
        <?php if(isset($error)): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="fas fa-exclamation-circle me-2"></i>
            <strong>Login Gagal!</strong> <?= $error ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        
        <?php if(isset($_GET['logout'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle me-2"></i>
            Anda berhasil logout. Silakan login kembali.
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        
        <!-- ============================================ -->
        <!-- FORM LOGIN -->
        <!-- ============================================ -->
        <form method="POST" id="loginForm">
            <!-- Username -->
            <div class="mb-3">
                <label class="form-label">
                    <i class="fas fa-user me-1"></i> Username
                </label>
                <input type="text" name="username" id="username" 
                       class="form-control <?= (isset($error) && strpos($error, 'Username') !== false) ? 'is-invalid' : '' ?>" 
                       placeholder="Masukkan username" 
                       value="<?= isset($_POST['username']) ? htmlspecialchars($_POST['username']) : '' ?>" 
                       required>
                <div id="usernameFeedback" class="invalid-feedback-custom"></div>
            </div>
            
            <!-- Password -->
            <div class="mb-3">
                <label class="form-label">
                    <i class="fas fa-lock me-1"></i> Password
                </label>
                <div class="input-group">
                    <input type="password" name="password" id="password" 
                           class="form-control <?= (isset($error) && strpos($error, 'Password') !== false) ? 'is-invalid' : '' ?>" 
                           placeholder="Masukkan password" 
                           value="<?= isset($_POST['password']) ? htmlspecialchars($_POST['password']) : '' ?>" 
                           required>
                    <button class="btn btn-outline-secondary" type="button" id="togglePassword" 
                            style="background: rgba(255,255,255,0.1); border-color: rgba(255,255,255,0.2); color: #fff;">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
                <div id="passwordFeedback" class="invalid-feedback-custom"></div>
            </div>
            
            <!-- Role -->
            <div class="mb-3">
                <label class="form-label">
                    <i class="fas fa-user-tag me-1"></i> Pilih Role
                </label>
                <select name="role" id="role" class="form-select <?= (isset($error) && strpos($error, 'Role') !== false) ? 'is-invalid' : '' ?>" required>
                    <option value="">-- Pilih Role --</option>
                    <option value="admin" <?= (isset($_POST['role']) && $_POST['role'] == 'admin') ? 'selected' : '' ?>>👑 Admin (Super User)</option>
                    <option value="admin_gudang" <?= (isset($_POST['role']) && $_POST['role'] == 'admin_gudang') ? 'selected' : '' ?>>📦 Admin Gudang Material</option>
                    <option value="admin_produksi" <?= (isset($_POST['role']) && $_POST['role'] == 'admin_produksi') ? 'selected' : '' ?>>⚙️ Admin Produksi</option>
                    <option value="qc" <?= (isset($_POST['role']) && $_POST['role'] == 'qc') ? 'selected' : '' ?>>✅ Quality Control</option>
                    <option value="fg_admin" <?= (isset($_POST['role']) && $_POST['role'] == 'fg_admin') ? 'selected' : '' ?>>📊 Finished Goods Admin</option>
                </select>
                <div id="roleFeedback" class="invalid-feedback-custom"></div>
                <small class="form-text">
                    <i class="fas fa-info-circle me-1"></i>
                    Pilih role sesuai dengan akses yang diinginkan
                </small>
            </div>
            
            <!-- Submit Button -->
            <button type="submit" name="login" class="btn btn-primary btn-login w-100">
                <i class="fas fa-sign-in-alt me-2"></i>Login
            </button>
        </form>
        
        <!-- ============================================ -->
        <!-- DEMO CREDENTIALS -->
        <!-- ============================================ -->
        <hr class="my-4" style="border-color: rgba(255,255,255,0.1);">
        
        <div class="credential-box">
            <small class="d-block text-center mb-2">
                <i class="fas fa-key me-1"></i> Demo Credentials
            </small>
            <div class="row g-1 text-center">
                <div class="col-6">
                    <span class="badge-credential">admin / admin123</span>
                </div>
                <div class="col-6">
                    <span class="badge-credential">gudang / gudang123</span>
                </div>
                <div class="col-6">
                    <span class="badge-credential">produksi / produksi123</span>
                </div>
                <div class="col-6">
                    <span class="badge-credential">qc / qc123</span>
                </div>
                <div class="col-12 mt-1">
                    <span class="badge-credential">fg / fg123</span>
                </div>
            </div>
        </div>
    </div>
    
    <!-- ============================================ -->
    <!-- SCRIPT VALIDASI CLIENT-SIDE -->
    <!-- ============================================ -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // ==============================================
        // VALIDASI FORM SEBELUM SUBMIT
        // ==============================================
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            let valid = true;
            
            // Validasi Username
            const username = document.getElementById('username');
            const usernameFeedback = document.getElementById('usernameFeedback');
            if (username.value.trim() === '') {
                username.classList.add('is-invalid');
                usernameFeedback.textContent = 'Username tidak boleh kosong!';
                valid = false;
            } else {
                username.classList.remove('is-invalid');
                usernameFeedback.textContent = '';
            }
            
            // Validasi Password
            const password = document.getElementById('password');
            const passwordFeedback = document.getElementById('passwordFeedback');
            if (password.value.trim() === '') {
                password.classList.add('is-invalid');
                passwordFeedback.textContent = 'Password tidak boleh kosong!';
                valid = false;
            } else {
                password.classList.remove('is-invalid');
                passwordFeedback.textContent = '';
            }
            
            // Validasi Role
            const role = document.getElementById('role');
            const roleFeedback = document.getElementById('roleFeedback');
            if (role.value === '') {
                role.classList.add('is-invalid');
                roleFeedback.textContent = 'Silakan pilih role!';
                valid = false;
            } else {
                role.classList.remove('is-invalid');
                roleFeedback.textContent = '';
            }
            
            if (!valid) {
                e.preventDefault();
            }
        });
        
        // ==============================================
        // TOGGLE PASSWORD VISIBILITY
        // ==============================================
        document.getElementById('togglePassword').addEventListener('click', function() {
            const password = document.getElementById('password');
            const icon = this.querySelector('i');
            
            if (password.type === 'password') {
                password.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                password.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
        
        // ==============================================
        // CLEAR VALIDATION ON INPUT
        // ==============================================
        document.querySelectorAll('input, select').forEach(function(element) {
            element.addEventListener('input', function() {
                this.classList.remove('is-invalid');
                const feedback = this.id + 'Feedback';
                const feedbackElement = document.getElementById(feedback);
                if (feedbackElement) {
                    feedbackElement.textContent = '';
                }
            });
        });
    </script>
</body>
</html>