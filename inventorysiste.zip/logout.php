<?php
// ======================================================
// LOGOUT - HAPUS SESSION
// ======================================================

// Start session
session_start();

// Hapus semua session
$_SESSION = array();

// Hapus session cookie
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Destroy session
session_destroy();

// Redirect ke halaman login dengan parameter logout
header("Location: login.php?logout=1");
exit;
?>