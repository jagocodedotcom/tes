<?php
// ======================================================
// PROSES HAPUS QC INSPECTION
// ======================================================
ob_start();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$qc = fetchOne("SELECT * FROM qc_inspections WHERE QCID = ?", [$id]);

if(!$qc) {
    ob_clean();
    header("Location: index.php?page=qc_inspections&msg=Inspection not found&type=danger");
    exit;
}

// Cek apakah sudah ada FG Receipt
$hasFG = fetchCount("SELECT COUNT(*) FROM fg_receipts WHERE QCID = ?", [$id]);

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    if($hasFG > 0) {
        // Soft delete - tidak bisa dihapus karena sudah ada FG
        $error = "Cannot delete this inspection because it already has FG Receipt.";
        ob_clean();
        header("Location: index.php?page=qc_inspections&msg=" . urlencode($error) . "&type=danger");
        exit;
    } else {
        // Jika final status Accepted, kurangi stock FG
        if($qc['FinalStatus'] == 'Accepted' && $qc['QtyPASS'] > 0) {
            $wo = fetchOne("
                SELECT wo.ProductID 
                FROM production_results pr
                LEFT JOIN production_orders wo ON pr.ProductionOrderID = wo.ProductionOrderID
                WHERE pr.ProductionResultID = ?
            ", [$qc['ProductionResultID']]);
            
            if($wo) {
                $warehouse = fetchOne("SELECT WarehouseID FROM warehouses LIMIT 1");
                $warehouseID = $warehouse ? $warehouse['WarehouseID'] : 1;
                
                $stock = fetchOne("SELECT StockFGID FROM stock_fg WHERE ProductID = ? AND WarehouseID = ?", 
                                  [$wo['ProductID'], $warehouseID]);
                if($stock) {
                    query("UPDATE stock_fg SET QtyOnHand = QtyOnHand - ? WHERE ProductID = ? AND WarehouseID = ?", 
                          [$qc['QtyPASS'], $wo['ProductID'], $warehouseID]);
                }
            }
        }
        
        query("DELETE FROM qc_inspections WHERE QCID = ?", [$id]);
    }
    
    ob_clean();
    header("Location: index.php?page=qc_inspections&msg=deleted&type=success");
    exit;
}

ob_end_clean();
?>
<div id="page-content-wrapper">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-header bg-danger text-white">
                    <i class="fas fa-exclamation-triangle me-1"></i> Confirm Delete
                </div>
                <div class="card-body text-center py-4">
                    <i class="fas fa-check-double fa-4x text-danger mb-3"></i>
                    <h4>Are you sure you want to delete this QC inspection?</h4>
                    <p class="text-muted">
                        <strong>QC-<?= str_pad($qc['QCID'], 4, '0', STR_PAD_LEFT) ?></strong>
                        <br>
                        Date: <?= date('d/m/Y', strtotime($qc['InspectionDate'])) ?>
                        <br>
                        Checked: <?= number_format($qc['QtyChecked']) ?>
                        <br>
                        PASS: <?= number_format($qc['QtyPASS']) ?>
                        <br>
                        NG: <?= number_format($qc['QtyNG']) ?>
                        <br>
                        Final Status: <?= $qc['FinalStatus'] ?>
                    </p>
                    
                    <?php if($hasFG > 0): ?>
                    <div class="alert alert-warning">
                        <i class="fas fa-info-circle me-1"></i>
                        This inspection has <strong><?= number_format($hasFG) ?> FG Receipt(s)</strong>.
                        <br>
                        <strong>Cannot be deleted!</strong>
                    </div>
                    <?php else: ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-info-circle me-1"></i>
                        This inspection has <strong>no FG receipts</strong>.
                        It will be <strong>permanently deleted</strong>.
                        <?php if($qc['FinalStatus'] == 'Accepted'): ?>
                        <br>
                        <span class="text-warning">Stock FG will be reduced by <?= number_format($qc['QtyPASS']) ?> items.</span>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="" class="d-inline">
                        <?php if($hasFG > 0): ?>
                        <a href="<?= url('qc_inspections') ?>" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-1"></i> Back
                        </a>
                        <?php else: ?>
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash me-1"></i> Yes, Delete
                        </button>
                        <a href="<?= url('qc_inspections') ?>" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i> Cancel
                        </a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>