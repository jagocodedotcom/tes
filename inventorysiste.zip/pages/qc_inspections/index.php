<?php
// ======================================================
// HALAMAN LIST QC INSPECTIONS
// ======================================================

// Pagination
$page = isset($_GET['page_num']) ? (int)$_GET['page_num'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

// Search
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Build Query
$whereClause = "WHERE 1=1";
$params = [];

if (!empty($search)) {
    $whereClause .= " AND (wo.WONumber LIKE ? OR qc.Inspector LIKE ? OR qc.FinalStatus LIKE ?)";
    $searchTerm = "%$search%";
    $params = [$searchTerm, $searchTerm, $searchTerm];
}

// Get Total Data
$totalQuery = "
    SELECT COUNT(*) 
    FROM qc_inspections qc
    LEFT JOIN production_results pr ON qc.ProductionResultID = pr.ProductionResultID
    LEFT JOIN production_orders wo ON pr.ProductionOrderID = wo.ProductionOrderID
    $whereClause
";
$totalData = fetchCount($totalQuery, $params);
$totalPages = ceil($totalData / $limit);

// Get Data
$query = "
    SELECT 
        qc.QCID,
        qc.InspectionDate,
        qc.QtyChecked,
        qc.QtyPASS,
        qc.QtyNG,
        qc.NGReason,
        qc.StatusQC,
        qc.FinalStatus,
        qc.Inspector,
        qc.CreatedAt,
        wo.WONumber,
        p.ProductName,
        p.ProductCode,
        pr.ProductionDate,
        pr.Shift,
        pr.Operator
    FROM qc_inspections qc
    LEFT JOIN production_results pr ON qc.ProductionResultID = pr.ProductionResultID
    LEFT JOIN production_orders wo ON pr.ProductionOrderID = wo.ProductionOrderID
    LEFT JOIN products p ON wo.ProductID = p.ProductID
    $whereClause
    ORDER BY qc.InspectionDate DESC
    LIMIT $limit OFFSET $offset
";
$inspections = fetchAll($query, $params);

// Get Success/Error Message
$message = isset($_GET['msg']) ? $_GET['msg'] : '';
$messageType = isset($_GET['type']) ? $_GET['type'] : '';
?>

<div id="page-content-wrapper">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3">
                <i class="fas fa-check-double me-2 text-primary"></i>QC Inspections
            </h1>
            <p class="text-muted">Manage quality control inspections</p>
        </div>
        <a href="<?= url('qc_inspections', 'create') ?>" class="btn btn-primary">
            <i class="fas fa-plus me-1"></i>Add Inspection
        </a>
    </div>

    <!-- Alert Message -->
    <?php if($message): ?>
    <div class="alert alert-<?= $messageType ?> alert-dismissible fade show" role="alert">
        <?php 
        if($message == 'created') echo 'QC Inspection berhasil ditambahkan!';
        elseif($message == 'updated') echo 'QC Inspection berhasil diperbarui!';
        elseif($message == 'deleted') echo 'QC Inspection berhasil dihapus!';
        else echo htmlspecialchars($message);
        ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <!-- Search -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <input type="hidden" name="page" value="qc_inspections">
                <div class="col-md-10">
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                        <input type="text" name="search" class="form-control" 
                               placeholder="Search by WO number, inspector, or status..." 
                               value="<?= htmlspecialchars($search) ?>">
                    </div>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search me-1"></i>Search
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Table -->
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <span><i class="fas fa-list me-1"></i> QC Inspection List</span>
                <span class="badge bg-primary"><?= number_format($totalData) ?> Records</span>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover table-striped mb-0">
                    <thead>
                        <tr>
                            <th width="50">#</th>
                            <th>WO Number</th>
                            <th>Product</th>
                            <th>Date</th>
                            <th>Checked</th>
                            <th>PASS</th>
                            <th>NG</th>
                            <th>Pass Rate</th>
                            <th>Status</th>
                            <th>Inspector</th>
                            <th width="120">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($inspections)): ?>
                        <tr>
                            <td colspan="11" class="text-center text-muted py-4">
                                <i class="fas fa-inbox fa-2x d-block mb-2"></i>
                                No QC inspections found
                            </td>
                        </tr>
                        <?php else: ?>
                        <?php 
                        $no = $offset + 1;
                        foreach($inspections as $row): 
                            $passRate = 0;
                            if ($row['QtyChecked'] > 0) {
                                $passRate = ($row['QtyPASS'] / $row['QtyChecked']) * 100;
                            }
                            $statusColors = [
                                'Pending' => 'secondary',
                                'Inspected' => 'info',
                                'Rework' => 'warning',
                                'Rejected' => 'danger'
                            ];
                            $statusColor = isset($statusColors[$row['StatusQC']]) ? $statusColors[$row['StatusQC']] : 'secondary';
                            
                            $finalColors = [
                                'Accepted' => 'success',
                                'Rejected' => 'danger',
                                'Rework' => 'warning'
                            ];
                            $finalColor = isset($finalColors[$row['FinalStatus']]) ? $finalColors[$row['FinalStatus']] : 'secondary';
                        ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td>
                                <?php if($row['WONumber']): ?>
                                <span class="badge bg-info"><?= htmlspecialchars($row['WONumber']) ?></span>
                                <?php else: ?>
                                <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <strong><?= htmlspecialchars($row['ProductName']) ?></strong>
                                <br>
                                <small class="text-muted"><?= htmlspecialchars($row['ProductCode']) ?></small>
                            </td>
                            <td><?= date('d/m/Y', strtotime($row['InspectionDate'])) ?></td>
                            <td><?= number_format($row['QtyChecked']) ?></td>
                            <td class="text-success"><?= number_format($row['QtyPASS']) ?></td>
                            <td class="text-danger"><?= number_format($row['QtyNG']) ?></td>
                            <td>
                                <span class="badge bg-<?= $passRate >= 90 ? 'success' : ($passRate >= 70 ? 'warning' : 'danger') ?>">
                                    <?= number_format($passRate, 1) ?>%
                                </span>
                            </td>
                            <td>
                                <span class="badge bg-<?= $statusColor ?>"><?= $row['StatusQC'] ?></span>
                                <?php if($row['FinalStatus']): ?>
                                <br>
                                <span class="badge bg-<?= $finalColor ?>"><?= $row['FinalStatus'] ?></span>
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($row['Inspector']) ?: '-' ?></td>
                            <td>
                                <div class="btn-group btn-group-sm">
                                    <a href="<?= url('qc_inspections', 'view', ['id' => $row['QCID']]) ?>" 
                                       class="btn btn-outline-info" title="View">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="<?= url('qc_inspections', 'edit', ['id' => $row['QCID']]) ?>" 
                                       class="btn btn-outline-primary" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                   <!--  <a href="<?= url('qc_inspections', 'delete', ['id' => $row['QCID']]) ?>" 
                                       class="btn btn-outline-danger" title="Delete"
                                       onclick="return confirm('Are you sure you want to delete this inspection?')">
                                        <i class="fas fa-trash"></i>
                                    </a> -->
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php if($totalPages > 1): ?>
        <div class="card-footer">
            <nav>
                <ul class="pagination pagination-sm mb-0">
                    <?php if($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=qc_inspections&page_num=<?= $page-1 ?>&search=<?= urlencode($search) ?>">
                            <i class="fas fa-chevron-left"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <?php for($i = 1; $i <= $totalPages; $i++): ?>
                    <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                        <a class="page-link" href="?page=qc_inspections&page_num=<?= $i ?>&search=<?= urlencode($search) ?>">
                            <?= $i ?>
                        </a>
                    </li>
                    <?php endfor; ?>
                    
                    <?php if($page < $totalPages): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=qc_inspections&page_num=<?= $page+1 ?>&search=<?= urlencode($search) ?>">
                            <i class="fas fa-chevron-right"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
        <?php endif; ?>
    </div>
</div>