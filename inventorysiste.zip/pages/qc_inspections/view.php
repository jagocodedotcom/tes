<?php
// ======================================================
// HALAMAN DETAIL QC INSPECTION
// ======================================================

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Get Inspection
$qc = fetchOne("
    SELECT 
        qc.*,
        pr.ProductionResultID,
        pr.ProductionDate,
        pr.Shift,
        pr.QtyProduced,
        pr.QtyGood,
        pr.Operator,
        wo.WONumber,
        wo.QtyTarget,
        p.ProductName,
        p.ProductCode,
        p.UOM
    FROM qc_inspections qc
    LEFT JOIN production_results pr ON qc.ProductionResultID = pr.ProductionResultID
    LEFT JOIN production_orders wo ON pr.ProductionOrderID = wo.ProductionOrderID
    LEFT JOIN products p ON wo.ProductID = p.ProductID
    WHERE qc.QCID = ?
", [$id]);

if(!$qc) {
    header("Location: index.php?page=qc_inspections&msg=Inspection not found&type=danger");
    exit;
}

$passRate = 0;
if ($qc['QtyChecked'] > 0) {
    $passRate = ($qc['QtyPASS'] / $qc['QtyChecked']) * 100;
}
?>

<div id="page-content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3">
                <i class="fas fa-check-double me-2 text-primary"></i>QC Inspection Detail
            </h1>
            <p class="text-muted">View quality control inspection details</p>
        </div>
        <div>
            <a href="<?= url('qc_inspections', 'edit', ['id' => $id]) ?>" class="btn btn-primary">
                <i class="fas fa-edit me-1"></i>Edit
            </a>
            <a href="<?= url('qc_inspections') ?>" class="btn btn-secondary">
                <i class="fas fa-arrow-left me-1"></i>Back
            </a>
        </div>
    </div>

    <!-- Summary -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <h5 class="text-primary"><?= number_format($qc['QtyChecked']) ?></h5>
                    <small class="text-muted">Checked</small>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <h5 class="text-success"><?= number_format($qc['QtyPASS']) ?></h5>
                    <small class="text-muted">PASS</small>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <h5 class="text-danger"><?= number_format($qc['QtyNG']) ?></h5>
                    <small class="text-muted">NG</small>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <h5 class="badge bg-<?= $passRate >= 90 ? 'success' : ($passRate >= 70 ? 'warning' : 'danger') ?>" style="font-size:20px;padding:10px 20px;">
                        <?= number_format($passRate, 1) ?>%
                    </h5>
                    <br>
                    <small class="text-muted">Pass Rate</small>
                </div>
            </div>
        </div>
    </div>

    <!-- Inspection Information -->
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-info-circle me-1"></i> Inspection Information
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <table class="table table-bordered mb-0">
                        <tr>
                            <th width="35%">Inspection ID</th>
                            <td><span class="badge bg-info">QC-<?= str_pad($qc['QCID'], 4, '0', STR_PAD_LEFT) ?></span></td>
                        </tr>
                        <tr>
                            <th>Inspection Date</th>
                            <td><?= date('d/m/Y', strtotime($qc['InspectionDate'])) ?></td>
                        </tr>
                        <tr>
                            <th>QC Status</th>
                            <td>
                                <?php 
                                $statusColors = [
                                    'Pending' => 'secondary',
                                    'Inspected' => 'info',
                                    'Rework' => 'warning',
                                    'Rejected' => 'danger'
                                ];
                                $color = isset($statusColors[$qc['StatusQC']]) ? $statusColors[$qc['StatusQC']] : 'secondary';
                                ?>
                                <span class="badge bg-<?= $color ?>"><?= $qc['StatusQC'] ?></span>
                            </td>
                        </tr>
                        <tr>
                            <th>Final Status</th>
                            <td>
                                <?php 
                                $finalColors = [
                                    'Accepted' => 'success',
                                    'Rejected' => 'danger',
                                    'Rework' => 'warning'
                                ];
                                $fColor = isset($finalColors[$qc['FinalStatus']]) ? $finalColors[$qc['FinalStatus']] : 'secondary';
                                ?>
                                <span class="badge bg-<?= $fColor ?>"><?= $qc['FinalStatus'] ?></span>
                            </td>
                        </tr>
                    </table>
                </div>
                <div class="col-md-6">
                    <table class="table table-bordered mb-0">
                        <tr>
                            <th width="35%">Inspector</th>
                            <td><?= htmlspecialchars($qc['Inspector']) ?: '-' ?></td>
                        </tr>
                        <tr>
                            <th>Work Order</th>
                            <td><span class="badge bg-info"><?= htmlspecialchars($qc['WONumber']) ?></span></td>
                        </tr>
                        <tr>
                            <th>Product</th>
                            <td><strong><?= htmlspecialchars($qc['ProductName']) ?></strong></td>
                        </tr>
                        <tr>
                            <th>Production Date</th>
                            <td><?= date('d/m/Y', strtotime($qc['ProductionDate'])) ?></td>
                        </tr>
                    </table>
                </div>
            </div>
            <?php if($qc['NGReason']): ?>
            <div class="row mt-3">
                <div class="col-12">
                    <div class="alert alert-danger">
                        <strong>NG Reason:</strong> <?= htmlspecialchars($qc['NGReason']) ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <?php if($qc['Notes']): ?>
            <div class="row mt-2">
                <div class="col-12">
                    <div class="alert alert-info">
                        <strong>Notes:</strong> <?= htmlspecialchars($qc['Notes']) ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>