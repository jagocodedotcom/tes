<?php
// ======================================================
// HALAMAN TAMBAH QC INSPECTION
// ======================================================
ob_start();

// Get Production Results without QC
$results = fetchAll("
    SELECT 
        pr.ProductionResultID,
        pr.ProductionDate,
        pr.Shift,
        pr.QtyProduced,
        pr.QtyGood,
        pr.Operator,
        wo.WONumber,
        p.ProductName
    FROM production_results pr
    LEFT JOIN production_orders wo ON pr.ProductionOrderID = wo.ProductionOrderID
    LEFT JOIN products p ON wo.ProductID = p.ProductID
    WHERE pr.ProductionResultID NOT IN (SELECT ProductionResultID FROM qc_inspections)
    ORDER BY pr.ProductionDate DESC
");

// Proses submit form
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $productionResultID = isset($_POST['production_result_id']) ? (int)$_POST['production_result_id'] : 0;
    $inspectionDate = $_POST['inspection_date'];
    $qtyChecked = isset($_POST['qty_checked']) ? str_replace(',', '', $_POST['qty_checked']) : 0;
    $qtyPASS = isset($_POST['qty_pass']) ? str_replace(',', '', $_POST['qty_pass']) : 0;
    $qtyNG = isset($_POST['qty_ng']) ? str_replace(',', '', $_POST['qty_ng']) : 0;
    $ngReason = trim($_POST['ng_reason']);
    $statusQC = $_POST['status_qc'];
    $finalStatus = $_POST['final_status'];
    $inspector = trim($_POST['inspector']);
    $notes = trim($_POST['notes']);
    
    $errors = [];
    
    // Validasi
    if(empty($productionResultID)) $errors[] = "Production Result is required";
    if(empty($inspectionDate)) $errors[] = "Inspection Date is required";
    if(empty($qtyChecked) || $qtyChecked <= 0) $errors[] = "Checked quantity must be greater than 0";
    if($qtyPASS < 0) $errors[] = "PASS quantity cannot be negative";
    if($qtyNG < 0) $errors[] = "NG quantity cannot be negative";
    if($qtyPASS + $qtyNG != $qtyChecked) $errors[] = "PASS + NG must equal Checked quantity";
    if(empty($inspector)) $errors[] = "Inspector is required";
    
    if(empty($errors)) {
        try {
            // Get production result data
            $result = fetchOne("SELECT QtyGood FROM production_results WHERE ProductionResultID = ?", [$productionResultID]);
            
            $sql = "INSERT INTO qc_inspections (ProductionResultID, InspectionDate, QtyChecked, QtyPASS, QtyNG, NGReason, StatusQC, FinalStatus, Inspector, Notes) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            query($sql, [$productionResultID, $inspectionDate, $qtyChecked, $qtyPASS, $qtyNG, $ngReason, $statusQC, $finalStatus, $inspector, $notes]);
            
            // Update FG stock if accepted
            if($finalStatus == 'Accepted' && $qtyPASS > 0) {
                $wo = fetchOne("
                    SELECT wo.ProductID, wo.WONumber 
                    FROM production_results pr
                    LEFT JOIN production_orders wo ON pr.ProductionOrderID = wo.ProductionOrderID
                    WHERE pr.ProductionResultID = ?
                ", [$productionResultID]);
                
                if($wo) {
                    // Update stock FG
                    $warehouse = fetchOne("SELECT WarehouseID FROM warehouses LIMIT 1");
                    $warehouseID = $warehouse ? $warehouse['WarehouseID'] : 1;
                    
                    // Check if stock exists
                    $stock = fetchOne("SELECT StockFGID FROM stock_fg WHERE ProductID = ? AND WarehouseID = ?", [$wo['ProductID'], $warehouseID]);
                    if($stock) {
                        query("UPDATE stock_fg SET QtyOnHand = QtyOnHand + ? WHERE ProductID = ? AND WarehouseID = ?", 
                              [$qtyPASS, $wo['ProductID'], $warehouseID]);
                    } else {
                        query("INSERT INTO stock_fg (ProductID, WarehouseID, QtyOnHand, BatchNo) VALUES (?, ?, ?, ?)", 
                              [$wo['ProductID'], $warehouseID, $qtyPASS, 'BATCH-' . date('Ymd') . '-' . $productionResultID]);
                    }
                    
                    // Insert inventory transaction
                    $stockBefore = fetchOne("SELECT QtyOnHand FROM stock_fg WHERE ProductID = ? AND WarehouseID = ?", [$wo['ProductID'], $warehouseID]);
                    $before = $stockBefore ? $stockBefore['QtyOnHand'] - $qtyPASS : 0;
                    
                    query("INSERT INTO inventory_transactions (TransactionDate, TransactionType, ReferenceID, ReferenceType, ProductID, WarehouseID, QtyIn, StockBefore, StockAfter, CreatedBy) 
                          VALUES (NOW(), 'FG_Produce', ?, 'qc_inspections', ?, ?, ?, ?, ?, ?)",
                          [$productionResultID, $wo['ProductID'], $warehouseID, $qtyPASS, $before, $before + $qtyPASS, $inspector]);
                }
            }
            
            ob_clean();
            header("Location: index.php?page=qc_inspections&msg=created&type=success");
            exit;
        } catch(PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}

ob_end_clean();
?>
<div id="page-content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3"><i class="fas fa-check-double-plus me-2 text-primary"></i>Add QC Inspection</h1>
            <p class="text-muted">Create new quality control inspection</p>
        </div>
        <a href="<?= url('qc_inspections') ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i>Back
        </a>
    </div>

    <?php if(isset($errors) && !empty($errors)): ?>
    <div class="alert alert-danger">
        <strong><i class="fas fa-exclamation-circle me-1"></i> Please fix the following errors:</strong>
        <ul class="mb-0 mt-1">
            <?php foreach($errors as $error): ?>
            <li><?= htmlspecialchars($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header"><i class="fas fa-edit me-1"></i> QC Inspection Form</div>
        <div class="card-body">
            <form method="POST" action="" id="qcForm">
                <div class="row g-3">
                    <!-- Production Result -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Production Result <span class="text-danger">*</span></label>
                        <select name="production_result_id" class="form-select" required>
                            <option value="">-- Select Result --</option>
                            <?php foreach($results as $r): ?>
                            <option value="<?= $r['ProductionResultID'] ?>" 
                                    <?= (isset($_POST['production_result_id']) && $_POST['production_result_id'] == $r['ProductionResultID']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($r['WONumber']) ?> - <?= htmlspecialchars($r['ProductName']) ?> 
                                (<?= date('d/m/Y', strtotime($r['ProductionDate'])) ?>)
                            </option>
                            <?php endforeach; ?>
                        </select>
                        <?php if(empty($results)): ?>
                        <small class="text-warning">No production results available for QC</small>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Inspection Date -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Inspection Date <span class="text-danger">*</span></label>
                        <input type="date" name="inspection_date" class="form-control" 
                               value="<?= isset($_POST['inspection_date']) ? $_POST['inspection_date'] : date('Y-m-d') ?>" 
                               required>
                    </div>
                    
                    <!-- Qty Checked -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Qty Checked <span class="text-danger">*</span></label>
                        <input type="number" name="qty_checked" id="qtyChecked" class="form-control" 
                               placeholder="0" 
                               value="<?= isset($_POST['qty_checked']) ? htmlspecialchars($_POST['qty_checked']) : '' ?>" 
                               min="1" required>
                    </div>
                    
                    <!-- Qty PASS -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Qty PASS <span class="text-danger">*</span></label>
                        <input type="number" name="qty_pass" id="qtyPass" class="form-control" 
                               placeholder="0" 
                               value="<?= isset($_POST['qty_pass']) ? htmlspecialchars($_POST['qty_pass']) : '' ?>" 
                               min="0" required>
                    </div>
                    
                    <!-- Qty NG -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Qty NG <span class="text-danger">*</span></label>
                        <input type="number" name="qty_ng" id="qtyNg" class="form-control" 
                               placeholder="0" 
                               value="<?= isset($_POST['qty_ng']) ? htmlspecialchars($_POST['qty_ng']) : '' ?>" 
                               min="0" required>
                        <small id="qtyCheckMsg" class="text-muted"></small>
                    </div>
                    
                    <!-- NG Reason -->
                    <div class="col-12">
                        <label class="form-label fw-bold">NG Reason</label>
                        <textarea name="ng_reason" class="form-control" rows="2" 
                                  placeholder="Reason for NG items"><?= isset($_POST['ng_reason']) ? htmlspecialchars($_POST['ng_reason']) : '' ?></textarea>
                    </div>
                    
                    <!-- Status QC -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">QC Status <span class="text-danger">*</span></label>
                        <select name="status_qc" class="form-select" required>
                            <option value="Pending" <?= (isset($_POST['status_qc']) && $_POST['status_qc'] == 'Pending') ? 'selected' : '' ?>>Pending</option>
                            <option value="Inspected" <?= (isset($_POST['status_qc']) && $_POST['status_qc'] == 'Inspected') ? 'selected' : '' ?>>Inspected</option>
                            <option value="Rework" <?= (isset($_POST['status_qc']) && $_POST['status_qc'] == 'Rework') ? 'selected' : '' ?>>Rework</option>
                            <option value="Rejected" <?= (isset($_POST['status_qc']) && $_POST['status_qc'] == 'Rejected') ? 'selected' : '' ?>>Rejected</option>
                        </select>
                    </div>
                    
                    <!-- Final Status -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Final Status <span class="text-danger">*</span></label>
                        <select name="final_status" class="form-select" required>
                            <option value="Accepted" <?= (isset($_POST['final_status']) && $_POST['final_status'] == 'Accepted') ? 'selected' : '' ?>>Accepted</option>
                            <option value="Rejected" <?= (isset($_POST['final_status']) && $_POST['final_status'] == 'Rejected') ? 'selected' : '' ?>>Rejected</option>
                            <option value="Rework" <?= (isset($_POST['final_status']) && $_POST['final_status'] == 'Rework') ? 'selected' : '' ?>>Rework</option>
                        </select>
                    </div>
                    
                    <!-- Inspector -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Inspector <span class="text-danger">*</span></label>
                        <input type="text" name="inspector" class="form-control" 
                               placeholder="e.g: Rina QC" 
                               value="<?= isset($_POST['inspector']) ? htmlspecialchars($_POST['inspector']) : '' ?>" 
                               required>
                    </div>
                    
                    <!-- Notes -->
                    <div class="col-12">
                        <label class="form-label fw-bold">Notes</label>
                        <textarea name="notes" class="form-control" rows="2" 
                                  placeholder="Additional notes"><?= isset($_POST['notes']) ? htmlspecialchars($_POST['notes']) : '' ?></textarea>
                    </div>
                    
                    <!-- Buttons -->
                    <div class="col-12">
                        <hr>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Save Inspection
                        </button>
                       <!--  <a href="<?= url('qc_inspections') ?>" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i>Cancel
                        </a> -->
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Auto calculate NG = Checked - PASS
document.getElementById('qtyChecked').addEventListener('input', function() {
    updateQty();
});
document.getElementById('qtyPass').addEventListener('input', function() {
    updateQty();
});

function updateQty() {
    var checked = parseInt(document.getElementById('qtyChecked').value) || 0;
    var pass = parseInt(document.getElementById('qtyPass').value) || 0;
    var ng = checked - pass;
    document.getElementById('qtyNg').value = ng >= 0 ? ng : 0;
    
    var msg = document.getElementById('qtyCheckMsg');
    if (checked > 0 && pass > 0) {
        var diff = checked - pass;
        if (diff < 0) {
            msg.innerHTML = '<span class="text-danger">PASS cannot exceed Checked!</span>';
        } else {
            msg.innerHTML = '<span class="text-success">NG: ' + diff + ' items</span>';
        }
    }
}
</script>