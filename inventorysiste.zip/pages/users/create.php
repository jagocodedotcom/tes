<?php
// ======================================================
// HALAMAN TAMBAH USER
// ======================================================
ob_start();

// Proses submit form
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $fullname = trim($_POST['fullname']);
    $email = trim($_POST['email']);
    $role = trim($_POST['role']);
    $department = trim($_POST['department']);
    $isActive = isset($_POST['is_active']) ? (int)$_POST['is_active'] : 1;
    
    $errors = [];
    
    // Validasi required
    if(empty($username)) $errors[] = "Username is required";
    if(empty($password)) $errors[] = "Password is required";
    if(empty($fullname)) $errors[] = "Full Name is required";
    if(empty($role)) $errors[] = "Role is required";
    
    // Validasi email
    if(!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format";
    }
    
    // Cek duplicate username
    if(empty($errors)) {
        $check = fetchOne("SELECT UserID FROM users WHERE Username = ?", [$username]);
        if($check) {
            $errors[] = "Username already exists!";
        }
    }
    
    // Cek duplicate email
    if(empty($errors) && !empty($email)) {
        $check = fetchOne("SELECT UserID FROM users WHERE Email = ?", [$email]);
        if($check) {
            $errors[] = "Email already exists!";
        }
    }
    
    if(empty($errors)) {
        try {
            // Hash password dengan MD5 (atau bisa gunakan password_hash)
            $hashedPassword = md5($password);
            
            $sql = "INSERT INTO users (Username, PasswordHash, FullName, Email, Role, Department, IsActive) 
                    VALUES (?, ?, ?, ?, ?, ?, ?)";
            query($sql, [$username, $hashedPassword, $fullname, $email, $role, $department, $isActive]);
            
            ob_clean();
            header("Location: index.php?page=users&msg=created&type=success");
            exit;
        } catch(PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}

ob_end_clean();
?>
<div id="page-content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3"><i class="fas fa-user-plus me-2 text-primary"></i>Add User</h1>
            <p class="text-muted">Add new system user</p>
        </div>
        <a href="<?= url('users') ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i>Back
        </a>
    </div>

    <?php if(isset($errors) && !empty($errors)): ?>
    <div class="alert alert-danger">
        <strong><i class="fas fa-exclamation-circle me-1"></i> Please fix the following errors:</strong>
        <ul class="mb-0 mt-1">
            <?php foreach($errors as $error): ?>
            <li><?= htmlspecialchars($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header"><i class="fas fa-edit me-1"></i> User Form</div>
        <div class="card-body">
            <form method="POST" action="">
                <div class="row g-3">
                    <!-- Username -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Username <span class="text-danger">*</span></label>
                        <input type="text" name="username" class="form-control" 
                               placeholder="e.g: john_doe" 
                               value="<?= isset($_POST['username']) ? htmlspecialchars($_POST['username']) : '' ?>" 
                               required>
                    </div>
                    
                    <!-- Password -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Password <span class="text-danger">*</span></label>
                        <input type="password" name="password" class="form-control" 
                               placeholder="Enter password" 
                               required>
                        <small class="text-muted">Minimum 6 characters</small>
                    </div>
                    
                    <!-- Full Name -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Full Name <span class="text-danger">*</span></label>
                        <input type="text" name="fullname" class="form-control" 
                               placeholder="e.g: John Doe" 
                               value="<?= isset($_POST['fullname']) ? htmlspecialchars($_POST['fullname']) : '' ?>" 
                               required>
                    </div>
                    
                    <!-- Email -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Email</label>
                        <input type="email" name="email" class="form-control" 
                               placeholder="e.g: john@company.com" 
                               value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '' ?>">
                    </div>
                    
                    <!-- Role -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Role <span class="text-danger">*</span></label>
                        <select name="role" class="form-select" required>
                            <option value="">-- Select Role --</option>
                            <option value="admin" <?= (isset($_POST['role']) && $_POST['role'] == 'admin') ? 'selected' : '' ?>>Admin</option>
                            <option value="admin_gudang" <?= (isset($_POST['role']) && $_POST['role'] == 'admin_gudang') ? 'selected' : '' ?>>Admin Gudang</option>
                            <option value="admin_produksi" <?= (isset($_POST['role']) && $_POST['role'] == 'admin_produksi') ? 'selected' : '' ?>>Admin Produksi</option>
                            <option value="qc" <?= (isset($_POST['role']) && $_POST['role'] == 'qc') ? 'selected' : '' ?>>Quality Control</option>
                            <option value="fg_admin" <?= (isset($_POST['role']) && $_POST['role'] == 'fg_admin') ? 'selected' : '' ?>>FG Admin</option>
                            <option value="supervisor" <?= (isset($_POST['role']) && $_POST['role'] == 'supervisor') ? 'selected' : '' ?>>Supervisor</option>
                            <option value="manager" <?= (isset($_POST['role']) && $_POST['role'] == 'manager') ? 'selected' : '' ?>>Manager</option>
                        </select>
                    </div>
                    
                    <!-- Department -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Department</label>
                        <input type="text" name="department" class="form-control" 
                               placeholder="e.g: IT, HR, Production" 
                               value="<?= isset($_POST['department']) ? htmlspecialchars($_POST['department']) : '' ?>">
                    </div>
                    
                    <!-- Status -->
                    <div class="col-12">
                        <label class="form-label fw-bold">Status</label>
                        <div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="is_active" id="active1" value="1" checked>
                                <label class="form-check-label" for="active1">
                                    <span class="badge bg-success">Active</span>
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="is_active" id="active0" value="0">
                                <label class="form-check-label" for="active0">
                                    <span class="badge bg-danger">Inactive</span>
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Buttons -->
                    <div class="col-12">
                        <hr>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Save User
                        </button>
                        <a href="<?= url('users') ?>" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i>Cancel
                        </a>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>