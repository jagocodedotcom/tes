<?php
// ======================================================
// PROSES HAPUS USER
// ======================================================
ob_start();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$user = fetchOne("SELECT * FROM users WHERE UserID = ?", [$id]);

if(!$user) {
    ob_clean();
    header("Location: index.php?page=users&msg=User not found&type=danger");
    exit;
}

// Cegah menghapus user sendiri
if($id == $_SESSION['user_id']) {
    ob_clean();
    header("Location: index.php?page=users&msg=You cannot delete your own account&type=danger");
    exit;
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    query("DELETE FROM users WHERE UserID = ?", [$id]);
    
    ob_clean();
    header("Location: index.php?page=users&msg=deleted&type=success");
    exit;
}

ob_end_clean();
?>
<div id="page-content-wrapper">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-header bg-danger text-white">
                    <i class="fas fa-exclamation-triangle me-1"></i> Confirm Delete
                </div>
                <div class="card-body text-center py-4">
                    <i class="fas fa-user-times fa-4x text-danger mb-3"></i>
                    <h4>Apakah anda yakin akan menghapus data ini ?</h4>
                    <p class="text-muted">
                        <strong><?= htmlspecialchars($user['Username']) ?></strong> - 
                        <?= htmlspecialchars($user['FullName']) ?>
                    </p>
                    
                    <div class="alert alert-danger">
                        <i class="fas fa-info-circle me-1"></i>
                        This action <strong>cannot be undone</strong>.
                    </div>
                    
                    <form method="POST" action="" class="d-inline">
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash me-1"></i> Yes, Delete
                        </button>
                        <a href="<?= url('users') ?>" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i> Cancel
                        </a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>