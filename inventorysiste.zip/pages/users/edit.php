<?php
// ======================================================
// HALAMAN EDIT USER
// ======================================================
ob_start();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$user = fetchOne("SELECT * FROM users WHERE UserID = ?", [$id]);

if(!$user) {
    ob_clean();
    header("Location: index.php?page=users&msg=User not found&type=danger");
    exit;
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $fullname = trim($_POST['fullname']);
    $email = trim($_POST['email']);
    $role = trim($_POST['role']);
    $department = trim($_POST['department']);
    $isActive = isset($_POST['is_active']) ? (int)$_POST['is_active'] : 1;
    
    $errors = [];
    
    if(empty($username)) $errors[] = "Username is required";
    if(empty($fullname)) $errors[] = "Full Name is required";
    if(empty($role)) $errors[] = "Role is required";
    
    if(!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format";
    }
    
    if(empty($errors)) {
        $check = fetchOne("SELECT UserID FROM users WHERE Username = ? AND UserID != ?", [$username, $id]);
        if($check) {
            $errors[] = "Username already exists!";
        }
    }
    
    if(empty($errors) && !empty($email)) {
        $check = fetchOne("SELECT UserID FROM users WHERE Email = ? AND UserID != ?", [$email, $id]);
        if($check) {
            $errors[] = "Email already exists!";
        }
    }
    
    if(empty($errors)) {
        try {
            // Jika password diisi, update password
            if(!empty($password)) {
                $hashedPassword = md5($password);
                $sql = "UPDATE users SET 
                        Username = ?, 
                        PasswordHash = ?, 
                        FullName = ?, 
                        Email = ?, 
                        Role = ?, 
                        Department = ?,
                        IsActive = ?
                        WHERE UserID = ?";
                query($sql, [$username, $hashedPassword, $fullname, $email, $role, $department, $isActive, $id]);
            } else {
                // Jika password kosong, tidak update password
                $sql = "UPDATE users SET 
                        Username = ?, 
                        FullName = ?, 
                        Email = ?, 
                        Role = ?, 
                        Department = ?,
                        IsActive = ?
                        WHERE UserID = ?";
                query($sql, [$username, $fullname, $email, $role, $department, $isActive, $id]);
            }
            
            ob_clean();
            header("Location: index.php?page=users&msg=updated&type=success");
            exit;
        } catch(PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}

ob_end_clean();
?>
<div id="page-content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3"><i class="fas fa-user-edit me-2 text-primary"></i>Edit User</h1>
            <p class="text-muted">Edit user: <?= htmlspecialchars($user['Username']) ?></p>
        </div>
        <a href="<?= url('users') ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i>Back
        </a>
    </div>

    <?php if(isset($errors) && !empty($errors)): ?>
    <div class="alert alert-danger">
        <strong><i class="fas fa-exclamation-circle me-1"></i> Please fix the following errors:</strong>
        <ul class="mb-0 mt-1">
            <?php foreach($errors as $error): ?>
            <li><?= htmlspecialchars($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header"><i class="fas fa-edit me-1"></i> Edit User Form</div>
        <div class="card-body">
            <form method="POST" action="">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Username <span class="text-danger">*</span></label>
                        <input type="text" name="username" class="form-control" 
                               value="<?= htmlspecialchars($user['Username']) ?>" required>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Password</label>
                        <input type="password" name="password" class="form-control" 
                               placeholder="Leave blank to keep current password">
                        <small class="text-muted">Leave blank to keep current password</small>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Full Name <span class="text-danger">*</span></label>
                        <input type="text" name="fullname" class="form-control" 
                               value="<?= htmlspecialchars($user['FullName']) ?>" required>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Email</label>
                        <input type="email" name="email" class="form-control" 
                               value="<?= htmlspecialchars($user['Email']) ?>">
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Role <span class="text-danger">*</span></label>
                        <select name="role" class="form-select" required>
                            <option value="">-- Select Role --</option>
                            <option value="admin" <?= $user['Role'] == 'admin' ? 'selected' : '' ?>>Admin</option>
                            <option value="admin_gudang" <?= $user['Role'] == 'admin_gudang' ? 'selected' : '' ?>>Admin Gudang</option>
                            <option value="admin_produksi" <?= $user['Role'] == 'admin_produksi' ? 'selected' : '' ?>>Admin Produksi</option>
                            <option value="qc" <?= $user['Role'] == 'qc' ? 'selected' : '' ?>>Quality Control</option>
                            <option value="fg_admin" <?= $user['Role'] == 'fg_admin' ? 'selected' : '' ?>>FG Admin</option>
                            <option value="supervisor" <?= $user['Role'] == 'supervisor' ? 'selected' : '' ?>>Supervisor</option>
                            <option value="manager" <?= $user['Role'] == 'manager' ? 'selected' : '' ?>>Manager</option>
                        </select>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Department</label>
                        <input type="text" name="department" class="form-control" 
                               value="<?= htmlspecialchars($user['Department']) ?>">
                    </div>
                    
                    <div class="col-12">
                        <label class="form-label fw-bold">Status</label>
                        <div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="is_active" id="active1" value="1" 
                                       <?= $user['IsActive'] == 1 ? 'checked' : '' ?>>
                                <label class="form-check-label" for="active1">
                                    <span class="badge bg-success">Active</span>
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="is_active" id="active0" value="0"
                                       <?= $user['IsActive'] == 0 ? 'checked' : '' ?>>
                                <label class="form-check-label" for="active0">
                                    <span class="badge bg-danger">Inactive</span>
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-12">
                        <div class="alert alert-info">
                            <small>
                                <i class="fas fa-info-circle me-1"></i>
                                Created: <?= date('d/m/Y H:i', strtotime($user['CreatedAt'])) ?>
                                <?php if($user['LastLogin']): ?>
                                | Last Login: <?= date('d/m/Y H:i', strtotime($user['LastLogin'])) ?>
                                <?php endif; ?>
                            </small>
                        </div>
                    </div>
                    
                    <div class="col-12">
                        <hr>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Update User
                        </button>
                        <a href="<?= url('users') ?>" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i>Cancel
                        </a>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>