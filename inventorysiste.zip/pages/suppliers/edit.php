<?php
// ======================================================
// HALAMAN EDIT SUPPLIER
// ======================================================

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$supplier = fetchOne("SELECT * FROM suppliers WHERE SupplierID = ?", [$id]);

if(!$supplier) {
    header("Location: index.php?page=suppliers&msg=Supplier not found&type=danger");
    exit;
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $supplierCode = trim($_POST['supplier_code']);
    $supplierName = trim($_POST['supplier_name']);
    $address = trim($_POST['address']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $status = isset($_POST['status']) ? (int)$_POST['status'] : 1;
    
    $errors = [];
    
    // Validasi required
    if(empty($supplierCode)) $errors[] = "Supplier Code is required";
    if(empty($supplierName)) $errors[] = "Supplier Name is required";
    if(empty($address)) $errors[] = "Address is required";
    if(empty($phone)) $errors[] = "Phone number is required";
    
    // Validasi phone hanya angka
    if(!empty($phone) && !preg_match('/^[0-9]+$/', $phone)) {
        $errors[] = "Phone number must contain only numbers (0-9)";
    }
    
    // Validasi email format
    if(!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format";
    }
    
    if(empty($errors)) {
        $check = fetchOne("SELECT SupplierID FROM suppliers WHERE SupplierCode = ? AND SupplierID != ?", [$supplierCode, $id]);
        if($check) {
            $errors[] = "Supplier Code already exists!";
        }
    }
    
    if(empty($errors)) {
        try {
            $sql = "UPDATE suppliers SET 
                    SupplierCode = ?, 
                    SupplierName = ?, 
                    Address = ?, 
                    Phone = ?, 
                    Email = ?, 
                    Status = ?,
                    UpdatedAt = NOW()
                    WHERE SupplierID = ?";
            query($sql, [$supplierCode, $supplierName, $address, $phone, $email, $status, $id]);
            
            header("Location: index.php?page=suppliers&msg=updated&type=success");
            exit;
        } catch(PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}
?>

<div id="page-content-wrapper" class="p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3"><i class="fas fa-edit me-2 text-primary"></i>Edit Supplier</h1>
            <p class="text-muted">Edit supplier: <?= htmlspecialchars($supplier['SupplierCode']) ?></p>
        </div>
        <a href="index.php?page=suppliers" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i>Back
        </a>
    </div>

    <?php if(isset($errors) && !empty($errors)): ?>
    <div class="alert alert-danger">
        <strong><i class="fas fa-exclamation-circle me-1"></i> Please fix the following errors:</strong>
        <ul class="mb-0 mt-1">
            <?php foreach($errors as $error): ?>
            <li><?= htmlspecialchars($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header"><i class="fas fa-edit me-1"></i> Edit Supplier Form</div>
        <div class="card-body">
            <form method="POST" action="" id="supplierForm">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Supplier Code <span class="text-danger">*</span></label>
                        <input type="text" name="supplier_code" class="form-control" 
                               value="<?= htmlspecialchars($supplier['SupplierCode']) ?>" required>
                        <small class="text-muted">Unique identifier for the supplier</small>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Supplier Name <span class="text-danger">*</span></label>
                        <input type="text" name="supplier_name" class="form-control" 
                               value="<?= htmlspecialchars($supplier['SupplierName']) ?>" required>
                    </div>
                    
                    <div class="col-12">
                        <label class="form-label fw-bold">Address <span class="text-danger">*</span></label>
                        <textarea name="address" class="form-control" rows="2" required><?= htmlspecialchars($supplier['Address']) ?></textarea>
                        <small class="text-muted">Complete address is required</small>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Phone <span class="text-danger">*</span></label>
                        <input type="tel" name="phone" class="form-control" 
                               value="<?= htmlspecialchars($supplier['Phone']) ?>" 
                               pattern="[0-9]+" maxlength="15" required>
                        <small class="text-muted">Numbers only (e.g: 0215551001)</small>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Email</label>
                        <input type="email" name="email" class="form-control" 
                               value="<?= htmlspecialchars($supplier['Email']) ?>">
                        <small class="text-muted">Optional, but must be valid email format</small>
                    </div>
                    
                    <div class="col-12">
                        <label class="form-label fw-bold">Status</label>
                        <div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="status" id="status1" value="1" 
                                       <?= $supplier['Status'] == 1 ? 'checked' : '' ?>>
                                <label class="form-check-label" for="status1">
                                    <span class="badge bg-success">Active</span>
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="status" id="status0" value="0"
                                       <?= $supplier['Status'] == 0 ? 'checked' : '' ?>>
                                <label class="form-check-label" for="status0">
                                    <span class="badge bg-danger">Inactive</span>
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-12">
                        <div class="alert alert-info">
                            <small>
                                <i class="fas fa-info-circle me-1"></i>
                                Created: <?= date('d/m/Y H:i', strtotime($supplier['CreatedAt'])) ?>
                                <?php if($supplier['UpdatedAt'] != $supplier['CreatedAt']): ?>
                                | Updated: <?= date('d/m/Y H:i', strtotime($supplier['UpdatedAt'])) ?>
                                <?php endif; ?>
                            </small>
                        </div>
                    </div>
                    
                    <div class="col-12">
                        <hr>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Update Supplier
                        </button>
                     
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- JavaScript untuk validasi -->
<script>
document.getElementById('supplierForm').addEventListener('submit', function(e) {
    var phone = document.querySelector('input[name="phone"]');
    var phoneValue = phone.value.replace(/\D/g, '');
    
    if (phoneValue.length === 0) {
        alert('Phone number is required!');
        e.preventDefault();
        return false;
    }
    
    phone.value = phoneValue;
    return true;
});

document.querySelector('input[name="phone"]').addEventListener('input', function(e) {
    this.value = this.value.replace(/\D/g, '');
});
</script>