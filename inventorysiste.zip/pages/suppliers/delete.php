<?php
// ======================================================
// PROSES HAPUS SUPPLIER
// ======================================================

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$supplier = fetchOne("SELECT * FROM suppliers WHERE SupplierID = ?", [$id]);

if(!$supplier) {
    header("Location: index.php?page=suppliers&msg=Supplier not found&type=danger");
    exit;
}

$hasOrders = fetchCount("SELECT COUNT(*) FROM purchase_orders WHERE SupplierID = ?", [$id]);

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    if($hasOrders > 0) {
        // Soft delete - hanya ubah status
        query("UPDATE suppliers SET Status = 0, UpdatedAt = NOW() WHERE SupplierID = ?", [$id]);
    } else {
        // Permanent delete
        query("DELETE FROM suppliers WHERE SupplierID = ?", [$id]);
    }
    
    header("Location: index.php?page=suppliers&msg=deleted&type=success");
    exit;
}
?>

<div id="page-content-wrapper" class="p-4">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-header bg-danger text-white">
                    <i class="fas fa-exclamation-triangle me-1"></i> Confirm Delete
                </div>
                <div class="card-body text-center py-4">
                    <i class="fas fa-truck fa-4x text-danger mb-3"></i>
                    <h4>Apakah anda yakin akan menghapus data ini?</h4>
                    <p class="text-muted">
                        <strong><?= htmlspecialchars($supplier['SupplierCode']) ?></strong> - 
                        <?= htmlspecialchars($supplier['SupplierName']) ?>
                    </p>
                    
                    <?php if($hasOrders > 0): ?>
                    <div class="alert alert-warning">
                        <i class="fas fa-info-circle me-1"></i>
                        This supplier has <strong><?= number_format($hasOrders) ?> purchase order(s)</strong>.
                        Supplier will be <strong>deactivated</strong> instead of permanently deleted.
                    </div>
                    <?php else: ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-info-circle me-1"></i>
                        Supplier ini memiliki <strong>no purchase orders</strong>.
                       Supplier akan <strong>dihapus secara permanen?</strong>.
                    </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="" class="d-inline">
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash me-1"></i> Yes, Delete
                        </button>
                        <a href="index.php?page=suppliers" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i> Cancel
                        </a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>