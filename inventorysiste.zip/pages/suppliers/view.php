<?php
// ======================================================
// HALAMAN DETAIL SUPPLIER
// ======================================================

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$supplier = fetchOne("SELECT * FROM suppliers WHERE SupplierID = ?", [$id]);

if(!$supplier) {
    header("Location: index.php?page=suppliers&msg=Supplier not found&type=danger");
    exit;
}

$totalOrders = fetchCount("SELECT COUNT(*) FROM purchase_orders WHERE SupplierID = ?", [$id]);

$recentOrders = fetchAll("
    SELECT 
        POID, 
        PONumber, 
        PODate, 
        Status, 
        CreatedAt
    FROM purchase_orders 
    WHERE SupplierID = ?
    ORDER BY CreatedAt DESC
    LIMIT 5
", [$id]);
?>

<div id="page-content-wrapper" class="p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3"><i class="fas fa-truck me-2 text-primary"></i>Supplier Detail</h1>
            <p class="text-muted">View complete supplier information</p>
        </div>
        <div>
            <a href="index.php?page=suppliers&action=edit&id=<?= $id ?>" class="btn btn-primary">
                <i class="fas fa-edit me-1"></i>Edit
            </a>
            <a href="index.php?page=suppliers" class="btn btn-secondary">
                <i class="fas fa-arrow-left me-1"></i>Back
            </a>
        </div>
    </div>

    <div class="row g-3">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-header"><i class="fas fa-info-circle me-1"></i> Supplier Information</div>
                <div class="card-body">
                    <table class="table table-bordered mb-0">
                        <tr>
                            <th width="40%">Supplier Code</th>
                            <td><span class="badge bg-info"><?= htmlspecialchars($supplier['SupplierCode']) ?></span></td>
                        </tr>
                        <tr>
                            <th>Supplier Name</th>
                            <td><strong><?= htmlspecialchars($supplier['SupplierName']) ?></strong></td>
                        </tr>
                        <tr>
                            <th>Address</th>
                            <td><?= nl2br(htmlspecialchars($supplier['Address'])) ?></td>
                        </tr>
                        <tr>
                            <th>Phone</th>
                            <td><?= htmlspecialchars($supplier['Phone']) ?></td>
                        </tr>
                        <tr>
                            <th>Email</th>
                            <td><a href="mailto:<?= htmlspecialchars($supplier['Email']) ?>"><?= htmlspecialchars($supplier['Email']) ?></a></td>
                        </tr>
                        <tr>
                            <th>Status</th>
                            <td>
                                <?php if($supplier['Status'] == 1): ?>
                                <span class="badge bg-success">Active</span>
                                <?php else: ?>
                                <span class="badge bg-danger">Inactive</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>Total Orders</th>
                            <td><span class="badge bg-primary"><?= number_format($totalOrders) ?></span></td>
                        </tr>
                        <tr>
                            <th>Created At</th>
                            <td><?= date('d/m/Y H:i', strtotime($supplier['CreatedAt'])) ?></td>
                        </tr>
                        <tr>
                            <th>Updated At</th>
                            <td><?= date('d/m/Y H:i', strtotime($supplier['UpdatedAt'])) ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="card">
                <div class="card-header"><i class="fas fa-file-invoice me-1"></i> Recent Purchase Orders</div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-sm mb-0">
                            <thead>
                                <tr>
                                    <th>PO Number</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(empty($recentOrders)): ?>
                                <tr>
                                    <td colspan="3" class="text-center text-muted py-3">
                                        <i class="fas fa-inbox d-block mb-1"></i>
                                        No purchase orders found
                                    </td>
                                </tr>
                                <?php else: ?>
                                <?php foreach($recentOrders as $order): ?>
                                <tr>
                                    <td><?= htmlspecialchars($order['PONumber']) ?></td>
                                    <td><?= date('d/m/Y', strtotime($order['PODate'])) ?></td>
                                    <td>
                                        <?php 
                                        $colors = [
                                            'Draft' => 'secondary',
                                            'Submitted' => 'info',
                                            'Approved' => 'primary',
                                            'Partial' => 'warning',
                                            'Completed' => 'success',
                                            'Cancelled' => 'danger'
                                        ];
                                        $color = isset($colors[$order['Status']]) ? $colors[$order['Status']] : 'secondary';
                                        ?>
                                        <span class="badge bg-<?= $color ?>"><?= htmlspecialchars($order['Status']) ?></span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php if($totalOrders > 5): ?>
                    <div class="card-footer text-center">
                        <a href="index.php?page=purchase_orders&supplier_id=<?= $id ?>" class="btn btn-sm btn-outline-primary">
                            View All Orders
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>