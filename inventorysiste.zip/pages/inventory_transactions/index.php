<?php
// ======================================================
// HALAMAN INVENTORY TRANSACTIONS
// ======================================================

// Pagination
$page = isset($_GET['page_num']) ? (int)$_GET['page_num'] : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

// Filters
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$typeFilter = isset($_GET['type']) ? trim($_GET['type']) : '';
$dateFrom = isset($_GET['date_from']) ? $_GET['date_from'] : '';
$dateTo = isset($_GET['date_to']) ? $_GET['date_to'] : '';

// Build Query
$whereClause = "WHERE 1=1";
$params = [];

if (!empty($search)) {
    $whereClause .= " AND (TransactionType LIKE ? OR CreatedBy LIKE ? OR Notes LIKE ?)";
    $searchTerm = "%$search%";
    $params = [$searchTerm, $searchTerm, $searchTerm];
}

if (!empty($typeFilter)) {
    $whereClause .= " AND TransactionType = ?";
    $params[] = $typeFilter;
}

if (!empty($dateFrom)) {
    $whereClause .= " AND DATE(TransactionDate) >= ?";
    $params[] = $dateFrom;
}

if (!empty($dateTo)) {
    $whereClause .= " AND DATE(TransactionDate) <= ?";
    $params[] = $dateTo;
}

// Get Total Data
$totalQuery = "SELECT COUNT(*) FROM inventory_transactions $whereClause";
$totalData = fetchCount($totalQuery, $params);
$totalPages = ceil($totalData / $limit);

// Get Data
$query = "
    SELECT 
        TransactionID,
        TransactionDate,
        TransactionType,
        ReferenceID,
        ReferenceType,
        MaterialID,
        ProductID,
        WarehouseID,
        QtyIn,
        QtyOut,
        StockBefore,
        StockAfter,
        BatchNo,
        CreatedBy,
        Notes,
        (SELECT WarehouseName FROM warehouses WHERE WarehouseID = t.WarehouseID) AS WarehouseName,
        (SELECT MaterialCode FROM materials WHERE MaterialID = t.MaterialID) AS MaterialCode,
        (SELECT MaterialName FROM materials WHERE MaterialID = t.MaterialID) AS MaterialName,
        (SELECT ProductCode FROM products WHERE ProductID = t.ProductID) AS ProductCode,
        (SELECT ProductName FROM products WHERE ProductID = t.ProductID) AS ProductName
    FROM inventory_transactions t
    $whereClause
    ORDER BY TransactionDate DESC
    LIMIT $limit OFFSET $offset
";
$transactions = fetchAll($query, $params);

// Get all transaction types for filter
$types = fetchAll("SELECT DISTINCT TransactionType FROM inventory_transactions ORDER BY TransactionType");

// Get Summary
$summary = fetchOne("
    SELECT 
        COUNT(*) AS TotalTransactions,
        COALESCE(SUM(QtyIn), 0) AS TotalIn,
        COALESCE(SUM(QtyOut), 0) AS TotalOut,
        (SELECT COUNT(DISTINCT DATE(TransactionDate)) FROM inventory_transactions) AS TotalDays
    FROM inventory_transactions
");

// Get Summary by Type
$summaryByType = fetchAll("
    SELECT 
        TransactionType,
        COUNT(*) AS Total,
        COALESCE(SUM(QtyIn), 0) AS TotalIn,
        COALESCE(SUM(QtyOut), 0) AS TotalOut
    FROM inventory_transactions
    GROUP BY TransactionType
    ORDER BY Total DESC
    LIMIT 10
");

// Get Today's Transactions
$todayTransactions = fetchAll("
    SELECT 
        TransactionID,
        TransactionType,
        QtyIn,
        QtyOut,
        CreatedBy,
        TransactionDate
    FROM inventory_transactions
    WHERE DATE(TransactionDate) = CURDATE()
    ORDER BY TransactionDate DESC
    LIMIT 10
");
?>

<div id="page-content-wrapper">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3">
                <i class="fas fa-list me-2 text-primary"></i>Inventory Transactions
            </h1>
            <p class="text-muted">View all inventory movements</p>
        </div>
        <span class="badge bg-primary">Total: <?= number_format($summary['TotalTransactions']) ?> transactions</span>
    </div>

    <!-- Summary Cards -->
    <div class="row g-3 mb-4">
        <div class="col-md-3">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-white-50">Total Transactions</h6>
                            <h2 class="display-6 fw-bold"><?= number_format($summary['TotalTransactions']) ?></h2>
                        </div>
                        <i class="fas fa-exchange-alt fa-3x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-white-50">Total In</h6>
                            <h2 class="display-6 fw-bold"><?= number_format($summary['TotalIn']) ?></h2>
                        </div>
                        <i class="fas fa-arrow-down fa-3x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-danger text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-white-50">Total Out</h6>
                            <h2 class="display-6 fw-bold"><?= number_format($summary['TotalOut']) ?></h2>
                        </div>
                        <i class="fas fa-arrow-up fa-3x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-white-50">Active Days</h6>
                            <h2 class="display-6 fw-bold"><?= number_format($summary['TotalDays']) ?></h2>
                        </div>
                        <i class="fas fa-calendar-alt fa-3x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Search & Filter -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <input type="hidden" name="page" value="inventory_transactions">
                <div class="col-md-3">
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                        <input type="text" name="search" class="form-control" 
                               placeholder="Search by type or user..." 
                               value="<?= htmlspecialchars($search) ?>">
                    </div>
                </div>
                <div class="col-md-2">
                    <select name="type" class="form-select">
                        <option value="">All Types</option>
                        <?php foreach($types as $t): ?>
                        <option value="<?= $t['TransactionType'] ?>" <?= ($typeFilter == $t['TransactionType']) ? 'selected' : '' ?>>
                            <?= str_replace('_', ' ', $t['TransactionType']) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <input type="date" name="date_from" class="form-control" 
                           placeholder="Date From" value="<?= $dateFrom ?>">
                </div>
                <div class="col-md-2">
                    <input type="date" name="date_to" class="form-control" 
                           placeholder="Date To" value="<?= $dateTo ?>">
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-filter me-1"></i>Filter
                    </button>
                </div>
                <div class="col-md-1">
                    <a href="<?= url('inventory_transactions') ?>" class="btn btn-secondary w-100">
                        <i class="fas fa-undo"></i>
                    </a>
                </div>
            </form>
        </div>
    </div>

    <!-- Summary by Type -->
    <div class="row g-3 mb-4">
        <div class="col-md-6">
            <div class="card h-100">
                <div class="card-header">
                    <i class="fas fa-chart-pie me-1"></i> Transaction Summary by Type
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-sm mb-0">
                            <thead>
                                <tr>
                                    <th>Type</th>
                                    <th class="text-end">Total</th>
                                    <th class="text-end">In</th>
                                    <th class="text-end">Out</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($summaryByType as $st): ?>
                                <tr>
                                    <td>
                                        <span class="badge bg-secondary"><?= str_replace('_', ' ', $st['TransactionType']) ?></span>
                                    </td>
                                    <td class="text-end"><?= number_format($st['Total']) ?></td>
                                    <td class="text-end text-success"><?= number_format($st['TotalIn']) ?></td>
                                    <td class="text-end text-danger"><?= number_format($st['TotalOut']) ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Today's Transactions -->
        <div class="col-md-6">
            <div class="card h-100">
                <div class="card-header">
                    <i class="fas fa-clock me-1"></i> Today's Transactions
                    <span class="badge bg-secondary float-end"><?= count($todayTransactions) ?> records</span>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-sm mb-0">
                            <thead>
                                <tr>
                                    <th>Type</th>
                                    <th class="text-end">In</th>
                                    <th class="text-end">Out</th>
                                    <th>User</th>
                                    <th>Time</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(empty($todayTransactions)): ?>
                                <tr>
                                    <td colspan="5" class="text-center text-muted py-3">No transactions today</td>
                                </tr>
                                <?php else: ?>
                                <?php foreach($todayTransactions as $tt): ?>
                                <tr>
                                    <td>
                                        <span class="badge bg-secondary"><?= str_replace('_', ' ', $tt['TransactionType']) ?></span>
                                    </td>
                                    <td class="text-end text-success"><?= $tt['QtyIn'] > 0 ? number_format($tt['QtyIn']) : '-' ?></td>
                                    <td class="text-end text-danger"><?= $tt['QtyOut'] > 0 ? number_format($tt['QtyOut']) : '-' ?></td>
                                    <td><?= htmlspecialchars($tt['CreatedBy']) ?></td>
                                    <td><?= date('H:i', strtotime($tt['TransactionDate'])) ?></td>
                                </tr>
                                <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Table -->
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <span><i class="fas fa-list me-1"></i> Transaction List</span>
                <span class="badge bg-primary"><?= number_format($totalData) ?> Records</span>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover table-striped mb-0">
                    <thead>
                        <tr>
                            <th width="50">#</th>
                            <th>Date/Time</th>
                            <th>Type</th>
                            <th>Item</th>
                            <th>Warehouse</th>
                            <th class="text-end">Qty In</th>
                            <th class="text-end">Qty Out</th>
                            <th class="text-end">Stock Before</th>
                            <th class="text-end">Stock After</th>
                            <th>User</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($transactions)): ?>
                        <tr>
                            <td colspan="10" class="text-center text-muted py-4">
                                <i class="fas fa-inbox fa-2x d-block mb-2"></i>
                                No transactions found
                            </td>
                        </tr>
                        <?php else: ?>
                        <?php 
                        $no = $offset + 1;
                        foreach($transactions as $row): 
                            // Determine item name
                            $itemName = '';
                            if($row['MaterialID']) {
                                $itemName = $row['MaterialCode'] . ' - ' . $row['MaterialName'];
                            } elseif($row['ProductID']) {
                                $itemName = $row['ProductCode'] . ' - ' . $row['ProductName'];
                            } else {
                                $itemName = '-';
                            }
                            
                            $typeColors = [
                                'PO_Receive' => 'success',
                                'PO_Return' => 'danger',
                                'Transfer_Out' => 'warning',
                                'Transfer_In' => 'info',
                                'FG_Produce' => 'success',
                                'FG_Deliver' => 'danger',
                                'FG_Return' => 'warning',
                                'Adjustment_Add' => 'success',
                                'Adjustment_Sub' => 'danger',
                                'QC_Reject' => 'danger'
                            ];
                            $color = isset($typeColors[$row['TransactionType']]) ? $typeColors[$row['TransactionType']] : 'secondary';
                        ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= date('d/m/Y H:i', strtotime($row['TransactionDate'])) ?></td>
                            <td>
                                <span class="badge bg-<?= $color ?>"><?= str_replace('_', ' ', $row['TransactionType']) ?></span>
                            </td>
                            <td><?= htmlspecialchars($itemName) ?></td>
                            <td><?= htmlspecialchars($row['WarehouseName']) ?></td>
                            <td class="text-end text-success">
                                <?= $row['QtyIn'] > 0 ? number_format($row['QtyIn']) : '-' ?>
                            </td>
                            <td class="text-end text-danger">
                                <?= $row['QtyOut'] > 0 ? number_format($row['QtyOut']) : '-' ?>
                            </td>
                            <td class="text-end"><?= number_format($row['StockBefore']) ?></td>
                            <td class="text-end">
                                <strong><?= number_format($row['StockAfter']) ?></strong>
                            </td>
                            <td><?= htmlspecialchars($row['CreatedBy']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php if($totalPages > 1): ?>
        <div class="card-footer">
            <nav>
                <ul class="pagination pagination-sm mb-0">
                    <?php if($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=inventory_transactions&page_num=<?= $page-1 ?>&search=<?= urlencode($search) ?>&type=<?= urlencode($typeFilter) ?>&date_from=<?= $dateFrom ?>&date_to=<?= $dateTo ?>">
                            <i class="fas fa-chevron-left"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <?php for($i = 1; $i <= $totalPages; $i++): ?>
                    <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                        <a class="page-link" href="?page=inventory_transactions&page_num=<?= $i ?>&search=<?= urlencode($search) ?>&type=<?= urlencode($typeFilter) ?>&date_from=<?= $dateFrom ?>&date_to=<?= $dateTo ?>">
                            <?= $i ?>
                        </a>
                    </li>
                    <?php endfor; ?>
                    
                    <?php if($page < $totalPages): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=inventory_transactions&page_num=<?= $page+1 ?>&search=<?= urlencode($search) ?>&type=<?= urlencode($typeFilter) ?>&date_from=<?= $dateFrom ?>&date_to=<?= $dateTo ?>">
                            <i class="fas fa-chevron-right"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
        <?php endif; ?>
    </div>

    <!-- Transaction Type Legend -->
    <div class="card mt-3">
        <div class="card-body">
            <h6 class="mb-2"><i class="fas fa-info-circle me-1"></i> Transaction Type Legend</h6>
            <div class="d-flex flex-wrap gap-2">
                <span class="badge bg-success">PO_Receive - Purchase Order Receive</span>
                <span class="badge bg-danger">PO_Return - Purchase Order Return</span>
                <span class="badge bg-warning">Transfer_Out - Transfer Out</span>
                <span class="badge bg-info">Transfer_In - Transfer In</span>
                <span class="badge bg-success">FG_Produce - FG Production</span>
                <span class="badge bg-danger">FG_Deliver - FG Delivery</span>
                <span class="badge bg-warning">FG_Return - FG Return</span>
                <span class="badge bg-success">Adjustment_Add - Adjustment Add</span>
                <span class="badge bg-danger">Adjustment_Sub - Adjustment Subtract</span>
                <span class="badge bg-danger">QC_Reject - QC Reject</span>
            </div>
        </div>
    </div>
</div>

<script>
// Auto-submit form when filters change (optional)
document.querySelectorAll('select[name="type"], input[name="date_from"], input[name="date_to"]').forEach(function(el) {
    el.addEventListener('change', function() {
        // Uncomment to auto-submit
        // this.closest('form').submit();
    });
});
</script>