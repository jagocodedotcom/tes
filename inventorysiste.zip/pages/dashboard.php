<?php
// ======================================================
// DASHBOARD UTAMA
// ======================================================

// Query Total Summary
$totalCustomers = fetchCount("SELECT COUNT(*) FROM customers WHERE Status = 1");
$totalSuppliers = fetchCount("SELECT COUNT(*) FROM suppliers WHERE Status = 1");
$totalProducts = fetchCount("SELECT COUNT(*) FROM products WHERE Active = 1");
$totalMaterials = fetchCount("SELECT COUNT(*) FROM materials WHERE Active = 1");
$totalUsers = fetchCount("SELECT COUNT(*) FROM users WHERE IsActive = 1");

// Query Order Summary
$activePO = fetchCount("SELECT COUNT(*) FROM purchase_orders WHERE Status NOT IN ('Completed', 'Cancelled')");
$activeSO = fetchCount("SELECT COUNT(*) FROM customer_pos WHERE Status NOT IN ('Completed', 'Cancelled')");
$activeWO = fetchCount("SELECT COUNT(*) FROM production_orders WHERE Status NOT IN ('Completed', 'Cancelled')");

// Query Stock Summary
$stockSummary = fetchAll("
    SELECT 
        'Material' AS Type,
        COUNT(DISTINCT MaterialID) AS TotalItems,
        SUM(QtyOnHand) AS TotalStock,
        SUM(QtyReserved) AS TotalReserved,
        SUM(QtyAvailable) AS TotalAvailable
    FROM material_stock
    UNION ALL
    SELECT 
        'FG' AS Type,
        COUNT(DISTINCT ProductID) AS TotalItems,
        SUM(QtyOnHand) AS TotalStock,
        SUM(QtyReserved) AS TotalReserved,
        SUM(QtyAvailable) AS TotalAvailable
    FROM stock_fg
");

// Query Critical Stock
$criticalMaterials = fetchAll("
    SELECT 
        m.MaterialCode,
        m.MaterialName,
        m.MinStock,
        m.MaxStock,
        COALESCE(s.QtyAvailable, 0) AS AvailableStock
    FROM materials m
    LEFT JOIN material_stock s ON m.MaterialID = s.MaterialID
    WHERE m.Active = 1
    HAVING AvailableStock <= m.MinStock
    ORDER BY (m.MinStock - AvailableStock) DESC
    LIMIT 5
");

// Query Production Today
$productionToday = fetchAll("
    SELECT 
        pr.ProductionDate,
        pr.Shift,
        SUM(pr.QtyProduced) AS TotalProduced,
        SUM(pr.QtyReject) AS TotalReject,
        ROUND(SUM(pr.QtyGood) / NULLIF(SUM(pr.QtyProduced), 0) * 100, 2) AS YieldRate
    FROM production_results pr
    WHERE pr.ProductionDate = CURDATE()
    GROUP BY pr.Shift
");

// Query Recent Activities
$recentActivities = fetchAll("
    (SELECT 
        'PO' AS Type,
        PONumber AS Document,
        Status,
        CreatedAt AS Date
    FROM purchase_orders
    ORDER BY CreatedAt DESC
    LIMIT 3)
    UNION ALL
    (SELECT 
        'SO' AS Type,
        PONumber AS Document,
        Status,
        CreatedAt AS Date
    FROM customer_pos
    ORDER BY CreatedAt DESC
    LIMIT 3)
    UNION ALL
    (SELECT 
        'WO' AS Type,
        WONumber AS Document,
        Status,
        CreatedAt AS Date
    FROM production_orders
    ORDER BY CreatedAt DESC
    LIMIT 3)
    ORDER BY Date DESC
    LIMIT 10
");
?>

<!-- ====================================================== -->
<!-- DASHBOARD CONTENT -->
<!-- ====================================================== -->

<div id="page-content-wrapper" class="p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3">
            <i class="fas fa-tachometer-alt me-2 text-primary"></i>Dashboard
        </h1>
        <div>
            <span class="text-muted">
                <i class="far fa-calendar-alt me-1"></i>
                <?= date('d F Y, H:i') ?>
            </span>
        </div>
    </div>

    <!-- ====================================================== -->
    <!-- STATISTIK KARTU -->
    <!-- ====================================================== -->
    <div class="row g-3 mb-4">
        <div class="col-xl-3 col-md-6">
            <div class="card bg-primary text-white h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-white-50">Total Customer</h6>
                            <h2 class="display-6 fw-bold"><?= number_format($totalCustomers) ?></h2>
                        </div>
                        <i class="fas fa-users fa-3x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6">
            <div class="card bg-success text-white h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-white-50">Total Supplier</h6>
                            <h2 class="display-6 fw-bold"><?= number_format($totalSuppliers) ?></h2>
                        </div>
                        <i class="fas fa-truck fa-3x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6">
            <div class="card bg-warning text-dark h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-dark-50">Total Product</h6>
                            <h2 class="display-6 fw-bold"><?= number_format($totalProducts) ?></h2>
                        </div>
                        <i class="fas fa-box fa-3x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6">
            <div class="card bg-info text-white h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-white-50">Total Material</h6>
                            <h2 class="display-6 fw-bold"><?= number_format($totalMaterials) ?></h2>
                        </div>
                        <i class="fas fa-cubes fa-3x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ====================================================== -->
    <!-- ORDER STATUS -->
    <!-- ====================================================== -->
    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="card h-100 border-start border-primary border-4">
                <div class="card-body text-center">
                    <i class="fas fa-shopping-cart fa-3x text-primary mb-2"></i>
                    <h5>Purchase Orders</h5>
                    <h2 class="display-5 fw-bold"><?= number_format($activePO) ?></h2>
                    <span class="text-muted">Active Orders</span>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card h-100 border-start border-success border-4">
                <div class="card-body text-center">
                    <i class="fas fa-file-invoice fa-3x text-success mb-2"></i>
                    <h5>Sales Orders</h5>
                    <h2 class="display-5 fw-bold"><?= number_format($activeSO) ?></h2>
                    <span class="text-muted">Active Orders</span>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card h-100 border-start border-warning border-4">
                <div class="card-body text-center">
                    <i class="fas fa-tasks fa-3x text-warning mb-2"></i>
                    <h5>Work Orders</h5>
                    <h2 class="display-5 fw-bold"><?= number_format($activeWO) ?></h2>
                    <span class="text-muted">Active Orders</span>
                </div>
            </div>
        </div>
    </div>

    <!-- ====================================================== -->
    <!-- CHART & STOCK SUMMARY -->
    <!-- ====================================================== -->
    <div class="row g-3 mb-4">
        <div class="col-lg-8">
            <div class="card h-100">
                <div class="card-header">
                    <i class="fas fa-chart-line me-2"></i>
                    Production Trend (Last 30 Days)
                </div>
                <div class="card-body">
                    <canvas id="productionChart" height="250"></canvas>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card h-100">
                <div class="card-header">
                    <i class="fas fa-warehouse me-2"></i>
                    Stock Summary
                </div>
                <div class="card-body">
                    <?php 
                    $stockCount = count($stockSummary);
                    $stockIndex = 0;
                    foreach($stockSummary as $stock): 
                        $stockIndex++;
                    ?>
                    <div class="mb-3">
                        <h6><?= htmlspecialchars($stock['Type']) ?></h6>
                        <div class="d-flex justify-content-between mb-1">
                            <span>Total Stock</span>
                            <strong><?= number_format($stock['TotalStock'], 0) ?></strong>
                        </div>
                        <div class="d-flex justify-content-between mb-1">
                            <span>Reserved</span>
                            <strong><?= number_format($stock['TotalReserved'], 0) ?></strong>
                        </div>
                        <div class="d-flex justify-content-between">
                            <span>Available</span>
                            <strong class="text-success"><?= number_format($stock['TotalAvailable'], 0) ?></strong>
                        </div>
                        <?php if($stockIndex < $stockCount): ?>
                        <hr>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                    
                    <?php if(empty($stockSummary)): ?>
                    <div class="text-center text-muted">
                        <i class="fas fa-box-open fa-2x mb-2 d-block"></i>
                        No stock data available
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- ====================================================== -->
    <!-- CRITICAL STOCK & PRODUCTION TODAY -->
    <!-- ====================================================== -->
    <div class="row g-3 mb-4">
        <div class="col-lg-6">
            <div class="card h-100">
                <div class="card-header">
                    <i class="fas fa-exclamation-triangle text-danger me-2"></i>
                    Critical Stock Warning
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-sm mb-0">
                            <thead>
                                <tr>
                                    <th>Material Code</th>
                                    <th>Material Name</th>
                                    <th>Available</th>
                                    <th>Min Stock</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(empty($criticalMaterials)): ?>
                                <tr>
                                    <td colspan="5" class="text-center text-success py-3">
                                        <i class="fas fa-check-circle me-1"></i> 
                                        All materials are safe!
                                    </td>
                                </tr>
                                <?php else: ?>
                                <?php foreach($criticalMaterials as $item): ?>
                                <tr>
                                    <td><?= htmlspecialchars($item['MaterialCode']) ?></td>
                                    <td><?= htmlspecialchars($item['MaterialName']) ?></td>
                                    <td class="text-danger fw-bold"><?= number_format($item['AvailableStock'], 0) ?></td>
                                    <td><?= number_format($item['MinStock'], 0) ?></td>
                                    <td>
                                        <span class="badge bg-danger">Critical</span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="card h-100">
                <div class="card-header">
                    <i class="fas fa-industry me-2"></i>
                    Production Today
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-sm mb-0">
                            <thead>
                                <tr>
                                    <th>Shift</th>
                                    <th>Produced</th>
                                    <th>Reject</th>
                                    <th>Yield</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(empty($productionToday)): ?>
                                <tr>
                                    <td colspan="4" class="text-center text-muted py-3">
                                        <i class="fas fa-info-circle me-1"></i>
                                        No production data today
                                    </td>
                                </tr>
                                <?php else: ?>
                                <?php foreach($productionToday as $prod): ?>
                                <tr>
                                    <td>
                                        <?php 
                                        $shiftLabels = [
                                            'Shift 1' => 'Shift 1 (08:00-16:00)',
                                            'Shift 2' => 'Shift 2 (16:00-00:00)',
                                            'Shift 3' => 'Shift 3 (00:00-08:00)'
                                        ];
                                        $shiftLabel = isset($shiftLabels[$prod['Shift']]) ? $shiftLabels[$prod['Shift']] : $prod['Shift'];
                                        echo htmlspecialchars($shiftLabel);
                                        ?>
                                    </td>
                                    <td><?= number_format($prod['TotalProduced'], 0) ?></td>
                                    <td><?= number_format($prod['TotalReject'], 0) ?></td>
                                    <td>
                                        <?php 
                                        $percentage = isset($prod['YieldRate']) ? (float)$prod['YieldRate'] : 0;
                                        $color = 'success';
                                        if ($percentage < 30) $color = 'danger';
                                        else if ($percentage < 70) $color = 'warning';
                                        ?>
                                        <div class="progress" style="height: 20px;">
                                            <div class="progress-bar bg-<?= $color ?>" 
                                                 role="progressbar" 
                                                 style="width: <?= $percentage ?>%;" 
                                                 aria-valuenow="<?= $percentage ?>" 
                                                 aria-valuemin="0" 
                                                 aria-valuemax="100">
                                                <?= number_format($percentage, 1) ?>%
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ====================================================== -->
    <!-- RECENT ACTIVITIES -->
    <!-- ====================================================== -->
    <div class="card">
        <div class="card-header">
            <i class="fas fa-clock me-2"></i>
            Recent Activities
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-sm mb-0">
                    <thead>
                        <tr>
                            <th>Type</th>
                            <th>Document</th>
                            <th>Status</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($recentActivities)): ?>
                        <tr>
                            <td colspan="4" class="text-center text-muted py-3">
                                <i class="fas fa-info-circle me-1"></i>
                                No recent activities
                            </td>
                        </tr>
                        <?php else: ?>
                        <?php foreach($recentActivities as $activity): ?>
                        <tr>
                            <td>
                                <?php if($activity['Type'] == 'PO'): ?>
                                <span class="badge bg-primary">PO</span>
                                <?php elseif($activity['Type'] == 'SO'): ?>
                                <span class="badge bg-success">SO</span>
                                <?php else: ?>
                                <span class="badge bg-warning">WO</span>
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($activity['Document']) ?></td>
                            <td>
                                <?php 
                                $statusColors = [
                                    'Open' => 'primary',
                                    'Running' => 'info',
                                    'Partial' => 'warning',
                                    'Completed' => 'success',
                                    'Cancelled' => 'danger',
                                    'Draft' => 'secondary',
                                    'Submitted' => 'info',
                                    'Approved' => 'success'
                                ];
                                $color = isset($statusColors[$activity['Status']]) ? $statusColors[$activity['Status']] : 'secondary';
                                ?>
                                <span class="badge bg-<?= $color ?>"><?= htmlspecialchars($activity['Status']) ?></span>
                            </td>
                            <td><?= date('d/m/Y H:i', strtotime($activity['Date'])) ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- ====================================================== -->
<!-- SCRIPT CHART -->
<!-- ====================================================== -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Ambil data chart dari API
    fetch('api/get_chart_data.php')
        .then(response => response.json())
        .then(data => {
            const ctx = document.getElementById('productionChart').getContext('2d');
            
            // Default data jika kosong
            if (!data.labels || data.labels.length === 0) {
                data.labels = [];
                data.values = [];
                for(let i = 29; i >= 0; i--) {
                    const d = new Date();
                    d.setDate(d.getDate() - i);
                    data.labels.push(d.toLocaleDateString('id-ID', {day: '2-digit', month: 'short'}));
                    data.values.push(0);
                }
            }
            
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: data.labels,
                    datasets: [{
                        label: 'Production Qty',
                        data: data.values,
                        borderColor: '#4e73df',
                        backgroundColor: 'rgba(78, 115, 223, 0.1)',
                        borderWidth: 2,
                        tension: 0.3,
                        fill: true,
                        pointBackgroundColor: '#4e73df',
                        pointBorderColor: '#fff',
                        pointBorderWidth: 2,
                        pointRadius: 3
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: function(value) {
                                    return value.toLocaleString('id-ID');
                                }
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            }
                        }
                    }
                }
            });
        })
        .catch(error => {
            console.error('Error loading chart data:', error);
            // Tampilkan pesan error di chart
            const ctx = document.getElementById('productionChart').getContext('2d');
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: ['No Data Available'],
                    datasets: [{
                        label: 'No Data',
                        data: [0],
                        borderColor: '#ccc',
                        backgroundColor: 'rgba(200, 200, 200, 0.1)'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    }
                }
            });
        });
});
</script>