<?php
// ======================================================
// HALAMAN TAMBAH MATERIAL
// ======================================================

// ======================================================
// PERBAIKAN: Output Buffering di awal
// ======================================================
ob_start();

// Proses submit form
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $materialCode = trim($_POST['material_code']);
    $materialName = trim($_POST['material_name']);
    $specification = trim($_POST['specification']);
    $uom = trim($_POST['uom']);
    $category = trim($_POST['category']);
    $minStock = isset($_POST['min_stock']) ? str_replace(',', '', $_POST['min_stock']) : 0;
    $maxStock = isset($_POST['max_stock']) ? str_replace(',', '', $_POST['max_stock']) : 0;
    $active = isset($_POST['active']) ? (int)$_POST['active'] : 1;
    
    $errors = [];
    
    // Validasi required
    if(empty($materialCode)) $errors[] = "Material Code is required";
    if(empty($materialName)) $errors[] = "Material Name is required";
    if(empty($uom)) $errors[] = "Unit of Measure (UOM) is required";
    if(empty($category)) $errors[] = "Category is required";
    
    // Validasi stock
    if($minStock < 0) $errors[] = "Min stock cannot be negative";
    if($maxStock < 0) $errors[] = "Max stock cannot be negative";
    if($maxStock > 0 && $minStock > $maxStock) $errors[] = "Min stock cannot be greater than max stock";
    
    // Cek duplicate code
    if(empty($errors)) {
        $check = fetchOne("SELECT MaterialID FROM materials WHERE MaterialCode = ?", [$materialCode]);
        if($check) {
            $errors[] = "Material Code '{$materialCode}' already exists! Please use a different code.";
        }
    }
    
    if(empty($errors)) {
        try {
            $sql = "INSERT INTO materials (MaterialCode, MaterialName, Specification, UOM, Category, MinStock, MaxStock, Active) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            query($sql, [$materialCode, $materialName, $specification, $uom, $category, $minStock, $maxStock, $active]);
            
            // ======================================================
            // PERBAIKAN: Bersihkan buffer sebelum redirect
            // ======================================================
            ob_clean();
            header("Location: index.php?page=materials&msg=created&type=success");
            exit;
        } catch(PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}

// ======================================================
// PERBAIKAN: Bersihkan buffer sebelum HTML
// ======================================================
ob_end_clean();
?>
<div id="page-content-wrapper" class="p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3"><i class="fas fa-cubes-plus me-2 text-primary"></i>Add Material</h1>
            <p class="text-muted">Add new raw material</p>
        </div>
        <a href="<?= url('materials') ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i>Back
        </a>
    </div>

    <?php if(isset($errors) && !empty($errors)): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <strong><i class="fas fa-exclamation-circle me-1"></i> Please fix the following errors:</strong>
        <ul class="mb-0 mt-1">
            <?php foreach($errors as $error): ?>
            <li><?= htmlspecialchars($error) ?></li>
            <?php endforeach; ?>
        </ul>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header"><i class="fas fa-edit me-1"></i> Material Form</div>
        <div class="card-body">
            <form method="POST" action="" id="materialForm">
                <div class="row g-3">
                    <!-- Material Code -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Material Code <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <input type="text" name="material_code" id="material_code" class="form-control" 
                                   placeholder="e.g: MTR-001" 
                                   value="<?= isset($_POST['material_code']) ? htmlspecialchars($_POST['material_code']) : '' ?>" 
                                   required>
                            <button type="button" class="btn btn-outline-secondary" id="suggestCode" title="Suggest new code">
                                <i class="fas fa-sync-alt"></i>
                            </button>
                        </div>
                        <small class="text-muted">
                            <i class="fas fa-info-circle me-1"></i>
                            Unique identifier for the material
                        </small>
                        <div id="codeStatus" class="mt-1"></div>
                    </div>
                    
                    <!-- Material Name -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Material Name <span class="text-danger">*</span></label>
                        <input type="text" name="material_name" class="form-control" 
                               placeholder="e.g: PVC Resin" 
                               value="<?= isset($_POST['material_name']) ? htmlspecialchars($_POST['material_name']) : '' ?>" 
                               required>
                    </div>
                    
                    <!-- Specification -->
                    <div class="col-12">
                        <label class="form-label fw-bold">Specification</label>
                        <textarea name="specification" class="form-control" rows="2" 
                                  placeholder="Material specification (e.g: Grade A, 25kg/bag)"><?= isset($_POST['specification']) ? htmlspecialchars($_POST['specification']) : '' ?></textarea>
                    </div>
                    
                    <!-- UOM & Category -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Unit of Measure (UOM) <span class="text-danger">*</span></label>
                        <select name="uom" class="form-select" required>
                            <option value="">-- Select UOM --</option>
                            <option value="PCS" <?= (isset($_POST['uom']) && $_POST['uom'] == 'PCS') ? 'selected' : '' ?>>PCS</option>
                            <option value="KG" <?= (isset($_POST['uom']) && $_POST['uom'] == 'KG') ? 'selected' : '' ?>>KG</option>
                            <option value="GRAM" <?= (isset($_POST['uom']) && $_POST['uom'] == 'GRAM') ? 'selected' : '' ?>>GRAM</option>
                            <option value="LITER" <?= (isset($_POST['uom']) && $_POST['uom'] == 'LITER') ? 'selected' : '' ?>>LITER</option>
                            <option value="METER" <?= (isset($_POST['uom']) && $_POST['uom'] == 'METER') ? 'selected' : '' ?>>METER</option>
                            <option value="ROLL" <?= (isset($_POST['uom']) && $_POST['uom'] == 'ROLL') ? 'selected' : '' ?>>ROLL</option>
                            <option value="UNIT" <?= (isset($_POST['uom']) && $_POST['uom'] == 'UNIT') ? 'selected' : '' ?>>UNIT</option>
                            <option value="BAG" <?= (isset($_POST['uom']) && $_POST['uom'] == 'BAG') ? 'selected' : '' ?>>BAG</option>
                            <option value="DRUM" <?= (isset($_POST['uom']) && $_POST['uom'] == 'DRUM') ? 'selected' : '' ?>>DRUM</option>
                        </select>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Category <span class="text-danger">*</span></label>
                        <input type="text" name="category" class="form-control" 
                               placeholder="e.g: Chemical, Plastic, Additive" 
                               value="<?= isset($_POST['category']) ? htmlspecialchars($_POST['category']) : '' ?>" 
                               required>
                    </div>
                    
                    <!-- Min Stock & Max Stock -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Min Stock</label>
                        <input type="number" name="min_stock" class="form-control" 
                               placeholder="0" 
                               value="<?= isset($_POST['min_stock']) ? htmlspecialchars($_POST['min_stock']) : '0' ?>"
                               min="0">
                        <small class="text-muted">Minimum stock level</small>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Max Stock</label>
                        <input type="number" name="max_stock" class="form-control" 
                               placeholder="0" 
                               value="<?= isset($_POST['max_stock']) ? htmlspecialchars($_POST['max_stock']) : '0' ?>"
                               min="0">
                        <small class="text-muted">Maximum stock level</small>
                    </div>
                    
                    <!-- Status -->
                    <div class="col-12">
                        <label class="form-label fw-bold">Status</label>
                        <div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="active" id="active1" value="1" checked>
                                <label class="form-check-label" for="active1">
                                    <span class="badge bg-success">Active</span>
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="active" id="active0" value="0">
                                <label class="form-check-label" for="active0">
                                    <span class="badge bg-danger">Inactive</span>
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Buttons -->
                    <div class="col-12">
                        <hr>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Save Material
                        </button>
                       
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ====================================================== -->
<!-- SCRIPT JAVASCRIPT -->
<!-- ====================================================== -->
<script>
// Cek kode material secara real-time
document.getElementById('material_code').addEventListener('blur', function() {
    var code = this.value.trim();
    var statusDiv = document.getElementById('codeStatus');
    
    if (code.length > 0) {
        fetch('api/check_material_code.php?code=' + encodeURIComponent(code))
            .then(response => response.json())
            .then(data => {
                if (data.exists) {
                    statusDiv.innerHTML = '<span class="text-danger"><i class="fas fa-times-circle me-1"></i> Code already exists!</span>';
                    document.getElementById('material_code').classList.add('is-invalid');
                    document.getElementById('material_code').classList.remove('is-valid');
                } else {
                    statusDiv.innerHTML = '<span class="text-success"><i class="fas fa-check-circle me-1"></i> Code available</span>';
                    document.getElementById('material_code').classList.remove('is-invalid');
                    document.getElementById('material_code').classList.add('is-valid');
                }
            })
            .catch(error => {
                console.error('Error checking code:', error);
            });
    }
});

// Suggest Code
document.getElementById('suggestCode').addEventListener('click', function() {
    var currentCode = document.getElementById('material_code').value;
    var prefix = currentCode.substring(0, 4);
    if (prefix.length < 4 || !prefix.includes('-')) {
        prefix = 'MTR-';
    }
    
    fetch('api/get_material_codes.php')
        .then(response => response.json())
        .then(data => {
            var maxNumber = 0;
            if (data.codes && data.codes.length > 0) {
                data.codes.forEach(function(code) {
                    var num = parseInt(code.substring(4));
                    if (num > maxNumber) maxNumber = num;
                });
            }
            var newNumber = maxNumber + 1;
            var newCode = prefix + String(newNumber).padStart(3, '0');
            document.getElementById('material_code').value = newCode;
            document.getElementById('material_code').focus();
            document.getElementById('material_code').dispatchEvent(new Event('blur'));
        })
        .catch(error => {
            var current = document.getElementById('material_code').value;
            var num = parseInt(current.substring(4)) || 0;
            var newNum = num + 1;
            var prefix = current.substring(0, 4) || 'MTR-';
            var newCode = prefix + String(newNum).padStart(3, '0');
            document.getElementById('material_code').value = newCode;
            document.getElementById('material_code').focus();
            document.getElementById('material_code').dispatchEvent(new Event('blur'));
        });
});
</script>
