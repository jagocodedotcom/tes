<?php
// ======================================================
// HALAMAN DETAIL MATERIAL
// ======================================================

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$material = fetchOne("SELECT * FROM materials WHERE MaterialID = ?", [$id]);

if(!$material) {
    header("Location: index.php?page=materials&msg=Material not found&type=danger");
    exit;
}

// Get Stock Information
$stockData = fetchOne("
    SELECT 
        COALESCE(SUM(QtyOnHand), 0) AS TotalStock,
        COALESCE(SUM(QtyReserved), 0) AS TotalReserved,
        COALESCE(SUM(QtyAvailable), 0) AS TotalAvailable
    FROM material_stock 
    WHERE MaterialID = ?
", [$id]);

// Get Recent Purchase Orders
$recentPO = fetchAll("
    SELECT 
        pod.PODetailID,
        po.PONumber,
        pod.QtyOrder,
        pod.QtyReceived,
        pod.Price,
        po.PODate,
        po.Status
    FROM purchase_order_details pod
    JOIN purchase_orders po ON pod.POID = po.POID
    WHERE pod.MaterialID = ?
    ORDER BY po.PODate DESC
    LIMIT 5
", [$id]);

$stockStatus = 'Safe';
$stockColor = 'success';
if ($stockData['TotalStock'] <= $material['MinStock']) {
    $stockStatus = 'Critical';
    $stockColor = 'danger';
} elseif ($stockData['TotalStock'] <= $material['MinStock'] * 1.5) {
    $stockStatus = 'Warning';
    $stockColor = 'warning';
}
?>

<div id="page-content-wrapper" class="p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3"><i class="fas fa-cubes me-2 text-primary"></i>Material Detail</h1>
            <p class="text-muted">View complete material information</p>
        </div>
        <div>
            <a href="<?= url('materials', 'edit', ['id' => $id]) ?>" class="btn btn-primary">
                <i class="fas fa-edit me-1"></i>Edit
            </a>
            <a href="<?= url('materials') ?>" class="btn btn-secondary">
                <i class="fas fa-arrow-left me-1"></i>Back
            </a>
        </div>
    </div>

    <div class="row g-3">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-header"><i class="fas fa-info-circle me-1"></i> Material Information</div>
                <div class="card-body">
                    <table class="table table-bordered mb-0">
                        <tr>
                            <th width="40%">Material Code</th>
                            <td><span class="badge bg-info"><?= htmlspecialchars($material['MaterialCode']) ?></span></td>
                        </tr>
                        <tr>
                            <th>Material Name</th>
                            <td><strong><?= htmlspecialchars($material['MaterialName']) ?></strong></td>
                        </tr>
                        <tr>
                            <th>Specification</th>
                            <td><?= nl2br(htmlspecialchars($material['Specification'])) ?></td>
                        </tr>
                        <tr>
                            <th>Unit of Measure</th>
                            <td><span class="badge bg-secondary"><?= htmlspecialchars($material['UOM']) ?></span></td>
                        </tr>
                        <tr>
                            <th>Category</th>
                            <td><?= htmlspecialchars($material['Category']) ?></td>
                        </tr>
                        <tr>
                            <th>Min Stock</th>
                            <td><?= number_format($material['MinStock']) ?></td>
                        </tr>
                        <tr>
                            <th>Max Stock</th>
                            <td><?= number_format($material['MaxStock']) ?></td>
                        </tr>
                        <tr>
                            <th>Status</th>
                            <td>
                                <?php if($material['Active'] == 1): ?>
                                <span class="badge bg-success">Active</span>
                                <?php else: ?>
                                <span class="badge bg-danger">Inactive</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>Created At</th>
                            <td><?= date('d/m/Y H:i', strtotime($material['CreatedAt'])) ?></td>
                        </tr>
                        <tr>
                            <th>Updated At</th>
                            <td><?= date('d/m/Y H:i', strtotime($material['UpdatedAt'])) ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <!-- Stock Information -->
            <div class="card mb-3">
                <div class="card-header"><i class="fas fa-warehouse me-1"></i> Stock Information</div>
                <div class="card-body">
                    <div class="row text-center">
                        <div class="col-4">
                            <h5><?= number_format($stockData['TotalStock']) ?></h5>
                            <small class="text-muted">On Hand</small>
                        </div>
                        <div class="col-4">
                            <h5 class="text-warning"><?= number_format($stockData['TotalReserved']) ?></h5>
                            <small class="text-muted">Reserved</small>
                        </div>
                        <div class="col-4">
                            <h5 class="text-success"><?= number_format($stockData['TotalAvailable']) ?></h5>
                            <small class="text-muted">Available</small>
                        </div>
                    </div>
                    <div class="text-center mt-2">
                        <span class="badge bg-<?= $stockColor ?>">Stock Status: <?= $stockStatus ?></span>
                    </div>
                </div>
            </div>

            <!-- Recent Purchase Orders -->
            <div class="card">
                <div class="card-header"><i class="fas fa-file-invoice me-1"></i> Recent Purchase Orders</div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-sm mb-0">
                            <thead>
                                <tr>
                                    <th>PO Number</th>
                                    <th>Qty Order</th>
                                    <th>Qty Received</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(empty($recentPO)): ?>
                                <tr>
                                    <td colspan="4" class="text-center text-muted py-3">
                                        <i class="fas fa-inbox d-block mb-1"></i>
                                        No purchase orders found
                                    </td>
                                </tr>
                                <?php else: ?>
                                <?php foreach($recentPO as $po): ?>
                                <tr>
                                    <td><?= htmlspecialchars($po['PONumber']) ?></td>
                                    <td><?= number_format($po['QtyOrder']) ?></td>
                                    <td><?= number_format($po['QtyReceived']) ?></td>
                                    <td>
                                        <?php 
                                        $colors = [
                                            'Draft' => 'secondary',
                                            'Submitted' => 'info',
                                            'Approved' => 'primary',
                                            'Partial' => 'warning',
                                            'Completed' => 'success',
                                            'Cancelled' => 'danger'
                                        ];
                                        $color = isset($colors[$po['Status']]) ? $colors[$po['Status']] : 'secondary';
                                        ?>
                                        <span class="badge bg-<?= $color ?>"><?= htmlspecialchars($po['Status']) ?></span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>