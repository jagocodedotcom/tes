<?php
// ======================================================
// HALAMAN LIST MATERIALS
// ======================================================

// ======================================================
// PERBAIKAN: HAPUS ob_start() - TIDAK PERLU!
// File index hanya menampilkan data, tidak ada header/redirect
// ======================================================

// Pagination
$page = isset($_GET['page_num']) ? (int)$_GET['page_num'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

// Search
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Build Query
$whereClause = "WHERE 1=1";
$params = [];

if (!empty($search)) {
    $whereClause .= " AND (MaterialCode LIKE ? OR MaterialName LIKE ? OR Category LIKE ?)";
    $searchTerm = "%$search%";
    $params = [$searchTerm, $searchTerm, $searchTerm];
}

// Get Total Data
$totalQuery = "SELECT COUNT(*) FROM materials $whereClause";
$totalData = fetchCount($totalQuery, $params);
$totalPages = ceil($totalData / $limit);

// Get Data
$query = "
    SELECT 
        MaterialID,
        MaterialCode,
        MaterialName,
        Specification,
        UOM,
        Category,
        MinStock,
        MaxStock,
        Active,
        CreatedAt,
        (SELECT COALESCE(SUM(QtyOnHand), 0) FROM material_stock WHERE MaterialID = m.MaterialID) AS TotalStock
    FROM materials m
    $whereClause
    ORDER BY MaterialName
    LIMIT $limit OFFSET $offset
";
$materials = fetchAll($query, $params);

// Get Success/Error Message
$message = isset($_GET['msg']) ? $_GET['msg'] : '';
$messageType = isset($_GET['type']) ? $_GET['type'] : '';
?>

<div id="page-content-wrapper" class="p-4">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3">
                <i class="fas fa-cubes me-2 text-primary"></i>Materials
            </h1>
            <p class="text-muted">Manage raw materials inventory</p>
        </div>
        <a href="<?= url('materials', 'create') ?>" class="btn btn-primary">
            <i class="fas fa-plus me-1"></i>Add Material
        </a>
    </div>

    <!-- Alert Message -->
    <?php if($message): ?>
    <div class="alert alert-<?= $messageType ?> alert-dismissible fade show" role="alert">
        <?php 
        if($message == 'created') echo 'Material berhasil ditambahkan!';
        elseif($message == 'updated') echo 'Material berhasil diperbarui!';
        elseif($message == 'deleted') echo 'Material berhasil dihapus!';
        else echo htmlspecialchars($message);
        ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <!-- Search -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <input type="hidden" name="page" value="materials">
                <div class="col-md-10">
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                        <input type="text" name="search" class="form-control" 
                               placeholder="Search by code, name, or category..." 
                               value="<?= htmlspecialchars($search) ?>">
                    </div>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search me-1"></i>Search
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Table -->
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <span><i class="fas fa-list me-1"></i> Material List</span>
                <span class="badge bg-primary"><?= number_format($totalData) ?> Records</span>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover table-striped mb-0">
                    <thead>
                        <tr>
                            <th width="50">#</th>
                            <th>Code</th>
                            <th>Material Name</th>
                            <th>Category</th>
                            <th>UOM</th>
                            <th>Stock</th>
                            <th>Min Stock</th>
                            <th>Status</th>
                            <th>Created</th>
                            <th width="120">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($materials)): ?>
                        <tr>
                            <td colspan="10" class="text-center text-muted py-4">
                                <i class="fas fa-inbox fa-2x d-block mb-2"></i>
                                No materials found
                            </td>
                        </tr>
                        <?php else: ?>
                        <?php 
                        $no = $offset + 1;
                        foreach($materials as $row): 
                            $stockStatus = 'Safe';
                            $stockColor = 'success';
                            if ($row['TotalStock'] <= $row['MinStock']) {
                                $stockStatus = 'Critical';
                                $stockColor = 'danger';
                            } elseif ($row['TotalStock'] <= $row['MinStock'] * 1.5) {
                                $stockStatus = 'Warning';
                                $stockColor = 'warning';
                            }
                        ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td>
                                <span class="badge bg-info"><?= htmlspecialchars($row['MaterialCode']) ?></span>
                            </td>
                            <td>
                                <strong><?= htmlspecialchars($row['MaterialName']) ?></strong>
                                <br>
                                <small class="text-muted"><?= htmlspecialchars($row['Specification']) ?></small>
                            </td>
                            <td>
                                <span class="badge bg-secondary"><?= htmlspecialchars($row['Category']) ?></span>
                            </td>
                            <td><?= htmlspecialchars($row['UOM']) ?></td>
                            <td>
                                <span class="badge bg-<?= $stockColor ?>">
                                    <?= number_format($row['TotalStock']) ?>
                                </span>
                            </td>
                            <td><?= number_format($row['MinStock']) ?></td>
                            <td>
                                <?php if($row['Active'] == 1): ?>
                                <span class="badge bg-success">Active</span>
                                <?php else: ?>
                                <span class="badge bg-danger">Inactive</span>
                                <?php endif; ?>
                            </td>
                            <td><?= date('d/m/Y', strtotime($row['CreatedAt'])) ?></td>
                            <td>
                                <div class="btn-group btn-group-sm">
                                    <a href="<?= url('materials', 'view', ['id' => $row['MaterialID']]) ?>" 
                                       class="btn btn-outline-info" title="View">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="<?= url('materials', 'edit', ['id' => $row['MaterialID']]) ?>" 
                                       class="btn btn-outline-primary" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="<?= url('materials', 'delete', ['id' => $row['MaterialID']]) ?>" 
                                       class="btn btn-outline-danger" title="Delete"
                                       onclick="return confirm('Apakah anda yakin akan menghapus data ini?')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php if($totalPages > 1): ?>
        <div class="card-footer">
            <nav>
                <ul class="pagination pagination-sm mb-0">
                    <?php if($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=materials&page_num=<?= $page-1 ?>&search=<?= urlencode($search) ?>">
                            <i class="fas fa-chevron-left"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <?php for($i = 1; $i <= $totalPages; $i++): ?>
                    <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                        <a class="page-link" href="?page=materials&page_num=<?= $i ?>&search=<?= urlencode($search) ?>">
                            <?= $i ?>
                        </a>
                    </li>
                    <?php endfor; ?>
                    
                    <?php if($page < $totalPages): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=materials&page_num=<?= $page+1 ?>&search=<?= urlencode($search) ?>">
                            <i class="fas fa-chevron-right"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php
// ======================================================
// PERBAIKAN: TIDAK PERLU ob_end_flush() DI SINI
// Karena tidak ada ob_start() di file ini
// ======================================================
?>