<?php
// ======================================================
// HALAMAN EDIT MATERIAL
// ======================================================

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$material = fetchOne("SELECT * FROM materials WHERE MaterialID = ?", [$id]);

if(!$material) {
    header("Location: index.php?page=materials&msg=Material not found&type=danger");
    exit;
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $materialCode = trim($_POST['material_code']);
    $materialName = trim($_POST['material_name']);
    $specification = trim($_POST['specification']);
    $uom = trim($_POST['uom']);
    $category = trim($_POST['category']);
    $minStock = isset($_POST['min_stock']) ? str_replace(',', '', $_POST['min_stock']) : 0;
    $maxStock = isset($_POST['max_stock']) ? str_replace(',', '', $_POST['max_stock']) : 0;
    $active = isset($_POST['active']) ? (int)$_POST['active'] : 1;
    
    $errors = [];
    
    if(empty($materialCode)) $errors[] = "Material Code is required";
    if(empty($materialName)) $errors[] = "Material Name is required";
    if(empty($uom)) $errors[] = "Unit of Measure (UOM) is required";
    if(empty($category)) $errors[] = "Category is required";
    if($minStock < 0) $errors[] = "Min stock cannot be negative";
    if($maxStock < 0) $errors[] = "Max stock cannot be negative";
    if($maxStock > 0 && $minStock > $maxStock) $errors[] = "Min stock cannot be greater than max stock";
    
    if(empty($errors)) {
        $check = fetchOne("SELECT MaterialID FROM materials WHERE MaterialCode = ? AND MaterialID != ?", [$materialCode, $id]);
        if($check) {
            $errors[] = "Material Code already exists!";
        }
    }
    
    if(empty($errors)) {
        try {
            $sql = "UPDATE materials SET 
                    MaterialCode = ?, 
                    MaterialName = ?, 
                    Specification = ?, 
                    UOM = ?, 
                    Category = ?, 
                    MinStock = ?,
                    MaxStock = ?,
                    Active = ?,
                    UpdatedAt = NOW()
                    WHERE MaterialID = ?";
            query($sql, [$materialCode, $materialName, $specification, $uom, $category, $minStock, $maxStock, $active, $id]);
            
            header("Location: index.php?page=materials&msg=updated&type=success");
            exit;
        } catch(PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}
?>

<div id="page-content-wrapper" class="p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3"><i class="fas fa-edit me-2 text-primary"></i>Edit Material</h1>
            <p class="text-muted">Edit material: <?= htmlspecialchars($material['MaterialCode']) ?></p>
        </div>
        <a href="<?= url('materials') ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i>Back
        </a>
    </div>

    <?php if(isset($errors) && !empty($errors)): ?>
    <div class="alert alert-danger">
        <strong><i class="fas fa-exclamation-circle me-1"></i> Please fix the following errors:</strong>
        <ul class="mb-0 mt-1">
            <?php foreach($errors as $error): ?>
            <li><?= htmlspecialchars($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header"><i class="fas fa-edit me-1"></i> Edit Material Form</div>
        <div class="card-body">
            <form method="POST" action="">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Material Code <span class="text-danger">*</span></label>
                        <input type="text" name="material_code" class="form-control" 
                               value="<?= htmlspecialchars($material['MaterialCode']) ?>" required>
                        <small class="text-muted">Unique identifier for the material</small>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Material Name <span class="text-danger">*</span></label>
                        <input type="text" name="material_name" class="form-control" 
                               value="<?= htmlspecialchars($material['MaterialName']) ?>" required>
                    </div>
                    
                    <div class="col-12">
                        <label class="form-label fw-bold">Specification</label>
                        <textarea name="specification" class="form-control" rows="2"><?= htmlspecialchars($material['Specification']) ?></textarea>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Unit of Measure (UOM) <span class="text-danger">*</span></label>
                        <select name="uom" class="form-select" required>
                            <option value="">-- Select UOM --</option>
                            <option value="PCS" <?= $material['UOM'] == 'PCS' ? 'selected' : '' ?>>PCS</option>
                            <option value="KG" <?= $material['UOM'] == 'KG' ? 'selected' : '' ?>>KG</option>
                            <option value="GRAM" <?= $material['UOM'] == 'GRAM' ? 'selected' : '' ?>>GRAM</option>
                            <option value="LITER" <?= $material['UOM'] == 'LITER' ? 'selected' : '' ?>>LITER</option>
                            <option value="METER" <?= $material['UOM'] == 'METER' ? 'selected' : '' ?>>METER</option>
                            <option value="ROLL" <?= $material['UOM'] == 'ROLL' ? 'selected' : '' ?>>ROLL</option>
                            <option value="UNIT" <?= $material['UOM'] == 'UNIT' ? 'selected' : '' ?>>UNIT</option>
                            <option value="BAG" <?= $material['UOM'] == 'BAG' ? 'selected' : '' ?>>BAG</option>
                            <option value="DRUM" <?= $material['UOM'] == 'DRUM' ? 'selected' : '' ?>>DRUM</option>
                        </select>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Category <span class="text-danger">*</span></label>
                        <input type="text" name="category" class="form-control" 
                               value="<?= htmlspecialchars($material['Category']) ?>" required>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Min Stock</label>
                        <input type="number" name="min_stock" class="form-control" 
                               value="<?= htmlspecialchars($material['MinStock']) ?>">
                        <small class="text-muted">Minimum stock level</small>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Max Stock</label>
                        <input type="number" name="max_stock" class="form-control" 
                               value="<?= htmlspecialchars($material['MaxStock']) ?>">
                        <small class="text-muted">Maximum stock level</small>
                    </div>
                    
                    <div class="col-12">
                        <label class="form-label fw-bold">Status</label>
                        <div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="active" id="active1" value="1" 
                                       <?= $material['Active'] == 1 ? 'checked' : '' ?>>
                                <label class="form-check-label" for="active1">
                                    <span class="badge bg-success">Active</span>
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="active" id="active0" value="0"
                                       <?= $material['Active'] == 0 ? 'checked' : '' ?>>
                                <label class="form-check-label" for="active0">
                                    <span class="badge bg-danger">Inactive</span>
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-12">
                        <div class="alert alert-info">
                            <small>
                                <i class="fas fa-info-circle me-1"></i>
                                Created: <?= date('d/m/Y H:i', strtotime($material['CreatedAt'])) ?>
                                <?php if($material['UpdatedAt'] != $material['CreatedAt']): ?>
                                | Updated: <?= date('d/m/Y H:i', strtotime($material['UpdatedAt'])) ?>
                                <?php endif; ?>
                            </small>
                        </div>
                    </div>
                    
                    <div class="col-12">
                        <hr>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Update Material
                        </button>
                       
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>