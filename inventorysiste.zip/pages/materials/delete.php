<?php
// ======================================================
// PROSES HAPUS MATERIAL
// ======================================================

// ======================================================
// PERBAIKAN: Output Buffering di awal
// ======================================================
ob_start();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$material = fetchOne("SELECT * FROM materials WHERE MaterialID = ?", [$id]);

if(!$material) {
    // ======================================================
    // PERBAIKAN: Bersihkan buffer sebelum redirect
    // ======================================================
    ob_clean();
    header("Location: index.php?page=materials&msg=Material not found&type=danger");
    exit;
}

$hasStock = fetchCount("SELECT COUNT(*) FROM material_stock WHERE MaterialID = ?", [$id]);
$hasOrders = fetchCount("SELECT COUNT(*) FROM purchase_order_details WHERE MaterialID = ?", [$id]);

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    if($hasStock > 0 || $hasOrders > 0) {
        // Soft delete - hanya ubah status
        query("UPDATE materials SET Active = 0, UpdatedAt = NOW() WHERE MaterialID = ?", [$id]);
    } else {
        // Permanent delete
        query("DELETE FROM materials WHERE MaterialID = ?", [$id]);
    }
    
    // ======================================================
    // PERBAIKAN: Bersihkan buffer sebelum redirect
    // ======================================================
    ob_clean();
    header("Location: index.php?page=materials&msg=deleted&type=success");
    exit;
}

// ======================================================
// PERBAIKAN: Bersihkan buffer sebelum HTML
// ======================================================
ob_end_clean();
?>
<div id="page-content-wrapper" class="p-4">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-header bg-danger text-white">
                    <i class="fas fa-exclamation-triangle me-1"></i> Confirm Delete
                </div>
                <div class="card-body text-center py-4">
                    <i class="fas fa-cubes fa-4x text-danger mb-3"></i>
                    <h4>Apakah anda yakin akan menghapus data ini?</h4>
                    <p class="text-muted">
                        <strong><?= htmlspecialchars($material['MaterialCode']) ?></strong> - 
                        <?= htmlspecialchars($material['MaterialName']) ?>
                    </p>
                    
                    <?php if($hasStock > 0 || $hasOrders > 0): ?>
                    <div class="alert alert-warning">
                        <i class="fas fa-info-circle me-1"></i>
                        This material has 
                        <?php if($hasStock > 0): ?>
                        <strong><?= number_format($hasStock) ?> stock record(s)</strong>
                        <?php endif; ?>
                        <?php if($hasStock > 0 && $hasOrders > 0): ?> and <?php endif; ?>
                        <?php if($hasOrders > 0): ?>
                        <strong><?= number_format($hasOrders) ?> purchase order(s)</strong>
                        <?php endif; ?>.
                        Material ini akan <strong>deactivated</strong> akan dihapus secara permanen?
                    </div>
                    <?php else: ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-info-circle me-1"></i>
                        Material ini memiliki<strong>no stock or orders</strong>.
                        Material ini  <strong>akan dihapus secara permanen?</strong>.
                    </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="" class="d-inline">
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash me-1"></i> Yes, Delete
                        </button>
                        <a href="<?= url('materials') ?>" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i> Cancel
                        </a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>