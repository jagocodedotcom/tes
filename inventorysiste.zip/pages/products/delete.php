<?php
// ======================================================
// PROSES HAPUS PRODUCT
// ======================================================

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$product = fetchOne("SELECT * FROM products WHERE ProductID = ?", [$id]);

if(!$product) {
    header("Location: index.php?page=products&msg=Product not found&type=danger");
    exit;
}

$hasOrders = fetchCount("SELECT COUNT(*) FROM customer_po_details WHERE ProductID = ?", [$id]);

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    if($hasOrders > 0) {
        // Soft delete - hanya ubah status
        query("UPDATE products SET Active = 0, UpdatedAt = NOW() WHERE ProductID = ?", [$id]);
    } else {
        // Permanent delete - HAPUS TANDA -- SEBELUM query DELETE
        query("DELETE FROM products WHERE ProductID = ?", [$id]);
    }
    
    header("Location: index.php?page=products&msg=deleted&type=success");
    exit;
}
?>

<div id="page-content-wrapper" class="p-4">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-header bg-danger text-white">
                    <i class="fas fa-exclamation-triangle me-1"></i> Confirm Delete
                </div>
                <div class="card-body text-center py-4">
                    <i class="fas fa-box fa-4x text-danger mb-3"></i>
                    <h4>Apakah anda yakin akan menghapus data ini?</h4>
                    <p class="text-muted">
                        <strong><?= htmlspecialchars($product['ProductCode']) ?></strong> - 
                        <?= htmlspecialchars($product['ProductName']) ?>
                    </p>
                    
                    <?php if($hasOrders > 0): ?>
                    <div class="alert alert-warning">
                        <i class="fas fa-info-circle me-1"></i>
                        Product ini memiliki <strong><?= number_format($hasOrders) ?> order(s)</strong>.
                        Product ini akan <strong>deactivated</strong> dihapus secara permanen ?
                    </div>
                    <?php else: ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-info-circle me-1"></i>
                        Product ini memiliki <strong>no orders</strong>.
                        Product ini <strong>akan dihapus secara permanen?</strong>.
                    </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="" class="d-inline">
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash me-1"></i> Yes, Delete
                        </button>
                        <a href="index.php?page=products" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i> Cancel
                        </a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>