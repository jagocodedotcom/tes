<?php
// ======================================================
// HALAMAN DETAIL PRODUCT
// ======================================================

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$product = fetchOne("SELECT * FROM products WHERE ProductID = ?", [$id]);

if(!$product) {
    header("Location: index.php?page=products&msg=Product not found&type=danger");
    exit;
}

// Get Stock Summary
$stockData = fetchOne("
    SELECT 
        COALESCE(SUM(QtyOnHand), 0) AS TotalStock,
        COALESCE(SUM(QtyReserved), 0) AS TotalReserved,
        COALESCE(SUM(QtyAvailable), 0) AS TotalAvailable
    FROM stock_fg 
    WHERE ProductID = ?
", [$id]);

// Get Recent Orders
$recentOrders = fetchAll("
    SELECT 
        cpod.CustomerPODetailID,
        cpo.PONumber,
        cpod.QtyOrder,
        cpod.QtyProduced,
        cpod.UnitPrice,
        cpod.Total,
        cpo.PODate,
        cpo.Status
    FROM customer_po_details cpod
    JOIN customer_pos cpo ON cpod.CustomerPOID = cpo.CustomerPOID
    WHERE cpod.ProductID = ?
    ORDER BY cpo.PODate DESC
    LIMIT 5
", [$id]);
?>

<div id="page-content-wrapper" class="p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3"><i class="fas fa-box me-2 text-primary"></i>Product Detail</h1>
            <p class="text-muted">View complete product information</p>
        </div>
        <div>
            <a href="index.php?page=products&action=edit&id=<?= $id ?>" class="btn btn-primary">
                <i class="fas fa-edit me-1"></i>Edit
            </a>
            <a href="index.php?page=products" class="btn btn-secondary">
                <i class="fas fa-arrow-left me-1"></i>Back
            </a>
        </div>
    </div>

    <div class="row g-3">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-header"><i class="fas fa-info-circle me-1"></i> Product Information</div>
                <div class="card-body">
                    <table class="table table-bordered mb-0">
                        <tr>
                            <th width="40%">Product Code</th>
                            <td><span class="badge bg-info"><?= htmlspecialchars($product['ProductCode']) ?></span></td>
                        </tr>
                        <tr>
                            <th>Product Name</th>
                            <td><strong><?= htmlspecialchars($product['ProductName']) ?></strong></td>
                        </tr>
                        <tr>
                            <th>Description</th>
                            <td><?= nl2br(htmlspecialchars($product['Description'])) ?></td>
                        </tr>
                        <tr>
                            <th>Unit of Measure</th>
                            <td><span class="badge bg-secondary"><?= htmlspecialchars($product['UOM']) ?></span></td>
                        </tr>
                        <tr>
                            <th>Category</th>
                            <td><?= htmlspecialchars($product['Category']) ?></td>
                        </tr>
                        <tr>
                            <th>Unit Price</th>
                            <td><strong>Rp <?= number_format($product['UnitPrice'], 0) ?></strong></td>
                        </tr>
                        <tr>
                            <th>Status</th>
                            <td>
                                <?php if($product['Active'] == 1): ?>
                                <span class="badge bg-success">Active</span>
                                <?php else: ?>
                                <span class="badge bg-danger">Inactive</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>Created At</th>
                            <td><?= date('d/m/Y H:i', strtotime($product['CreatedAt'])) ?></td>
                        </tr>
                        <tr>
                            <th>Updated At</th>
                            <td><?= date('d/m/Y H:i', strtotime($product['UpdatedAt'])) ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <!-- Stock Information -->
            <div class="card mb-3">
                <div class="card-header"><i class="fas fa-warehouse me-1"></i> Stock Information</div>
                <div class="card-body">
                    <div class="row text-center">
                        <div class="col-4">
                            <h5><?= number_format($stockData['TotalStock'] ?? 0) ?></h5>
                            <small class="text-muted">On Hand</small>
                        </div>
                        <div class="col-4">
                            <h5 class="text-warning"><?= number_format($stockData['TotalReserved'] ?? 0) ?></h5>
                            <small class="text-muted">Reserved</small>
                        </div>
                        <div class="col-4">
                            <h5 class="text-success"><?= number_format($stockData['TotalAvailable'] ?? 0) ?></h5>
                            <small class="text-muted">Available</small>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Orders -->
            <div class="card">
                <div class="card-header"><i class="fas fa-file-invoice me-1"></i> Recent Orders</div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-sm mb-0">
                            <thead>
                                <tr>
                                    <th>PO Number</th>
                                    <th>Qty</th>
                                    <th>Price</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(empty($recentOrders)): ?>
                                <tr>
                                    <td colspan="4" class="text-center text-muted py-3">
                                        <i class="fas fa-inbox d-block mb-1"></i>
                                        No orders found
                                    </td>
                                </tr>
                                <?php else: ?>
                                <?php foreach($recentOrders as $order): ?>
                                <tr>
                                    <td><?= htmlspecialchars($order['PONumber']) ?></td>
                                    <td><?= number_format($order['QtyOrder']) ?></td>
                                    <td>Rp <?= number_format($order['UnitPrice'], 0) ?></td>
                                    <td>
                                        <?php 
                                        $colors = [
                                            'Open' => 'primary',
                                            'Production' => 'info',
                                            'Partial' => 'warning',
                                            'Completed' => 'success',
                                            'Cancelled' => 'danger'
                                        ];
                                        $color = isset($colors[$order['Status']]) ? $colors[$order['Status']] : 'secondary';
                                        ?>
                                        <span class="badge bg-<?= $color ?>"><?= htmlspecialchars($order['Status']) ?></span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>