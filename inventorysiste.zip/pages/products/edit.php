<?php
// ======================================================
// HALAMAN EDIT PRODUCT
// ======================================================

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$product = fetchOne("SELECT * FROM products WHERE ProductID = ?", [$id]);

if(!$product) {
    header("Location: index.php?page=products&msg=Product not found&type=danger");
    exit;
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $productCode = trim($_POST['product_code']);
    $productName = trim($_POST['product_name']);
    $description = trim($_POST['description']);
    $uom = trim($_POST['uom']);
    $category = trim($_POST['category']);
    $unitPrice = isset($_POST['unit_price']) ? str_replace(',', '', $_POST['unit_price']) : 0;
    $active = isset($_POST['active']) ? (int)$_POST['active'] : 1;
    
    $errors = [];
    
    if(empty($productCode)) $errors[] = "Product Code is required";
    if(empty($productName)) $errors[] = "Product Name is required";
    if(empty($uom)) $errors[] = "Unit of Measure (UOM) is required";
    if(empty($category)) $errors[] = "Category is required";
    if($unitPrice < 0) $errors[] = "Unit price cannot be negative";
    
    if(empty($errors)) {
        $check = fetchOne("SELECT ProductID FROM products WHERE ProductCode = ? AND ProductID != ?", [$productCode, $id]);
        if($check) {
            $errors[] = "Product Code already exists!";
        }
    }
    
    if(empty($errors)) {
        try {
            $sql = "UPDATE products SET 
                    ProductCode = ?, 
                    ProductName = ?, 
                    Description = ?, 
                    UOM = ?, 
                    Category = ?, 
                    UnitPrice = ?,
                    Active = ?,
                    UpdatedAt = NOW()
                    WHERE ProductID = ?";
            query($sql, [$productCode, $productName, $description, $uom, $category, $unitPrice, $active, $id]);
            
            header("Location: index.php?page=products&msg=updated&type=success");
            exit;
        } catch(PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}
?>

<div id="page-content-wrapper" class="p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3"><i class="fas fa-edit me-2 text-primary"></i>Edit Product</h1>
            <p class="text-muted">Edit product: <?= htmlspecialchars($product['ProductCode']) ?></p>
        </div>
        <a href="index.php?page=products" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i>Back
        </a>
    </div>

    <?php if(isset($errors) && !empty($errors)): ?>
    <div class="alert alert-danger">
        <strong><i class="fas fa-exclamation-circle me-1"></i> Please fix the following errors:</strong>
        <ul class="mb-0 mt-1">
            <?php foreach($errors as $error): ?>
            <li><?= htmlspecialchars($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header"><i class="fas fa-edit me-1"></i> Edit Product Form</div>
        <div class="card-body">
            <form method="POST" action="">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Product Code <span class="text-danger">*</span></label>
                        <input type="text" name="product_code" class="form-control" 
                               value="<?= htmlspecialchars($product['ProductCode']) ?>" required>
                        <small class="text-muted">Unique identifier for the product</small>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Product Name <span class="text-danger">*</span></label>
                        <input type="text" name="product_name" class="form-control" 
                               value="<?= htmlspecialchars($product['ProductName']) ?>" required>
                    </div>
                    
                    <div class="col-12">
                        <label class="form-label fw-bold">Description</label>
                        <textarea name="description" class="form-control" rows="2"><?= htmlspecialchars($product['Description']) ?></textarea>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Unit of Measure (UOM) <span class="text-danger">*</span></label>
                        <select name="uom" class="form-select" required>
                            <option value="">-- Select UOM --</option>
                            <option value="PCS" <?= $product['UOM'] == 'PCS' ? 'selected' : '' ?>>PCS</option>
                            <option value="KG" <?= $product['UOM'] == 'KG' ? 'selected' : '' ?>>KG</option>
                            <option value="ROLL" <?= $product['UOM'] == 'ROLL' ? 'selected' : '' ?>>ROLL</option>
                            <option value="METER" <?= $product['UOM'] == 'METER' ? 'selected' : '' ?>>METER</option>
                            <option value="LITER" <?= $product['UOM'] == 'LITER' ? 'selected' : '' ?>>LITER</option>
                            <option value="UNIT" <?= $product['UOM'] == 'UNIT' ? 'selected' : '' ?>>UNIT</option>
                            <option value="SET" <?= $product['UOM'] == 'SET' ? 'selected' : '' ?>>SET</option>
                        </select>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Category <span class="text-danger">*</span></label>
                        <input type="text" name="category" class="form-control" 
                               value="<?= htmlspecialchars($product['Category']) ?>" required>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Unit Price</label>
                        <div class="input-group">
                            <span class="input-group-text">Rp</span>
                            <input type="text" name="unit_price" class="form-control" 
                                   value="<?= htmlspecialchars($product['UnitPrice']) ?>">
                        </div>
                        <small class="text-muted">Price per unit in Rupiah</small>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Status</label>
                        <div class="mt-2">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="active" id="active1" value="1" 
                                       <?= $product['Active'] == 1 ? 'checked' : '' ?>>
                                <label class="form-check-label" for="active1">
                                    <span class="badge bg-success">Active</span>
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="active" id="active0" value="0"
                                       <?= $product['Active'] == 0 ? 'checked' : '' ?>>
                                <label class="form-check-label" for="active0">
                                    <span class="badge bg-danger">Inactive</span>
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-12">
                        <div class="alert alert-info">
                            <small>
                                <i class="fas fa-info-circle me-1"></i>
                                Created: <?= date('d/m/Y H:i', strtotime($product['CreatedAt'])) ?>
                                <?php if($product['UpdatedAt'] != $product['CreatedAt']): ?>
                                | Updated: <?= date('d/m/Y H:i', strtotime($product['UpdatedAt'])) ?>
                                <?php endif; ?>
                            </small>
                        </div>
                    </div>
                    
                    <div class="col-12">
                        <hr>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Update Product
                        </button>
                    
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.querySelector('input[name="unit_price"]').addEventListener('input', function(e) {
    this.value = this.value.replace(/[^0-9]/g, '');
});
</script>