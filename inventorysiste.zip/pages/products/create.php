<?php
// ======================================================
// HALAMAN TAMBAH PRODUCT
// ======================================================
ob_start();
// Proses submit form
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $productCode = trim($_POST['product_code']);
    $productName = trim($_POST['product_name']);
    $description = trim($_POST['description']);
    $uom = trim($_POST['uom']);
    $category = trim($_POST['category']);
    $unitPrice = isset($_POST['unit_price']) ? str_replace(',', '', $_POST['unit_price']) : 0;
    $active = isset($_POST['active']) ? (int)$_POST['active'] : 1;
    
    $errors = [];
    
    // Validasi required
    if(empty($productCode)) $errors[] = "Product Code is required";
    if(empty($productName)) $errors[] = "Product Name is required";
    if(empty($uom)) $errors[] = "Unit of Measure (UOM) is required";
    if(empty($category)) $errors[] = "Category is required";
    
    // Validasi price
    if($unitPrice < 0) $errors[] = "Unit price cannot be negative";
    
    // Cek duplicate code
    if(empty($errors)) {
        $check = fetchOne("SELECT ProductID FROM products WHERE ProductCode = ?", [$productCode]);
        if($check) {
            $errors[] = "Product Code already exists!";
        }
    }
    
    if(empty($errors)) {
        try {
            $sql = "INSERT INTO products (ProductCode, ProductName, Description, UOM, Category, UnitPrice, Active) 
                    VALUES (?, ?, ?, ?, ?, ?, ?)";
            query($sql, [$productCode, $productName, $description, $uom, $category, $unitPrice, $active]);
            
            header("Location: index.php?page=products&msg=created&type=success");
            exit;
        } catch(PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}
?>

<div id="page-content-wrapper" class="p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3"><i class="fas fa-box-plus me-2 text-primary"></i>Add Product</h1>
            <p class="text-muted">Add new finished goods product</p>
        </div>
        <a href="index.php?page=products" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i>Back
        </a>
    </div>

    <?php if(isset($errors) && !empty($errors)): ?>
    <div class="alert alert-danger">
        <strong><i class="fas fa-exclamation-circle me-1"></i> Please fix the following errors:</strong>
        <ul class="mb-0 mt-1">
            <?php foreach($errors as $error): ?>
            <li><?= htmlspecialchars($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header"><i class="fas fa-edit me-1"></i> Product Form</div>
        <div class="card-body">
            <form method="POST" action="">
                <div class="row g-3">
                    <!-- Product Code -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Product Code <span class="text-danger">*</span></label>
                        <input type="text" name="product_code" class="form-control" 
                               placeholder="e.g: FG-001" 
                               value="<?= isset($_POST['product_code']) ? htmlspecialchars($_POST['product_code']) : '' ?>" 
                               required>
                        <small class="text-muted">Unique identifier for the product</small>
                    </div>
                    
                    <!-- Product Name -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Product Name <span class="text-danger">*</span></label>
                        <input type="text" name="product_name" class="form-control" 
                               placeholder="e.g: Plastic Sheet Clear" 
                               value="<?= isset($_POST['product_name']) ? htmlspecialchars($_POST['product_name']) : '' ?>" 
                               required>
                    </div>
                    
                    <!-- Description -->
                    <div class="col-12">
                        <label class="form-label fw-bold">Description</label>
                        <textarea name="description" class="form-control" rows="2" 
                                  placeholder="Product description"><?= isset($_POST['description']) ? htmlspecialchars($_POST['description']) : '' ?></textarea>
                    </div>
                    
                    <!-- UOM & Category -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Unit of Measure (UOM) <span class="text-danger">*</span></label>
                        <select name="uom" class="form-select" required>
                            <option value="">-- Select UOM --</option>
                            <option value="PCS" <?= (isset($_POST['uom']) && $_POST['uom'] == 'PCS') ? 'selected' : '' ?>>PCS</option>
                            <option value="KG" <?= (isset($_POST['uom']) && $_POST['uom'] == 'KG') ? 'selected' : '' ?>>KG</option>
                            <option value="ROLL" <?= (isset($_POST['uom']) && $_POST['uom'] == 'ROLL') ? 'selected' : '' ?>>ROLL</option>
                            <option value="METER" <?= (isset($_POST['uom']) && $_POST['uom'] == 'METER') ? 'selected' : '' ?>>METER</option>
                            <option value="LITER" <?= (isset($_POST['uom']) && $_POST['uom'] == 'LITER') ? 'selected' : '' ?>>LITER</option>
                            <option value="UNIT" <?= (isset($_POST['uom']) && $_POST['uom'] == 'UNIT') ? 'selected' : '' ?>>UNIT</option>
                            <option value="SET" <?= (isset($_POST['uom']) && $_POST['uom'] == 'SET') ? 'selected' : '' ?>>SET</option>
                        </select>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Category <span class="text-danger">*</span></label>
                        <input type="text" name="category" class="form-control" 
                               placeholder="e.g: Plastic Sheet, Pipe, Pallet" 
                               value="<?= isset($_POST['category']) ? htmlspecialchars($_POST['category']) : '' ?>" 
                               required>
                    </div>
                    
                    <!-- Unit Price -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Unit Price</label>
                        <div class="input-group">
                            <span class="input-group-text">Rp</span>
                            <input type="text" name="unit_price" class="form-control" 
                                   placeholder="0" 
                                   value="<?= isset($_POST['unit_price']) ? htmlspecialchars($_POST['unit_price']) : '' ?>">
                        </div>
                        <small class="text-muted">Price per unit in Rupiah</small>
                    </div>
                    
                    <!-- Status -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Status</label>
                        <div class="mt-2">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="active" id="active1" value="1" checked>
                                <label class="form-check-label" for="active1">
                                    <span class="badge bg-success">Active</span>
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="active" id="active0" value="0">
                                <label class="form-check-label" for="active0">
                                    <span class="badge bg-danger">Inactive</span>
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Buttons -->
                    <div class="col-12">
                        <hr>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Save Product
                        </button>
                       
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- JavaScript untuk format currency -->
<script>
document.querySelector('input[name="unit_price"]').addEventListener('input', function(e) {
    // Hanya angka yang boleh diinput
    this.value = this.value.replace(/[^0-9]/g, '');
});
</script>