<?php
// ======================================================
// HALAMAN LIST CUSTOMER PO (SALES ORDERS)
// ======================================================

// Pagination
$page = isset($_GET['page_num']) ? (int)$_GET['page_num'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

// Search
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Build Query
$whereClause = "WHERE 1=1";
$params = [];

if (!empty($search)) {
    $whereClause .= " AND (cpo.PONumber LIKE ? OR c.CustomerName LIKE ?)";
    $searchTerm = "%$search%";
    $params = [$searchTerm, $searchTerm];
}

// Get Total Data
$totalQuery = "
    SELECT COUNT(*) 
    FROM customer_pos cpo
    LEFT JOIN customers c ON cpo.CustomerID = c.CustomerID
    $whereClause
";
$totalData = fetchCount($totalQuery, $params);
$totalPages = ceil($totalData / $limit);

// Get Data
$query = "
    SELECT 
        cpo.CustomerPOID,
        cpo.PONumber,
        cpo.PODate,
        cpo.DeliveryDate,
        c.CustomerName,
        cpo.Status,
        cpo.SalesPIC,
        cpo.CreatedAt,
        (SELECT COUNT(*) FROM customer_po_details WHERE CustomerPOID = cpo.CustomerPOID) AS TotalItems,
        (SELECT COALESCE(SUM(QtyOrder), 0) FROM customer_po_details WHERE CustomerPOID = cpo.CustomerPOID) AS TotalQty,
        (SELECT COALESCE(SUM(Total), 0) FROM customer_po_details WHERE CustomerPOID = cpo.CustomerPOID) AS TotalAmount
    FROM customer_pos cpo
    LEFT JOIN customers c ON cpo.CustomerID = c.CustomerID
    $whereClause
    ORDER BY cpo.PODate DESC
    LIMIT $limit OFFSET $offset
";
$salesOrders = fetchAll($query, $params);

// Get Success/Error Message
$message = isset($_GET['msg']) ? $_GET['msg'] : '';
$messageType = isset($_GET['type']) ? $_GET['type'] : '';
?>

<div id="page-content-wrapper">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3">
                <i class="fas fa-file-invoice me-2 text-primary"></i>Sales Orders
            </h1>
            <p class="text-muted">Manage customer purchase orders</p>
        </div>
        <a href="<?= url('customer_pos', 'create') ?>" class="btn btn-primary">
            <i class="fas fa-plus me-1"></i>Add Sales Order
        </a>
    </div>

    <!-- Alert Message -->
    <?php if($message): ?>
    <div class="alert alert-<?= $messageType ?> alert-dismissible fade show" role="alert">
        <?php 
        if($message == 'created') echo 'Sales Order berhasil dibuat!';
        elseif($message == 'updated') echo 'Sales Order berhasil diperbarui!';
        elseif($message == 'deleted') echo 'Sales Order berhasil dihapus!';
        else echo htmlspecialchars($message);
        ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <!-- Search -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <input type="hidden" name="page" value="customer_pos">
                <div class="col-md-10">
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                        <input type="text" name="search" class="form-control" 
                               placeholder="Search by SO number or customer..." 
                               value="<?= htmlspecialchars($search) ?>">
                    </div>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search me-1"></i>Search
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Table -->
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <span><i class="fas fa-list me-1"></i> Sales Order List</span>
                <span class="badge bg-primary"><?= number_format($totalData) ?> Records</span>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover table-striped mb-0">
                    <thead>
                        <tr>
                            <th width="50">#</th>
                            <th>SO Number</th>
                            <th>Date</th>
                            <th>Customer</th>
                            <th>Delivery</th>
                            <th>Items</th>
                            <th>Qty</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th width="120">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($salesOrders)): ?>
                        <tr>
                            <td colspan="10" class="text-center text-muted py-4">
                                <i class="fas fa-inbox fa-2x d-block mb-2"></i>
                                No sales orders found
                            </td>
                        </tr>
                        <?php else: ?>
                        <?php 
                        $no = $offset + 1;
                        foreach($salesOrders as $row): 
                        ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td>
                                <span class="badge bg-info"><?= htmlspecialchars($row['PONumber']) ?></span>
                            </td>
                            <td><?= date('d/m/Y', strtotime($row['PODate'])) ?></td>
                            <td><?= htmlspecialchars($row['CustomerName']) ?></td>
                            <td>
                                <?php if($row['DeliveryDate']): ?>
                                <?= date('d/m/Y', strtotime($row['DeliveryDate'])) ?>
                                <?php else: ?>
                                <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge bg-secondary"><?= number_format($row['TotalItems']) ?></span>
                            </td>
                            <td><?= number_format($row['TotalQty']) ?></td>
                            <td>Rp <?= number_format($row['TotalAmount'], 0) ?></td>
                            <td><?= getStatusBadge($row['Status']) ?></td>
                            <td>
                                <div class="btn-group btn-group-sm">
                                    <a href="<?= url('customer_pos', 'view', ['id' => $row['CustomerPOID']]) ?>" 
                                       class="btn btn-outline-info" title="View">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="<?= url('customer_pos', 'edit', ['id' => $row['CustomerPOID']]) ?>" 
                                       class="btn btn-outline-primary" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="<?= url('customer_pos', 'delete', ['id' => $row['CustomerPOID']]) ?>" 
                                       class="btn btn-outline-danger" title="Delete"
                                       onclick="return confirm('Apakah anda yakin akan menghapus data ini?')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php if($totalPages > 1): ?>
        <div class="card-footer">
            <nav>
                <ul class="pagination pagination-sm mb-0">
                    <?php if($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=customer_pos&page_num=<?= $page-1 ?>&search=<?= urlencode($search) ?>">
                            <i class="fas fa-chevron-left"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <?php for($i = 1; $i <= $totalPages; $i++): ?>
                    <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                        <a class="page-link" href="?page=customer_pos&page_num=<?= $i ?>&search=<?= urlencode($search) ?>">
                            <?= $i ?>
                        </a>
                    </li>
                    <?php endfor; ?>
                    
                    <?php if($page < $totalPages): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=customer_pos&page_num=<?= $page+1 ?>&search=<?= urlencode($search) ?>">
                            <i class="fas fa-chevron-right"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
        <?php endif; ?>
    </div>
</div>