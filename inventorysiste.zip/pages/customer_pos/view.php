<?php
// ======================================================
// HALAMAN DETAIL SALES ORDER
// ======================================================

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Get SO Header
$so = fetchOne("
    SELECT 
        cpo.*,
        c.CustomerName,
        c.Address,
        c.Phone,
        c.Email
    FROM customer_pos cpo
    LEFT JOIN customers c ON cpo.CustomerID = c.CustomerID
    WHERE cpo.CustomerPOID = ?
", [$id]);

if(!$so) {
    header("Location: index.php?page=customer_pos&msg=Sales Order not found&type=danger");
    exit;
}

// Get SO Details
$details = fetchAll("
    SELECT 
        cpod.*,
        p.ProductCode,
        p.ProductName,
        p.UOM
    FROM customer_po_details cpod
    LEFT JOIN products p ON cpod.ProductID = p.ProductID
    WHERE cpod.CustomerPOID = ?
    ORDER BY cpod.CustomerPODetailID
", [$id]);

// Calculate totals
$totalQty = 0;
$totalAmount = 0;
$totalProduced = 0;
foreach($details as $d) {
    $totalQty += $d['QtyOrder'];
    $totalAmount += $d['Total'];
    $totalProduced += $d['QtyProduced'];
}
$progress = ($totalQty > 0) ? ($totalProduced / $totalQty * 100) : 0;
?>

<div id="page-content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3">
                <i class="fas fa-file-invoice me-2 text-primary"></i>Sales Order Detail
            </h1>
            <p class="text-muted">View sales order details</p>
        </div>
        <div>
            <a href="<?= url('customer_pos', 'edit', ['id' => $id]) ?>" class="btn btn-primary">
                <i class="fas fa-edit me-1"></i>Edit
            </a>
            <a href="<?= url('customer_pos') ?>" class="btn btn-secondary">
                <i class="fas fa-arrow-left me-1"></i>Back
            </a>
        </div>
    </div>

    <!-- Progress -->
    <div class="card mb-4">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center">
                <span>Production Progress</span>
                <span><?= number_format($progress, 1) ?>%</span>
            </div>
            <?= getProgressBar($progress) ?>
        </div>
    </div>

    <!-- SO Information -->
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-info-circle me-1"></i> Sales Order Information
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <table class="table table-bordered mb-0">
                        <tr>
                            <th width="35%">SO Number</th>
                            <td><span class="badge bg-info"><?= htmlspecialchars($so['PONumber']) ?></span></td>
                        </tr>
                        <tr>
                            <th>Order Date</th>
                            <td><?= date('d/m/Y', strtotime($so['PODate'])) ?></td>
                        </tr>
                        <tr>
                            <th>Delivery Date</th>
                            <td><?= $so['DeliveryDate'] ? date('d/m/Y', strtotime($so['DeliveryDate'])) : '-' ?></td>
                        </tr>
                        <tr>
                            <th>Status</th>
                            <td><?= getStatusBadge($so['Status']) ?></td>
                        </tr>
                        <tr>
                            <th>Sales PIC</th>
                            <td><?= htmlspecialchars($so['SalesPIC']) ?></td>
                        </tr>
                    </table>
                </div>
                <div class="col-md-6">
                    <table class="table table-bordered mb-0">
                        <tr>
                            <th width="35%">Customer</th>
                            <td><strong><?= htmlspecialchars($so['CustomerName']) ?></strong></td>
                        </tr>
                        <tr>
                            <th>Address</th>
                            <td><?= nl2br(htmlspecialchars($so['Address'])) ?></td>
                        </tr>
                        <tr>
                            <th>Phone</th>
                            <td><?= htmlspecialchars($so['Phone']) ?></td>
                        </tr>
                        <tr>
                            <th>Email</th>
                            <td><?= htmlspecialchars($so['Email']) ?></td>
                        </tr>
                        <tr>
                            <th>Notes</th>
                            <td><?= nl2br(htmlspecialchars($so['Notes'])) ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Items -->
    <div class="card">
        <div class="card-header">
            <i class="fas fa-list me-1"></i> Items
            <span class="badge bg-secondary float-end">Total: <?= number_format($totalQty) ?> items</span>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-striped mb-0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Product Code</th>
                            <th>Product Name</th>
                            <th>UOM</th>
                            <th class="text-end">Qty</th>
                            <th class="text-end">Price</th>
                            <th class="text-end">Total</th>
                            <th class="text-end">Produced</th>
                            <th class="text-end">Remaining</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($details)): ?>
                        <tr>
                            <td colspan="9" class="text-center text-muted py-3">No items found</td>
                        </tr>
                        <?php else: ?>
                        <?php $no = 1; foreach($details as $row): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= htmlspecialchars($row['ProductCode']) ?></td>
                            <td><?= htmlspecialchars($row['ProductName']) ?></td>
                            <td><?= htmlspecialchars($row['UOM']) ?></td>
                            <td class="text-end"><?= number_format($row['QtyOrder']) ?></td>
                            <td class="text-end">Rp <?= number_format($row['UnitPrice'], 0) ?></td>
                            <td class="text-end">Rp <?= number_format($row['Total'], 0) ?></td>
                            <td class="text-end"><?= number_format($row['QtyProduced']) ?></td>
                            <td class="text-end"><?= number_format($row['QtyRemaining']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <tr class="table-active">
                            <td colspan="4" class="text-end fw-bold">Grand Total</td>
                            <td class="text-end fw-bold"><?= number_format($totalQty) ?></td>
                            <td></td>
                            <td class="text-end fw-bold">Rp <?= number_format($totalAmount, 0) ?></td>
                            <td class="text-end fw-bold"><?= number_format($totalProduced) ?></td>
                            <td class="text-end fw-bold"><?= number_format($totalQty - $totalProduced) ?></td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>