<?php
// ======================================================
// HALAMAN TAMBAH SALES ORDER
// ======================================================
ob_start();

// Get customers for dropdown
$customers = fetchAll("SELECT CustomerID, CustomerName FROM customers WHERE Status = 1 ORDER BY CustomerName");

// Get products for dropdown
$products = fetchAll("SELECT ProductID, ProductCode, ProductName, UOM, UnitPrice FROM products WHERE Active = 1 ORDER BY ProductName");

// Proses submit form
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $customerID = isset($_POST['customer_id']) ? (int)$_POST['customer_id'] : 0;
    $poDate = $_POST['po_date'];
    $deliveryDate = !empty($_POST['delivery_date']) ? $_POST['delivery_date'] : null;
    $salesPIC = trim($_POST['sales_pic']);
    $notes = trim($_POST['notes']);
    
    // Ambil data items dari form
    $productIDs = isset($_POST['product_id']) ? $_POST['product_id'] : [];
    $qtys = isset($_POST['qty']) ? $_POST['qty'] : [];
    $unitPrices = isset($_POST['unit_price']) ? $_POST['unit_price'] : [];
    
    $errors = [];
    
    // Validasi
    if(empty($customerID)) $errors[] = "Customer is required";
    if(empty($poDate)) $errors[] = "Order Date is required";
    if(empty($productIDs) || count($productIDs) == 0) $errors[] = "At least one item is required";
    
    // Validasi setiap item
    foreach($productIDs as $index => $pid) {
        if(empty($pid)) $errors[] = "Item #" . ($index+1) . ": Product is required";
        if(empty($qtys[$index]) || $qtys[$index] <= 0) $errors[] = "Item #" . ($index+1) . ": Quantity must be greater than 0";
        if(isset($unitPrices[$index]) && $unitPrices[$index] < 0) $errors[] = "Item #" . ($index+1) . ": Price cannot be negative";
    }
    
    if(empty($errors)) {
        try {
            // Generate SO Number
            $year = date('Y');
            $month = date('m');
            $lastSO = fetchOne("SELECT PONumber FROM customer_pos ORDER BY CustomerPOID DESC LIMIT 1");
            $lastNumber = 0;
            if($lastSO) {
                $lastNumber = (int)substr($lastSO['PONumber'], -4);
            }
            $newNumber = str_pad($lastNumber + 1, 4, '0', STR_PAD_LEFT);
            $poNumber = 'SO-' . $year . $month . '-' . $newNumber;
            
            // Insert SO Header
            $sql = "INSERT INTO customer_pos (CustomerID, PONumber, PODate, DeliveryDate, Status, SalesPIC, Notes) 
                    VALUES (?, ?, ?, ?, 'Open', ?, ?)";
            query($sql, [$customerID, $poNumber, $poDate, $deliveryDate, $salesPIC, $notes]);
            $soID = $pdo->lastInsertId();
            
            // Insert SO Details
            foreach($productIDs as $index => $productID) {
                if(empty($productID)) continue;
                $qty = $qtys[$index];
                $unitPrice = isset($unitPrices[$index]) ? $unitPrices[$index] : 0;
                $total = $qty * $unitPrice;
                
                $sqlDetail = "INSERT INTO customer_po_details (CustomerPOID, ProductID, QtyOrder, UnitPrice, Total, QtyRemaining) 
                              VALUES (?, ?, ?, ?, ?, ?)";
                query($sqlDetail, [$soID, $productID, $qty, $unitPrice, $total, $qty]);
            }
            
            ob_clean();
            header("Location: index.php?page=customer_pos&msg=created&type=success");
            exit;
        } catch(PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}

ob_end_clean();
?>
<div id="page-content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3"><i class="fas fa-file-invoice-plus me-2 text-primary"></i>Add Sales Order</h1>
            <p class="text-muted">Create new customer purchase order</p>
        </div>
        <a href="<?= url('customer_pos') ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i>Back
        </a>
    </div>

    <?php if(isset($errors) && !empty($errors)): ?>
    <div class="alert alert-danger">
        <strong><i class="fas fa-exclamation-circle me-1"></i> Please fix the following errors:</strong>
        <ul class="mb-0 mt-1">
            <?php foreach($errors as $error): ?>
            <li><?= htmlspecialchars($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header"><i class="fas fa-edit me-1"></i> Sales Order Form</div>
        <div class="card-body">
            <form method="POST" action="" id="soForm">
                <div class="row g-3">
                    <!-- Customer -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Customer <span class="text-danger">*</span></label>
                        <select name="customer_id" class="form-select" required>
                            <option value="">-- Select Customer --</option>
                            <?php foreach($customers as $cust): ?>
                            <option value="<?= $cust['CustomerID'] ?>" 
                                    <?= (isset($_POST['customer_id']) && $_POST['customer_id'] == $cust['CustomerID']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($cust['CustomerName']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <!-- Order Date -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Order Date <span class="text-danger">*</span></label>
                        <input type="date" name="po_date" class="form-control" 
                               value="<?= isset($_POST['po_date']) ? $_POST['po_date'] : date('Y-m-d') ?>" 
                               required>
                    </div>
                    
                    <!-- Delivery Date -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Delivery Date</label>
                        <input type="date" name="delivery_date" class="form-control" 
                               value="<?= isset($_POST['delivery_date']) ? $_POST['delivery_date'] : '' ?>">
                        <small class="text-muted">Expected delivery date</small>
                    </div>
                    
                    <!-- Sales PIC -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Sales PIC</label>
                        <input type="text" name="sales_pic" class="form-control" 
                               placeholder="e.g: sales1" 
                               value="<?= isset($_POST['sales_pic']) ? htmlspecialchars($_POST['sales_pic']) : '' ?>">
                    </div>
                    
                    <!-- Notes -->
                    <div class="col-12">
                        <label class="form-label fw-bold">Notes</label>
                        <textarea name="notes" class="form-control" rows="2" 
                                  placeholder="Additional notes"><?= isset($_POST['notes']) ? htmlspecialchars($_POST['notes']) : '' ?></textarea>
                    </div>
                    
                    <!-- Items Section -->
                    <div class="col-12">
                        <hr>
                        <h5 class="fw-bold"><i class="fas fa-list me-2"></i>Items</h5>
                        <div id="itemsContainer">
                            <div class="row g-2 item-row">
                                <div class="col-md-5">
                                    <select name="product_id[]" class="form-select" required>
                                        <option value="">-- Select Product --</option>
                                        <?php foreach($products as $prod): ?>
                                        <option value="<?= $prod['ProductID'] ?>" data-price="<?= $prod['UnitPrice'] ?>">
                                            <?= htmlspecialchars($prod['ProductCode']) ?> - <?= htmlspecialchars($prod['ProductName']) ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <input type="number" name="qty[]" class="form-control" placeholder="Qty" min="1" required>
                                </div>
                                <div class="col-md-3">
                                    <input type="number" name="unit_price[]" class="form-control" placeholder="Price" min="0" step="1000" required>
                                </div>
                                <div class="col-md-1">
                                    <button type="button" class="btn btn-danger btn-sm remove-item" style="display:none;">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <button type="button" class="btn btn-sm btn-outline-primary mt-2" id="addItem">
                            <i class="fas fa-plus me-1"></i>Add Item
                        </button>
                    </div>
                    
                    <!-- Buttons -->
                    <div class="col-12">
                        <hr>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Create Sales Order
                        </button>
                       <!--  <a href="<?= url('customer_pos') ?>" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i>Cancel
                        </a> -->
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Auto-fill price when product selected
document.addEventListener('change', function(e) {
    if (e.target && e.target.matches('select[name="product_id[]"]')) {
        var row = e.target.closest('.item-row');
        var priceInput = row.querySelector('input[name="unit_price[]"]');
        var selectedOption = e.target.options[e.target.selectedIndex];
        var price = selectedOption.getAttribute('data-price');
        if (price) {
            priceInput.value = price;
        }
    }
});

// Add new item row
document.getElementById('addItem').addEventListener('click', function() {
    var container = document.getElementById('itemsContainer');
    var rows = container.querySelectorAll('.item-row');
    var lastRow = rows[rows.length - 1];
    var newRow = lastRow.cloneNode(true);
    
    // Reset values
    newRow.querySelectorAll('input').forEach(function(input) {
        input.value = '';
    });
    newRow.querySelectorAll('select').forEach(function(select) {
        select.selectedIndex = 0;
    });
    
    // Show remove button
    var removeBtn = newRow.querySelector('.remove-item');
    removeBtn.style.display = 'inline-block';
    
    container.appendChild(newRow);
});

// Remove item row
document.addEventListener('click', function(e) {
    if (e.target.closest('.remove-item')) {
        var row = e.target.closest('.item-row');
        if (document.querySelectorAll('.item-row').length > 1) {
            row.remove();
        }
    }
});
</script>