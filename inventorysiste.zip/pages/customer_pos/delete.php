<?php
// ======================================================
// PROSES HAPUS SALES ORDER
// ======================================================
ob_start();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$so = fetchOne("SELECT * FROM customer_pos WHERE CustomerPOID = ?", [$id]);

if(!$so) {
    ob_clean();
    header("Location: index.php?page=customer_pos&msg=Sales Order not found&type=danger");
    exit;
}

// Cek apakah SO sudah memiliki production orders
$hasProduction = fetchCount("SELECT COUNT(*) FROM production_orders WHERE CustomerPOID = ?", [$id]);

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    if($hasProduction > 0) {
        // Soft delete - hanya ubah status
        query("UPDATE customer_pos SET Status = 'Cancelled' WHERE CustomerPOID = ?", [$id]);
    } else {
        // Permanent delete
        query("DELETE FROM customer_po_details WHERE CustomerPOID = ?", [$id]);
        query("DELETE FROM customer_pos WHERE CustomerPOID = ?", [$id]);
    }
    
    ob_clean();
    header("Location: index.php?page=customer_pos&msg=deleted&type=success");
    exit;
}

ob_end_clean();
?>
<div id="page-content-wrapper">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-header bg-danger text-white">
                    <i class="fas fa-exclamation-triangle me-1"></i> Confirm Delete
                </div>
                <div class="card-body text-center py-4">
                    <i class="fas fa-file-invoice fa-4x text-danger mb-3"></i>
                    <h4>Are you sure you want to delete this sales order?</h4>
                    <p class="text-muted">
                        <strong><?= htmlspecialchars($so['PONumber']) ?></strong>
                        <br>
                        Date: <?= date('d/m/Y', strtotime($so['PODate'])) ?>
                        <br>
                        Status: <?= $so['Status'] ?>
                    </p>
                    
                    <?php if($hasProduction > 0): ?>
                    <div class="alert alert-warning">
                        <i class="fas fa-info-circle me-1"></i>
                        This SO has <strong><?= number_format($hasProduction) ?> production order(s)</strong>.
                        SO will be <strong>cancelled</strong> instead of permanently deleted.
                    </div>
                    <?php else: ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-info-circle me-1"></i>
                        This SO has <strong>no production orders</strong>.
                        SO will be <strong>permanently deleted</strong>.
                    </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="" class="d-inline">
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash me-1"></i> Yes, Delete
                        </button>
                        <a href="<?= url('customer_pos') ?>" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i> Cancel
                        </a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>