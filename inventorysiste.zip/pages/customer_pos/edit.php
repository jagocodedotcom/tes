<?php
// ======================================================
// HALAMAN EDIT SALES ORDER
// ======================================================
ob_start();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Get SO Header
$so = fetchOne("SELECT * FROM customer_pos WHERE CustomerPOID = ?", [$id]);

if(!$so) {
    ob_clean();
    header("Location: index.php?page=customer_pos&msg=Sales Order not found&type=danger");
    exit;
}

// Get customers for dropdown
$customers = fetchAll("SELECT CustomerID, CustomerName FROM customers WHERE Status = 1 ORDER BY CustomerName");

// Get products for dropdown
$products = fetchAll("SELECT ProductID, ProductCode, ProductName, UOM, UnitPrice FROM products WHERE Active = 1 ORDER BY ProductName");

// Get existing SO details
$existingDetails = fetchAll("
    SELECT 
        cpod.*,
        p.ProductCode,
        p.ProductName,
        p.UOM
    FROM customer_po_details cpod
    LEFT JOIN products p ON cpod.ProductID = p.ProductID
    WHERE cpod.CustomerPOID = ?
    ORDER BY cpod.CustomerPODetailID
", [$id]);

// Proses submit form
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $customerID = isset($_POST['customer_id']) ? (int)$_POST['customer_id'] : 0;
    $poDate = $_POST['po_date'];
    $deliveryDate = !empty($_POST['delivery_date']) ? $_POST['delivery_date'] : null;
    $status = $_POST['status'];
    $salesPIC = trim($_POST['sales_pic']);
    $notes = trim($_POST['notes']);
    
    // Ambil data items dari form
    $detailIDs = isset($_POST['detail_id']) ? $_POST['detail_id'] : [];
    $productIDs = isset($_POST['product_id']) ? $_POST['product_id'] : [];
    $qtys = isset($_POST['qty']) ? $_POST['qty'] : [];
    $unitPrices = isset($_POST['unit_price']) ? $_POST['unit_price'] : [];
    
    $errors = [];
    
    // Validasi
    if(empty($customerID)) $errors[] = "Customer is required";
    if(empty($poDate)) $errors[] = "Order Date is required";
    if(empty($productIDs) || count($productIDs) == 0) $errors[] = "At least one item is required";
    
    // Validasi setiap item
    foreach($productIDs as $index => $pid) {
        if(empty($pid)) $errors[] = "Item #" . ($index+1) . ": Product is required";
        if(empty($qtys[$index]) || $qtys[$index] <= 0) $errors[] = "Item #" . ($index+1) . ": Quantity must be greater than 0";
    }
    
    if(empty($errors)) {
        try {
            // Update SO Header
            $sql = "UPDATE customer_pos SET 
                    CustomerID = ?, 
                    PODate = ?, 
                    DeliveryDate = ?, 
                    Status = ?, 
                    SalesPIC = ?, 
                    Notes = ?
                    WHERE CustomerPOID = ?";
            query($sql, [$customerID, $poDate, $deliveryDate, $status, $salesPIC, $notes, $id]);
            
            // Delete existing details
            query("DELETE FROM customer_po_details WHERE CustomerPOID = ?", [$id]);
            
            // Insert new details
            foreach($productIDs as $index => $productID) {
                if(empty($productID)) continue;
                $qty = $qtys[$index];
                $unitPrice = isset($unitPrices[$index]) ? $unitPrices[$index] : 0;
                $total = $qty * $unitPrice;
                
                $sqlDetail = "INSERT INTO customer_po_details (CustomerPOID, ProductID, QtyOrder, UnitPrice, Total, QtyRemaining) 
                              VALUES (?, ?, ?, ?, ?, ?)";
                query($sqlDetail, [$id, $productID, $qty, $unitPrice, $total, $qty]);
            }
            
            ob_clean();
            header("Location: index.php?page=customer_pos&msg=updated&type=success");
            exit;
        } catch(PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}

ob_end_clean();
?>
<div id="page-content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3"><i class="fas fa-file-invoice-plus me-2 text-primary"></i>Edit Sales Order</h1>
            <p class="text-muted">Edit sales order: <?= htmlspecialchars($so['PONumber']) ?></p>
        </div>
        <a href="<?= url('customer_pos') ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i>Back
        </a>
    </div>

    <?php if(isset($errors) && !empty($errors)): ?>
    <div class="alert alert-danger">
        <strong><i class="fas fa-exclamation-circle me-1"></i> Please fix the following errors:</strong>
        <ul class="mb-0 mt-1">
            <?php foreach($errors as $error): ?>
            <li><?= htmlspecialchars($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header"><i class="fas fa-edit me-1"></i> Edit Sales Order Form</div>
        <div class="card-body">
            <form method="POST" action="" id="soForm">
                <div class="row g-3">
                    <!-- Customer -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Customer <span class="text-danger">*</span></label>
                        <select name="customer_id" class="form-select" required>
                            <option value="">-- Select Customer --</option>
                            <?php foreach($customers as $cust): ?>
                            <option value="<?= $cust['CustomerID'] ?>" 
                                    <?= $so['CustomerID'] == $cust['CustomerID'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($cust['CustomerName']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <!-- Order Date -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Order Date <span class="text-danger">*</span></label>
                        <input type="date" name="po_date" class="form-control" 
                               value="<?= $so['PODate'] ?>" 
                               required>
                    </div>
                    
                    <!-- Delivery Date -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Delivery Date</label>
                        <input type="date" name="delivery_date" class="form-control" 
                               value="<?= $so['DeliveryDate'] ?>">
                    </div>
                    
                    <!-- Status -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Status <span class="text-danger">*</span></label>
                        <select name="status" class="form-select" required>
                            <option value="Open" <?= $so['Status'] == 'Open' ? 'selected' : '' ?>>Open</option>
                            <option value="Production" <?= $so['Status'] == 'Production' ? 'selected' : '' ?>>Production</option>
                            <option value="Partial" <?= $so['Status'] == 'Partial' ? 'selected' : '' ?>>Partial</option>
                            <option value="Completed" <?= $so['Status'] == 'Completed' ? 'selected' : '' ?>>Completed</option>
                            <option value="Cancelled" <?= $so['Status'] == 'Cancelled' ? 'selected' : '' ?>>Cancelled</option>
                        </select>
                    </div>
                    
                    <!-- Sales PIC -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Sales PIC</label>
                        <input type="text" name="sales_pic" class="form-control" 
                               value="<?= htmlspecialchars($so['SalesPIC']) ?>">
                    </div>
                    
                    <!-- Notes -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Notes</label>
                        <textarea name="notes" class="form-control" rows="2"><?= htmlspecialchars($so['Notes']) ?></textarea>
                    </div>
                    
                    <!-- Created Info -->
                    <div class="col-12">
                        <div class="alert alert-info">
                            <small>
                                <i class="fas fa-info-circle me-1"></i>
                                Created: <?= date('d/m/Y H:i', strtotime($so['CreatedAt'])) ?>
                                <?php if($so['UpdatedAt'] != $so['CreatedAt']): ?>
                                <br>Updated: <?= date('d/m/Y H:i', strtotime($so['UpdatedAt'])) ?>
                                <?php endif; ?>
                            </small>
                        </div>
                    </div>
                    
                    <!-- Items Section -->
                    <div class="col-12">
                        <hr>
                        <h5 class="fw-bold"><i class="fas fa-list me-2"></i>Items</h5>
                        <div id="itemsContainer">
                            <?php if(empty($existingDetails)): ?>
                            <div class="row g-2 item-row">
                                <div class="col-md-5">
                                    <select name="product_id[]" class="form-select" required>
                                        <option value="">-- Select Product --</option>
                                        <?php foreach($products as $prod): ?>
                                        <option value="<?= $prod['ProductID'] ?>" data-price="<?= $prod['UnitPrice'] ?>">
                                            <?= htmlspecialchars($prod['ProductCode']) ?> - <?= htmlspecialchars($prod['ProductName']) ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <input type="number" name="qty[]" class="form-control" placeholder="Qty" min="1" required>
                                </div>
                                <div class="col-md-3">
                                    <input type="number" name="unit_price[]" class="form-control" placeholder="Price" min="0" step="1000" required>
                                </div>
                                <div class="col-md-1">
                                    <button type="button" class="btn btn-danger btn-sm remove-item" style="display:none;">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                            </div>
                            <?php else: ?>
                            <?php foreach($existingDetails as $index => $item): ?>
                            <div class="row g-2 item-row">
                                <input type="hidden" name="detail_id[]" value="<?= $item['CustomerPODetailID'] ?>">
                                <div class="col-md-5">
                                    <select name="product_id[]" class="form-select" required>
                                        <option value="">-- Select Product --</option>
                                        <?php foreach($products as $prod): ?>
                                        <option value="<?= $prod['ProductID'] ?>" 
                                                <?= $item['ProductID'] == $prod['ProductID'] ? 'selected' : '' ?>
                                                data-price="<?= $prod['UnitPrice'] ?>">
                                            <?= htmlspecialchars($prod['ProductCode']) ?> - <?= htmlspecialchars($prod['ProductName']) ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <input type="number" name="qty[]" class="form-control" placeholder="Qty" min="1" 
                                           value="<?= $item['QtyOrder'] ?>" required>
                                </div>
                                <div class="col-md-3">
                                    <input type="number" name="unit_price[]" class="form-control" placeholder="Price" min="0" step="1000" 
                                           value="<?= $item['UnitPrice'] ?>" required>
                                </div>
                                <div class="col-md-1">
                                    <button type="button" class="btn btn-danger btn-sm remove-item" 
                                            <?= (count($existingDetails) <= 1) ? 'style="display:none;"' : '' ?>>
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                                <?php if($item['QtyProduced'] > 0): ?>
                                <div class="col-12">
                                    <small class="text-muted">
                                        <i class="fas fa-info-circle me-1"></i>
                                        Already produced: <?= number_format($item['QtyProduced']) ?> 
                                        (Remaining: <?= number_format($item['QtyRemaining']) ?>)
                                    </small>
                                </div>
                                <?php endif; ?>
                            </div>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                        <button type="button" class="btn btn-sm btn-outline-primary mt-2" id="addItem">
                            <i class="fas fa-plus me-1"></i>Add Item
                        </button>
                    </div>
                    
                    <!-- Buttons -->
                    <div class="col-12">
                        <hr>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Update Sales Order
                        </button>
                        <!-- <a href="<?= url('customer_pos') ?>" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i>Cancel
                        </a> -->
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Auto-fill price when product selected
document.addEventListener('change', function(e) {
    if (e.target && e.target.matches('select[name="product_id[]"]')) {
        var row = e.target.closest('.item-row');
        var priceInput = row.querySelector('input[name="unit_price[]"]');
        var selectedOption = e.target.options[e.target.selectedIndex];
        var price = selectedOption.getAttribute('data-price');
        if (price) {
            priceInput.value = price;
        }
    }
});

// Add new item row
document.getElementById('addItem').addEventListener('click', function() {
    var container = document.getElementById('itemsContainer');
    var rows = container.querySelectorAll('.item-row');
    var lastRow = rows[rows.length - 1];
    var newRow = lastRow.cloneNode(true);
    
    newRow.querySelectorAll('input').forEach(function(input) {
        if(input.type != 'hidden') {
            input.value = '';
        }
    });
    newRow.querySelectorAll('select').forEach(function(select) {
        select.selectedIndex = 0;
    });
    
    var removeBtn = newRow.querySelector('.remove-item');
    removeBtn.style.display = 'inline-block';
    
    // Remove info message
    var infoDiv = newRow.querySelector('.col-12');
    if(infoDiv) {
        infoDiv.remove();
    }
    
    container.appendChild(newRow);
});

// Remove item row
document.addEventListener('click', function(e) {
    if (e.target.closest('.remove-item')) {
        var row = e.target.closest('.item-row');
        if (document.querySelectorAll('.item-row').length > 1) {
            row.remove();
        }
    }
});
</script>