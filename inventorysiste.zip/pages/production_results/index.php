<?php
// ======================================================
// HALAMAN LIST PRODUCTION RESULTS
// ======================================================

// Pagination
$page = isset($_GET['page_num']) ? (int)$_GET['page_num'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

// Search
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Build Query
$whereClause = "WHERE 1=1";
$params = [];

if (!empty($search)) {
    $whereClause .= " AND (wo.WONumber LIKE ? OR pr.Operator LIKE ?)";
    $searchTerm = "%$search%";
    $params = [$searchTerm, $searchTerm];
}

// Get Total Data
$totalQuery = "
    SELECT COUNT(*) 
    FROM production_results pr
    LEFT JOIN production_orders wo ON pr.ProductionOrderID = wo.ProductionOrderID
    $whereClause
";
$totalData = fetchCount($totalQuery, $params);
$totalPages = ceil($totalData / $limit);

// Get Data
$query = "
    SELECT 
        pr.ProductionResultID,
        pr.ProductionDate,
        pr.Shift,
        pr.QtyTarget,
        pr.QtyProduced,
        pr.QtyReject,
        pr.QtyRepair,
        pr.QtyGood,
        pr.Operator,
        pr.MachineNo,
        pr.CreatedAt,
        wo.WONumber,
        p.ProductName,
        p.ProductCode,
        (SELECT COUNT(*) FROM qc_inspections WHERE ProductionResultID = pr.ProductionResultID) AS HasQC
    FROM production_results pr
    LEFT JOIN production_orders wo ON pr.ProductionOrderID = wo.ProductionOrderID
    LEFT JOIN products p ON wo.ProductID = p.ProductID
    $whereClause
    ORDER BY pr.ProductionDate DESC
    LIMIT $limit OFFSET $offset
";
$results = fetchAll($query, $params);

// Get Success/Error Message
$message = isset($_GET['msg']) ? $_GET['msg'] : '';
$messageType = isset($_GET['type']) ? $_GET['type'] : '';
?>

<div id="page-content-wrapper">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3">
                <i class="fas fa-chart-bar me-2 text-primary"></i>Production Results
            </h1>
            <p class="text-muted">Manage production output results</p>
        </div>
        <a href="<?= url('production_results', 'create') ?>" class="btn btn-primary">
            <i class="fas fa-plus me-1"></i>Add Result
        </a>
    </div>

    <!-- Alert Message -->
    <?php if($message): ?>
    <div class="alert alert-<?= $messageType ?> alert-dismissible fade show" role="alert">
        <?php 
        if($message == 'created') echo 'Production Result berhasil ditambahkan!';
        elseif($message == 'updated') echo 'Production Result berhasil diperbarui!';
        elseif($message == 'deleted') echo 'Production Result berhasil dihapus!';
        else echo htmlspecialchars($message);
        ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <!-- Search -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <input type="hidden" name="page" value="production_results">
                <div class="col-md-10">
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                        <input type="text" name="search" class="form-control" 
                               placeholder="Search by WO number or operator..." 
                               value="<?= htmlspecialchars($search) ?>">
                    </div>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search me-1"></i>Search
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Table -->
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <span><i class="fas fa-list me-1"></i> Production Results List</span>
                <span class="badge bg-primary"><?= number_format($totalData) ?> Records</span>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover table-striped mb-0">
                    <thead>
                        <tr>
                            <th width="50">#</th>
                            <th>WO Number</th>
                            <th>Product</th>
                            <th>Date</th>
                            <th>Shift</th>
                            <th>Target</th>
                            <th>Produced</th>
                            <th>Reject</th>
                            <th>Good</th>
                            <th>Yield</th>
                            <th>QC</th>
                            <th width="120">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($results)): ?>
                        <tr>
                            <td colspan="12" class="text-center text-muted py-4">
                                <i class="fas fa-inbox fa-2x d-block mb-2"></i>
                                No production results found
                            </td>
                        </tr>
                        <?php else: ?>
                        <?php 
                        $no = $offset + 1;
                        foreach($results as $row): 
                            $yield = 0;
                            if ($row['QtyProduced'] > 0) {
                                $yield = ($row['QtyGood'] / $row['QtyProduced']) * 100;
                            }
                            $color = 'success';
                            if ($yield < 70) $color = 'danger';
                            else if ($yield < 85) $color = 'warning';
                        ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td>
                                <?php if($row['WONumber']): ?>
                                <span class="badge bg-info"><?= htmlspecialchars($row['WONumber']) ?></span>
                                <?php else: ?>
                                <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <strong><?= htmlspecialchars($row['ProductName']) ?></strong>
                                <br>
                                <small class="text-muted"><?= htmlspecialchars($row['ProductCode']) ?></small>
                            </td>
                            <td><?= date('d/m/Y', strtotime($row['ProductionDate'])) ?></td>
                            <td><?= getShiftLabel($row['Shift']) ?></td>
                            <td><?= number_format($row['QtyTarget']) ?></td>
                            <td><?= number_format($row['QtyProduced']) ?></td>
                            <td class="text-danger"><?= number_format($row['QtyReject']) ?></td>
                            <td class="text-success"><?= number_format($row['QtyGood']) ?></td>
                            <td>
                                <span class="badge bg-<?= $color ?>">
                                    <?= number_format($yield, 1) ?>%
                                </span>
                            </td>
                            <td>
                                <?php if($row['HasQC'] > 0): ?>
                                <span class="badge bg-success">Inspected</span>
                                <?php else: ?>
                                <span class="badge bg-warning">Pending</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="btn-group btn-group-sm">
                                    <a href="<?= url('production_results', 'view', ['id' => $row['ProductionResultID']]) ?>" 
                                       class="btn btn-outline-info" title="View">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <!-- <a href="<?= url('production_results', 'edit', ['id' => $row['ProductionResultID']]) ?>" 
                                       class="btn btn-outline-primary" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a> -->
                                    <a href="<?= url('production_results', 'delete', ['id' => $row['ProductionResultID']]) ?>" 
                                       class="btn btn-outline-danger" title="Delete"
                                       onclick="return confirm('Apakah anda yakin akan menghapus data ini ?')">
                                        <i class="fas fa-trash"></i>
                                    </a>

                                </div>

                            </td>
                            <td>
    <div class="btn-group btn-group-sm">
        
    </div>
</td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php if($totalPages > 1): ?>
        <div class="card-footer">
            <nav>
                <ul class="pagination pagination-sm mb-0">
                    <?php if($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=production_results&page_num=<?= $page-1 ?>&search=<?= urlencode($search) ?>">
                            <i class="fas fa-chevron-left"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <?php for($i = 1; $i <= $totalPages; $i++): ?>
                    <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                        <a class="page-link" href="?page=production_results&page_num=<?= $i ?>&search=<?= urlencode($search) ?>">
                            <?= $i ?>
                        </a>
                    </li>
                    <?php endfor; ?>
                    
                    <?php if($page < $totalPages): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=production_results&page_num=<?= $page+1 ?>&search=<?= urlencode($search) ?>">
                            <i class="fas fa-chevron-right"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
        <?php endif; ?>
    </div>
</div>