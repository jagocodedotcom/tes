<?php
// ======================================================
// HALAMAN DETAIL PRODUCTION RESULT
// ======================================================

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Get Result
$result = fetchOne("
    SELECT 
        pr.*,
        wo.WONumber,
        p.ProductName,
        p.ProductCode,
        p.UOM,
        mt.TransferNumber
    FROM production_results pr
    LEFT JOIN production_orders wo ON pr.ProductionOrderID = wo.ProductionOrderID
    LEFT JOIN products p ON wo.ProductID = p.ProductID
    LEFT JOIN material_transfers mt ON pr.TransferID = mt.TransferID
    WHERE pr.ProductionResultID = ?
", [$id]);

if(!$result) {
    header("Location: index.php?page=production_results&msg=Result not found&type=danger");
    exit;
}

// Get QC Inspection
$qc = fetchOne("SELECT * FROM qc_inspections WHERE ProductionResultID = ?", [$id]);

$yield = 0;
if ($result['QtyProduced'] > 0) {
    $yield = ($result['QtyGood'] / $result['QtyProduced']) * 100;
}
$color = 'success';
if ($yield < 70) $color = 'danger';
else if ($yield < 85) $color = 'warning';
?>

<div id="page-content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3">
                <i class="fas fa-chart-bar me-2 text-primary"></i>Production Result Detail
            </h1>
            <p class="text-muted">View production result details</p>
        </div>
       <!--  <div>
            <a href="<?= url('production_results', 'edit', ['id' => $id]) ?>" class="btn btn-primary">
                <i class="fas fa-edit me-1"></i>Edit
            </a>
            <a href="<?= url('production_results') ?>" class="btn btn-secondary">
                <i class="fas fa-arrow-left me-1"></i>Back
            </a>
        </div> -->
    </div>

    <!-- Summary -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <h5 class="text-primary"><?= number_format($result['QtyTarget']) ?></h5>
                    <small class="text-muted">Target</small>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <h5 class="text-primary"><?= number_format($result['QtyProduced']) ?></h5>
                    <small class="text-muted">Produced</small>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <h5 class="text-danger"><?= number_format($result['QtyReject']) ?></h5>
                    <small class="text-muted">Reject</small>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <h5 class="text-success"><?= number_format($result['QtyGood']) ?></h5>
                    <small class="text-muted">Good</small>
                </div>
            </div>
        </div>
    </div>

    <!-- Yield -->
    <div class="card mb-4">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center">
                <span>Yield Rate</span>
                <span class="badge bg-<?= $color ?>"><?= number_format($yield, 1) ?>%</span>
            </div>
            <?= getProgressBar($yield) ?>
        </div>
    </div>

    <!-- Result Information -->
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-info-circle me-1"></i> Production Information
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <table class="table table-bordered mb-0">
                        <tr>
                            <th width="35%">Work Order</th>
                            <td><span class="badge bg-info"><?= htmlspecialchars($result['WONumber']) ?></span></td>
                        </tr>
                        <tr>
                            <th>Product</th>
                            <td><strong><?= htmlspecialchars($result['ProductName']) ?></strong></td>
                        </tr>
                        <tr>
                            <th>Product Code</th>
                            <td><?= htmlspecialchars($result['ProductCode']) ?></td>
                        </tr>
                        <tr>
                            <th>UOM</th>
                            <td><?= htmlspecialchars($result['UOM']) ?></td>
                        </tr>
                    </table>
                </div>
                <div class="col-md-6">
                    <table class="table table-bordered mb-0">
                        <tr>
                            <th width="35%">Production Date</th>
                            <td><?= date('d/m/Y', strtotime($result['ProductionDate'])) ?></td>
                        </tr>
                        <tr>
                            <th>Shift</th>
                            <td><?= getShiftLabel($result['Shift']) ?></td>
                        </tr>
                        <tr>
                            <th>Operator</th>
                            <td><?= htmlspecialchars($result['Operator']) ?: '-' ?></td>
                        </tr>
                        <tr>
                            <th>Machine No</th>
                            <td><?= htmlspecialchars($result['MachineNo']) ?: '-' ?></td>
                        </tr>
                    </table>
                </div>
            </div>
            <?php if($result['TransferNumber']): ?>
            <div class="row mt-3">
                <div class="col-12">
                    <div class="alert alert-info">
                        <strong>Material Transfer:</strong> <?= htmlspecialchars($result['TransferNumber']) ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- QC Inspection -->
    <div class="card">
        <div class="card-header">
            <i class="fas fa-check-double me-1"></i> QC Inspection
        </div>
        <div class="card-body">
            <?php if($qc): ?>
            <div class="row">
                <div class="col-md-6">
                    <table class="table table-bordered mb-0">
                        <tr>
                            <th width="35%">Inspection Date</th>
                            <td><?= date('d/m/Y', strtotime($qc['InspectionDate'])) ?></td>
                        </tr>
                        <tr>
                            <th>Qty Checked</th>
                            <td><?= number_format($qc['QtyChecked']) ?></td>
                        </tr>
                        <tr>
                            <th>Qty PASS</th>
                            <td class="text-success"><?= number_format($qc['QtyPASS']) ?></td>
                        </tr>
                    </table>
                </div>
                <div class="col-md-6">
                    <table class="table table-bordered mb-0">
                        <tr>
                            <th width="35%">Qty NG</th>
                            <td class="text-danger"><?= number_format($qc['QtyNG']) ?></td>
                        </tr>
                        <tr>
                            <th>Status</th>
                            <td>
                                <?php if($qc['FinalStatus'] == 'Accepted'): ?>
                                <span class="badge bg-success">Accepted</span>
                                <?php elseif($qc['FinalStatus'] == 'Rejected'): ?>
                                <span class="badge bg-danger">Rejected</span>
                                <?php elseif($qc['FinalStatus'] == 'Rework'): ?>
                                <span class="badge bg-warning">Rework</span>
                                <?php else: ?>
                                <span class="badge bg-secondary">Pending</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>Inspector</th>
                            <td><?= htmlspecialchars($qc['Inspector']) ?: '-' ?></td>
                        </tr>
                    </table>
                </div>
                <?php if($qc['NGReason']): ?>
                <div class="col-12 mt-3">
                    <div class="alert alert-danger">
                        <strong>NG Reason:</strong> <?= htmlspecialchars($qc['NGReason']) ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            <?php else: ?>
            <div class="text-center text-muted py-3">
                <i class="fas fa-clock fa-2x d-block mb-2"></i>
                QC Inspection not yet performed
            </div>
            <div class="text-center">
                <a href="<?= url('qc_inspections', 'create', ['result_id' => $id]) ?>" class="btn btn-primary">
                    <i class="fas fa-plus me-1"></i>Create QC Inspection
                </a>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>