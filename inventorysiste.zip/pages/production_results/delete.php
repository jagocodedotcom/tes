<?php
// ======================================================
// PROSES HAPUS PRODUCTION RESULT
// ======================================================
ob_start();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Get Result
$result = fetchOne("SELECT * FROM production_results WHERE ProductionResultID = ?", [$id]);

if(!$result) {
    ob_clean();
    header("Location: index.php?page=production_results&msg=Result not found&type=danger");
    exit;
}

// Cek apakah sudah ada QC Inspection
$hasQC = fetchCount("SELECT COUNT(*) FROM qc_inspections WHERE ProductionResultID = ?", [$id]);

// Cek apakah sudah ada FG Receipt
$hasFG = fetchCount("SELECT COUNT(*) FROM fg_receipts WHERE ProductionResultID = ?", [$id]);

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    if($hasQC > 0 || $hasFG > 0) {
        // Soft delete - tidak bisa dihapus karena sudah ada QC/FG
        $error = "Cannot delete this production result because it already has QC Inspection or FG Receipt.";
        // Redirect dengan pesan error
        ob_clean();
        header("Location: index.php?page=production_results&msg=" . urlencode($error) . "&type=danger");
        exit;
    } else {
        // Permanent delete
        query("DELETE FROM production_results WHERE ProductionResultID = ?", [$id]);
        
        // Update production order status
        $wo = fetchOne("SELECT QtyTarget FROM production_orders WHERE ProductionOrderID = ?", [$result['ProductionOrderID']]);
        $totalProduced = fetchOne("SELECT COALESCE(SUM(QtyProduced), 0) as total FROM production_results WHERE ProductionOrderID = ?", [$result['ProductionOrderID']]);
        
        if($totalProduced['total'] >= $wo['QtyTarget']) {
            query("UPDATE production_orders SET Status = 'Completed', CompletedAt = NOW() WHERE ProductionOrderID = ?", [$result['ProductionOrderID']]);
        } else if($totalProduced['total'] > 0) {
            query("UPDATE production_orders SET Status = 'Running' WHERE ProductionOrderID = ?", [$result['ProductionOrderID']]);
        } else {
            query("UPDATE production_orders SET Status = 'Open' WHERE ProductionOrderID = ?", [$result['ProductionOrderID']]);
        }
    }
    
    ob_clean();
    header("Location: index.php?page=production_results&msg=deleted&type=success");
    exit;
}

ob_end_clean();
?>
<div id="page-content-wrapper">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-header bg-danger text-white">
                    <i class="fas fa-exclamation-triangle me-1"></i> Confirm Delete
                </div>
                <div class="card-body text-center py-4">
                    <i class="fas fa-chart-bar fa-4x text-danger mb-3"></i>
                    <h4>Are you sure you want to delete this production result?</h4>
                    <p class="text-muted">
                        <strong>ID: <?= htmlspecialchars($result['ProductionResultID']) ?></strong>
                        <br>
                        Work Order: <?php 
                            $wo = fetchOne("SELECT WONumber FROM production_orders WHERE ProductionOrderID = ?", [$result['ProductionOrderID']]);
                            echo $wo ? htmlspecialchars($wo['WONumber']) : '-';
                        ?>
                        <br>
                        Date: <?= date('d/m/Y', strtotime($result['ProductionDate'])) ?>
                        <br>
                        Shift: <?= getShiftLabel($result['Shift']) ?>
                        <br>
                        Produced: <?= number_format($result['QtyProduced']) ?>
                        <br>
                        Reject: <?= number_format($result['QtyReject']) ?>
                        <br>
                        Operator: <?= htmlspecialchars($result['Operator']) ?: '-' ?>
                    </p>
                    
                    <?php if($hasQC > 0 || $hasFG > 0): ?>
                    <div class="alert alert-warning">
                        <i class="fas fa-info-circle me-1"></i>
                        This production result has 
                        <?php if($hasQC > 0): ?>
                        <strong><?= number_format($hasQC) ?> QC Inspection(s)</strong>
                        <?php endif; ?>
                        <?php if($hasFG > 0): ?>
                        <?php if($hasQC > 0) echo ' and '; ?>
                        <strong><?= number_format($hasFG) ?> FG Receipt(s)</strong>
                        <?php endif; ?>.
                        <br>
                        <strong>Cannot be deleted!</strong>
                    </div>
                    <?php else: ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-info-circle me-1"></i>
                        This production result has <strong>no QC inspections or FG receipts</strong>.
                        It will be <strong>permanently deleted</strong>.
                    </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="" class="d-inline">
                        <?php if($hasQC > 0 || $hasFG > 0): ?>
                        <a href="<?= url('production_results') ?>" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-1"></i> Back
                        </a>
                        <?php else: ?>
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash me-1"></i> Yes, Delete
                        </button>
                        <a href="<?= url('production_results') ?>" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i> Cancel
                        </a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>