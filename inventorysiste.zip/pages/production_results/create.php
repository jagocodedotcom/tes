<?php
// ======================================================
// HALAMAN TAMBAH PRODUCTION RESULT
// ======================================================
ob_start();

// Get Work Orders for dropdown
$workOrders = fetchAll("
    SELECT ProductionOrderID, WONumber 
    FROM production_orders 
    WHERE Status IN ('Open', 'Running', 'Partial') 
    ORDER BY WONumber
");

// Get Material Transfers for dropdown
$transfers = fetchAll("
    SELECT TransferID, TransferNumber 
    FROM material_transfers 
    WHERE Status = 'Issued' 
    ORDER BY TransferNumber DESC
");

// Proses submit form
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $productionOrderID = isset($_POST['production_order_id']) ? (int)$_POST['production_order_id'] : 0;
    $transferID = isset($_POST['transfer_id']) ? (int)$_POST['transfer_id'] : null;
    $productionDate = $_POST['production_date'];
    $shift = $_POST['shift'];
    $qtyProduced = isset($_POST['qty_produced']) ? str_replace(',', '', $_POST['qty_produced']) : 0;
    $qtyReject = isset($_POST['qty_reject']) ? str_replace(',', '', $_POST['qty_reject']) : 0;
    $qtyRepair = isset($_POST['qty_repair']) ? str_replace(',', '', $_POST['qty_repair']) : 0;
    $operator = trim($_POST['operator']);
    $machineNo = trim($_POST['machine_no']);
    $notes = trim($_POST['notes']);
    
    $errors = [];
    
    // Validasi
    if(empty($productionOrderID)) $errors[] = "Work Order is required";
    if(empty($productionDate)) $errors[] = "Production Date is required";
    if(empty($shift)) $errors[] = "Shift is required";
    if(empty($qtyProduced) || $qtyProduced <= 0) $errors[] = "Produced quantity must be greater than 0";
    if($qtyReject < 0) $errors[] = "Reject quantity cannot be negative";
    if($qtyRepair < 0) $errors[] = "Repair quantity cannot be negative";
    if($qtyReject > $qtyProduced) $errors[] = "Reject quantity cannot exceed produced quantity";
    
    // Get target from production order
    if(empty($errors)) {
        $wo = fetchOne("SELECT QtyTarget FROM production_orders WHERE ProductionOrderID = ?", [$productionOrderID]);
        if($wo) {
            $qtyTarget = $wo['QtyTarget'];
        } else {
            $errors[] = "Work Order not found";
        }
    }
    
    if(empty($errors)) {
        try {
            // Insert ke production_results
            $sql = "INSERT INTO production_results (ProductionOrderID, TransferID, ProductionDate, Shift, QtyTarget, QtyProduced, QtyReject, QtyRepair, Operator, MachineNo, Notes) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            query($sql, [$productionOrderID, $transferID, $productionDate, $shift, $qtyTarget, $qtyProduced, $qtyReject, $qtyRepair, $operator, $machineNo, $notes]);
            
            // Update production order status
            $totalProduced = fetchOne("SELECT COALESCE(SUM(QtyProduced), 0) as total FROM production_results WHERE ProductionOrderID = ?", [$productionOrderID]);
            $wo = fetchOne("SELECT QtyTarget FROM production_orders WHERE ProductionOrderID = ?", [$productionOrderID]);
            
            // ============================================================
            // PERBAIKAN: HAPUS QtyProduced di UPDATE production_orders
            // Kolom QtyProduced tidak ada di production_orders
            // ============================================================
            if($totalProduced['total'] >= $wo['QtyTarget']) {
                query("UPDATE production_orders SET Status = 'Completed', CompletedAt = NOW() WHERE ProductionOrderID = ?", [$productionOrderID]);
            } else {
                query("UPDATE production_orders SET Status = 'Running' WHERE ProductionOrderID = ?", [$productionOrderID]);
            }
            
            ob_clean();
            header("Location: index.php?page=production_results&msg=created&type=success");
            exit;
        } catch(PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}

ob_end_clean();
?>
<div id="page-content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3"><i class="fas fa-chart-bar-plus me-2 text-primary"></i>Add Production Result</h1>
            <p class="text-muted">Report production output</p>
        </div>
        <a href="<?= url('production_results') ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i>Back
        </a>
    </div>

    <?php if(isset($errors) && !empty($errors)): ?>
    <div class="alert alert-danger">
        <strong><i class="fas fa-exclamation-circle me-1"></i> Please fix the following errors:</strong>
        <ul class="mb-0 mt-1">
            <?php foreach($errors as $error): ?>
            <li><?= htmlspecialchars($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header"><i class="fas fa-edit me-1"></i> Production Result Form</div>
        <div class="card-body">
            <form method="POST" action="">
                <div class="row g-3">
                    <!-- Work Order -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Work Order <span class="text-danger">*</span></label>
                        <select name="production_order_id" class="form-select" required>
                            <option value="">-- Select WO --</option>
                            <?php foreach($workOrders as $wo): ?>
                            <option value="<?= $wo['ProductionOrderID'] ?>" 
                                    <?= (isset($_POST['production_order_id']) && $_POST['production_order_id'] == $wo['ProductionOrderID']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($wo['WONumber']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <!-- Material Transfer -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Material Transfer</label>
                        <select name="transfer_id" class="form-select">
                            <option value="">-- Without Transfer --</option>
                            <?php foreach($transfers as $tr): ?>
                            <option value="<?= $tr['TransferID'] ?>" 
                                    <?= (isset($_POST['transfer_id']) && $_POST['transfer_id'] == $tr['TransferID']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($tr['TransferNumber']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                        <small class="text-muted">Optional: Select Material Transfer if used</small>
                    </div>
                    
                    <!-- Production Date -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Production Date <span class="text-danger">*</span></label>
                        <input type="date" name="production_date" class="form-control" 
                               value="<?= isset($_POST['production_date']) ? $_POST['production_date'] : date('Y-m-d') ?>" 
                               required>
                    </div>
                    
                    <!-- Shift -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Shift <span class="text-danger">*</span></label>
                        <select name="shift" class="form-select" required>
                            <option value="">-- Select Shift --</option>
                            <option value="Shift 1" <?= (isset($_POST['shift']) && $_POST['shift'] == 'Shift 1') ? 'selected' : '' ?>>Shift 1 (08:00-16:00)</option>
                            <option value="Shift 2" <?= (isset($_POST['shift']) && $_POST['shift'] == 'Shift 2') ? 'selected' : '' ?>>Shift 2 (16:00-00:00)</option>
                            <option value="Shift 3" <?= (isset($_POST['shift']) && $_POST['shift'] == 'Shift 3') ? 'selected' : '' ?>>Shift 3 (00:00-08:00)</option>
                        </select>
                    </div>
                    
                    <!-- Operator -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Operator</label>
                        <input type="text" name="operator" class="form-control" 
                               placeholder="e.g: Operator A" 
                               value="<?= isset($_POST['operator']) ? htmlspecialchars($_POST['operator']) : '' ?>">
                    </div>
                    
                    <!-- Machine No -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Machine No</label>
                        <input type="text" name="machine_no" class="form-control" 
                               placeholder="e.g: M-001" 
                               value="<?= isset($_POST['machine_no']) ? htmlspecialchars($_POST['machine_no']) : '' ?>">
                    </div>
                    
                    <!-- Qty Produced -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Qty Produced <span class="text-danger">*</span></label>
                        <input type="number" name="qty_produced" class="form-control" 
                               placeholder="0" 
                               value="<?= isset($_POST['qty_produced']) ? htmlspecialchars($_POST['qty_produced']) : '' ?>" 
                               min="1" required>
                    </div>
                    
                    <!-- Qty Reject -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Qty Reject</label>
                        <input type="number" name="qty_reject" class="form-control" 
                               placeholder="0" 
                               value="<?= isset($_POST['qty_reject']) ? htmlspecialchars($_POST['qty_reject']) : '0' ?>" 
                               min="0">
                    </div>
                    
                    <!-- Qty Repair -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Qty Repair</label>
                        <input type="number" name="qty_repair" class="form-control" 
                               placeholder="0" 
                               value="<?= isset($_POST['qty_repair']) ? htmlspecialchars($_POST['qty_repair']) : '0' ?>" 
                               min="0">
                    </div>
                    
                    <!-- Notes -->
                    <div class="col-12">
                        <label class="form-label fw-bold">Notes</label>
                        <textarea name="notes" class="form-control" rows="2" 
                                  placeholder="Additional notes"><?= isset($_POST['notes']) ? htmlspecialchars($_POST['notes']) : '' ?></textarea>
                    </div>
                    
                    <!-- Buttons -->
                    <div class="col-12">
                        <hr>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Save Result
                        </button>
                      <!--   <a href="<?= url('production_results') ?>" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i>Cancel
                        </a> -->
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>