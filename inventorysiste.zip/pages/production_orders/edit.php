<?php
// ======================================================
// HALAMAN EDIT PRODUCTION ORDER (WORK ORDER)
// ======================================================
ob_start();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Get WO Header
$wo = fetchOne("SELECT * FROM production_orders WHERE ProductionOrderID = ?", [$id]);

if(!$wo) {
    ob_clean();
    header("Location: index.php?page=production_orders&msg=Work Order not found&type=danger");
    exit;
}

// Get products for dropdown
$products = fetchAll("SELECT ProductID, ProductCode, ProductName, UOM FROM products WHERE Active = 1 ORDER BY ProductName");

// Get Sales Orders for dropdown (yang masih Open/Production)
$salesOrders = fetchAll("
    SELECT 
        cpo.CustomerPOID,
        cpo.PONumber,
        c.CustomerName
    FROM customer_pos cpo
    LEFT JOIN customers c ON cpo.CustomerID = c.CustomerID
    WHERE cpo.Status IN ('Open', 'Production', 'Partial')
    ORDER BY cpo.PONumber
");

// Proses submit form
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $customerPOID = isset($_POST['customer_po_id']) ? (int)$_POST['customer_po_id'] : null;
    $productID = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;
    $qtyTarget = isset($_POST['qty_target']) ? str_replace(',', '', $_POST['qty_target']) : 0;
    $dueDate = !empty($_POST['due_date']) ? $_POST['due_date'] : null;
    $priority = $_POST['priority'];
    $status = $_POST['status'];
    
    $errors = [];
    
    // Validasi
    if(empty($productID)) $errors[] = "Product is required";
    if(empty($qtyTarget) || $qtyTarget <= 0) $errors[] = "Target quantity must be greater than 0";
    if(empty($dueDate)) $errors[] = "Due date is required";
    
    // Ambil qty remaining dari customer PO jika ada
    if($customerPOID > 0) {
        $remaining = fetchOne("
            SELECT COALESCE(SUM(QtyRemaining), 0) as total 
            FROM customer_po_details 
            WHERE CustomerPOID = ?
        ", [$customerPOID]);
        
        // Tambahkan qty yang sudah diproduksi dari WO ini
        $currentProduced = fetchOne("
            SELECT COALESCE(SUM(QtyProduced), 0) as total 
            FROM production_results 
            WHERE ProductionOrderID = ?
        ", [$id]);
        
        $available = $remaining['total'] + ($currentProduced ? $currentProduced['total'] : 0);
        
        if($available && $qtyTarget > $available) {
            $errors[] = "Qty target cannot exceed remaining qty of Sales Order (" . number_format($available) . ")";
        }
    }
    
    if(empty($errors)) {
        try {
            $sql = "UPDATE production_orders SET 
                    CustomerPOID = ?, 
                    ProductID = ?, 
                    QtyTarget = ?, 
                    DueDate = ?, 
                    Priority = ?,
                    Status = ?
                    WHERE ProductionOrderID = ?";
            query($sql, [$customerPOID, $productID, $qtyTarget, $dueDate, $priority, $status, $id]);
            
            // Update customer PO status jika ada
            if($customerPOID > 0) {
                // Cek apakah masih ada WO yang Running untuk PO ini
                $activeWO = fetchCount("
                    SELECT COUNT(*) 
                    FROM production_orders 
                    WHERE CustomerPOID = ? AND Status NOT IN ('Completed', 'Cancelled')
                ", [$customerPOID]);
                
                if($activeWO > 0) {
                    query("UPDATE customer_pos SET Status = 'Production' WHERE CustomerPOID = ?", [$customerPOID]);
                } else {
                    // Cek apakah semua WO sudah Completed
                    $totalWO = fetchCount("SELECT COUNT(*) FROM production_orders WHERE CustomerPOID = ?", [$customerPOID]);
                    $completedWO = fetchCount("SELECT COUNT(*) FROM production_orders WHERE CustomerPOID = ? AND Status = 'Completed'", [$customerPOID]);
                    
                    if($totalWO > 0 && $totalWO == $completedWO) {
                        query("UPDATE customer_pos SET Status = 'Completed' WHERE CustomerPOID = ?", [$customerPOID]);
                    }
                }
            }
            
            ob_clean();
            header("Location: index.php?page=production_orders&msg=updated&type=success");
            exit;
        } catch(PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}

ob_end_clean();
?>
<div id="page-content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3"><i class="fas fa-tasks-plus me-2 text-primary"></i>Edit Work Order</h1>
            <p class="text-muted">Edit work order: <?= htmlspecialchars($wo['WONumber']) ?></p>
        </div>
        <a href="<?= url('production_orders') ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i>Back
        </a>
    </div>

    <?php if(isset($errors) && !empty($errors)): ?>
    <div class="alert alert-danger">
        <strong><i class="fas fa-exclamation-circle me-1"></i> Please fix the following errors:</strong>
        <ul class="mb-0 mt-1">
            <?php foreach($errors as $error): ?>
            <li><?= htmlspecialchars($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header"><i class="fas fa-edit me-1"></i> Edit Work Order Form</div>
        <div class="card-body">
            <form method="POST" action="">
                <div class="row g-3">
                    <!-- Sales Order -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Sales Order</label>
                        <select name="customer_po_id" class="form-select">
                            <option value="">-- Without SO --</option>
                            <?php foreach($salesOrders as $so): ?>
                            <option value="<?= $so['CustomerPOID'] ?>" 
                                    <?= $wo['CustomerPOID'] == $so['CustomerPOID'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($so['PONumber']) ?> - <?= htmlspecialchars($so['CustomerName']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                        <small class="text-muted">Optional: Select Sales Order if this WO is for a customer order</small>
                    </div>
                    
                    <!-- Product -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Product <span class="text-danger">*</span></label>
                        <select name="product_id" class="form-select" required>
                            <option value="">-- Select Product --</option>
                            <?php foreach($products as $prod): ?>
                            <option value="<?= $prod['ProductID'] ?>" 
                                    <?= $wo['ProductID'] == $prod['ProductID'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($prod['ProductCode']) ?> - <?= htmlspecialchars($prod['ProductName']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <!-- Qty Target -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Target Quantity <span class="text-danger">*</span></label>
                        <input type="number" name="qty_target" class="form-control" 
                               placeholder="0" 
                               value="<?= htmlspecialchars($wo['QtyTarget']) ?>" 
                               min="1" required>
                    </div>
                    
                    <!-- Due Date -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Due Date <span class="text-danger">*</span></label>
                        <input type="date" name="due_date" class="form-control" 
                               value="<?= $wo['DueDate'] ?>" 
                               required>
                    </div>
                    
                    <!-- Priority -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Priority <span class="text-danger">*</span></label>
                        <select name="priority" class="form-select" required>
                            <option value="Low" <?= $wo['Priority'] == 'Low' ? 'selected' : '' ?>>Low</option>
                            <option value="Medium" <?= $wo['Priority'] == 'Medium' ? 'selected' : '' ?>>Medium</option>
                            <option value="High" <?= $wo['Priority'] == 'High' ? 'selected' : '' ?>>High</option>
                            <option value="Urgent" <?= $wo['Priority'] == 'Urgent' ? 'selected' : '' ?>>Urgent</option>
                        </select>
                    </div>
                    
                    <!-- Status -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Status <span class="text-danger">*</span></label>
                        <select name="status" class="form-select" required>
                            <option value="Open" <?= $wo['Status'] == 'Open' ? 'selected' : '' ?>>Open</option>
                            <option value="Running" <?= $wo['Status'] == 'Running' ? 'selected' : '' ?>>Running</option>
                            <option value="Partial" <?= $wo['Status'] == 'Partial' ? 'selected' : '' ?>>Partial</option>
                            <option value="Completed" <?= $wo['Status'] == 'Completed' ? 'selected' : '' ?>>Completed</option>
                            <option value="Cancelled" <?= $wo['Status'] == 'Cancelled' ? 'selected' : '' ?>>Cancelled</option>
                        </select>
                        <?php if($wo['Status'] != 'Open'): ?>
                        <small class="text-warning">
                            <i class="fas fa-info-circle me-1"></i>
                            Current status: <strong><?= $wo['Status'] ?></strong>
                        </small>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Created Info -->
                    <div class="col-md-6">
                        <div class="alert alert-info">
                            <small>
                                <i class="fas fa-info-circle me-1"></i>
                                WO Number: <strong><?= htmlspecialchars($wo['WONumber']) ?></strong><br>
                                Created: <?= date('d/m/Y H:i', strtotime($wo['CreatedAt'])) ?>
                                <?php if($wo['StartedAt']): ?>
                                <br>Started: <?= date('d/m/Y H:i', strtotime($wo['StartedAt'])) ?>
                                <?php endif; ?>
                                <?php if($wo['CompletedAt']): ?>
                                <br>Completed: <?= date('d/m/Y H:i', strtotime($wo['CompletedAt'])) ?>
                                <?php endif; ?>
                            </small>
                        </div>
                    </div>
                    
                    <!-- Buttons -->
                    <div class="col-12">
                        <hr>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Update Work Order
                        </button>
                    
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>