<?php
// ======================================================
// PROSES HAPUS WORK ORDER
// ======================================================
ob_start();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$wo = fetchOne("SELECT * FROM production_orders WHERE ProductionOrderID = ?", [$id]);

if(!$wo) {
    ob_clean();
    header("Location: index.php?page=production_orders&msg=Work Order not found&type=danger");
    exit;
}

// Cek apakah WO sudah memiliki production results
$hasResults = fetchCount("SELECT COUNT(*) FROM production_results WHERE ProductionOrderID = ?", [$id]);
$hasTransfers = fetchCount("SELECT COUNT(*) FROM material_transfers WHERE ProductionOrderID = ?", [$id]);

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    if($hasResults > 0 || $hasTransfers > 0) {
        // Soft delete - hanya ubah status
        query("UPDATE production_orders SET Status = 'Cancelled' WHERE ProductionOrderID = ?", [$id]);
    } else {
        // Permanent delete
        query("DELETE FROM production_orders WHERE ProductionOrderID = ?", [$id]);
    }
    
    ob_clean();
    header("Location: index.php?page=production_orders&msg=deleted&type=success");
    exit;
}

ob_end_clean();
?>
<div id="page-content-wrapper">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-header bg-danger text-white">
                    <i class="fas fa-exclamation-triangle me-1"></i> Confirm Delete
                </div>
                <div class="card-body text-center py-4">
                    <i class="fas fa-tasks fa-4x text-danger mb-3"></i>
                    <h4>Are you sure you want to delete this work order?</h4>
                    <p class="text-muted">
                        <strong><?= htmlspecialchars($wo['WONumber']) ?></strong>
                        <br>
                        Target: <?= number_format($wo['QtyTarget']) ?>
                        <br>
                        Status: <?= $wo['Status'] ?>
                    </p>
                    
                    <?php if($hasResults > 0 || $hasTransfers > 0): ?>
                    <div class="alert alert-warning">
                        <i class="fas fa-info-circle me-1"></i>
                        This WO has 
                        <?php if($hasResults > 0): ?>
                        <strong><?= number_format($hasResults) ?> production result(s)</strong>
                        <?php endif; ?>
                        <?php if($hasTransfers > 0): ?>
                        <?php if($hasResults > 0) echo ' and '; ?>
                        <strong><?= number_format($hasTransfers) ?> material transfer(s)</strong>
                        <?php endif; ?>.
                        WO will be <strong>cancelled</strong> instead of permanently deleted.
                    </div>
                    <?php else: ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-info-circle me-1"></i>
                        This WO has <strong>no records</strong>.
                        WO will be <strong>permanently deleted</strong>.
                    </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="" class="d-inline">
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash me-1"></i> Yes, Delete
                        </button>
                        <a href="<?= url('production_orders') ?>" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i> Cancel
                        </a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>