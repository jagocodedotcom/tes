<?php
// ======================================================
// HALAMAN DETAIL WORK ORDER
// ======================================================

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Get WO Header
$wo = fetchOne("
    SELECT 
        wo.*,
        p.ProductName,
        p.ProductCode,
        p.UOM,
        cpo.PONumber AS CustomerPONumber,
        c.CustomerName
    FROM production_orders wo
    LEFT JOIN products p ON wo.ProductID = p.ProductID
    LEFT JOIN customer_pos cpo ON wo.CustomerPOID = cpo.CustomerPOID
    LEFT JOIN customers c ON cpo.CustomerID = c.CustomerID
    WHERE wo.ProductionOrderID = ?
", [$id]);

if(!$wo) {
    header("Location: index.php?page=production_orders&msg=Work Order not found&type=danger");
    exit;
}

// Get Production Results
$results = fetchAll("
    SELECT 
        pr.*,
        qc.QCID,
        qc.QtyPASS,
        qc.QtyNG,
        qc.FinalStatus,
        qc.Inspector
    FROM production_results pr
    LEFT JOIN qc_inspections qc ON pr.ProductionResultID = qc.ProductionResultID
    WHERE pr.ProductionOrderID = ?
    ORDER BY pr.ProductionDate DESC
", [$id]);

// Get Material Transfers
$transfers = fetchAll("
    SELECT 
        mt.TransferID,
        mt.TransferNumber,
        mt.TransferDate,
        mt.Status,
        COUNT(mtd.TransferDetailID) AS TotalItems,
        SUM(mtd.QtyTransfer) AS TotalQty
    FROM material_transfers mt
    LEFT JOIN transfer_details mtd ON mt.TransferID = mtd.TransferID
    WHERE mt.ProductionOrderID = ?
    GROUP BY mt.TransferID
    ORDER BY mt.TransferDate DESC
", [$id]);

// Calculate totals
$totalProduced = 0;
$totalReject = 0;
$totalGood = 0;
foreach($results as $r) {
    $totalProduced += $r['QtyProduced'];
    $totalReject += $r['QtyReject'];
    $totalGood += $r['QtyGood'];
}
$progress = ($wo['QtyTarget'] > 0) ? ($totalProduced / $wo['QtyTarget'] * 100) : 0;
?>

<div id="page-content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3">
                <i class="fas fa-tasks me-2 text-primary"></i>Work Order Detail
            </h1>
            <p class="text-muted">View work order details</p>
        </div>
        <div>
            <a href="<?= url('production_orders', 'edit', ['id' => $id]) ?>" class="btn btn-primary">
                <i class="fas fa-edit me-1"></i>Edit
            </a>
            <a href="<?= url('production_orders') ?>" class="btn btn-secondary">
                <i class="fas fa-arrow-left me-1"></i>Back
            </a>
        </div>
    </div>

    <!-- Progress -->
    <div class="card mb-4">
        <div class="card-body">
            <div class="row">
                <div class="col-md-3 text-center">
                    <h5 class="text-primary"><?= number_format($progress, 1) ?>%</h5>
                    <small class="text-muted">Progress</small>
                </div>
                <div class="col-md-3 text-center">
                    <h5 class="text-primary"><?= number_format($wo['QtyTarget']) ?></h5>
                    <small class="text-muted">Target</small>
                </div>
                <div class="col-md-3 text-center">
                    <h5 class="text-success"><?= number_format($totalProduced) ?></h5>
                    <small class="text-muted">Produced</small>
                </div>
                <div class="col-md-3 text-center">
                    <h5 class="text-danger"><?= number_format($totalReject) ?></h5>
                    <small class="text-muted">Reject</small>
                </div>
            </div>
            <div class="mt-2">
                <?= getProgressBar($progress) ?>
            </div>
        </div>
    </div>

    <!-- WO Information -->
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-info-circle me-1"></i> Work Order Information
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <table class="table table-bordered mb-0">
                        <tr>
                            <th width="35%">WO Number</th>
                            <td><span class="badge bg-info"><?= htmlspecialchars($wo['WONumber']) ?></span></td>
                        </tr>
                        <tr>
                            <th>Product</th>
                            <td><strong><?= htmlspecialchars($wo['ProductName']) ?></strong> (<?= htmlspecialchars($wo['ProductCode']) ?>)</td>
                        </tr>
                        <tr>
                            <th>UOM</th>
                            <td><?= htmlspecialchars($wo['UOM']) ?></td>
                        </tr>
                        <tr>
                            <th>Target Qty</th>
                            <td><?= number_format($wo['QtyTarget']) ?></td>
                        </tr>
                    </table>
                </div>
                <div class="col-md-6">
                    <table class="table table-bordered mb-0">
                        <tr>
                            <th width="35%">Due Date</th>
                            <td><?= date('d/m/Y', strtotime($wo['DueDate'])) ?></td>
                        </tr>
                        <tr>
                            <th>Status</th>
                            <td><?= getStatusBadge($wo['Status']) ?></td>
                        </tr>
                        <tr>
                            <th>Priority</th>
                            <td><?= getPriorityBadge($wo['Priority']) ?></td>
                        </tr>
                        <tr>
                            <th>Created By</th>
                            <td><?= htmlspecialchars($wo['CreatedBy']) ?></td>
                        </tr>
                    </table>
                </div>
            </div>
            <?php if($wo['CustomerPONumber']): ?>
            <div class="row mt-3">
                <div class="col-12">
                    <div class="alert alert-info">
                        <strong>Sales Order:</strong> <?= htmlspecialchars($wo['CustomerPONumber']) ?>
                        <?php if($wo['CustomerName']): ?>
                        - Customer: <?= htmlspecialchars($wo['CustomerName']) ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Material Transfers -->
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-arrow-right me-1"></i> Material Transfers
            <span class="badge bg-secondary float-end"><?= count($transfers) ?> records</span>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-striped mb-0">
                    <thead>
                        <tr>
                            <th>Transfer Number</th>
                            <th>Date</th>
                            <th>Items</th>
                            <th>Qty</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($transfers)): ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted py-3">No material transfers found</td>
                        </tr>
                        <?php else: ?>
                        <?php foreach($transfers as $t): ?>
                        <tr>
                            <td><?= htmlspecialchars($t['TransferNumber']) ?></td>
                            <td><?= date('d/m/Y', strtotime($t['TransferDate'])) ?></td>
                            <td><?= number_format($t['TotalItems']) ?></td>
                            <td><?= number_format($t['TotalQty']) ?></td>
                            <td><?= getStatusBadge($t['Status']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Production Results -->
    <div class="card">
        <div class="card-header">
            <i class="fas fa-chart-bar me-1"></i> Production Results
            <span class="badge bg-secondary float-end"><?= count($results) ?> records</span>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-striped mb-0">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Shift</th>
                            <th>Produced</th>
                            <th>Reject</th>
                            <th>Good</th>
                            <th>QC Status</th>
                            <th>Inspector</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($results)): ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted py-3">No production results found</td>
                        </tr>
                        <?php else: ?>
                        <?php foreach($results as $r): ?>
                        <tr>
                            <td><?= date('d/m/Y', strtotime($r['ProductionDate'])) ?></td>
                            <td><?= getShiftLabel($r['Shift']) ?></td>
                            <td class="text-end"><?= number_format($r['QtyProduced']) ?></td>
                            <td class="text-end text-danger"><?= number_format($r['QtyReject']) ?></td>
                            <td class="text-end text-success"><?= number_format($r['QtyGood']) ?></td>
                            <td>
                                <?php if($r['QCID']): ?>
                                <span class="badge bg-<?= $r['FinalStatus'] == 'Accepted' ? 'success' : ($r['FinalStatus'] == 'Rejected' ? 'danger' : 'warning') ?>">
                                    <?= $r['FinalStatus'] ?: 'Pending' ?>
                                </span>
                                <?php else: ?>
                                <span class="badge bg-secondary">Pending QC</span>
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($r['Inspector']) ?: '-' ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <tr class="table-active">
                            <td colspan="2" class="text-end fw-bold">Total</td>
                            <td class="text-end fw-bold"><?= number_format($totalProduced) ?></td>
                            <td class="text-end fw-bold text-danger"><?= number_format($totalReject) ?></td>
                            <td class="text-end fw-bold text-success"><?= number_format($totalGood) ?></td>
                            <td colspan="2"></td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>