<?php
// ======================================================
// HALAMAN TAMBAH WORK ORDER
// ======================================================
ob_start();

// Get products for dropdown
$products = fetchAll("SELECT ProductID, ProductCode, ProductName, UOM FROM products WHERE Active = 1 ORDER BY ProductName");

// Get Sales Orders for dropdown (yang masih Open/Production)
$salesOrders = fetchAll("
    SELECT 
        cpo.CustomerPOID,
        cpo.PONumber,
        c.CustomerName
    FROM customer_pos cpo
    LEFT JOIN customers c ON cpo.CustomerID = c.CustomerID
    WHERE cpo.Status IN ('Open', 'Production', 'Partial')
    ORDER BY cpo.PONumber
");

// Proses submit form
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $customerPOID = isset($_POST['customer_po_id']) ? (int)$_POST['customer_po_id'] : null;
    $productID = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;
    $qtyTarget = isset($_POST['qty_target']) ? str_replace(',', '', $_POST['qty_target']) : 0;
    $dueDate = !empty($_POST['due_date']) ? $_POST['due_date'] : null;
    $priority = $_POST['priority'];
    $createdBy = 'production1'; // Nanti dari session
    
    $errors = [];
    
    // Validasi
    if(empty($productID)) $errors[] = "Product is required";
    if(empty($qtyTarget) || $qtyTarget <= 0) $errors[] = "Target quantity must be greater than 0";
    if(empty($dueDate)) $errors[] = "Due date is required";
    
    // Ambil qty remaining dari customer PO jika ada
    if($customerPOID > 0) {
        $remaining = fetchOne("
            SELECT COALESCE(SUM(QtyRemaining), 0) as total 
            FROM customer_po_details 
            WHERE CustomerPOID = ?
        ", [$customerPOID]);
        
        if($remaining && $qtyTarget > $remaining['total']) {
            $errors[] = "Qty target cannot exceed remaining qty of Sales Order (" . number_format($remaining['total']) . ")";
        }
    }
    
    if(empty($errors)) {
        try {
            // Generate WO Number
            $year = date('Y');
            $month = date('m');
            $lastWO = fetchOne("SELECT WONumber FROM production_orders ORDER BY ProductionOrderID DESC LIMIT 1");
            $lastNumber = 0;
            if($lastWO) {
                $lastNumber = (int)substr($lastWO['WONumber'], -4);
            }
            $newNumber = str_pad($lastNumber + 1, 4, '0', STR_PAD_LEFT);
            $woNumber = 'WO-' . $year . $month . '-' . $newNumber;
            
            // Insert WO
            $sql = "INSERT INTO production_orders (WONumber, CustomerPOID, ProductID, QtyTarget, DueDate, Status, Priority, CreatedBy) 
                    VALUES (?, ?, ?, ?, ?, 'Open', ?, ?)";
            query($sql, [$woNumber, $customerPOID, $productID, $qtyTarget, $dueDate, $priority, $createdBy]);
            
            // Update customer PO status jika ada
            if($customerPOID > 0) {
                query("UPDATE customer_pos SET Status = 'Production' WHERE CustomerPOID = ?", [$customerPOID]);
            }
            
            ob_clean();
            header("Location: index.php?page=production_orders&msg=created&type=success");
            exit;
        } catch(PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}

ob_end_clean();
?>
<div id="page-content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3"><i class="fas fa-tasks-plus me-2 text-primary"></i>Add Work Order</h1>
            <p class="text-muted">Create new production work order</p>
        </div>
        <a href="<?= url('production_orders') ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i>Back
        </a>
    </div>

    <?php if(isset($errors) && !empty($errors)): ?>
    <div class="alert alert-danger">
        <strong><i class="fas fa-exclamation-circle me-1"></i> Please fix the following errors:</strong>
        <ul class="mb-0 mt-1">
            <?php foreach($errors as $error): ?>
            <li><?= htmlspecialchars($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header"><i class="fas fa-edit me-1"></i> Work Order Form</div>
        <div class="card-body">
            <form method="POST" action="">
                <div class="row g-3">
                    <!-- Sales Order -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Sales Order</label>
                        <select name="customer_po_id" class="form-select">
                            <option value="">-- Without SO --</option>
                            <?php foreach($salesOrders as $so): ?>
                            <option value="<?= $so['CustomerPOID'] ?>" 
                                    <?= (isset($_POST['customer_po_id']) && $_POST['customer_po_id'] == $so['CustomerPOID']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($so['PONumber']) ?> - <?= htmlspecialchars($so['CustomerName']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                        <small class="text-muted">Optional: Select Sales Order if this WO is for a customer order</small>
                    </div>
                    
                    <!-- Product -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Product <span class="text-danger">*</span></label>
                        <select name="product_id" class="form-select" required>
                            <option value="">-- Select Product --</option>
                            <?php foreach($products as $prod): ?>
                            <option value="<?= $prod['ProductID'] ?>" 
                                    <?= (isset($_POST['product_id']) && $_POST['product_id'] == $prod['ProductID']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($prod['ProductCode']) ?> - <?= htmlspecialchars($prod['ProductName']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <!-- Qty Target -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Target Quantity <span class="text-danger">*</span></label>
                        <input type="number" name="qty_target" class="form-control" 
                               placeholder="0" 
                               value="<?= isset($_POST['qty_target']) ? htmlspecialchars($_POST['qty_target']) : '' ?>" 
                               min="1" required>
                    </div>
                    
                    <!-- Due Date -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Due Date <span class="text-danger">*</span></label>
                        <input type="date" name="due_date" class="form-control" 
                               value="<?= isset($_POST['due_date']) ? $_POST['due_date'] : date('Y-m-d', strtotime('+7 days')) ?>" 
                               required>
                    </div>
                    
                    <!-- Priority -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Priority <span class="text-danger">*</span></label>
                        <select name="priority" class="form-select" required>
                            <option value="Low" <?= (isset($_POST['priority']) && $_POST['priority'] == 'Low') ? 'selected' : '' ?>>Low</option>
                            <option value="Medium" <?= (isset($_POST['priority']) && $_POST['priority'] == 'Medium') ? 'selected' : '' ?>>Medium</option>
                            <option value="High" <?= (isset($_POST['priority']) && $_POST['priority'] == 'High') ? 'selected' : '' ?>>High</option>
                            <option value="Urgent" <?= (isset($_POST['priority']) && $_POST['priority'] == 'Urgent') ? 'selected' : '' ?>>Urgent</option>
                        </select>
                    </div>
                    
                    <!-- Buttons -->
                    <div class="col-12">
                        <hr>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Create Work Order
                        </button>
                        
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>