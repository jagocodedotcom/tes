<?php
// ======================================================
// HALAMAN LIST PRODUCTION ORDERS (WORK ORDERS)
// ======================================================

// Pagination
$page = isset($_GET['page_num']) ? (int)$_GET['page_num'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

// Search
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Build Query
$whereClause = "WHERE 1=1";
$params = [];

if (!empty($search)) {
    $whereClause .= " AND (wo.WONumber LIKE ? OR p.ProductName LIKE ?)";
    $searchTerm = "%$search%";
    $params = [$searchTerm, $searchTerm];
}

// Get Total Data
$totalQuery = "
    SELECT COUNT(*) 
    FROM production_orders wo
    LEFT JOIN products p ON wo.ProductID = p.ProductID
    $whereClause
";
$totalData = fetchCount($totalQuery, $params);
$totalPages = ceil($totalData / $limit);

// Get Data - HAPUS wo.QtyProduced
$query = "
    SELECT 
        wo.ProductionOrderID,
        wo.WONumber,
        wo.QtyTarget,
        wo.DueDate,
        wo.Status,
        wo.Priority,
        wo.CreatedBy,
        wo.CreatedAt,
        p.ProductName,
        p.ProductCode,
        cpo.PONumber AS CustomerPONumber,
        (SELECT COALESCE(SUM(QtyProduced), 0) FROM production_results WHERE ProductionOrderID = wo.ProductionOrderID) AS TotalProduced,
        (SELECT COALESCE(SUM(QtyReject), 0) FROM production_results WHERE ProductionOrderID = wo.ProductionOrderID) AS TotalReject
    FROM production_orders wo
    LEFT JOIN products p ON wo.ProductID = p.ProductID
    LEFT JOIN customer_pos cpo ON wo.CustomerPOID = cpo.CustomerPOID
    $whereClause
    ORDER BY 
        FIELD(wo.Priority, 'Urgent', 'High', 'Medium', 'Low'),
        wo.DueDate ASC
    LIMIT $limit OFFSET $offset
";
$workOrders = fetchAll($query, $params);

// Get Success/Error Message
$message = isset($_GET['msg']) ? $_GET['msg'] : '';
$messageType = isset($_GET['type']) ? $_GET['type'] : '';
?>

<div id="page-content-wrapper">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3">
                <i class="fas fa-tasks me-2 text-primary"></i>Work Orders
            </h1>
            <p class="text-muted">Manage production work orders</p>
        </div>
        <a href="<?= url('production_orders', 'create') ?>" class="btn btn-primary">
            <i class="fas fa-plus me-1"></i>Add Work Order
        </a>
    </div>

    <!-- Alert Message -->
    <?php if($message): ?>
    <div class="alert alert-<?= $messageType ?> alert-dismissible fade show" role="alert">
        <?php 
        if($message == 'created') echo 'Work Order berhasil dibuat!';
        elseif($message == 'updated') echo 'Work Order berhasil diperbarui!';
        elseif($message == 'deleted') echo 'Work Order berhasil dihapus!';
        else echo htmlspecialchars($message);
        ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <!-- Search -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <input type="hidden" name="page" value="production_orders">
                <div class="col-md-10">
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                        <input type="text" name="search" class="form-control" 
                               placeholder="Search by WO number or product..." 
                               value="<?= htmlspecialchars($search) ?>">
                    </div>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search me-1"></i>Search
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Table -->
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <span><i class="fas fa-list me-1"></i> Work Order List</span>
                <span class="badge bg-primary"><?= number_format($totalData) ?> Records</span>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover table-striped mb-0">
                    <thead>
                        <tr>
                            <th width="50">#</th>
                            <th>WO Number</th>
                            <th>Product</th>
                            <th>SO Number</th>
                            <th>Target</th>
                            <th>Produced</th>
                            <th>Progress</th>
                            <th>Due Date</th>
                            <th>Priority</th>
                            <th>Status</th>
                            <th width="120">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($workOrders)): ?>
                        <tr>
                            <td colspan="11" class="text-center text-muted py-4">
                                <i class="fas fa-inbox fa-2x d-block mb-2"></i>
                                No work orders found
                            </td>
                        </tr>
                        <?php else: ?>
                        <?php 
                        $no = $offset + 1;
                        foreach($workOrders as $row):
                            $produced = $row['TotalProduced'] ?? 0;
                            $progress = 0;
                            if ($row['QtyTarget'] > 0) {
                                $progress = ($produced / $row['QtyTarget']) * 100;
                            }
                            $daysRemaining = '';
                            if ($row['DueDate']) {
                                $now = new DateTime();
                                $due = new DateTime($row['DueDate']);
                                $diff = $now->diff($due);
                                $days = (int)$diff->format('%r%a');
                                if ($days < 0) $daysRemaining = '<span class="text-danger">Overdue</span>';
                                else if ($days == 0) $daysRemaining = '<span class="text-warning">Today</span>';
                                else $daysRemaining = $days . ' days';
                            }
                        ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td>
                                <span class="badge bg-info"><?= htmlspecialchars($row['WONumber']) ?></span>
                            </td>
                            <td>
                                <strong><?= htmlspecialchars($row['ProductName']) ?></strong>
                                <br>
                                <small class="text-muted"><?= htmlspecialchars($row['ProductCode']) ?></small>
                            </td>
                            <td>
                                <?php if($row['CustomerPONumber']): ?>
                                <?= htmlspecialchars($row['CustomerPONumber']) ?>
                                <?php else: ?>
                                <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td><?= number_format($row['QtyTarget']) ?></td>
                            <td><?= number_format($produced) ?></td>
                            <td>
                                <?php 
                                $color = 'success';
                                if ($progress < 30) $color = 'danger';
                                else if ($progress < 70) $color = 'warning';
                                ?>
                                <div class="progress" style="height: 20px;">
                                    <div class="progress-bar bg-<?= $color ?>" 
                                         role="progressbar" 
                                         style="width: <?= $progress ?>%;" 
                                         aria-valuenow="<?= $progress ?>" 
                                         aria-valuemin="0" 
                                         aria-valuemax="100">
                                        <?= number_format($progress, 1) ?>%
                                    </div>
                                </div>
                            </td>
                            <td>
                                <?= $row['DueDate'] ? date('d/m/Y', strtotime($row['DueDate'])) : '-' ?>
                                <?php if($daysRemaining): ?>
                                <br><small><?= $daysRemaining ?></small>
                                <?php endif; ?>
                            </td>
                            <td><?= getPriorityBadge($row['Priority']) ?></td>
                            <td><?= getStatusBadge($row['Status']) ?></td>
                            <td>
                                <div class="btn-group btn-group-sm">
                                    <a href="<?= url('production_orders', 'view', ['id' => $row['ProductionOrderID']]) ?>" 
                                       class="btn btn-outline-info" title="View">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="<?= url('production_orders', 'edit', ['id' => $row['ProductionOrderID']]) ?>" 
                                       class="btn btn-outline-primary" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="<?= url('production_orders', 'delete', ['id' => $row['ProductionOrderID']]) ?>" 
                                       class="btn btn-outline-danger" title="Delete"
                                       onclick="return confirm('Apakah anda yakin akan menghapus data ini?')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php if($totalPages > 1): ?>
        <div class="card-footer">
            <nav>
                <ul class="pagination pagination-sm mb-0">
                    <?php if($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=production_orders&page_num=<?= $page-1 ?>&search=<?= urlencode($search) ?>">
                            <i class="fas fa-chevron-left"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <?php for($i = 1; $i <= $totalPages; $i++): ?>
                    <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                        <a class="page-link" href="?page=production_orders&page_num=<?= $i ?>&search=<?= urlencode($search) ?>">
                            <?= $i ?>
                        </a>
                    </li>
                    <?php endfor; ?>
                    
                    <?php if($page < $totalPages): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=production_orders&page_num=<?= $page+1 ?>&search=<?= urlencode($search) ?>">
                            <i class="fas fa-chevron-right"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
        <?php endif; ?>
    </div>
</div>