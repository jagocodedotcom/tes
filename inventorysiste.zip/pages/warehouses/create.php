<?php
// ======================================================
// HALAMAN TAMBAH WAREHOUSE
// ======================================================
ob_start();

// Proses submit form
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $warehouseCode = trim($_POST['warehouse_code']);
    $warehouseName = trim($_POST['warehouse_name']);
    $location = trim($_POST['location']);
    $isActive = isset($_POST['is_active']) ? (int)$_POST['is_active'] : 1;
    
    $errors = [];
    
    // Validasi required
    if(empty($warehouseCode)) $errors[] = "Warehouse Code is required";
    if(empty($warehouseName)) $errors[] = "Warehouse Name is required";
    if(empty($location)) $errors[] = "Location is required";
    
    // Cek duplicate code
    if(empty($errors)) {
        $check = fetchOne("SELECT WarehouseID FROM warehouses WHERE WarehouseCode = ?", [$warehouseCode]);
        if($check) {
            $errors[] = "Warehouse Code already exists!";
        }
    }
    
    if(empty($errors)) {
        try {
            $sql = "INSERT INTO warehouses (WarehouseCode, WarehouseName, Location, IsActive) 
                    VALUES (?, ?, ?, ?)";
            query($sql, [$warehouseCode, $warehouseName, $location, $isActive]);
            
            ob_clean();
            header("Location: index.php?page=warehouses&msg=created&type=success");
            exit;
        } catch(PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}

ob_end_clean();
?>
<div id="page-content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3"><i class="fas fa-warehouse-plus me-2 text-primary"></i>Add Warehouse</h1>
            <p class="text-muted">Add new warehouse location</p>
        </div>
        <a href="<?= url('warehouses') ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i>Back
        </a>
    </div>

    <?php if(isset($errors) && !empty($errors)): ?>
    <div class="alert alert-danger">
        <strong><i class="fas fa-exclamation-circle me-1"></i> Please fix the following errors:</strong>
        <ul class="mb-0 mt-1">
            <?php foreach($errors as $error): ?>
            <li><?= htmlspecialchars($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header"><i class="fas fa-edit me-1"></i> Warehouse Form</div>
        <div class="card-body">
            <form method="POST" action="">
                <div class="row g-3">
                    <!-- Warehouse Code -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Warehouse Code <span class="text-danger">*</span></label>
                        <input type="text" name="warehouse_code" class="form-control" 
                               placeholder="e.g: WH-001" 
                               value="<?= isset($_POST['warehouse_code']) ? htmlspecialchars($_POST['warehouse_code']) : '' ?>" 
                               required>
                        <small class="text-muted">Unique identifier for the warehouse</small>
                    </div>
                    
                    <!-- Warehouse Name -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Warehouse Name <span class="text-danger">*</span></label>
                        <input type="text" name="warehouse_name" class="form-control" 
                               placeholder="e.g: Gudang Material Utama" 
                               value="<?= isset($_POST['warehouse_name']) ? htmlspecialchars($_POST['warehouse_name']) : '' ?>" 
                               required>
                    </div>
                    
                    <!-- Location -->
                    <div class="col-12">
                        <label class="form-label fw-bold">Location <span class="text-danger">*</span></label>
                        <input type="text" name="location" class="form-control" 
                               placeholder="e.g: Jl. Industri Raya No. 5, Jakarta" 
                               value="<?= isset($_POST['location']) ? htmlspecialchars($_POST['location']) : '' ?>" 
                               required>
                    </div>
                    
                    <!-- Status -->
                    <div class="col-12">
                        <label class="form-label fw-bold">Status</label>
                        <div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="is_active" id="active1" value="1" checked>
                                <label class="form-check-label" for="active1">
                                    <span class="badge bg-success">Active</span>
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="is_active" id="active0" value="0">
                                <label class="form-check-label" for="active0">
                                    <span class="badge bg-danger">Inactive</span>
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Buttons -->
                    <div class="col-12">
                        <hr>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Save Warehouse
                        </button>
                        <a href="<?= url('warehouses') ?>" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i>Cancel
                        </a>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>