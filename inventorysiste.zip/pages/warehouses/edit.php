<?php
// ======================================================
// HALAMAN EDIT WAREHOUSE
// ======================================================
ob_start();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$warehouse = fetchOne("SELECT * FROM warehouses WHERE WarehouseID = ?", [$id]);

if(!$warehouse) {
    ob_clean();
    header("Location: index.php?page=warehouses&msg=Warehouse not found&type=danger");
    exit;
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $warehouseCode = trim($_POST['warehouse_code']);
    $warehouseName = trim($_POST['warehouse_name']);
    $location = trim($_POST['location']);
    $isActive = isset($_POST['is_active']) ? (int)$_POST['is_active'] : 1;
    
    $errors = [];
    
    if(empty($warehouseCode)) $errors[] = "Warehouse Code is required";
    if(empty($warehouseName)) $errors[] = "Warehouse Name is required";
    if(empty($location)) $errors[] = "Location is required";
    
    if(empty($errors)) {
        $check = fetchOne("SELECT WarehouseID FROM warehouses WHERE WarehouseCode = ? AND WarehouseID != ?", [$warehouseCode, $id]);
        if($check) {
            $errors[] = "Warehouse Code already exists!";
        }
    }
    
    if(empty($errors)) {
        try {
            $sql = "UPDATE warehouses SET 
                    WarehouseCode = ?, 
                    WarehouseName = ?, 
                    Location = ?, 
                    IsActive = ?
                    WHERE WarehouseID = ?";
            query($sql, [$warehouseCode, $warehouseName, $location, $isActive, $id]);
            
            ob_clean();
            header("Location: index.php?page=warehouses&msg=updated&type=success");
            exit;
        } catch(PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}

ob_end_clean();
?>
<div id="page-content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3"><i class="fas fa-edit me-2 text-primary"></i>Edit Warehouse</h1>
            <p class="text-muted">Edit warehouse: <?= htmlspecialchars($warehouse['WarehouseCode']) ?></p>
        </div>
        <a href="<?= url('warehouses') ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i>Back
        </a>
    </div>

    <?php if(isset($errors) && !empty($errors)): ?>
    <div class="alert alert-danger">
        <strong><i class="fas fa-exclamation-circle me-1"></i> Please fix the following errors:</strong>
        <ul class="mb-0 mt-1">
            <?php foreach($errors as $error): ?>
            <li><?= htmlspecialchars($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header"><i class="fas fa-edit me-1"></i> Edit Warehouse Form</div>
        <div class="card-body">
            <form method="POST" action="">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Warehouse Code <span class="text-danger">*</span></label>
                        <input type="text" name="warehouse_code" class="form-control" 
                               value="<?= htmlspecialchars($warehouse['WarehouseCode']) ?>" required>
                        <small class="text-muted">Unique identifier for the warehouse</small>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Warehouse Name <span class="text-danger">*</span></label>
                        <input type="text" name="warehouse_name" class="form-control" 
                               value="<?= htmlspecialchars($warehouse['WarehouseName']) ?>" required>
                    </div>
                    
                    <div class="col-12">
                        <label class="form-label fw-bold">Location <span class="text-danger">*</span></label>
                        <input type="text" name="location" class="form-control" 
                               value="<?= htmlspecialchars($warehouse['Location']) ?>" required>
                    </div>
                    
                    <div class="col-12">
                        <label class="form-label fw-bold">Status</label>
                        <div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="is_active" id="active1" value="1" 
                                       <?= $warehouse['IsActive'] == 1 ? 'checked' : '' ?>>
                                <label class="form-check-label" for="active1">
                                    <span class="badge bg-success">Active</span>
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="is_active" id="active0" value="0"
                                       <?= $warehouse['IsActive'] == 0 ? 'checked' : '' ?>>
                                <label class="form-check-label" for="active0">
                                    <span class="badge bg-danger">Inactive</span>
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-12">
                        <div class="alert alert-info">
                            <small>
                                <i class="fas fa-info-circle me-1"></i>
                                Created: <?= date('d/m/Y H:i', strtotime($warehouse['CreatedAt'])) ?>
                            </small>
                        </div>
                    </div>
                    
                    <div class="col-12">
                        <hr>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Update Warehouse
                        </button>
                        <a href="<?= url('warehouses') ?>" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i>Cancel
                        </a>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>