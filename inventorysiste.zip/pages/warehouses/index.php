<?php
// ======================================================
// HALAMAN LIST WAREHOUSES
// ======================================================

// Pagination
$page = isset($_GET['page_num']) ? (int)$_GET['page_num'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

// Search
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Build Query
$whereClause = "WHERE 1=1";
$params = [];

if (!empty($search)) {
    $whereClause .= " AND (WarehouseCode LIKE ? OR WarehouseName LIKE ? OR Location LIKE ?)";
    $searchTerm = "%$search%";
    $params = [$searchTerm, $searchTerm, $searchTerm];
}

// Get Total Data
$totalQuery = "SELECT COUNT(*) FROM warehouses $whereClause";
$totalData = fetchCount($totalQuery, $params);
$totalPages = ceil($totalData / $limit);

// Get Data - HAPUS Capacity
$query = "
    SELECT 
        WarehouseID,
        WarehouseCode,
        WarehouseName,
        Location,
        IsActive,
        CreatedAt,
        (SELECT COUNT(*) FROM loading_docks WHERE WarehouseID = w.WarehouseID) AS TotalDocks
    FROM warehouses w
    $whereClause
    ORDER BY WarehouseName
    LIMIT $limit OFFSET $offset
";
$warehouses = fetchAll($query, $params);

// Get Success/Error Message
$message = isset($_GET['msg']) ? $_GET['msg'] : '';
$messageType = isset($_GET['type']) ? $_GET['type'] : '';
?>

<div id="page-content-wrapper">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3">
                <i class="fas fa-warehouse me-2 text-primary"></i>Warehouses
            </h1>
            <p class="text-muted">Manage warehouse locations</p>
        </div>
        <a href="<?= url('warehouses', 'create') ?>" class="btn btn-primary">
            <i class="fas fa-plus me-1"></i>Add Warehouse
        </a>
    </div>

    <!-- Alert Message -->
    <?php if($message): ?>
    <div class="alert alert-<?= $messageType ?> alert-dismissible fade show" role="alert">
        <?php 
        if($message == 'created') echo 'Warehouse berhasil ditambahkan!';
        elseif($message == 'updated') echo 'Warehouse berhasil diperbarui!';
        elseif($message == 'deleted') echo 'Warehouse berhasil dihapus!';
        else echo htmlspecialchars($message);
        ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <!-- Search -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <input type="hidden" name="page" value="warehouses">
                <div class="col-md-10">
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                        <input type="text" name="search" class="form-control" 
                               placeholder="Search by code, name, or location..." 
                               value="<?= htmlspecialchars($search) ?>">
                    </div>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search me-1"></i>Search
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Table -->
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <span><i class="fas fa-list me-1"></i> Warehouse List</span>
                <span class="badge bg-primary"><?= number_format($totalData) ?> Records</span>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover table-striped mb-0">
                    <thead>
                        <tr>
                            <th width="50">#</th>
                            <th>Code</th>
                            <th>Warehouse Name</th>
                            <th>Location</th>
                            <th>Docks</th>
                            <th>Status</th>
                            <th>Created</th>
                            <th width="120">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($warehouses)): ?>
                        <tr>
                            <td colspan="8" class="text-center text-muted py-4">
                                <i class="fas fa-inbox fa-2x d-block mb-2"></i>
                                No warehouses found
                            </td>
                        </tr>
                        <?php else: ?>
                        <?php 
                        $no = $offset + 1;
                        foreach($warehouses as $row): 
                        ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td>
                                <span class="badge bg-info"><?= htmlspecialchars($row['WarehouseCode']) ?></span>
                            </td>
                            <td>
                                <strong><?= htmlspecialchars($row['WarehouseName']) ?></strong>
                            </td>
                            <td><?= htmlspecialchars($row['Location']) ?></td>
                            <td>
                                <span class="badge bg-primary"><?= number_format($row['TotalDocks']) ?></span>
                            </td>
                            <td>
                                <?php if($row['IsActive'] == 1): ?>
                                <span class="badge bg-success">Active</span>
                                <?php else: ?>
                                <span class="badge bg-danger">Inactive</span>
                                <?php endif; ?>
                            </td>
                            <td><?= date('d/m/Y', strtotime($row['CreatedAt'])) ?></td>
                            <td>
                                <div class="btn-group btn-group-sm">
                                    <a href="<?= url('warehouses', 'edit', ['id' => $row['WarehouseID']]) ?>" 
                                       class="btn btn-outline-primary" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="<?= url('warehouses', 'delete', ['id' => $row['WarehouseID']]) ?>" 
                                       class="btn btn-outline-danger" title="Delete"
                                       onclick="return confirm('Apakah kamu yakin akan menghapus data ini?')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php if($totalPages > 1): ?>
        <div class="card-footer">
            <nav>
                <ul class="pagination pagination-sm mb-0">
                    <?php if($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=warehouses&page_num=<?= $page-1 ?>&search=<?= urlencode($search) ?>">
                            <i class="fas fa-chevron-left"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <?php for($i = 1; $i <= $totalPages; $i++): ?>
                    <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                        <a class="page-link" href="?page=warehouses&page_num=<?= $i ?>&search=<?= urlencode($search) ?>">
                            <?= $i ?>
                        </a>
                    </li>
                    <?php endfor; ?>
                    
                    <?php if($page < $totalPages): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=warehouses&page_num=<?= $page+1 ?>&search=<?= urlencode($search) ?>">
                            <i class="fas fa-chevron-right"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
        <?php endif; ?>
    </div>
</div>