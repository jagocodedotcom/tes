<?php
// ======================================================
// PROSES HAPUS WAREHOUSE
// ======================================================
ob_start();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$warehouse = fetchOne("SELECT * FROM warehouses WHERE WarehouseID = ?", [$id]);

if(!$warehouse) {
    ob_clean();
    header("Location: index.php?page=warehouses&msg=Warehouse not found&type=danger");
    exit;
}

// Cek apakah warehouse memiliki relasi
$hasMaterialStock = fetchCount("SELECT COUNT(*) FROM material_stock WHERE WarehouseID = ?", [$id]);
$hasFGStock = fetchCount("SELECT COUNT(*) FROM stock_fg WHERE WarehouseID = ?", [$id]);
$hasDocks = fetchCount("SELECT COUNT(*) FROM loading_docks WHERE WarehouseID = ?", [$id]);

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    if($hasMaterialStock > 0 || $hasFGStock > 0 || $hasDocks > 0) {
        // Soft delete - hanya ubah status
        query("UPDATE warehouses SET IsActive = 0 WHERE WarehouseID = ?", [$id]);
    } else {
        // Permanent delete
        query("DELETE FROM warehouses WHERE WarehouseID = ?", [$id]);
    }
    
    ob_clean();
    header("Location: index.php?page=warehouses&msg=deleted&type=success");
    exit;
}

ob_end_clean();
?>
<div id="page-content-wrapper">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-header bg-danger text-white">
                    <i class="fas fa-exclamation-triangle me-1"></i> Confirm Delete
                </div>
                <div class="card-body text-center py-4">
                    <i class="fas fa-warehouse fa-4x text-danger mb-3"></i>
                    <h4>Are you sure you want to delete this warehouse?</h4>
                    <p class="text-muted">
                        <strong><?= htmlspecialchars($warehouse['WarehouseCode']) ?></strong> - 
                        <?= htmlspecialchars($warehouse['WarehouseName']) ?>
                    </p>
                    
                    <?php if($hasMaterialStock > 0 || $hasFGStock > 0 || $hasDocks > 0): ?>
                    <div class="alert alert-warning">
                        <i class="fas fa-info-circle me-1"></i>
                        This warehouse has 
                        <?php if($hasMaterialStock > 0): ?>
                        <strong><?= number_format($hasMaterialStock) ?> material stock(s)</strong>
                        <?php endif; ?>
                        <?php if($hasFGStock > 0): ?>
                        <?php if($hasMaterialStock > 0) echo ', '; ?>
                        <strong><?= number_format($hasFGStock) ?> FG stock(s)</strong>
                        <?php endif; ?>
                        <?php if($hasDocks > 0): ?>
                        <?php if($hasMaterialStock > 0 || $hasFGStock > 0) echo ', '; ?>
                        <strong><?= number_format($hasDocks) ?> loading dock(s)</strong>
                        <?php endif; ?>.
                        Warehouse will be <strong>deactivated</strong> instead of permanently deleted.
                    </div>
                    <?php else: ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-info-circle me-1"></i>
                        This warehouse has <strong>no records</strong>.
                        Warehouse will be <strong>permanently deleted</strong>.
                    </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="" class="d-inline">
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash me-1"></i> Yes, Delete
                        </button>
                        <a href="<?= url('warehouses') ?>" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i> Cancel
                        </a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>