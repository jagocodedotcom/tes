<?php
// ======================================================
// HALAMAN MATERIAL STOCK
// ======================================================

// Pagination
$page = isset($_GET['page_num']) ? (int)$_GET['page_num'] : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

// Search
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Filter by warehouse
$warehouseFilter = isset($_GET['warehouse']) ? (int)$_GET['warehouse'] : 0;

// Filter by stock status
$statusFilter = isset($_GET['status']) ? trim($_GET['status']) : '';

// Build Query
$whereClause = "WHERE 1=1";
$params = [];

if (!empty($search)) {
    $whereClause .= " AND (m.MaterialCode LIKE ? OR m.MaterialName LIKE ? OR m.Category LIKE ?)";
    $searchTerm = "%$search%";
    $params = [$searchTerm, $searchTerm, $searchTerm];
}

if ($warehouseFilter > 0) {
    $whereClause .= " AND s.WarehouseID = ?";
    $params[] = $warehouseFilter;
}

// Get Total Data
$totalQuery = "
    SELECT COUNT(*) 
    FROM material_stock s
    LEFT JOIN materials m ON s.MaterialID = m.MaterialID
    $whereClause
";
$totalData = fetchCount($totalQuery, $params);
$totalPages = ceil($totalData / $limit);

// Get Data
$query = "
    SELECT 
        s.StockID,
        m.MaterialCode,
        m.MaterialName,
        m.Specification,
        m.UOM,
        m.Category,
        m.MinStock,
        m.MaxStock,
        w.WarehouseName,
        s.QtyOnHand,
        s.QtyReserved,
        s.QtyAvailable,
        s.LastUpdated
    FROM material_stock s
    LEFT JOIN materials m ON s.MaterialID = m.MaterialID
    LEFT JOIN warehouses w ON s.WarehouseID = w.WarehouseID
    $whereClause
    ORDER BY m.MaterialName
    LIMIT $limit OFFSET $offset
";
$stocks = fetchAll($query, $params);

// Get warehouses for filter
$warehouses = fetchAll("SELECT WarehouseID, WarehouseName FROM warehouses WHERE IsActive = 1 ORDER BY WarehouseName");

// Get Summary
$summary = fetchOne("
    SELECT 
        COUNT(DISTINCT s.MaterialID) AS TotalMaterials,
        COALESCE(SUM(s.QtyOnHand), 0) AS TotalStock,
        COALESCE(SUM(s.QtyReserved), 0) AS TotalReserved,
        COALESCE(SUM(s.QtyAvailable), 0) AS TotalAvailable,
        COUNT(CASE WHEN s.QtyAvailable <= m.MinStock THEN 1 END) AS CriticalItems,
        COUNT(CASE WHEN s.QtyAvailable > m.MinStock AND s.QtyAvailable <= m.MinStock * 1.5 THEN 1 END) AS WarningItems
    FROM material_stock s
    LEFT JOIN materials m ON s.MaterialID = m.MaterialID
");

// Get Stock by Warehouse
$stockByWarehouse = fetchAll("
    SELECT 
        w.WarehouseName,
        COALESCE(SUM(s.QtyOnHand), 0) AS TotalStock,
        COALESCE(SUM(s.QtyAvailable), 0) AS TotalAvailable,
        COUNT(DISTINCT s.MaterialID) AS TotalItems
    FROM material_stock s
    LEFT JOIN warehouses w ON s.WarehouseID = w.WarehouseID
    GROUP BY s.WarehouseID
    ORDER BY w.WarehouseName
");

// Get Critical Stock Items
$criticalItems = fetchAll("
    SELECT 
        m.MaterialCode,
        m.MaterialName,
        m.MinStock,
        COALESCE(s.QtyAvailable, 0) AS AvailableStock,
        (m.MinStock - COALESCE(s.QtyAvailable, 0)) AS NeedToOrder
    FROM materials m
    LEFT JOIN material_stock s ON m.MaterialID = s.MaterialID
    WHERE m.Active = 1
    HAVING AvailableStock <= MinStock
    ORDER BY NeedToOrder DESC
    LIMIT 10
");

// Get Top Materials by Stock
$topMaterials = fetchAll("
    SELECT 
        m.MaterialCode,
        m.MaterialName,
        COALESCE(SUM(s.QtyOnHand), 0) AS TotalStock
    FROM material_stock s
    LEFT JOIN materials m ON s.MaterialID = m.MaterialID
    GROUP BY s.MaterialID
    ORDER BY TotalStock DESC
    LIMIT 5
");
?>

<div id="page-content-wrapper">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3">
                <i class="fas fa-cubes me-2 text-primary"></i>Material Stock
            </h1>
            <p class="text-muted">View raw materials stock levels</p>
        </div>
        <a href="<?= url('materials', 'create') ?>" class="btn btn-primary">
            <i class="fas fa-plus me-1"></i>Add Material
        </a>
    </div>

    <!-- Summary Cards -->
    <div class="row g-3 mb-4">
        <div class="col-md-3">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-white-50">Total Materials</h6>
                            <h2 class="display-6 fw-bold"><?= number_format($summary['TotalMaterials']) ?></h2>
                        </div>
                        <i class="fas fa-cubes fa-3x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-white-50">Total Stock</h6>
                            <h2 class="display-6 fw-bold"><?= number_format($summary['TotalStock']) ?></h2>
                        </div>
                        <i class="fas fa-warehouse fa-3x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-warning text-dark">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-dark-50">Reserved</h6>
                            <h2 class="display-6 fw-bold"><?= number_format($summary['TotalReserved']) ?></h2>
                        </div>
                        <i class="fas fa-clock fa-3x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-white-50">Available</h6>
                            <h2 class="display-6 fw-bold"><?= number_format($summary['TotalAvailable']) ?></h2>
                        </div>
                        <i class="fas fa-check-circle fa-3x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Critical Stock Alert -->
    <?php if($summary['CriticalItems'] > 0): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="fas fa-exclamation-triangle me-2"></i>
        <strong>Warning!</strong> There are <strong><?= $summary['CriticalItems'] ?></strong> material(s) with critical stock levels!
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <?php if($summary['WarningItems'] > 0): ?>
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
        <i class="fas fa-exclamation-circle me-2"></i>
        <strong>Attention!</strong> There are <strong><?= $summary['WarningItems'] ?></strong> material(s) with stock below min stock!
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <!-- Charts Row -->
    <div class="row g-3 mb-4">
        <!-- Stock by Warehouse -->
        <div class="col-md-6">
            <div class="card h-100">
                <div class="card-header">
                    <i class="fas fa-warehouse me-1"></i> Stock by Warehouse
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Warehouse</th>
                                    <th class="text-end">Items</th>
                                    <th class="text-end">Total Stock</th>
                                    <th class="text-end">Available</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($stockByWarehouse as $sw): ?>
                                <tr>
                                    <td><?= htmlspecialchars($sw['WarehouseName']) ?></td>
                                    <td class="text-end"><?= number_format($sw['TotalItems']) ?></td>
                                    <td class="text-end"><?= number_format($sw['TotalStock']) ?></td>
                                    <td class="text-end text-success"><?= number_format($sw['TotalAvailable']) ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Critical Stock Items -->
        <div class="col-md-6">
            <div class="card h-100">
                <div class="card-header">
                    <i class="fas fa-exclamation-triangle text-danger me-1"></i> Critical Stock Items
                </div>
                <div class="card-body">
                    <?php if(empty($criticalItems)): ?>
                    <div class="text-center text-muted py-3">
                        <i class="fas fa-check-circle fa-2x text-success d-block mb-2"></i>
                        All materials are at safe levels
                    </div>
                    <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Material</th>
                                    <th class="text-end">Available</th>
                                    <th class="text-end">Min Stock</th>
                                    <th class="text-end">Need to Order</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($criticalItems as $ci): ?>
                                <tr>
                                    <td>
                                        <span class="badge bg-danger"><?= htmlspecialchars($ci['MaterialCode']) ?></span>
                                        <?= htmlspecialchars($ci['MaterialName']) ?>
                                    </td>
                                    <td class="text-end text-danger"><?= number_format($ci['AvailableStock']) ?></td>
                                    <td class="text-end"><?= number_format($ci['MinStock']) ?></td>
                                    <td class="text-end"><strong><?= number_format($ci['NeedToOrder']) ?></strong></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Top Materials -->
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-chart-bar me-1"></i> Top Materials by Stock
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>Material</th>
                            <th class="text-end">Total Stock</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($topMaterials as $tm): ?>
                        <tr>
                            <td>
                                <span class="badge bg-secondary"><?= htmlspecialchars($tm['MaterialCode']) ?></span>
                                <?= htmlspecialchars($tm['MaterialName']) ?>
                            </td>
                            <td class="text-end"><?= number_format($tm['TotalStock']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Search & Filter -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <input type="hidden" name="page" value="material_stock">
                <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                        <input type="text" name="search" class="form-control" 
                               placeholder="Search by material code, name, or category..." 
                               value="<?= htmlspecialchars($search) ?>">
                    </div>
                </div>
                <div class="col-md-3">
                    <select name="warehouse" class="form-select">
                        <option value="0">All Warehouses</option>
                        <?php foreach($warehouses as $w): ?>
                        <option value="<?= $w['WarehouseID'] ?>" <?= ($warehouseFilter == $w['WarehouseID']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($w['WarehouseName']) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-filter me-1"></i>Filter
                    </button>
                </div>
                <div class="col-md-2">
                    <a href="<?= url('material_stock') ?>" class="btn btn-secondary w-100">
                        <i class="fas fa-undo me-1"></i>Reset
                    </a>
                </div>
            </form>
        </div>
    </div>

    <!-- Table -->
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <span><i class="fas fa-list me-1"></i> Material Stock List</span>
                <span class="badge bg-primary"><?= number_format($totalData) ?> Records</span>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover table-striped mb-0">
                    <thead>
                        <tr>
                            <th width="50">#</th>
                            <th>Code</th>
                            <th>Material Name</th>
                            <th>Category</th>
                            <th>Warehouse</th>
                            <th>UOM</th>
                            <th class="text-end">On Hand</th>
                            <th class="text-end">Reserved</th>
                            <th class="text-end">Available</th>
                            <th class="text-end">Min Stock</th>
                            <th class="text-end">Status</th>
                            <th>Last Updated</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($stocks)): ?>
                        <tr>
                            <td colspan="12" class="text-center text-muted py-4">
                                <i class="fas fa-inbox fa-2x d-block mb-2"></i>
                                No material stock found
                            </td>
                        </tr>
                        <?php else: ?>
                        <?php 
                        $no = $offset + 1;
                        foreach($stocks as $row): 
                            $status = 'Safe';
                            $statusColor = 'success';
                            if ($row['QtyAvailable'] <= 0) {
                                $status = 'Out of Stock';
                                $statusColor = 'danger';
                            } elseif ($row['QtyAvailable'] <= $row['MinStock']) {
                                $status = 'Critical';
                                $statusColor = 'danger';
                            } elseif ($row['QtyAvailable'] <= $row['MinStock'] * 1.5) {
                                $status = 'Warning';
                                $statusColor = 'warning';
                            }
                        ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td>
                                <span class="badge bg-info"><?= htmlspecialchars($row['MaterialCode']) ?></span>
                            </td>
                            <td>
                                <strong><?= htmlspecialchars($row['MaterialName']) ?></strong>
                                <br>
                                <small class="text-muted"><?= htmlspecialchars($row['Specification']) ?></small>
                            </td>
                            <td>
                                <span class="badge bg-secondary"><?= htmlspecialchars($row['Category']) ?></span>
                            </td>
                            <td><?= htmlspecialchars($row['WarehouseName']) ?></td>
                            <td><?= htmlspecialchars($row['UOM']) ?></td>
                            <td class="text-end"><?= number_format($row['QtyOnHand']) ?></td>
                            <td class="text-end text-warning"><?= number_format($row['QtyReserved']) ?></td>
                            <td class="text-end text-success">
                                <strong><?= number_format($row['QtyAvailable']) ?></strong>
                            </td>
                            <td class="text-end"><?= number_format($row['MinStock']) ?></td>
                            <td>
                                <span class="badge bg-<?= $statusColor ?>"><?= $status ?></span>
                            </td>
                            <td><?= date('d/m/Y H:i', strtotime($row['LastUpdated'])) ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php if($totalPages > 1): ?>
        <div class="card-footer">
            <nav>
                <ul class="pagination pagination-sm mb-0">
                    <?php if($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=material_stock&page_num=<?= $page-1 ?>&search=<?= urlencode($search) ?>&warehouse=<?= $warehouseFilter ?>">
                            <i class="fas fa-chevron-left"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <?php for($i = 1; $i <= $totalPages; $i++): ?>
                    <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                        <a class="page-link" href="?page=material_stock&page_num=<?= $i ?>&search=<?= urlencode($search) ?>&warehouse=<?= $warehouseFilter ?>">
                            <?= $i ?>
                        </a>
                    </li>
                    <?php endfor; ?>
                    
                    <?php if($page < $totalPages): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=material_stock&page_num=<?= $page+1 ?>&search=<?= urlencode($search) ?>&warehouse=<?= $warehouseFilter ?>">
                            <i class="fas fa-chevron-right"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
        <?php endif; ?>
    </div>
</div>