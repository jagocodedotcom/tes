<?php
// ======================================================
// HALAMAN TAMBAH LOADING DOCK
// ======================================================
ob_start();

// Get warehouses for dropdown
$warehouses = fetchAll("SELECT WarehouseID, WarehouseName FROM warehouses WHERE IsActive = 1 ORDER BY WarehouseName");

// Proses submit form
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $dockCode = trim($_POST['dock_code']);
    $dockName = trim($_POST['dock_name']);
    $warehouseID = isset($_POST['warehouse_id']) ? (int)$_POST['warehouse_id'] : null;
    $statusColor = trim($_POST['status_color']);
    $isActive = isset($_POST['is_active']) ? (int)$_POST['is_active'] : 1;
    
    $errors = [];
    
    // Validasi required
    if(empty($dockCode)) $errors[] = "Dock Code is required";
    if(empty($dockName)) $errors[] = "Dock Name is required";
    if(empty($warehouseID)) $errors[] = "Warehouse is required";
    
    // Cek duplicate code
    if(empty($errors)) {
        $check = fetchOne("SELECT DockID FROM loading_docks WHERE DockCode = ?", [$dockCode]);
        if($check) {
            $errors[] = "Dock Code already exists!";
        }
    }
    
    if(empty($errors)) {
        try {
            $sql = "INSERT INTO loading_docks (DockCode, DockName, WarehouseID, StatusColor, IsActive) 
                    VALUES (?, ?, ?, ?, ?)";
            query($sql, [$dockCode, $dockName, $warehouseID, $statusColor, $isActive]);
            
            ob_clean();
            header("Location: index.php?page=loading_docks&msg=created&type=success");
            exit;
        } catch(PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}

ob_end_clean();
?>
<div id="page-content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3"><i class="fas fa-anchor-plus me-2 text-primary"></i>Add Loading Dock</h1>
            <p class="text-muted">Add new loading dock location</p>
        </div>
        <a href="<?= url('loading_docks') ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i>Back
        </a>
    </div>

    <?php if(isset($errors) && !empty($errors)): ?>
    <div class="alert alert-danger">
        <strong><i class="fas fa-exclamation-circle me-1"></i> Please fix the following errors:</strong>
        <ul class="mb-0 mt-1">
            <?php foreach($errors as $error): ?>
            <li><?= htmlspecialchars($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header"><i class="fas fa-edit me-1"></i> Loading Dock Form</div>
        <div class="card-body">
            <form method="POST" action="">
                <div class="row g-3">
                    <!-- Dock Code -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Dock Code <span class="text-danger">*</span></label>
                        <input type="text" name="dock_code" class="form-control" 
                               placeholder="e.g: DOCK-001" 
                               value="<?= isset($_POST['dock_code']) ? htmlspecialchars($_POST['dock_code']) : '' ?>" 
                               required>
                        <small class="text-muted">Unique identifier for the loading dock</small>
                    </div>
                    
                    <!-- Dock Name -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Dock Name <span class="text-danger">*</span></label>
                        <input type="text" name="dock_name" class="form-control" 
                               placeholder="e.g: Dock A - Material In" 
                               value="<?= isset($_POST['dock_name']) ? htmlspecialchars($_POST['dock_name']) : '' ?>" 
                               required>
                    </div>
                    
                    <!-- Warehouse -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Warehouse <span class="text-danger">*</span></label>
                        <select name="warehouse_id" class="form-select" required>
                            <option value="">-- Select Warehouse --</option>
                            <?php foreach($warehouses as $wh): ?>
                            <option value="<?= $wh['WarehouseID'] ?>" 
                                    <?= (isset($_POST['warehouse_id']) && $_POST['warehouse_id'] == $wh['WarehouseID']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($wh['WarehouseName']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <!-- Status Color -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Status Color <span class="text-danger">*</span></label>
                        <select name="status_color" class="form-select" required>
                            <option value="GREEN" <?= (isset($_POST['status_color']) && $_POST['status_color'] == 'GREEN') ? 'selected' : '' ?>>🟢 Green - Available</option>
                            <option value="YELLOW" <?= (isset($_POST['status_color']) && $_POST['status_color'] == 'YELLOW') ? 'selected' : '' ?>>🟡 Yellow - Half Full</option>
                            <option value="RED" <?= (isset($_POST['status_color']) && $_POST['status_color'] == 'RED') ? 'selected' : '' ?>>🔴 Red - Full</option>
                        </select>
                    </div>
                    
                    <!-- Is Active -->
                    <div class="col-12">
                        <label class="form-label fw-bold">Status</label>
                        <div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="is_active" id="active1" value="1" checked>
                                <label class="form-check-label" for="active1">
                                    <span class="badge bg-success">Active</span>
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="is_active" id="active0" value="0">
                                <label class="form-check-label" for="active0">
                                    <span class="badge bg-danger">Inactive</span>
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Buttons -->
                    <div class="col-12">
                        <hr>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Save Loading Dock
                        </button>
                        <a href="<?= url('loading_docks') ?>" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i>Cancel
                        </a>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>