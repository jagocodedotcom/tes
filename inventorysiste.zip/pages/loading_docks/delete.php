<?php
// ======================================================
// PROSES HAPUS LOADING DOCK
// ======================================================
ob_start();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$dock = fetchOne("SELECT * FROM loading_docks WHERE DockID = ?", [$id]);

if(!$dock) {
    ob_clean();
    header("Location: index.php?page=loading_docks&msg=Loading Dock not found&type=danger");
    exit;
}

// Cek apakah dock memiliki relasi dengan fg_receipts
$hasReceipts = fetchCount("SELECT COUNT(*) FROM fg_receipts WHERE DockID = ?", [$id]);

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    if($hasReceipts > 0) {
        // Soft delete - hanya ubah status
        query("UPDATE loading_docks SET IsActive = 0 WHERE DockID = ?", [$id]);
    } else {
        // Permanent delete
        query("DELETE FROM loading_docks WHERE DockID = ?", [$id]);
    }
    
    ob_clean();
    header("Location: index.php?page=loading_docks&msg=deleted&type=success");
    exit;
}

ob_end_clean();
?>
<div id="page-content-wrapper">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-header bg-danger text-white">
                    <i class="fas fa-exclamation-triangle me-1"></i> Confirm Delete
                </div>
                <div class="card-body text-center py-4">
                    <i class="fas fa-anchor fa-4x text-danger mb-3"></i>
                    <h4>Are you sure you want to delete this loading dock?</h4>
                    <p class="text-muted">
                        <strong><?= htmlspecialchars($dock['DockCode']) ?></strong> - 
                        <?= htmlspecialchars($dock['DockName']) ?>
                    </p>
                    
                    <?php if($hasReceipts > 0): ?>
                    <div class="alert alert-warning">
                        <i class="fas fa-info-circle me-1"></i>
                        This loading dock has <strong><?= number_format($hasReceipts) ?> FG receipt(s)</strong>.
                        Loading dock will be <strong>deactivated</strong> instead of permanently deleted.
                    </div>
                    <?php else: ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-info-circle me-1"></i>
                        This loading dock has <strong>no records</strong>.
                        Loading dock will be <strong>permanently deleted</strong>.
                    </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="" class="d-inline">
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash me-1"></i> Yes, Delete
                        </button>
                        <a href="<?= url('loading_docks') ?>" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i> Cancel
                        </a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>