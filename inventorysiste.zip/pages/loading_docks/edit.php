<?php
// ======================================================
// HALAMAN EDIT LOADING DOCK
// ======================================================
ob_start();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$dock = fetchOne("SELECT * FROM loading_docks WHERE DockID = ?", [$id]);

if(!$dock) {
    ob_clean();
    header("Location: index.php?page=loading_docks&msg=Loading Dock not found&type=danger");
    exit;
}

// Get warehouses for dropdown
$warehouses = fetchAll("SELECT WarehouseID, WarehouseName FROM warehouses WHERE IsActive = 1 ORDER BY WarehouseName");

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $dockCode = trim($_POST['dock_code']);
    $dockName = trim($_POST['dock_name']);
    $warehouseID = isset($_POST['warehouse_id']) ? (int)$_POST['warehouse_id'] : null;
    $statusColor = trim($_POST['status_color']);
    $isActive = isset($_POST['is_active']) ? (int)$_POST['is_active'] : 1;
    
    $errors = [];
    
    if(empty($dockCode)) $errors[] = "Dock Code is required";
    if(empty($dockName)) $errors[] = "Dock Name is required";
    if(empty($warehouseID)) $errors[] = "Warehouse is required";
    
    if(empty($errors)) {
        $check = fetchOne("SELECT DockID FROM loading_docks WHERE DockCode = ? AND DockID != ?", [$dockCode, $id]);
        if($check) {
            $errors[] = "Dock Code already exists!";
        }
    }
    
    if(empty($errors)) {
        try {
            $sql = "UPDATE loading_docks SET 
                    DockCode = ?, 
                    DockName = ?, 
                    WarehouseID = ?, 
                    StatusColor = ?,
                    IsActive = ?
                    WHERE DockID = ?";
            query($sql, [$dockCode, $dockName, $warehouseID, $statusColor, $isActive, $id]);
            
            ob_clean();
            header("Location: index.php?page=loading_docks&msg=updated&type=success");
            exit;
        } catch(PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}

ob_end_clean();
?>
<div id="page-content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3"><i class="fas fa-edit me-2 text-primary"></i>Edit Loading Dock</h1>
            <p class="text-muted">Edit loading dock: <?= htmlspecialchars($dock['DockCode']) ?></p>
        </div>
        <a href="<?= url('loading_docks') ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i>Back
        </a>
    </div>

    <?php if(isset($errors) && !empty($errors)): ?>
    <div class="alert alert-danger">
        <strong><i class="fas fa-exclamation-circle me-1"></i> Please fix the following errors:</strong>
        <ul class="mb-0 mt-1">
            <?php foreach($errors as $error): ?>
            <li><?= htmlspecialchars($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header"><i class="fas fa-edit me-1"></i> Edit Loading Dock Form</div>
        <div class="card-body">
            <form method="POST" action="">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Dock Code <span class="text-danger">*</span></label>
                        <input type="text" name="dock_code" class="form-control" 
                               value="<?= htmlspecialchars($dock['DockCode']) ?>" required>
                        <small class="text-muted">Unique identifier for the loading dock</small>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Dock Name <span class="text-danger">*</span></label>
                        <input type="text" name="dock_name" class="form-control" 
                               value="<?= htmlspecialchars($dock['DockName']) ?>" required>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Warehouse <span class="text-danger">*</span></label>
                        <select name="warehouse_id" class="form-select" required>
                            <option value="">-- Select Warehouse --</option>
                            <?php foreach($warehouses as $wh): ?>
                            <option value="<?= $wh['WarehouseID'] ?>" 
                                    <?= $dock['WarehouseID'] == $wh['WarehouseID'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($wh['WarehouseName']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Status Color <span class="text-danger">*</span></label>
                        <select name="status_color" class="form-select" required>
                            <option value="GREEN" <?= $dock['StatusColor'] == 'GREEN' ? 'selected' : '' ?>>🟢 Green - Available</option>
                            <option value="YELLOW" <?= $dock['StatusColor'] == 'YELLOW' ? 'selected' : '' ?>>🟡 Yellow - Half Full</option>
                            <option value="RED" <?= $dock['StatusColor'] == 'RED' ? 'selected' : '' ?>>🔴 Red - Full</option>
                        </select>
                    </div>
                    
                    <div class="col-12">
                        <label class="form-label fw-bold">Status</label>
                        <div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="is_active" id="active1" value="1" 
                                       <?= $dock['IsActive'] == 1 ? 'checked' : '' ?>>
                                <label class="form-check-label" for="active1">
                                    <span class="badge bg-success">Active</span>
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="is_active" id="active0" value="0"
                                       <?= $dock['IsActive'] == 0 ? 'checked' : '' ?>>
                                <label class="form-check-label" for="active0">
                                    <span class="badge bg-danger">Inactive</span>
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-12">
                        <div class="alert alert-info">
                            <small>
                                <i class="fas fa-info-circle me-1"></i>
                                Created: <?= date('d/m/Y H:i', strtotime($dock['CreatedAt'])) ?>
                            </small>
                        </div>
                    </div>
                    
                    <div class="col-12">
                        <hr>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Update Loading Dock
                        </button>
                        <a href="<?= url('loading_docks') ?>" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i>Cancel
                        </a>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>