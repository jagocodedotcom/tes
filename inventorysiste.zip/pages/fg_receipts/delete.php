<?php
// ======================================================
// PROSES HAPUS FG RECEIPT
// ======================================================
ob_start();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$fg = fetchOne("SELECT * FROM fg_receipts WHERE FGReceiptID = ?", [$id]);

if(!$fg) {
    ob_clean();
    header("Location: index.php?page=fg_receipts&msg=FG Receipt not found&type=danger");
    exit;
}

// Cek apakah sudah ada delivery
$hasDelivery = ($fg['Status'] == 'Delivered');

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    if($hasDelivery) {
        $error = "Cannot delete FG Receipt that has been Delivered.";
        ob_clean();
        header("Location: index.php?page=fg_receipts&msg=" . urlencode($error) . "&type=danger");
        exit;
    } else {
        // Kurangi stock FG
        $warehouse = fetchOne("SELECT WarehouseID FROM warehouses LIMIT 1");
        $warehouseID = $warehouse ? $warehouse['WarehouseID'] : 1;
        
        $details = fetchAll("SELECT ProductID, Qty FROM fg_receipt_details WHERE FGReceiptID = ?", [$id]);
        foreach($details as $d) {
            $stock = fetchOne("SELECT StockFGID, QtyOnHand FROM stock_fg WHERE ProductID = ? AND WarehouseID = ?", 
                              [$d['ProductID'], $warehouseID]);
            if($stock) {
                $newQty = $stock['QtyOnHand'] - $d['Qty'];
                if($newQty < 0) $newQty = 0;
                query("UPDATE stock_fg SET QtyOnHand = ? WHERE ProductID = ? AND WarehouseID = ?", 
                      [$newQty, $d['ProductID'], $warehouseID]);
            }
        }
        
        // Delete details dan header
        query("DELETE FROM fg_receipt_details WHERE FGReceiptID = ?", [$id]);
        query("DELETE FROM fg_receipts WHERE FGReceiptID = ?", [$id]);
    }
    
    ob_clean();
    header("Location: index.php?page=fg_receipts&msg=deleted&type=success");
    exit;
}

ob_end_clean();
?>
<div id="page-content-wrapper">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-header bg-danger text-white">
                    <i class="fas fa-exclamation-triangle me-1"></i> Confirm Delete
                </div>
                <div class="card-body text-center py-4">
                    <i class="fas fa-clipboard-check fa-4x text-danger mb-3"></i>
                    <h4>Are you sure you want to delete this FG receipt?</h4>
                    <p class="text-muted">
                        <strong><?= htmlspecialchars($fg['FGNumber']) ?></strong>
                        <br>
                        Date: <?= date('d/m/Y', strtotime($fg['ReceiptDate'])) ?>
                        <br>
                        Accepted: <?= number_format($fg['QtyAccepted']) ?>
                        <br>
                        Status: <?= $fg['Status'] ?>
                    </p>
                    
                    <?php if($hasDelivery): ?>
                    <div class="alert alert-warning">
                        <i class="fas fa-info-circle me-1"></i>
                        This FG Receipt has been <strong>Delivered</strong>.
                        <br>
                        <strong>Cannot be deleted!</strong>
                    </div>
                    <?php else: ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-info-circle me-1"></i>
                        This FG Receipt has <strong>not been delivered</strong>.
                        It will be <strong>permanently deleted</strong>.
                        <br>
                        <span class="text-warning">Stock FG will be reduced by <?= number_format($fg['QtyAccepted']) ?> items.</span>
                    </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="" class="d-inline">
                        <?php if($hasDelivery): ?>
                        <a href="<?= url('fg_receipts') ?>" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-1"></i> Back
                        </a>
                        <?php else: ?>
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash me-1"></i> Yes, Delete
                        </button>
                        <a href="<?= url('fg_receipts') ?>" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i> Cancel
                        </a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>