<?php
// ======================================================
// HALAMAN DETAIL FG RECEIPT
// ======================================================

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Get Receipt
$receipt = fetchOne("
    SELECT 
        fg.*,
        cpo.PONumber AS CustomerPONumber,
        c.CustomerName,
        c.Address,
        ld.DockName,
        qc.QCID,
        qc.InspectionDate,
        qc.QtyPASS AS QCPASS,
        qc.FinalStatus AS QCFinalStatus,
        pr.ProductionDate,
        pr.Shift,
        wo.WONumber,
        p.ProductName,
        p.ProductCode,
        p.UOM
    FROM fg_receipts fg
    LEFT JOIN customer_pos cpo ON fg.CustomerPOID = cpo.CustomerPOID
    LEFT JOIN customers c ON cpo.CustomerID = c.CustomerID
    LEFT JOIN loading_docks ld ON fg.DockID = ld.DockID
    LEFT JOIN qc_inspections qc ON fg.QCID = qc.QCID
    LEFT JOIN production_results pr ON qc.ProductionResultID = pr.ProductionResultID
    LEFT JOIN production_orders wo ON pr.ProductionOrderID = wo.ProductionOrderID
    LEFT JOIN products p ON wo.ProductID = p.ProductID
    WHERE fg.FGReceiptID = ?
", [$id]);

if(!$receipt) {
    header("Location: index.php?page=fg_receipts&msg=Receipt not found&type=danger");
    exit;
}

// Get Details
$details = fetchAll("
    SELECT 
        fgd.*,
        p.ProductCode,
        p.ProductName,
        p.UOM
    FROM fg_receipt_details fgd
    LEFT JOIN products p ON fgd.ProductID = p.ProductID
    WHERE fgd.FGReceiptID = ?
    ORDER BY fgd.FGDetailID
", [$id]);
?>

<div id="page-content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3">
                <i class="fas fa-clipboard-check me-2 text-primary"></i>FG Receipt Detail
            </h1>
            <p class="text-muted">View finished goods receipt details</p>
        </div>
        <div>
            <a href="<?= url('fg_receipts', 'edit', ['id' => $id]) ?>" class="btn btn-primary">
                <i class="fas fa-edit me-1"></i>Edit
            </a>
            <a href="<?= url('fg_receipts') ?>" class="btn btn-secondary">
                <i class="fas fa-arrow-left me-1"></i>Back
            </a>
        </div>
    </div>

    <!-- Receipt Information -->
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-info-circle me-1"></i> Receipt Information
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <table class="table table-bordered mb-0">
                        <tr>
                            <th width="35%">FG Number</th>
                            <td><span class="badge bg-info"><?= htmlspecialchars($receipt['FGNumber']) ?></span></td>
                        </tr>
                        <tr>
                            <th>Receipt Date</th>
                            <td><?= date('d/m/Y', strtotime($receipt['ReceiptDate'])) ?></td>
                        </tr>
                        <tr>
                            <th>Status</th>
                            <td><?= getStatusBadge($receipt['Status']) ?></td>
                        </tr>
                        <tr>
                            <th>Loading Dock</th>
                            <td><?= htmlspecialchars($receipt['DockName']) ?: '-' ?></td>
                        </tr>
                        <tr>
                            <th>Admin FG</th>
                            <td><?= htmlspecialchars($receipt['AdminFG']) ?></td>
                        </tr>
                    </table>
                </div>
                <div class="col-md-6">
                    <table class="table table-bordered mb-0">
                        <tr>
                            <th width="35%">Customer</th>
                            <td><strong><?= htmlspecialchars($receipt['CustomerName']) ?></strong></td>
                        </tr>
                        <tr>
                            <th>Sales Order</th>
                            <td><?= htmlspecialchars($receipt['CustomerPONumber']) ?></td>
                        </tr>
                        <tr>
                            <th>Qty Accepted</th>
                            <td class="text-success"><strong><?= number_format($receipt['QtyAccepted']) ?></strong></td>
                        </tr>
                        <tr>
                            <th>Qty Rejected</th>
                            <td class="text-danger"><strong><?= number_format($receipt['QtyRejected']) ?></strong></td>
                        </tr>
                        <tr>
                            <th>Total</th>
                            <td><strong><?= number_format($receipt['QtyAccepted'] + $receipt['QtyRejected']) ?></strong></td>
                        </tr>
                    </table>
                </div>
            </div>
            <?php if($receipt['Notes']): ?>
            <div class="row mt-3">
                <div class="col-12">
                    <div class="alert alert-info">
                        <strong>Notes:</strong> <?= htmlspecialchars($receipt['Notes']) ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- QC & Production Info -->
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-check-double me-1"></i> QC & Production Information
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <table class="table table-bordered mb-0">
                        <tr>
                            <th width="35%">Work Order</th>
                            <td><span class="badge bg-info"><?= htmlspecialchars($receipt['WONumber']) ?></span></td>
                        </tr>
                        <tr>
                            <th>Product</th>
                            <td><strong><?= htmlspecialchars($receipt['ProductName']) ?></strong></td>
                        </tr>
                        <tr>
                            <th>Product Code</th>
                            <td><?= htmlspecialchars($receipt['ProductCode']) ?></td>
                        </tr>
                    </table>
                </div>
                <div class="col-md-6">
                    <table class="table table-bordered mb-0">
                        <tr>
                            <th width="35%">QC Inspection Date</th>
                            <td><?= date('d/m/Y', strtotime($receipt['InspectionDate'])) ?></td>
                        </tr>
                        <tr>
                            <th>QC PASS</th>
                            <td class="text-success"><?= number_format($receipt['QCPASS']) ?></td>
                        </tr>
                        <tr>
                            <th>QC Status</th>
                            <td><?= getStatusBadge($receipt['QCFinalStatus']) ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Items -->
    <div class="card">
        <div class="card-header">
            <i class="fas fa-list me-1"></i> Items
            <span class="badge bg-secondary float-end"><?= count($details) ?> items</span>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-striped mb-0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Product Code</th>
                            <th>Product Name</th>
                            <th>UOM</th>
                            <th class="text-end">Qty</th>
                            <th>Batch No</th>
                            <th>Pallet No</th>
                            <th>Bin Location</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($details)): ?>
                        <tr>
                            <td colspan="8" class="text-center text-muted py-3">No items found</td>
                        </tr>
                        <?php else: ?>
                        <?php $no = 1; foreach($details as $row): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= htmlspecialchars($row['ProductCode']) ?></td>
                            <td><?= htmlspecialchars($row['ProductName']) ?></td>
                            <td><?= htmlspecialchars($row['UOM']) ?></td>
                            <td class="text-end"><?= number_format($row['Qty']) ?></td>
                            <td><?= htmlspecialchars($row['BatchNo']) ?></td>
                            <td><?= htmlspecialchars($row['PalletNo']) ?></td>
                            <td><?= htmlspecialchars($row['BinLocation']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>