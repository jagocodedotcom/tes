<?php
// ======================================================
// HALAMAN EDIT FG RECEIPT
// ======================================================
ob_start();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Get FG Receipt
$fg = fetchOne("SELECT * FROM fg_receipts WHERE FGReceiptID = ?", [$id]);

if(!$fg) {
    ob_clean();
    header("Location: index.php?page=fg_receipts&msg=FG Receipt not found&type=danger");
    exit;
}

// Get Sales Orders for dropdown
$salesOrders = fetchAll("
    SELECT 
        cpo.CustomerPOID,
        cpo.PONumber,
        c.CustomerName
    FROM customer_pos cpo
    LEFT JOIN customers c ON cpo.CustomerID = c.CustomerID
    WHERE cpo.Status IN ('Production', 'Partial', 'Completed', 'Open')
    ORDER BY cpo.PONumber
");

// Get QC Inspections that are Accepted
$qcInspections = fetchAll("
    SELECT 
        qc.QCID,
        qc.ProductionResultID,
        qc.QtyPASS,
        qc.InspectionDate,
        wo.WONumber,
        p.ProductName
    FROM qc_inspections qc
    LEFT JOIN production_results pr ON qc.ProductionResultID = pr.ProductionResultID
    LEFT JOIN production_orders wo ON pr.ProductionOrderID = wo.ProductionOrderID
    LEFT JOIN products p ON wo.ProductID = p.ProductID
    WHERE qc.FinalStatus = 'Accepted'
    AND (qc.QCID NOT IN (SELECT QCID FROM fg_receipts WHERE QCID IS NOT NULL) OR qc.QCID = ?)
    ORDER BY qc.InspectionDate DESC
", [$fg['QCID']]);

// Get Loading Docks for dropdown
$docks = fetchAll("SELECT DockID, DockName FROM loading_docks WHERE IsActive = 1 ORDER BY DockName");

// Get existing FG Receipt Details
$existingDetails = fetchAll("
    SELECT 
        fgd.*,
        p.ProductCode,
        p.ProductName,
        p.UOM
    FROM fg_receipt_details fgd
    LEFT JOIN products p ON fgd.ProductID = p.ProductID
    WHERE fgd.FGReceiptID = ?
    ORDER BY fgd.FGDetailID
", [$id]);

// Proses submit form
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $customerPOID = isset($_POST['customer_po_id']) ? (int)$_POST['customer_po_id'] : 0;
    $qcid = isset($_POST['qcid']) ? (int)$_POST['qcid'] : 0;
    $dockID = isset($_POST['dock_id']) ? (int)$_POST['dock_id'] : null;
    $receiptDate = $_POST['receipt_date'];
    $qtyAccepted = isset($_POST['qty_accepted']) ? str_replace(',', '', $_POST['qty_accepted']) : 0;
    $qtyRejected = isset($_POST['qty_rejected']) ? str_replace(',', '', $_POST['qty_rejected']) : 0;
    $status = $_POST['status'];
    $adminFG = trim($_POST['admin_fg']);
    $notes = trim($_POST['notes']);
    
    $errors = [];
    
    // Validasi
    if(empty($customerPOID)) $errors[] = "Sales Order is required";
    if(empty($qcid)) $errors[] = "QC Inspection is required";
    if(empty($receiptDate)) $errors[] = "Receipt Date is required";
    if(empty($qtyAccepted) || $qtyAccepted <= 0) $errors[] = "Accepted quantity must be greater than 0";
    if($qtyRejected < 0) $errors[] = "Rejected quantity cannot be negative";
    if(empty($adminFG)) $errors[] = "Admin FG is required";
    
    // Validate qtyAccepted against QC PASS
    if(!empty($qcid)) {
        $qc = fetchOne("SELECT QtyPASS, ProductionResultID FROM qc_inspections WHERE QCID = ?", [$qcid]);
        if($qc) {
            if($qtyAccepted > $qc['QtyPASS']) {
                $errors[] = "Accepted quantity cannot exceed QC PASS quantity (" . number_format($qc['QtyPASS']) . ")";
            }
            $productionResultID = $qc['ProductionResultID'];
        } else {
            $errors[] = "QC Inspection not found";
            $productionResultID = null;
        }
    } else {
        $productionResultID = null;
    }
    
    if(empty($errors)) {
        try {
            // Get old data for stock adjustment
            $oldFG = fetchOne("SELECT QtyAccepted, QCID FROM fg_receipts WHERE FGReceiptID = ?", [$id]);
            
            // Update FG Receipt
            $sql = "UPDATE fg_receipts SET 
                    CustomerPOID = ?, 
                    ProductionResultID = ?, 
                    QCID = ?, 
                    DockID = ?, 
                    ReceiptDate = ?, 
                    QtyAccepted = ?, 
                    QtyRejected = ?, 
                    Status = ?, 
                    AdminFG = ?, 
                    Notes = ?
                    WHERE FGReceiptID = ?";
            query($sql, [$customerPOID, $productionResultID, $qcid, $dockID, $receiptDate, $qtyAccepted, $qtyRejected, $status, $adminFG, $notes, $id]);
            
            // Update FG Receipt Details
            // Delete existing details
            query("DELETE FROM fg_receipt_details WHERE FGReceiptID = ?", [$id]);
            
            // Get QC Inspection details for product
            $qcDetail = fetchOne("
                SELECT 
                    qc.ProductionResultID,
                    pr.ProductionOrderID,
                    wo.ProductID
                FROM qc_inspections qc
                LEFT JOIN production_results pr ON qc.ProductionResultID = pr.ProductionResultID
                LEFT JOIN production_orders wo ON pr.ProductionOrderID = wo.ProductionOrderID
                WHERE qc.QCID = ?
            ", [$qcid]);
            
            if($qcDetail && $qcDetail['ProductID']) {
                // Insert new FG Receipt Details
                $sqlDetail = "INSERT INTO fg_receipt_details (FGReceiptID, ProductID, CustomerPODetailID, BatchNo, PalletNo, Qty, BinLocation) 
                              VALUES (?, ?, ?, ?, ?, ?, ?)";
                
                // Get customer PO detail
                $poDetail = fetchOne("
                    SELECT CustomerPODetailID 
                    FROM customer_po_details 
                    WHERE CustomerPOID = ? AND ProductID = ?
                    LIMIT 1
                ", [$customerPOID, $qcDetail['ProductID']]);
                
                $podetailID = $poDetail ? $poDetail['CustomerPODetailID'] : null;
                $batchNo = 'BATCH-' . date('Ymd') . '-' . $id;
                $palletNo = 'PALLET-' . $id;
                $binLocation = 'FG-RACK-' . $id;
                
                query($sqlDetail, [$id, $qcDetail['ProductID'], $podetailID, $batchNo, $palletNo, $qtyAccepted, $binLocation]);
            }
            
            // Update stock FG
            $warehouse = fetchOne("SELECT WarehouseID FROM warehouses LIMIT 1");
            $warehouseID = $warehouse ? $warehouse['WarehouseID'] : 1;
            
            if($qcDetail && $qcDetail['ProductID']) {
                // Jika qty berubah, adjust stock
                $stock = fetchOne("SELECT StockFGID, QtyOnHand FROM stock_fg WHERE ProductID = ? AND WarehouseID = ?", 
                                  [$qcDetail['ProductID'], $warehouseID]);
                
                if($stock) {
                    // Kurangi stock lama
                    $newQty = $stock['QtyOnHand'] - $oldFG['QtyAccepted'] + $qtyAccepted;
                    query("UPDATE stock_fg SET QtyOnHand = ? WHERE ProductID = ? AND WarehouseID = ?", 
                          [$newQty, $qcDetail['ProductID'], $warehouseID]);
                } else {
                    // Insert baru
                    query("INSERT INTO stock_fg (ProductID, WarehouseID, QtyOnHand, BatchNo, PalletNo, BinLocation) 
                          VALUES (?, ?, ?, ?, ?, ?)", 
                          [$qcDetail['ProductID'], $warehouseID, $qtyAccepted, $batchNo, $palletNo, $binLocation]);
                }
                
                // Insert inventory transaction for adjustment
                $stockBefore = fetchOne("SELECT QtyOnHand FROM stock_fg WHERE ProductID = ? AND WarehouseID = ?", 
                                       [$qcDetail['ProductID'], $warehouseID]);
                $before = $stockBefore ? $stockBefore['QtyOnHand'] - $qtyAccepted : 0;
                
                query("INSERT INTO inventory_transactions (TransactionDate, TransactionType, ReferenceID, ReferenceType, ProductID, WarehouseID, QtyIn, StockBefore, StockAfter, CreatedBy) 
                      VALUES (NOW(), 'FG_Produce', ?, 'fg_receipts', ?, ?, ?, ?, ?, ?)",
                      [$id, $qcDetail['ProductID'], $warehouseID, $qtyAccepted, $before, $before + $qtyAccepted, $adminFG]);
            }
            
            ob_clean();
            header("Location: index.php?page=fg_receipts&msg=updated&type=success");
            exit;
        } catch(PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}

ob_end_clean();
?>
<div id="page-content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3"><i class="fas fa-edit me-2 text-primary"></i>Edit FG Receipt</h1>
            <p class="text-muted">Edit FG receipt: <?= htmlspecialchars($fg['FGNumber']) ?></p>
        </div>
        <a href="<?= url('fg_receipts') ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i>Back
        </a>
    </div>

    <?php if(isset($errors) && !empty($errors)): ?>
    <div class="alert alert-danger">
        <strong><i class="fas fa-exclamation-circle me-1"></i> Please fix the following errors:</strong>
        <ul class="mb-0 mt-1">
            <?php foreach($errors as $error): ?>
            <li><?= htmlspecialchars($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header"><i class="fas fa-edit me-1"></i> Edit FG Receipt Form</div>
        <div class="card-body">
            <form method="POST" action="">
                <div class="row g-3">
                    <!-- Sales Order -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Sales Order <span class="text-danger">*</span></label>
                        <select name="customer_po_id" class="form-select" required>
                            <option value="">-- Select SO --</option>
                            <?php foreach($salesOrders as $so): ?>
                            <option value="<?= $so['CustomerPOID'] ?>" 
                                    <?= $fg['CustomerPOID'] == $so['CustomerPOID'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($so['PONumber']) ?> - <?= htmlspecialchars($so['CustomerName']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <!-- QC Inspection -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">QC Inspection <span class="text-danger">*</span></label>
                        <select name="qcid" class="form-select" required>
                            <option value="">-- Select QC --</option>
                            <?php foreach($qcInspections as $qc): ?>
                            <option value="<?= $qc['QCID'] ?>" 
                                    <?= $fg['QCID'] == $qc['QCID'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($qc['WONumber']) ?> - <?= htmlspecialchars($qc['ProductName']) ?> 
                                (PASS: <?= number_format($qc['QtyPASS']) ?>)
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <!-- Receipt Date -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Receipt Date <span class="text-danger">*</span></label>
                        <input type="date" name="receipt_date" class="form-control" 
                               value="<?= $fg['ReceiptDate'] ?>" 
                               required>
                    </div>
                    
                    <!-- Dock -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Loading Dock</label>
                        <select name="dock_id" class="form-select">
                            <option value="">-- Select Dock --</option>
                            <?php foreach($docks as $d): ?>
                            <option value="<?= $d['DockID'] ?>" 
                                    <?= $fg['DockID'] == $d['DockID'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($d['DockName']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <!-- Status -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Status <span class="text-danger">*</span></label>
                        <select name="status" class="form-select" required>
                            <option value="Stored" <?= $fg['Status'] == 'Stored' ? 'selected' : '' ?>>Stored</option>
                            <option value="Reserved" <?= $fg['Status'] == 'Reserved' ? 'selected' : '' ?>>Reserved</option>
                            <option value="Delivered" <?= $fg['Status'] == 'Delivered' ? 'selected' : '' ?>>Delivered</option>
                            <option value="Partial" <?= $fg['Status'] == 'Partial' ? 'selected' : '' ?>>Partial</option>
                        </select>
                    </div>
                    
                    <!-- Qty Accepted -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Qty Accepted <span class="text-danger">*</span></label>
                        <input type="number" name="qty_accepted" class="form-control" 
                               placeholder="0" 
                               value="<?= $fg['QtyAccepted'] ?>" 
                               min="1" required>
                    </div>
                    
                    <!-- Qty Rejected -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Qty Rejected</label>
                        <input type="number" name="qty_rejected" class="form-control" 
                               placeholder="0" 
                               value="<?= $fg['QtyRejected'] ?>" 
                               min="0">
                    </div>
                    
                    <!-- Admin FG -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Admin FG <span class="text-danger">*</span></label>
                        <input type="text" name="admin_fg" class="form-control" 
                               placeholder="e.g: Agus Warehouse" 
                               value="<?= htmlspecialchars($fg['AdminFG']) ?>" 
                               required>
                    </div>
                    
                    <!-- Created Info -->
                    <div class="col-12">
                        <div class="alert alert-info">
                            <small>
                                <i class="fas fa-info-circle me-1"></i>
                                FG Number: <strong><?= htmlspecialchars($fg['FGNumber']) ?></strong><br>
                                Created: <?= date('d/m/Y H:i', strtotime($fg['CreatedAt'])) ?>
                                <?php if($fg['UpdatedAt'] != $fg['CreatedAt']): ?>
                                <br>Updated: <?= date('d/m/Y H:i', strtotime($fg['UpdatedAt'])) ?>
                                <?php endif; ?>
                            </small>
                        </div>
                    </div>
                    
                    <!-- Notes -->
                    <div class="col-12">
                        <label class="form-label fw-bold">Notes</label>
                        <textarea name="notes" class="form-control" rows="2" 
                                  placeholder="Additional notes"><?= htmlspecialchars($fg['Notes']) ?></textarea>
                    </div>
                    
                    <!-- Buttons -->
                    <div class="col-12">
                        <hr>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Update FG Receipt
                        </button>
                    
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>