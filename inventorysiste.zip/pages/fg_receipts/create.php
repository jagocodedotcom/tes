<?php
// ======================================================
// HALAMAN TAMBAH FG RECEIPT
// ======================================================
ob_start();

// Get Sales Orders for dropdown
$salesOrders = fetchAll("
    SELECT 
        cpo.CustomerPOID,
        cpo.PONumber,
        c.CustomerName
    FROM customer_pos cpo
    LEFT JOIN customers c ON cpo.CustomerID = c.CustomerID
    WHERE cpo.Status IN ('Production', 'Partial', 'Completed')
    ORDER BY cpo.PONumber
");

// Get QC Inspections that are Accepted
$qcInspections = fetchAll("
    SELECT 
        qc.QCID,
        qc.ProductionResultID,
        qc.QtyPASS,
        qc.InspectionDate,
        wo.WONumber,
        p.ProductName,
        pr.ProductionOrderID
    FROM qc_inspections qc
    LEFT JOIN production_results pr ON qc.ProductionResultID = pr.ProductionResultID
    LEFT JOIN production_orders wo ON pr.ProductionOrderID = wo.ProductionOrderID
    LEFT JOIN products p ON wo.ProductID = p.ProductID
    WHERE qc.FinalStatus = 'Accepted'
    AND qc.QCID NOT IN (SELECT QCID FROM fg_receipts WHERE QCID IS NOT NULL AND QCID != 0)
    ORDER BY qc.InspectionDate DESC
");

// Get Loading Docks for dropdown
$docks = fetchAll("SELECT DockID, DockName FROM loading_docks WHERE IsActive = 1 ORDER BY DockName");

// Proses submit form
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $customerPOID = isset($_POST['customer_po_id']) ? (int)$_POST['customer_po_id'] : 0;
    $qcid = isset($_POST['qcid']) ? (int)$_POST['qcid'] : 0;
    $dockID = isset($_POST['dock_id']) ? (int)$_POST['dock_id'] : null;
    $receiptDate = $_POST['receipt_date'];
    $qtyAccepted = isset($_POST['qty_accepted']) ? str_replace(',', '', $_POST['qty_accepted']) : 0;
    $qtyRejected = isset($_POST['qty_rejected']) ? str_replace(',', '', $_POST['qty_rejected']) : 0;
    $status = $_POST['status'];
    $adminFG = trim($_POST['admin_fg']);
    $notes = trim($_POST['notes']);
    
    $errors = [];
    
    // Validasi
    if(empty($customerPOID)) $errors[] = "Sales Order is required";
    if(empty($qcid)) $errors[] = "QC Inspection is required";
    if(empty($receiptDate)) $errors[] = "Receipt Date is required";
    if(empty($qtyAccepted) || $qtyAccepted <= 0) $errors[] = "Accepted quantity must be greater than 0";
    if($qtyRejected < 0) $errors[] = "Rejected quantity cannot be negative";
    if(empty($adminFG)) $errors[] = "Admin FG is required";
    
    // Validate qtyAccepted against QC PASS
    if(!empty($qcid)) {
        $qc = fetchOne("SELECT QtyPASS, ProductionResultID FROM qc_inspections WHERE QCID = ?", [$qcid]);
        if($qc) {
            if($qtyAccepted > $qc['QtyPASS']) {
                $errors[] = "Accepted quantity cannot exceed QC PASS quantity (" . number_format($qc['QtyPASS']) . ")";
            }
            // Simpan ProductionResultID dari QC
            $productionResultID = $qc['ProductionResultID'];
        } else {
            $errors[] = "QC Inspection not found";
            $productionResultID = null;
        }
    } else {
        $productionResultID = null;
    }
    
    if(empty($errors)) {
        try {
            // Generate FG Number
            $year = date('Y');
            $month = date('m');
            $lastFG = fetchOne("SELECT FGNumber FROM fg_receipts ORDER BY FGReceiptID DESC LIMIT 1");
            $lastNumber = 0;
            if($lastFG) {
                $lastNumber = (int)substr($lastFG['FGNumber'], -4);
            }
            $newNumber = str_pad($lastNumber + 1, 4, '0', STR_PAD_LEFT);
            $fgNumber = 'FG-' . $year . $month . '-' . $newNumber;
            
            // ============================================================
            // PERBAIKAN: Gunakan ProductionResultID dari QC
            // ============================================================
            $sql = "INSERT INTO fg_receipts (FGNumber, CustomerPOID, ProductionResultID, QCID, DockID, ReceiptDate, QtyAccepted, QtyRejected, Status, AdminFG, Notes) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            query($sql, [$fgNumber, $customerPOID, $productionResultID, $qcid, $dockID, $receiptDate, $qtyAccepted, $qtyRejected, $status, $adminFG, $notes]);
            $fgReceiptID = $pdo->lastInsertId();
            
            // Get QC Inspection details for product
            $qcDetail = fetchOne("
                SELECT 
                    qc.ProductionResultID,
                    pr.ProductionOrderID,
                    wo.ProductID
                FROM qc_inspections qc
                LEFT JOIN production_results pr ON qc.ProductionResultID = pr.ProductionResultID
                LEFT JOIN production_orders wo ON pr.ProductionOrderID = wo.ProductionOrderID
                WHERE qc.QCID = ?
            ", [$qcid]);
            
            if($qcDetail && $qcDetail['ProductID']) {
                // Insert FG Receipt Details
                $sqlDetail = "INSERT INTO fg_receipt_details (FGReceiptID, ProductID, CustomerPODetailID, BatchNo, PalletNo, Qty, BinLocation) 
                              VALUES (?, ?, ?, ?, ?, ?, ?)";
                
                // Get customer PO detail
                $poDetail = fetchOne("
                    SELECT CustomerPODetailID 
                    FROM customer_po_details 
                    WHERE CustomerPOID = ? AND ProductID = ?
                    LIMIT 1
                ", [$customerPOID, $qcDetail['ProductID']]);
                
                $podetailID = $poDetail ? $poDetail['CustomerPODetailID'] : null;
                $batchNo = 'BATCH-' . date('Ymd') . '-' . $fgReceiptID;
                $palletNo = 'PALLET-' . $fgReceiptID;
                $binLocation = 'FG-RACK-' . $fgReceiptID;
                
                query($sqlDetail, [$fgReceiptID, $qcDetail['ProductID'], $podetailID, $batchNo, $palletNo, $qtyAccepted, $binLocation]);
                
                // Update stock FG
                $warehouse = fetchOne("SELECT WarehouseID FROM warehouses LIMIT 1");
                $warehouseID = $warehouse ? $warehouse['WarehouseID'] : 1;
                
                $stock = fetchOne("SELECT StockFGID FROM stock_fg WHERE ProductID = ? AND WarehouseID = ?", 
                                  [$qcDetail['ProductID'], $warehouseID]);
                if($stock) {
                    query("UPDATE stock_fg SET QtyOnHand = QtyOnHand + ? WHERE ProductID = ? AND WarehouseID = ?", 
                          [$qtyAccepted, $qcDetail['ProductID'], $warehouseID]);
                } else {
                    query("INSERT INTO stock_fg (ProductID, WarehouseID, QtyOnHand, BatchNo, PalletNo, BinLocation) 
                          VALUES (?, ?, ?, ?, ?, ?)", 
                          [$qcDetail['ProductID'], $warehouseID, $qtyAccepted, $batchNo, $palletNo, $binLocation]);
                }
                
                // Insert inventory transaction
                $stockBefore = fetchOne("SELECT QtyOnHand FROM stock_fg WHERE ProductID = ? AND WarehouseID = ?", 
                                       [$qcDetail['ProductID'], $warehouseID]);
                $before = $stockBefore ? $stockBefore['QtyOnHand'] - $qtyAccepted : 0;
                
                query("INSERT INTO inventory_transactions (TransactionDate, TransactionType, ReferenceID, ReferenceType, ProductID, WarehouseID, QtyIn, StockBefore, StockAfter, CreatedBy) 
                      VALUES (NOW(), 'FG_Produce', ?, 'fg_receipts', ?, ?, ?, ?, ?, ?)",
                      [$fgReceiptID, $qcDetail['ProductID'], $warehouseID, $qtyAccepted, $before, $before + $qtyAccepted, $adminFG]);
            }
            
            ob_clean();
            header("Location: index.php?page=fg_receipts&msg=created&type=success");
            exit;
        } catch(PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}

ob_end_clean();
?>
<div id="page-content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3"><i class="fas fa-clipboard-check-plus me-2 text-primary"></i>Add FG Receipt</h1>
            <p class="text-muted">Create new finished goods receipt</p>
        </div>
        <a href="<?= url('fg_receipts') ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i>Back
        </a>
    </div>

    <?php if(isset($errors) && !empty($errors)): ?>
    <div class="alert alert-danger">
        <strong><i class="fas fa-exclamation-circle me-1"></i> Please fix the following errors:</strong>
        <ul class="mb-0 mt-1">
            <?php foreach($errors as $error): ?>
            <li><?= htmlspecialchars($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header"><i class="fas fa-edit me-1"></i> FG Receipt Form</div>
        <div class="card-body">
            <form method="POST" action="">
                <div class="row g-3">
                    <!-- Sales Order -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Sales Order <span class="text-danger">*</span></label>
                        <select name="customer_po_id" class="form-select" required>
                            <option value="">-- Select SO --</option>
                            <?php foreach($salesOrders as $so): ?>
                            <option value="<?= $so['CustomerPOID'] ?>" 
                                    <?= (isset($_POST['customer_po_id']) && $_POST['customer_po_id'] == $so['CustomerPOID']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($so['PONumber']) ?> - <?= htmlspecialchars($so['CustomerName']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <!-- QC Inspection -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">QC Inspection <span class="text-danger">*</span></label>
                        <select name="qcid" class="form-select" required>
                            <option value="">-- Select QC --</option>
                            <?php foreach($qcInspections as $qc): ?>
                            <option value="<?= $qc['QCID'] ?>" 
                                    <?= (isset($_POST['qcid']) && $_POST['qcid'] == $qc['QCID']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($qc['WONumber']) ?> - <?= htmlspecialchars($qc['ProductName']) ?> 
                                (PASS: <?= number_format($qc['QtyPASS']) ?>)
                            </option>
                            <?php endforeach; ?>
                        </select>
                        <?php if(empty($qcInspections)): ?>
                        <small class="text-warning">No QC inspections available for FG receipt</small>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Receipt Date -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Receipt Date <span class="text-danger">*</span></label>
                        <input type="date" name="receipt_date" class="form-control" 
                               value="<?= isset($_POST['receipt_date']) ? $_POST['receipt_date'] : date('Y-m-d') ?>" 
                               required>
                    </div>
                    
                    <!-- Dock -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Loading Dock</label>
                        <select name="dock_id" class="form-select">
                            <option value="">-- Select Dock --</option>
                            <?php foreach($docks as $d): ?>
                            <option value="<?= $d['DockID'] ?>" 
                                    <?= (isset($_POST['dock_id']) && $_POST['dock_id'] == $d['DockID']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($d['DockName']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <!-- Status -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Status <span class="text-danger">*</span></label>
                        <select name="status" class="form-select" required>
                            <option value="Stored" <?= (isset($_POST['status']) && $_POST['status'] == 'Stored') ? 'selected' : '' ?>>Stored</option>
                            <option value="Reserved" <?= (isset($_POST['status']) && $_POST['status'] == 'Reserved') ? 'selected' : '' ?>>Reserved</option>
                            <option value="Delivered" <?= (isset($_POST['status']) && $_POST['status'] == 'Delivered') ? 'selected' : '' ?>>Delivered</option>
                            <option value="Partial" <?= (isset($_POST['status']) && $_POST['status'] == 'Partial') ? 'selected' : '' ?>>Partial</option>
                        </select>
                    </div>
                    
                    <!-- Qty Accepted -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Qty Accepted <span class="text-danger">*</span></label>
                        <input type="number" name="qty_accepted" class="form-control" 
                               placeholder="0" 
                               value="<?= isset($_POST['qty_accepted']) ? htmlspecialchars($_POST['qty_accepted']) : '' ?>" 
                               min="1" required>
                    </div>
                    
                    <!-- Qty Rejected -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Qty Rejected</label>
                        <input type="number" name="qty_rejected" class="form-control" 
                               placeholder="0" 
                               value="<?= isset($_POST['qty_rejected']) ? htmlspecialchars($_POST['qty_rejected']) : '0' ?>" 
                               min="0">
                    </div>
                    
                    <!-- Admin FG -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Admin FG <span class="text-danger">*</span></label>
                        <input type="text" name="admin_fg" class="form-control" 
                               placeholder="e.g: Agus Warehouse" 
                               value="<?= isset($_POST['admin_fg']) ? htmlspecialchars($_POST['admin_fg']) : '' ?>" 
                               required>
                    </div>
                    
                    <!-- Notes -->
                    <div class="col-12">
                        <label class="form-label fw-bold">Notes</label>
                        <textarea name="notes" class="form-control" rows="2" 
                                  placeholder="Additional notes"><?= isset($_POST['notes']) ? htmlspecialchars($_POST['notes']) : '' ?></textarea>
                    </div>
                    
                    <!-- Buttons -->
                    <div class="col-12">
                        <hr>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Create FG Receipt
                        </button>
                     
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>