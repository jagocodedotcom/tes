<?php
// ======================================================
// HALAMAN LIST FG RECEIPTS
// ======================================================

// Pagination
$page = isset($_GET['page_num']) ? (int)$_GET['page_num'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

// Search
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Build Query
$whereClause = "WHERE 1=1";
$params = [];

if (!empty($search)) {
    $whereClause .= " AND (fg.FGNumber LIKE ? OR c.CustomerName LIKE ? OR cpo.PONumber LIKE ?)";
    $searchTerm = "%$search%";
    $params = [$searchTerm, $searchTerm, $searchTerm];
}

// Get Total Data
$totalQuery = "
    SELECT COUNT(*) 
    FROM fg_receipts fg
    LEFT JOIN customer_pos cpo ON fg.CustomerPOID = cpo.CustomerPOID
    LEFT JOIN customers c ON cpo.CustomerID = c.CustomerID
    $whereClause
";
$totalData = fetchCount($totalQuery, $params);
$totalPages = ceil($totalData / $limit);

// Get Data
$query = "
    SELECT 
        fg.FGReceiptID,
        fg.FGNumber,
        fg.ReceiptDate,
        fg.QtyAccepted,
        fg.QtyRejected,
        fg.Status,
        fg.AdminFG,
        fg.CreatedAt,
        cpo.PONumber AS CustomerPONumber,
        c.CustomerName,
        ld.DockName,
        (SELECT COUNT(*) FROM fg_receipt_details WHERE FGReceiptID = fg.FGReceiptID) AS TotalItems
    FROM fg_receipts fg
    LEFT JOIN customer_pos cpo ON fg.CustomerPOID = cpo.CustomerPOID
    LEFT JOIN customers c ON cpo.CustomerID = c.CustomerID
    LEFT JOIN loading_docks ld ON fg.DockID = ld.DockID
    $whereClause
    ORDER BY fg.ReceiptDate DESC
    LIMIT $limit OFFSET $offset
";
$receipts = fetchAll($query, $params);

// Get Success/Error Message
$message = isset($_GET['msg']) ? $_GET['msg'] : '';
$messageType = isset($_GET['type']) ? $_GET['type'] : '';
?>

<div id="page-content-wrapper">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3">
                <i class="fas fa-clipboard-check me-2 text-primary"></i>FG Receipts
            </h1>
            <p class="text-muted">Manage finished goods receipts</p>
        </div>
        <a href="<?= url('fg_receipts', 'create') ?>" class="btn btn-primary">
            <i class="fas fa-plus me-1"></i>Add FG Receipt
        </a>
    </div>

    <!-- Alert Message -->
    <?php if($message): ?>
    <div class="alert alert-<?= $messageType ?> alert-dismissible fade show" role="alert">
        <?php 
        if($message == 'created') echo 'FG Receipt berhasil ditambahkan!';
        elseif($message == 'updated') echo 'FG Receipt berhasil diperbarui!';
        elseif($message == 'deleted') echo 'FG Receipt berhasil dihapus!';
        else echo htmlspecialchars($message);
        ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <!-- Search -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <input type="hidden" name="page" value="fg_receipts">
                <div class="col-md-10">
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                        <input type="text" name="search" class="form-control" 
                               placeholder="Search by FG number, customer, or PO..." 
                               value="<?= htmlspecialchars($search) ?>">
                    </div>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search me-1"></i>Search
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Table -->
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <span><i class="fas fa-list me-1"></i> FG Receipt List</span>
                <span class="badge bg-primary"><?= number_format($totalData) ?> Records</span>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover table-striped mb-0">
                    <thead>
                        <tr>
                            <th width="50">#</th>
                            <th>FG Number</th>
                            <th>Date</th>
                            <th>Customer</th>
                            <th>PO Number</th>
                            <th>Dock</th>
                            <th>Accepted</th>
                            <th>Rejected</th>
                            <th>Status</th>
                            <th>Admin</th>
                            <th width="120">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($receipts)): ?>
                        <tr>
                            <td colspan="11" class="text-center text-muted py-4">
                                <i class="fas fa-inbox fa-2x d-block mb-2"></i>
                                No FG receipts found
                            </td>
                        </tr>
                        <?php else: ?>
                        <?php 
                        $no = $offset + 1;
                        foreach($receipts as $row): 
                        ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td>
                                <span class="badge bg-info"><?= htmlspecialchars($row['FGNumber']) ?></span>
                            </td>
                            <td><?= date('d/m/Y', strtotime($row['ReceiptDate'])) ?></td>
                            <td><?= htmlspecialchars($row['CustomerName']) ?></td>
                            <td><?= htmlspecialchars($row['CustomerPONumber']) ?></td>
                            <td><?= htmlspecialchars($row['DockName']) ?></td>
                            <td class="text-success"><?= number_format($row['QtyAccepted']) ?></td>
                            <td class="text-danger"><?= number_format($row['QtyRejected']) ?></td>
                            <td><?= getStatusBadge($row['Status']) ?></td>
                            <td><?= htmlspecialchars($row['AdminFG']) ?></td>
                            <td>
                                <div class="btn-group btn-group-sm">
                                    <a href="<?= url('fg_receipts', 'view', ['id' => $row['FGReceiptID']]) ?>" 
                                       class="btn btn-outline-info" title="View">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="<?= url('fg_receipts', 'edit', ['id' => $row['FGReceiptID']]) ?>" 
                                       class="btn btn-outline-primary" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="<?= url('fg_receipts', 'delete', ['id' => $row['FGReceiptID']]) ?>" 
                                       class="btn btn-outline-danger" title="Delete"
                                       onclick="return confirm('Are you sure you want to delete this FG receipt?')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php if($totalPages > 1): ?>
        <div class="card-footer">
            <nav>
                <ul class="pagination pagination-sm mb-0">
                    <?php if($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=fg_receipts&page_num=<?= $page-1 ?>&search=<?= urlencode($search) ?>">
                            <i class="fas fa-chevron-left"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <?php for($i = 1; $i <= $totalPages; $i++): ?>
                    <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                        <a class="page-link" href="?page=fg_receipts&page_num=<?= $i ?>&search=<?= urlencode($search) ?>">
                            <?= $i ?>
                        </a>
                    </li>
                    <?php endfor; ?>
                    
                    <?php if($page < $totalPages): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=fg_receipts&page_num=<?= $page+1 ?>&search=<?= urlencode($search) ?>">
                            <i class="fas fa-chevron-right"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
        <?php endif; ?>
    </div>
</div>