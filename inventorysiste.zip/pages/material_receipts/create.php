<?php
// ======================================================
// HALAMAN TAMBAH MATERIAL RECEIPT
// ======================================================
ob_start();

// Get suppliers for dropdown
$suppliers = fetchAll("SELECT SupplierID, SupplierName FROM suppliers WHERE Status = 1 ORDER BY SupplierName");

// Get PO yang sudah Approved untuk dropdown
$pos = fetchAll("
    SELECT 
        po.POID, 
        po.PONumber, 
        s.SupplierName 
    FROM purchase_orders po
    LEFT JOIN suppliers s ON po.SupplierID = s.SupplierID
    WHERE po.Status NOT IN ('Completed', 'Cancelled')
    ORDER BY po.PODate DESC
");

// Get materials for dropdown
$materials = fetchAll("SELECT MaterialID, MaterialCode, MaterialName, UOM FROM materials WHERE Active = 1 ORDER BY MaterialName");

// Get warehouses
$warehouses = fetchAll("SELECT WarehouseID, WarehouseName FROM warehouses WHERE IsActive = 1 ORDER BY WarehouseName");

// Proses submit form
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil data dari form
    $receiptDate = isset($_POST['receipt_date']) ? $_POST['receipt_date'] : date('Y-m-d');
    $poID = isset($_POST['po_id']) ? (int)$_POST['po_id'] : 0;
    $supplierID = isset($_POST['supplier_id']) ? (int)$_POST['supplier_id'] : 0;
    
    // ============================================================
    // PERHATIAN: Database pakai warehouseid (tanpa underscore)
    // ============================================================
    $warehouseid = isset($_POST['warehouse_id']) ? (int)$_POST['warehouse_id'] : 0;
    
    $suratJalan = isset($_POST['surat_jalan']) ? trim($_POST['surat_jalan']) : '';
    $receivedBy = isset($_POST['received_by']) ? trim($_POST['received_by']) : '';
    $status = 'Completed';
    
    // Ambil data items dari form
    $materialIDs = isset($_POST['material_id']) ? $_POST['material_id'] : [];
    $qtys = isset($_POST['qty']) ? $_POST['qty'] : [];
    $rejects = isset($_POST['reject']) ? $_POST['reject'] : [];
    $rackLocations = isset($_POST['rack_location']) ? $_POST['rack_location'] : [];
    
    $errors = [];
    
    // Validasi
    if(empty($receiptDate)) $errors[] = "Receipt Date is required";
    if(empty($supplierID)) $errors[] = "Supplier is required";
    if(empty($warehouseid)) $errors[] = "Warehouse is required";
    if(empty($receivedBy)) $errors[] = "Received By is required";
    if(empty($materialIDs) || count($materialIDs) == 0) $errors[] = "At least one item is required";
    
    // Validasi setiap item
    foreach($materialIDs as $index => $mid) {
        if(empty($mid)) $errors[] = "Item #" . ($index+1) . ": Material is required";
        if(empty($qtys[$index]) || $qtys[$index] <= 0) $errors[] = "Item #" . ($index+1) . ": Quantity must be greater than 0";
        if(isset($rejects[$index]) && $rejects[$index] > $qtys[$index]) {
            $errors[] = "Item #" . ($index+1) . ": Reject quantity cannot exceed received quantity";
        }
    }
    
    if(empty($errors)) {
        try {
            // Generate Receipt Number
            $year = date('Y');
            $month = date('m');
            $lastReceipt = fetchOne("SELECT ReceiptNumber FROM material_receipts ORDER BY ReceiptID DESC LIMIT 1");
            $lastNumber = 0;
            if($lastReceipt) {
                $lastNumber = (int)substr($lastReceipt['ReceiptNumber'], -4);
            }
            $newNumber = str_pad($lastNumber + 1, 4, '0', STR_PAD_LEFT);
            $receiptNumber = 'GRN-' . $year . $month . '-' . $newNumber;
            
            // ============================================================
            // 1. INSERT HEADER - PAKAI warehouseid (tanpa underscore)
            // ============================================================
            $sql = "INSERT INTO material_receipts (ReceiptNumber, ReceiptDate, POID, SupplierID, warehouseid, SuratJalan, ReceivedBy, Status) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            query($sql, [$receiptNumber, $receiptDate, $poID, $supplierID, $warehouseid, $suratJalan, $receivedBy, $status]);
            $receiptID = $pdo->lastInsertId();
            
            // ============================================================
            // 2. INSERT DETAILS - PAKAI warehouseid (tanpa underscore)
            // ============================================================
            foreach($materialIDs as $index => $materialID) {
                if(empty($materialID)) continue;
                
                $qty = isset($qtys[$index]) ? $qtys[$index] : 0;
                $reject = isset($rejects[$index]) ? $rejects[$index] : 0;
                $rackLocation = isset($rackLocations[$index]) ? $rackLocations[$index] : '';
                
                // Ambil PODetailID jika ada PO
                $podetailID = null;
                if($poID > 0) {
                    $poDetail = fetchOne("SELECT PODetailID FROM purchase_order_details WHERE POID = ? AND MaterialID = ?", 
                                         [$poID, $materialID]);
                    if($poDetail) {
                        $podetailID = $poDetail['PODetailID'];
                    }
                }
                
                $sqlDetail = "INSERT INTO material_receipt_details (ReceiptID, PODetailID, MaterialID, warehouseid, QtyReceived, QtyReject, RackLocation) 
                              VALUES (?, ?, ?, ?, ?, ?, ?)";
                query($sqlDetail, [$receiptID, $podetailID, $materialID, $warehouseid, $qty, $reject, $rackLocation]);
            }
            
            // ============================================================
            // 3. UPDATE PO STATUS
            // ============================================================
            if($poID > 0) {
                $totalQty = fetchOne("SELECT COALESCE(SUM(QtyOrder), 0) as total FROM purchase_order_details WHERE POID = ?", [$poID]);
                $totalReceived = fetchOne("SELECT COALESCE(SUM(mrd.QtyReceived), 0) as total 
                                           FROM material_receipt_details mrd 
                                           JOIN material_receipts mr ON mrd.ReceiptID = mr.ReceiptID 
                                           WHERE mr.POID = ?", [$poID]);
                
                if($totalReceived['total'] >= $totalQty['total']) {
                    query("UPDATE purchase_orders SET Status = 'Completed' WHERE POID = ?", [$poID]);
                } else {
                    query("UPDATE purchase_orders SET Status = 'Partial' WHERE POID = ?", [$poID]);
                }
            }
            
            // ============================================================
            // 4. UPDATE STOCK MATERIAL - PAKAI warehouseid
            // ============================================================
            foreach($materialIDs as $index => $materialID) {
                if(empty($materialID)) continue;
                $qty = isset($qtys[$index]) ? $qtys[$index] : 0;
                $reject = isset($rejects[$index]) ? $rejects[$index] : 0;
                $qtyAccepted = $qty - $reject;
                
                if($qtyAccepted > 0) {
                    // Cek apakah stock sudah ada
                    $stock = fetchOne("SELECT StockID FROM material_stock WHERE MaterialID = ? AND warehouseid = ?", 
                                      [$materialID, $warehouseid]);
                    if($stock) {
                        query("UPDATE material_stock SET QtyOnHand = QtyOnHand + ? WHERE MaterialID = ? AND warehouseid = ?", 
                              [$qtyAccepted, $materialID, $warehouseid]);
                    } else {
                        query("INSERT INTO material_stock (MaterialID, warehouseid, QtyOnHand) VALUES (?, ?, ?)", 
                              [$materialID, $warehouseid, $qtyAccepted]);
                    }
                }
            }
            
            ob_clean();
            header("Location: index.php?page=material_receipts&msg=created&type=success");
            exit;
        } catch(PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}

ob_end_clean();
?>
<div id="page-content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3"><i class="fas fa-clipboard-check-plus me-2 text-primary"></i>Add Material Receipt</h1>
            <p class="text-muted">Create new material receipt (GRN)</p>
        </div>
        <a href="<?= url('material_receipts') ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i>Back
        </a>
    </div>

    <?php if(isset($errors) && !empty($errors)): ?>
    <div class="alert alert-danger">
        <strong><i class="fas fa-exclamation-circle me-1"></i> Please fix the following errors:</strong>
        <ul class="mb-0 mt-1">
            <?php foreach($errors as $error): ?>
            <li><?= htmlspecialchars($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header"><i class="fas fa-edit me-1"></i> Material Receipt Form</div>
        <div class="card-body">
            <form method="POST" action="" id="receiptForm">
                <div class="row g-3">
                    <!-- Receipt Date -->
                    <div class="col-md-3">
                        <label class="form-label fw-bold">Receipt Date <span class="text-danger">*</span></label>
                        <input type="date" name="receipt_date" class="form-control" 
                               value="<?= isset($_POST['receipt_date']) ? $_POST['receipt_date'] : date('Y-m-d') ?>" 
                               required>
                    </div>
                    
                    <!-- Supplier -->
                    <div class="col-md-3">
                        <label class="form-label fw-bold">Supplier <span class="text-danger">*</span></label>
                        <select name="supplier_id" class="form-select" required>
                            <option value="">-- Select Supplier --</option>
                            <?php foreach($suppliers as $sup): ?>
                            <option value="<?= $sup['SupplierID'] ?>" 
                                    <?= (isset($_POST['supplier_id']) && $_POST['supplier_id'] == $sup['SupplierID']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($sup['SupplierName']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <!-- Warehouse -->
                    <div class="col-md-3">
                        <label class="form-label fw-bold">Warehouse <span class="text-danger">*</span></label>
                        <select name="warehouse_id" class="form-select" required>
                            <option value="">-- Select Warehouse --</option>
                            <?php foreach($warehouses as $wh): ?>
                            <option value="<?= $wh['WarehouseID'] ?>" 
                                    <?= (isset($_POST['warehouse_id']) && $_POST['warehouse_id'] == $wh['WarehouseID']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($wh['WarehouseName']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <!-- PO -->
                    <div class="col-md-3">
                        <label class="form-label fw-bold">Purchase Order</label>
                        <select name="po_id" class="form-select">
                            <option value="">-- Without PO --</option>
                            <?php foreach($pos as $po): ?>
                            <option value="<?= $po['POID'] ?>" 
                                    <?= (isset($_POST['po_id']) && $_POST['po_id'] == $po['POID']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($po['PONumber']) ?> - <?= htmlspecialchars($po['SupplierName']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                        <small class="text-muted">Optional: Select PO if this receipt is for a purchase order</small>
                    </div>
                    
                    <!-- Surat Jalan -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Surat Jalan</label>
                        <input type="text" name="surat_jalan" class="form-control" 
                               placeholder="e.g: SJ-001-2026" 
                               value="<?= isset($_POST['surat_jalan']) ? htmlspecialchars($_POST['surat_jalan']) : '' ?>">
                    </div>
                    
                    <!-- Received By -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Received By <span class="text-danger">*</span></label>
                        <input type="text" name="received_by" class="form-control" 
                               placeholder="e.g: warehouse1" 
                               value="<?= isset($_POST['received_by']) ? htmlspecialchars($_POST['received_by']) : '' ?>" 
                               required>
                    </div>
                    
                    <!-- Items Section -->
                    <div class="col-12">
                        <hr>
                        <h5 class="fw-bold"><i class="fas fa-list me-2"></i>Items</h5>
                        <div id="itemsContainer">
                            <div class="row g-2 item-row">
                                <div class="col-md-4">
                                    <select name="material_id[]" class="form-select" required>
                                        <option value="">-- Select Material --</option>
                                        <?php foreach($materials as $mat): ?>
                                        <option value="<?= $mat['MaterialID'] ?>">
                                            <?= htmlspecialchars($mat['MaterialCode']) ?> - <?= htmlspecialchars($mat['MaterialName']) ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <input type="number" name="qty[]" class="form-control" placeholder="Qty Received" min="1" required>
                                </div>
                                <div class="col-md-2">
                                    <input type="number" name="reject[]" class="form-control" placeholder="Qty Reject" min="0" value="0">
                                </div>
                                <div class="col-md-3">
                                    <input type="text" name="rack_location[]" class="form-control" placeholder="Rack Location">
                                </div>
                                <div class="col-md-1">
                                    <button type="button" class="btn btn-danger btn-sm remove-item" style="display:none;">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <button type="button" class="btn btn-sm btn-outline-primary mt-2" id="addItem">
                            <i class="fas fa-plus me-1"></i>Add Item
                        </button>
                    </div>
                    
                    <!-- Buttons -->
                    <div class="col-12">
                        <hr>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Create Receipt
                        </button>
                        <a href="<?= url('material_receipts') ?>" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i>Cancel
                        </a>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Add new item row
document.getElementById('addItem').addEventListener('click', function() {
    var container = document.getElementById('itemsContainer');
    var rows = container.querySelectorAll('.item-row');
    var lastRow = rows[rows.length - 1];
    var newRow = lastRow.cloneNode(true);
    
    // Reset values
    newRow.querySelectorAll('input').forEach(function(input) {
        if(input.type != 'hidden') {
            input.value = '';
        }
    });
    newRow.querySelectorAll('select').forEach(function(select) {
        select.selectedIndex = 0;
    });
    
    // Show remove button
    var removeBtn = newRow.querySelector('.remove-item');
    removeBtn.style.display = 'inline-block';
    
    container.appendChild(newRow);
});

// Remove item row
document.addEventListener('click', function(e) {
    if (e.target.closest('.remove-item')) {
        var row = e.target.closest('.item-row');
        if (document.querySelectorAll('.item-row').length > 1) {
            row.remove();
        }
    }
});
</script>