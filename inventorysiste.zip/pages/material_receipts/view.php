<?php
// ======================================================
// HALAMAN DETAIL MATERIAL RECEIPT
// ======================================================

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Get Receipt Header
$receipt = fetchOne("
    SELECT 
        mr.*,
        s.SupplierName,
        s.Address,
        s.Phone,
        s.Email,
        po.PONumber
    FROM material_receipts mr
    LEFT JOIN suppliers s ON mr.SupplierID = s.SupplierID
    LEFT JOIN purchase_orders po ON mr.POID = po.POID
    WHERE mr.ReceiptID = ?
", [$id]);

if(!$receipt) {
    header("Location: index.php?page=material_receipts&msg=Receipt not found&type=danger");
    exit;
}

// Get Receipt Details
$details = fetchAll("
    SELECT 
        mrd.*,
        m.MaterialCode,
        m.MaterialName,
        m.UOM,
        pod.QtyOrder,
        pod.Price
    FROM material_receipt_details mrd
    LEFT JOIN materials m ON mrd.MaterialID = m.MaterialID
    LEFT JOIN purchase_order_details pod ON mrd.PODetailID = pod.PODetailID
    WHERE mrd.ReceiptID = ?
    ORDER BY mrd.ReceiptDetailID
", [$id]);

// Calculate totals
$totalReceived = 0;
$totalReject = 0;
$totalAccepted = 0;
foreach($details as $d) {
    $totalReceived += $d['QtyReceived'];
    $totalReject += $d['QtyReject'];
    $totalAccepted += ($d['QtyReceived'] - $d['QtyReject']);
}
?>

<div id="page-content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3">
                <i class="fas fa-clipboard-check me-2 text-primary"></i>Material Receipt Detail
            </h1>
            <p class="text-muted">View receipt details</p>
        </div>
        <div>
            <a href="<?= url('material_receipts', 'edit', ['id' => $id]) ?>" class="btn btn-primary">
                <i class="fas fa-edit me-1"></i>Edit
            </a>
            <a href="<?= url('material_receipts') ?>" class="btn btn-secondary">
                <i class="fas fa-arrow-left me-1"></i>Back
            </a>
        </div>
    </div>

    <!-- Receipt Information -->
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-info-circle me-1"></i> Receipt Information
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <table class="table table-bordered mb-0">
                        <tr>
                            <th width="35%">Receipt Number</th>
                            <td><span class="badge bg-info"><?= htmlspecialchars($receipt['ReceiptNumber']) ?></span></td>
                        </tr>
                        <tr>
                            <th>Receipt Date</th>
                            <td><?= date('d/m/Y', strtotime($receipt['ReceiptDate'])) ?></td>
                        </tr>
                        <tr>
                            <th>Status</th>
                            <td><?= getStatusBadge($receipt['Status']) ?></td>
                        </tr>
                        <tr>
                            <th>Surat Jalan</th>
                            <td><?= htmlspecialchars($receipt['SuratJalan']) ?></td>
                        </tr>
                        <tr>
                            <th>Received By</th>
                            <td><?= htmlspecialchars($receipt['ReceivedBy']) ?></td>
                        </tr>
                        <tr>
                            <th>Created At</th>
                            <td><?= date('d/m/Y H:i', strtotime($receipt['CreatedAt'])) ?></td>
                        </tr>
                    </table>
                </div>
                <div class="col-md-6">
                    <table class="table table-bordered mb-0">
                        <tr>
                            <th width="35%">Supplier</th>
                            <td><strong><?= htmlspecialchars($receipt['SupplierName']) ?></strong></td>
                        </tr>
                        <tr>
                            <th>Address</th>
                            <td><?= nl2br(htmlspecialchars($receipt['Address'])) ?></td>
                        </tr>
                        <tr>
                            <th>Phone</th>
                            <td><?= htmlspecialchars($receipt['Phone']) ?></td>
                        </tr>
                        <tr>
                            <th>Email</th>
                            <td><?= htmlspecialchars($receipt['Email']) ?></td>
                        </tr>
                        <?php if($receipt['PONumber']): ?>
                        <tr>
                            <th>PO Number</th>
                            <td><?= htmlspecialchars($receipt['PONumber']) ?></td>
                        </tr>
                        <?php endif; ?>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Summary -->
    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card text-center">
                <div class="card-body">
                    <h5 class="text-primary"><?= number_format($totalReceived) ?></h5>
                    <small class="text-muted">Total Received</small>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-center">
                <div class="card-body">
                    <h5 class="text-danger"><?= number_format($totalReject) ?></h5>
                    <small class="text-muted">Total Reject</small>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-center">
                <div class="card-body">
                    <h5 class="text-success"><?= number_format($totalAccepted) ?></h5>
                    <small class="text-muted">Total Accepted</small>
                </div>
            </div>
        </div>
    </div>

    <!-- Items -->
    <div class="card">
        <div class="card-header">
            <i class="fas fa-list me-1"></i> Items
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-striped mb-0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Material Code</th>
                            <th>Material Name</th>
                            <th>UOM</th>
                            <th class="text-end">Received</th>
                            <th class="text-end">Reject</th>
                            <th class="text-end">Accepted</th>
                            <th>Rack Location</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($details)): ?>
                        <tr>
                            <td colspan="8" class="text-center text-muted py-3">No items found</td>
                        </tr>
                        <?php else: ?>
                        <?php $no = 1; foreach($details as $row): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= htmlspecialchars($row['MaterialCode']) ?></td>
                            <td><?= htmlspecialchars($row['MaterialName']) ?></td>
                            <td><?= htmlspecialchars($row['UOM']) ?></td>
                            <td class="text-end"><?= number_format($row['QtyReceived']) ?></td>
                            <td class="text-end"><?= number_format($row['QtyReject']) ?></td>
                            <td class="text-end"><?= number_format($row['QtyReceived'] - $row['QtyReject']) ?></td>
                            <td><?= htmlspecialchars($row['RackLocation']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>