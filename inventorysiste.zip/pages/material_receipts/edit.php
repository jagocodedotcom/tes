<?php
// ======================================================
// HALAMAN EDIT MATERIAL RECEIPT
// ======================================================
ob_start();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Get Receipt Header
$receipt = fetchOne("SELECT * FROM material_receipts WHERE ReceiptID = ?", [$id]);

if(!$receipt) {
    ob_clean();
    header("Location: index.php?page=material_receipts&msg=Receipt not found&type=danger");
    exit;
}

// Get suppliers for dropdown
$suppliers = fetchAll("SELECT SupplierID, SupplierName FROM suppliers WHERE Status = 1 ORDER BY SupplierName");

// Get PO yang sudah Approved untuk dropdown
$pos = fetchAll("
    SELECT 
        po.POID, 
        po.PONumber, 
        s.SupplierName 
    FROM purchase_orders po
    LEFT JOIN suppliers s ON po.SupplierID = s.SupplierID
    WHERE po.Status IN ('Approved', 'Partial', 'Completed')
    ORDER BY po.PONumber
");

// Get materials for dropdown
$materials = fetchAll("SELECT MaterialID, MaterialCode, MaterialName, UOM FROM materials WHERE Active = 1 ORDER BY MaterialName");

// Get warehouses for dropdown
$warehouses = fetchAll("SELECT WarehouseID, WarehouseName FROM warehouses WHERE IsActive = 1 ORDER BY WarehouseName");

// Get existing receipt details
$existingDetails = fetchAll("
    SELECT 
        mrd.*,
        m.MaterialCode,
        m.MaterialName,
        m.UOM
    FROM material_receipt_details mrd
    LEFT JOIN materials m ON mrd.MaterialID = m.MaterialID
    WHERE mrd.ReceiptID = ?
    ORDER BY mrd.ReceiptDetailID
", [$id]);

// Proses submit form
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $receiptDate = isset($_POST['receipt_date']) ? $_POST['receipt_date'] : date('Y-m-d');
    $poID = isset($_POST['po_id']) ? (int)$_POST['po_id'] : 0;
    $supplierID = isset($_POST['supplier_id']) ? (int)$_POST['supplier_id'] : 0;
    $warehouseID = isset($_POST['warehouse_id']) ? (int)$_POST['warehouse_id'] : 0;
    $suratJalan = isset($_POST['surat_jalan']) ? trim($_POST['surat_jalan']) : '';
    $receivedBy = isset($_POST['received_by']) ? trim($_POST['received_by']) : '';
    $status = isset($_POST['status']) ? $_POST['status'] : 'Completed';
    
    // Ambil data items dari form
    $detailIDs = isset($_POST['detail_id']) ? $_POST['detail_id'] : [];
    $materialIDs = isset($_POST['material_id']) ? $_POST['material_id'] : [];
    $qtys = isset($_POST['qty']) ? $_POST['qty'] : [];
    $rejects = isset($_POST['reject']) ? $_POST['reject'] : [];
    $rackLocations = isset($_POST['rack_location']) ? $_POST['rack_location'] : [];
    
    $errors = [];
    
    // Validasi
    if(empty($receiptDate)) $errors[] = "Receipt Date is required";
    if(empty($supplierID)) $errors[] = "Supplier is required";
    if(empty($warehouseID)) $errors[] = "Warehouse is required";
    if(empty($receivedBy)) $errors[] = "Received By is required";
    if(empty($materialIDs) || count($materialIDs) == 0) $errors[] = "At least one item is required";
    
    // Validasi setiap item
    foreach($materialIDs as $index => $mid) {
        if(empty($mid)) $errors[] = "Item #" . ($index+1) . ": Material is required";
        if(empty($qtys[$index]) || $qtys[$index] <= 0) $errors[] = "Item #" . ($index+1) . ": Quantity must be greater than 0";
        if(isset($rejects[$index]) && $rejects[$index] > $qtys[$index]) {
            $errors[] = "Item #" . ($index+1) . ": Reject quantity cannot exceed received quantity";
        }
    }
    
    if(empty($errors)) {
        try {
            // Update Receipt Header
            $sql = "UPDATE material_receipts SET 
                    ReceiptDate = ?, 
                    POID = ?, 
                    SupplierID = ?, 
                    WarehouseID = ?,
                    SuratJalan = ?, 
                    ReceivedBy = ?, 
                    Status = ?
                    WHERE ReceiptID = ?";
            query($sql, [$receiptDate, $poID, $supplierID, $warehouseID, $suratJalan, $receivedBy, $status, $id]);
            
            // Delete existing details
            query("DELETE FROM material_receipt_details WHERE ReceiptID = ?", [$id]);
            
            // Insert new details - PAKAI Warehouseid
            foreach($materialIDs as $index => $materialID) {
                if(empty($materialID)) continue;
                $qty = isset($qtys[$index]) ? $qtys[$index] : 0;
                $reject = isset($rejects[$index]) ? $rejects[$index] : 0;
                $rackLocation = isset($rackLocations[$index]) ? $rackLocations[$index] : '';
                
                // Ambil PODetailID jika ada
                $podetailID = null;
                if($poID > 0) {
                    $poDetail = fetchOne("SELECT PODetailID FROM purchase_order_details WHERE POID = ? AND MaterialID = ?", 
                                         [$poID, $materialID]);
                    if($poDetail) {
                        $podetailID = $poDetail['PODetailID'];
                    }
                }
                
                // PAKAI Warehouseid (huruf kecil semua)
                $sqlDetail = "INSERT INTO material_receipt_details (ReceiptID, PODetailID, MaterialID, Warehouseid, QtyReceived, QtyReject, RackLocation) 
                              VALUES (?, ?, ?, ?, ?, ?, ?)";
                query($sqlDetail, [$id, $podetailID, $materialID, $warehouseID, $qty, $reject, $rackLocation]);
            }
            
            // Update PO status jika ada
            if($poID > 0) {
                $totalQty = fetchOne("SELECT COALESCE(SUM(QtyOrder), 0) as total FROM purchase_order_details WHERE POID = ?", [$poID]);
                $totalReceived = fetchOne("SELECT COALESCE(SUM(mrd.QtyReceived), 0) as total 
                                           FROM material_receipt_details mrd 
                                           JOIN material_receipts mr ON mrd.ReceiptID = mr.ReceiptID 
                                           WHERE mr.POID = ?", [$poID]);
                
                if($totalReceived['total'] >= $totalQty['total']) {
                    query("UPDATE purchase_orders SET Status = 'Completed' WHERE POID = ?", [$poID]);
                } else if($totalReceived['total'] > 0) {
                    query("UPDATE purchase_orders SET Status = 'Partial' WHERE POID = ?", [$poID]);
                }
            }
            
            ob_clean();
            header("Location: index.php?page=material_receipts&msg=updated&type=success");
            exit;
        } catch(PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}

ob_end_clean();
?>
<div id="page-content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3"><i class="fas fa-clipboard-check-plus me-2 text-primary"></i>Edit Material Receipt</h1>
            <p class="text-muted">Edit receipt: <?= htmlspecialchars($receipt['ReceiptNumber']) ?></p>
        </div>
        <a href="<?= url('material_receipts') ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i>Back
        </a>
    </div>

    <?php if(isset($errors) && !empty($errors)): ?>
    <div class="alert alert-danger">
        <strong><i class="fas fa-exclamation-circle me-1"></i> Please fix the following errors:</strong>
        <ul class="mb-0 mt-1">
            <?php foreach($errors as $error): ?>
            <li><?= htmlspecialchars($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header"><i class="fas fa-edit me-1"></i> Edit Material Receipt Form</div>
        <div class="card-body">
            <form method="POST" action="" id="receiptForm">
                <div class="row g-3">
                    <!-- Receipt Date -->
                    <div class="col-md-3">
                        <label class="form-label fw-bold">Receipt Date <span class="text-danger">*</span></label>
                        <input type="date" name="receipt_date" class="form-control" 
                               value="<?= $receipt['ReceiptDate'] ?>" 
                               required>
                    </div>
                    
                    <!-- Supplier -->
                    <div class="col-md-3">
                        <label class="form-label fw-bold">Supplier <span class="text-danger">*</span></label>
                        <select name="supplier_id" class="form-select" required>
                            <option value="">-- Select Supplier --</option>
                            <?php foreach($suppliers as $sup): ?>
                            <option value="<?= $sup['SupplierID'] ?>" 
                                    <?= $receipt['SupplierID'] == $sup['SupplierID'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($sup['SupplierName']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <!-- Warehouse -->
                    <div class="col-md-3">
                        <label class="form-label fw-bold">Warehouse <span class="text-danger">*</span></label>
                        <select name="warehouse_id" class="form-select" required>
                            <option value="">-- Select Warehouse --</option>
                            <?php foreach($warehouses as $wh): ?>
                            <option value="<?= $wh['WarehouseID'] ?>" 
                                    <?= $receipt['WarehouseID'] == $wh['WarehouseID'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($wh['WarehouseName']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <!-- PO -->
                    <div class="col-md-3">
                        <label class="form-label fw-bold">Purchase Order</label>
                        <select name="po_id" class="form-select">
                            <option value="">-- Without PO --</option>
                            <?php foreach($pos as $po): ?>
                            <option value="<?= $po['POID'] ?>" 
                                    <?= $receipt['POID'] == $po['POID'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($po['PONumber']) ?> - <?= htmlspecialchars($po['SupplierName']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                        <small class="text-muted">Optional: Select PO if this receipt is for a purchase order</small>
                    </div>
                    
                    <!-- Surat Jalan -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Surat Jalan</label>
                        <input type="text" name="surat_jalan" class="form-control" 
                               placeholder="e.g: SJ-001-2026" 
                               value="<?= htmlspecialchars($receipt['SuratJalan']) ?>">
                    </div>
                    
                    <!-- Received By -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Received By <span class="text-danger">*</span></label>
                        <input type="text" name="received_by" class="form-control" 
                               placeholder="e.g: warehouse1" 
                               value="<?= htmlspecialchars($receipt['ReceivedBy']) ?>" 
                               required>
                    </div>
                    
                    <!-- Status -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Status <span class="text-danger">*</span></label>
                        <select name="status" class="form-select" required>
                            <option value="Draft" <?= $receipt['Status'] == 'Draft' ? 'selected' : '' ?>>Draft</option>
                            <option value="Completed" <?= $receipt['Status'] == 'Completed' ? 'selected' : '' ?>>Completed</option>
                            <option value="Cancelled" <?= $receipt['Status'] == 'Cancelled' ? 'selected' : '' ?>>Cancelled</option>
                        </select>
                    </div>
                    
                    <!-- Created Info -->
                    <div class="col-12">
                        <div class="alert alert-info">
                            <small>
                                <i class="fas fa-info-circle me-1"></i>
                                Created: <?= date('d/m/Y H:i', strtotime($receipt['CreatedAt'])) ?>
                                <?php if($receipt['UpdatedAt'] != $receipt['CreatedAt']): ?>
                                <br>Updated: <?= date('d/m/Y H:i', strtotime($receipt['UpdatedAt'])) ?>
                                <?php endif; ?>
                            </small>
                        </div>
                    </div>
                    
                    <!-- Items Section -->
                    <div class="col-12">
                        <hr>
                        <h5 class="fw-bold"><i class="fas fa-list me-2"></i>Items</h5>
                        <div id="itemsContainer">
                            <?php if(empty($existingDetails)): ?>
                            <div class="row g-2 item-row">
                                <div class="col-md-4">
                                    <select name="material_id[]" class="form-select" required>
                                        <option value="">-- Select Material --</option>
                                        <?php foreach($materials as $mat): ?>
                                        <option value="<?= $mat['MaterialID'] ?>">
                                            <?= htmlspecialchars($mat['MaterialCode']) ?> - <?= htmlspecialchars($mat['MaterialName']) ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <input type="number" name="qty[]" class="form-control" placeholder="Qty Received" min="1" required>
                                </div>
                                <div class="col-md-2">
                                    <input type="number" name="reject[]" class="form-control" placeholder="Qty Reject" min="0" value="0">
                                </div>
                                <div class="col-md-3">
                                    <input type="text" name="rack_location[]" class="form-control" placeholder="Rack Location">
                                </div>
                                <div class="col-md-1">
                                    <button type="button" class="btn btn-danger btn-sm remove-item" style="display:none;">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                            </div>
                            <?php else: ?>
                            <?php foreach($existingDetails as $index => $item): ?>
                            <div class="row g-2 item-row">
                                <input type="hidden" name="detail_id[]" value="<?= $item['ReceiptDetailID'] ?>">
                                <div class="col-md-4">
                                    <select name="material_id[]" class="form-select" required>
                                        <option value="">-- Select Material --</option>
                                        <?php foreach($materials as $mat): ?>
                                        <option value="<?= $mat['MaterialID'] ?>" 
                                                <?= $item['MaterialID'] == $mat['MaterialID'] ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($mat['MaterialCode']) ?> - <?= htmlspecialchars($mat['MaterialName']) ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <input type="number" name="qty[]" class="form-control" placeholder="Qty Received" min="1" 
                                           value="<?= $item['QtyReceived'] ?>" required>
                                </div>
                                <div class="col-md-2">
                                    <input type="number" name="reject[]" class="form-control" placeholder="Qty Reject" min="0" 
                                           value="<?= $item['QtyReject'] ?>">
                                </div>
                                <div class="col-md-3">
                                    <input type="text" name="rack_location[]" class="form-control" placeholder="Rack Location"
                                           value="<?= htmlspecialchars($item['RackLocation']) ?>">
                                </div>
                                <div class="col-md-1">
                                    <button type="button" class="btn btn-danger btn-sm remove-item" 
                                            <?= (count($existingDetails) <= 1) ? 'style="display:none;"' : '' ?>>
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                            </div>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                        <button type="button" class="btn btn-sm btn-outline-primary mt-2" id="addItem">
                            <i class="fas fa-plus me-1"></i>Add Item
                        </button>
                    </div>
                    
                    <!-- Buttons -->
                    <div class="col-12">
                        <hr>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Update Receipt
                        </button>
                      
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Add new item row
document.getElementById('addItem').addEventListener('click', function() {
    var container = document.getElementById('itemsContainer');
    var rows = container.querySelectorAll('.item-row');
    var lastRow = rows[rows.length - 1];
    var newRow = lastRow.cloneNode(true);
    
    // Reset values
    newRow.querySelectorAll('input').forEach(function(input) {
        if(input.type != 'hidden') {
            input.value = input.type == 'number' ? '0' : '';
        }
    });
    newRow.querySelectorAll('select').forEach(function(select) {
        select.selectedIndex = 0;
    });
    
    // Show remove button
    var removeBtn = newRow.querySelector('.remove-item');
    removeBtn.style.display = 'inline-block';
    
    container.appendChild(newRow);
});

// Remove item row
document.addEventListener('click', function(e) {
    if (e.target.closest('.remove-item')) {
        var row = e.target.closest('.item-row');
        if (document.querySelectorAll('.item-row').length > 1) {
            row.remove();
        }
    }
});
</script>