<?php
// ======================================================
// PROSES HAPUS MATERIAL RECEIPT
// ======================================================
ob_start();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$receipt = fetchOne("SELECT * FROM material_receipts WHERE ReceiptID = ?", [$id]);

if(!$receipt) {
    ob_clean();
    header("Location: index.php?page=material_receipts&msg=Receipt not found&type=danger");
    exit;
}

// Cek apakah receipt sudah digunakan untuk stock
$hasStock = fetchCount("SELECT COUNT(*) FROM material_stock WHERE MaterialID IN 
                        (SELECT MaterialID FROM material_receipt_details WHERE ReceiptID = ?)", [$id]);

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    if($hasStock > 0) {
        // Soft delete - hanya ubah status
        query("UPDATE material_receipts SET Status = 'Cancelled' WHERE ReceiptID = ?", [$id]);
        $message = "Receipt cancelled (has stock records)";
    } else {
        // Permanent delete
        // Hapus details dulu
        query("DELETE FROM material_receipt_details WHERE ReceiptID = ?", [$id]);
        // Hapus header
        query("DELETE FROM material_receipts WHERE ReceiptID = ?", [$id]);
        $message = "Receipt deleted permanently";
    }
    
    ob_clean();
    header("Location: index.php?page=material_receipts&msg=deleted&type=success");
    exit;
}

ob_end_clean();
?>
<div id="page-content-wrapper">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-header bg-danger text-white">
                    <i class="fas fa-exclamation-triangle me-1"></i> Confirm Delete
                </div>
                <div class="card-body text-center py-4">
                    <i class="fas fa-clipboard-check fa-4x text-danger mb-3"></i>
                    <h4>Are you sure you want to delete this receipt?</h4>
                    <p class="text-muted">
                        <strong><?= htmlspecialchars($receipt['ReceiptNumber']) ?></strong>
                        <br>
                        Date: <?= date('d/m/Y', strtotime($receipt['ReceiptDate'])) ?>
                        <br>
                        Status: <?= $receipt['Status'] ?>
                    </p>
                    
                    <?php if($hasStock > 0): ?>
                    <div class="alert alert-warning">
                        <i class="fas fa-info-circle me-1"></i>
                        This receipt has <strong><?= number_format($hasStock) ?> stock record(s)</strong>.
                        Receipt will be <strong>cancelled</strong> instead of permanently deleted.
                    </div>
                    <?php else: ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-info-circle me-1"></i>
                        This receipt has <strong>no stock records</strong>.
                        Receipt will be <strong>permanently deleted</strong>.
                    </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="" class="d-inline">
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash me-1"></i> Yes, Delete
                        </button>
                        <a href="<?= url('material_receipts') ?>" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i> Cancel
                        </a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>