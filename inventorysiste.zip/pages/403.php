<div id="page-content-wrapper" class="p-4">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-body text-center py-5">
                    <i class="fas fa-ban text-danger" style="font-size: 80px;"></i>
                    <h2 class="mt-3">Access Denied</h2>
                    <p class="text-muted">You don't have permission to access this page.</p>
                    <a href="<?= url('dashboard') ?>" class="btn btn-primary">
                        <i class="fas fa-arrow-left me-1"></i>Back to Dashboard
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>