<?php
// ======================================================
// HALAMAN DETAIL MATERIAL TRANSFER
// ======================================================

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// ============================================================
// PERBAIKAN: PAKAI from_warehouse_id (sesuai database)
// ============================================================
$transfer = fetchOne("
    SELECT 
        mt.*,
        w.WarehouseName,
        wo.WONumber,
        wo.ProductID,
        p.ProductName
    FROM material_transfers mt
    LEFT JOIN warehouses w ON mt.from_warehouse_id = w.WarehouseID
    LEFT JOIN production_orders wo ON mt.ProductionOrderID = wo.ProductionOrderID
    LEFT JOIN products p ON wo.ProductID = p.ProductID
    WHERE mt.TransferID = ?
", [$id]);

if(!$transfer) {
    header("Location: index.php?page=material_transfers&msg=Transfer not found&type=danger");
    exit;
}

// Get Transfer Details
$details = fetchAll("
    SELECT 
        td.*,
        m.MaterialCode,
        m.MaterialName,
        m.UOM
    FROM transfer_details td
    LEFT JOIN materials m ON td.MaterialID = m.MaterialID
    WHERE td.TransferID = ?
    ORDER BY td.TransferDetailID
", [$id]);

// Calculate totals
$totalQty = 0;
foreach($details as $d) {
    $totalQty += $d['QtyTransfer'];
}
?>

<div id="page-content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3">
                <i class="fas fa-arrow-right me-2 text-primary"></i>Material Transfer Detail
            </h1>
            <p class="text-muted">View material transfer details</p>
        </div>
        <div>
            <a href="<?= url('material_transfers', 'edit', ['id' => $id]) ?>" class="btn btn-primary">
                <i class="fas fa-edit me-1"></i>Edit
            </a>
            <a href="<?= url('material_transfers') ?>" class="btn btn-secondary">
                <i class="fas fa-arrow-left me-1"></i>Back
            </a>
        </div>
    </div>

    <!-- Transfer Information -->
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-info-circle me-1"></i> Transfer Information
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <table class="table table-bordered mb-0">
                        <tr>
                            <th width="35%">Transfer Number</th>
                            <td><span class="badge bg-info"><?= htmlspecialchars($transfer['TransferNumber']) ?></span></td>
                        </tr>
                        <tr>
                            <th>Transfer Date</th>
                            <td><?= date('d/m/Y', strtotime($transfer['TransferDate'])) ?></td>
                        </tr>
                        <tr>
                            <th>Status</th>
                            <td><?= getStatusBadge($transfer['Status']) ?></td>
                        </tr>
                        <tr>
                            <th>From Warehouse</th>
                            <td><?= htmlspecialchars($transfer['WarehouseName']) ?></td>
                        </tr>
                    </table>
                </div>
                <div class="col-md-6">
                    <table class="table table-bordered mb-0">
                        <tr>
                            <th width="35%">To Department</th>
                            <td><?= htmlspecialchars($transfer['ToDepartment']) ?></td>
                        </tr>
                        <tr>
                            <th>Issued By</th>
                            <td><?= htmlspecialchars($transfer['IssuedBy']) ?></td>
                        </tr>
                        <tr>
                            <th>Received By</th>
                            <td><?= htmlspecialchars($transfer['ReceivedBy']) ?: '-' ?></td>
                        </tr>
                        <?php if($transfer['WONumber']): ?>
                        <tr>
                            <th>Work Order</th>
                            <td><?= htmlspecialchars($transfer['WONumber']) ?></td>
                        </tr>
                        <?php endif; ?>
                        <?php if($transfer['ProductName']): ?>
                        <tr>
                            <th>Product</th>
                            <td><?= htmlspecialchars($transfer['ProductName']) ?></td>
                        </tr>
                        <?php endif; ?>
                    </table>
                </div>
            </div>
            <?php if($transfer['Notes']): ?>
            <div class="row mt-3">
                <div class="col-12">
                    <div class="alert alert-info">
                        <strong>Notes:</strong> <?= nl2br(htmlspecialchars($transfer['Notes'])) ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Items -->
    <div class="card">
        <div class="card-header">
            <i class="fas fa-list me-1"></i> Items
            <span class="badge bg-secondary float-end">Total Qty: <?= number_format($totalQty) ?></span>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-striped mb-0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Material Code</th>
                            <th>Material Name</th>
                            <th>UOM</th>
                            <th class="text-end">Qty Transfer</th>
                            <th class="text-end">Qty Received</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($details)): ?>
                        <tr>
                            <td colspan="6" class="text-center text-muted py-3">No items found</td>
                        </tr>
                        <?php else: ?>
                        <?php $no = 1; foreach($details as $row): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= htmlspecialchars($row['MaterialCode']) ?></td>
                            <td><?= htmlspecialchars($row['MaterialName']) ?></td>
                            <td><?= htmlspecialchars($row['UOM']) ?></td>
                            <td class="text-end"><?= number_format($row['QtyTransfer']) ?></td>
                            <td class="text-end"><?= number_format($row['QtyReceived']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>