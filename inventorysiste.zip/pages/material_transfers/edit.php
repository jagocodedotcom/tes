<?php
// ======================================================
// HALAMAN EDIT MATERIAL TRANSFER
// ======================================================
ob_start();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Get Transfer Header
$transfer = fetchOne("SELECT * FROM material_transfers WHERE TransferID = ?", [$id]);

if(!$transfer) {
    ob_clean();
    header("Location: index.php?page=material_transfers&msg=Transfer not found&type=danger");
    exit;
}

// Get warehouses for dropdown
$warehouses = fetchAll("SELECT WarehouseID, WarehouseName FROM warehouses WHERE IsActive = 1 ORDER BY WarehouseName");

// Get Production Orders for dropdown (yang masih Open/Running)
$workOrders = fetchAll("
    SELECT ProductionOrderID, WONumber 
    FROM production_orders 
    WHERE Status IN ('Open', 'Running') 
    ORDER BY WONumber
");

// Get materials for dropdown
$materials = fetchAll("SELECT MaterialID, MaterialCode, MaterialName, UOM FROM materials WHERE Active = 1 ORDER BY MaterialName");

// Get existing transfer details
$existingDetails = fetchAll("
    SELECT 
        td.*,
        m.MaterialCode,
        m.MaterialName,
        m.UOM
    FROM transfer_details td
    LEFT JOIN materials m ON td.MaterialID = m.MaterialID
    WHERE td.TransferID = ?
    ORDER BY td.TransferDetailID
", [$id]);

// Proses submit form
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $transferDate = $_POST['transfer_date'];
    $productionOrderID = isset($_POST['production_order_id']) ? (int)$_POST['production_order_id'] : null;
    
    // ============================================================
    // PERBAIKAN: from_warehouse_id (sesuai database)
    // ============================================================
    $fromWarehouseID = isset($_POST['from_warehouse_id']) ? (int)$_POST['from_warehouse_id'] : 0;
    
    $toDepartment = trim($_POST['to_department']);
    $status = $_POST['status'];
    $issuedBy = trim($_POST['issued_by']);
    $receivedBy = trim($_POST['received_by']);
    $notes = trim($_POST['notes']);
    
    // Ambil data items dari form
    $detailIDs = isset($_POST['detail_id']) ? $_POST['detail_id'] : [];
    $materialIDs = isset($_POST['material_id']) ? $_POST['material_id'] : [];
    $qtys = isset($_POST['qty']) ? $_POST['qty'] : [];
    
    $errors = [];
    
    // Validasi
    if(empty($transferDate)) $errors[] = "Transfer Date is required";
    if(empty($fromWarehouseID)) $errors[] = "From Warehouse is required";
    if(empty($toDepartment)) $errors[] = "To Department is required";
    if(empty($issuedBy)) $errors[] = "Issued By is required";
    if(empty($materialIDs) || count($materialIDs) == 0) $errors[] = "At least one item is required";
    
    // Validasi setiap item
    foreach($materialIDs as $index => $mid) {
        if(empty($mid)) $errors[] = "Item #" . ($index+1) . ": Material is required";
        if(empty($qtys[$index]) || $qtys[$index] <= 0) $errors[] = "Item #" . ($index+1) . ": Quantity must be greater than 0";
    }
    
    // Jika status berubah menjadi 'Received', cek apakah sudah ada ReceivedBy
    if($status == 'Received' && empty($receivedBy)) {
        $errors[] = "Received By is required when status is Received";
    }
    
    if(empty($errors)) {
        try {
            // ============================================================
            // UPDATE HEADER - PAKAI from_warehouse_id (sesuai database)
            // ============================================================
            $sql = "UPDATE material_transfers SET 
                    TransferDate = ?, 
                    ProductionOrderID = ?, 
                    from_warehouse_id = ?, 
                    ToDepartment = ?, 
                    Status = ?,
                    IssuedBy = ?,
                    ReceivedBy = ?,
                    Notes = ?
                    WHERE TransferID = ?";
            query($sql, [$transferDate, $productionOrderID, $fromWarehouseID, $toDepartment, $status, $issuedBy, $receivedBy, $notes, $id]);
            
            // Delete existing details
            query("DELETE FROM transfer_details WHERE TransferID = ?", [$id]);
            
            // Insert new details
            foreach($materialIDs as $index => $materialID) {
                if(empty($materialID)) continue;
                $qty = $qtys[$index];
                
                $sqlDetail = "INSERT INTO transfer_details (TransferID, MaterialID, QtyTransfer) 
                              VALUES (?, ?, ?)";
                query($sqlDetail, [$id, $materialID, $qty]);
            }
            
            ob_clean();
            header("Location: index.php?page=material_transfers&msg=updated&type=success");
            exit;
        } catch(PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}

ob_end_clean();
?>
<div id="page-content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3"><i class="fas fa-edit me-2 text-primary"></i>Edit Material Transfer</h1>
            <p class="text-muted">Edit material transfer: <?= htmlspecialchars($transfer['TransferNumber']) ?></p>
        </div>
        <a href="<?= url('material_transfers') ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i>Back
        </a>
    </div>

    <?php if(isset($errors) && !empty($errors)): ?>
    <div class="alert alert-danger">
        <strong><i class="fas fa-exclamation-circle me-1"></i> Please fix the following errors:</strong>
        <ul class="mb-0 mt-1">
            <?php foreach($errors as $error): ?>
            <li><?= htmlspecialchars($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header"><i class="fas fa-edit me-1"></i> Edit Material Transfer Form</div>
        <div class="card-body">
            <form method="POST" action="" id="transferForm">
                <div class="row g-3">
                    <!-- Transfer Date -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Transfer Date <span class="text-danger">*</span></label>
                        <input type="date" name="transfer_date" class="form-control" 
                               value="<?= $transfer['TransferDate'] ?>" 
                               required>
                    </div>
                    
                    <!-- Work Order -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Work Order</label>
                        <select name="production_order_id" class="form-select">
                            <option value="">-- Without WO --</option>
                            <?php foreach($workOrders as $wo): ?>
                            <option value="<?= $wo['ProductionOrderID'] ?>" 
                                    <?= $transfer['ProductionOrderID'] == $wo['ProductionOrderID'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($wo['WONumber']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                        <small class="text-muted">Optional: Select WO if this transfer is for a work order</small>
                    </div>
                    
                    <!-- Status -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Status <span class="text-danger">*</span></label>
                        <select name="status" class="form-select" required>
                            <option value="Draft" <?= $transfer['Status'] == 'Draft' ? 'selected' : '' ?>>Draft</option>
                            <option value="Issued" <?= $transfer['Status'] == 'Issued' ? 'selected' : '' ?>>Issued</option>
                            <option value="Received" <?= $transfer['Status'] == 'Received' ? 'selected' : '' ?>>Received</option>
                            <option value="Cancelled" <?= $transfer['Status'] == 'Cancelled' ? 'selected' : '' ?>>Cancelled</option>
                        </select>
                        <?php if($transfer['Status'] != 'Draft'): ?>
                        <small class="text-warning">
                            <i class="fas fa-info-circle me-1"></i>
                            Current status: <strong><?= $transfer['Status'] ?></strong>
                        </small>
                        <?php endif; ?>
                    </div>
                    
                    <!-- From Warehouse -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">From Warehouse <span class="text-danger">*</span></label>
                        <select name="from_warehouse_id" class="form-select" required>
                            <option value="">-- Select Warehouse --</option>
                            <?php foreach($warehouses as $wh): ?>
                            <option value="<?= $wh['WarehouseID'] ?>" 
                                    <?= $transfer['from_warehouse_id'] == $wh['WarehouseID'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($wh['WarehouseName']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <!-- To Department -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">To Department <span class="text-danger">*</span></label>
                        <select name="to_department" class="form-select" required>
                            <option value="">-- Select Department --</option>
                            <option value="Produksi" <?= $transfer['ToDepartment'] == 'Produksi' ? 'selected' : '' ?>>Produksi</option>
                            <option value="QC" <?= $transfer['ToDepartment'] == 'QC' ? 'selected' : '' ?>>QC</option>
                            <option value="Packing" <?= $transfer['ToDepartment'] == 'Packing' ? 'selected' : '' ?>>Packing</option>
                            <option value="Assembly" <?= $transfer['ToDepartment'] == 'Assembly' ? 'selected' : '' ?>>Assembly</option>
                        </select>
                    </div>
                    
                    <!-- Issued By -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Issued By <span class="text-danger">*</span></label>
                        <input type="text" name="issued_by" class="form-control" 
                               placeholder="e.g: warehouse1" 
                               value="<?= htmlspecialchars($transfer['IssuedBy']) ?>" 
                               required>
                    </div>
                    
                    <!-- Received By -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Received By</label>
                        <input type="text" name="received_by" class="form-control" 
                               placeholder="e.g: production1" 
                               value="<?= htmlspecialchars($transfer['ReceivedBy']) ?>">
                        <small class="text-muted">Required if status is Received</small>
                    </div>
                    
                    <!-- Created Info -->
                    <div class="col-12">
                        <div class="alert alert-info">
                            <small>
                                <i class="fas fa-info-circle me-1"></i>
                                Transfer Number: <strong><?= htmlspecialchars($transfer['TransferNumber']) ?></strong><br>
                                Created: <?= date('d/m/Y H:i', strtotime($transfer['CreatedAt'])) ?>
                                <?php if($transfer['UpdatedAt'] != $transfer['CreatedAt']): ?>
                                <br>Updated: <?= date('d/m/Y H:i', strtotime($transfer['UpdatedAt'])) ?>
                                <?php endif; ?>
                            </small>
                        </div>
                    </div>
                    
                    <!-- Notes -->
                    <div class="col-12">
                        <label class="form-label fw-bold">Notes</label>
                        <textarea name="notes" class="form-control" rows="2" 
                                  placeholder="Additional notes"><?= htmlspecialchars($transfer['Notes']) ?></textarea>
                    </div>
                    
                    <!-- Items Section -->
                    <div class="col-12">
                        <hr>
                        <h5 class="fw-bold"><i class="fas fa-list me-2"></i>Items</h5>
                        <div id="itemsContainer">
                            <?php if(empty($existingDetails)): ?>
                            <div class="row g-2 item-row">
                                <div class="col-md-7">
                                    <select name="material_id[]" class="form-select" required>
                                        <option value="">-- Select Material --</option>
                                        <?php foreach($materials as $mat): ?>
                                        <option value="<?= $mat['MaterialID'] ?>">
                                            <?= htmlspecialchars($mat['MaterialCode']) ?> - <?= htmlspecialchars($mat['MaterialName']) ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <input type="number" name="qty[]" class="form-control" placeholder="Qty Transfer" min="1" required>
                                </div>
                                <div class="col-md-1">
                                    <button type="button" class="btn btn-danger btn-sm remove-item" style="display:none;">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                            </div>
                            <?php else: ?>
                            <?php foreach($existingDetails as $index => $item): ?>
                            <div class="row g-2 item-row">
                                <input type="hidden" name="detail_id[]" value="<?= $item['TransferDetailID'] ?>">
                                <div class="col-md-7">
                                    <select name="material_id[]" class="form-select" required>
                                        <option value="">-- Select Material --</option>
                                        <?php foreach($materials as $mat): ?>
                                        <option value="<?= $mat['MaterialID'] ?>" 
                                                <?= $item['MaterialID'] == $mat['MaterialID'] ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($mat['MaterialCode']) ?> - <?= htmlspecialchars($mat['MaterialName']) ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <input type="number" name="qty[]" class="form-control" placeholder="Qty Transfer" min="1" 
                                           value="<?= $item['QtyTransfer'] ?>" required>
                                </div>
                                <div class="col-md-1">
                                    <button type="button" class="btn btn-danger btn-sm remove-item" 
                                            <?= (count($existingDetails) <= 1) ? 'style="display:none;"' : '' ?>>
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                                <?php if($item['QtyReceived'] > 0): ?>
                                <div class="col-12">
                                    <small class="text-muted">
                                        <i class="fas fa-info-circle me-1"></i>
                                        Already received: <?= number_format($item['QtyReceived']) ?>
                                    </small>
                                </div>
                                <?php endif; ?>
                            </div>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                        <button type="button" class="btn btn-sm btn-outline-primary mt-2" id="addItem">
                            <i class="fas fa-plus me-1"></i>Add Item
                        </button>
                    </div>
                    
                    <!-- Buttons -->
                    <div class="col-12">
                        <hr>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Update Transfer
                        </button>
                        
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Add new item row
document.getElementById('addItem').addEventListener('click', function() {
    var container = document.getElementById('itemsContainer');
    var rows = container.querySelectorAll('.item-row');
    var lastRow = rows[rows.length - 1];
    var newRow = lastRow.cloneNode(true);
    
    // Reset values
    newRow.querySelectorAll('input').forEach(function(input) {
        if(input.type != 'hidden') {
            input.value = '';
        }
    });
    newRow.querySelectorAll('select').forEach(function(select) {
        select.selectedIndex = 0;
    });
    
    // Show remove button
    var removeBtn = newRow.querySelector('.remove-item');
    removeBtn.style.display = 'inline-block';
    
    // Remove info message
    var infoDiv = newRow.querySelector('.col-12');
    if(infoDiv) {
        infoDiv.remove();
    }
    
    container.appendChild(newRow);
});

// Remove item row
document.addEventListener('click', function(e) {
    if (e.target.closest('.remove-item')) {
        var row = e.target.closest('.item-row');
        if (document.querySelectorAll('.item-row').length > 1) {
            row.remove();
        }
    }
});
</script>