<?php
// ======================================================
// PROSES HAPUS MATERIAL TRANSFER
// ======================================================
ob_start();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$transfer = fetchOne("SELECT * FROM material_transfers WHERE TransferID = ?", [$id]);

if(!$transfer) {
    ob_clean();
    header("Location: index.php?page=material_transfers&msg=Transfer not found&type=danger");
    exit;
}

// Cek apakah transfer sudah memiliki received items
$hasReceived = fetchCount("SELECT COUNT(*) FROM transfer_details WHERE TransferID = ? AND QtyReceived > 0", [$id]);

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    if($hasReceived > 0 || $transfer['Status'] == 'Received') {
        // Soft delete - hanya ubah status
        query("UPDATE material_transfers SET Status = 'Cancelled' WHERE TransferID = ?", [$id]);
    } else {
        // Permanent delete
        query("DELETE FROM transfer_details WHERE TransferID = ?", [$id]);
        query("DELETE FROM material_transfers WHERE TransferID = ?", [$id]);
    }
    
    ob_clean();
    header("Location: index.php?page=material_transfers&msg=deleted&type=success");
    exit;
}

ob_end_clean();
?>
<div id="page-content-wrapper">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-header bg-danger text-white">
                    <i class="fas fa-exclamation-triangle me-1"></i> Confirm Delete
                </div>
                <div class="card-body text-center py-4">
                    <i class="fas fa-arrow-right fa-4x text-danger mb-3"></i>
                    <h4>Are you sure you want to delete this material transfer?</h4>
                    <p class="text-muted">
                        <strong><?= htmlspecialchars($transfer['TransferNumber']) ?></strong>
                        <br>
                        Date: <?= date('d/m/Y', strtotime($transfer['TransferDate'])) ?>
                        <br>
                        Status: <?= $transfer['Status'] ?>
                    </p>
                    
                    <?php if($hasReceived > 0 || $transfer['Status'] == 'Received'): ?>
                    <div class="alert alert-warning">
                        <i class="fas fa-info-circle me-1"></i>
                        This transfer has already been <strong>received</strong>.
                        Transfer will be <strong>cancelled</strong> instead of permanently deleted.
                    </div>
                    <?php else: ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-info-circle me-1"></i>
                        This transfer has <strong>no received items</strong>.
                        Transfer will be <strong>permanently deleted</strong>.
                    </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="" class="d-inline">
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash me-1"></i> Yes, Delete
                        </button>
                        <a href="<?= url('material_transfers') ?>" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i> Cancel
                        </a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>