<?php
// ======================================================
// HALAMAN LIST MATERIAL TRANSFERS
// ======================================================

// Pagination
$page = isset($_GET['page_num']) ? (int)$_GET['page_num'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

// Search
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Build Query
$whereClause = "WHERE 1=1";
$params = [];

if (!empty($search)) {
    $whereClause .= " AND (mt.TransferNumber LIKE ? OR wo.WONumber LIKE ?)";
    $searchTerm = "%$search%";
    $params = [$searchTerm, $searchTerm];
}

// Get Total Data
$totalQuery = "
    SELECT COUNT(*) 
    FROM material_transfers mt
    LEFT JOIN production_orders wo ON mt.ProductionOrderID = wo.ProductionOrderID
    $whereClause
";
$totalData = fetchCount($totalQuery, $params);
$totalPages = ceil($totalData / $limit);

// ============================================================
// PERBAIKAN: PAKAI from_warehouse_id (sesuai database)
// ============================================================
$query = "
    SELECT 
        mt.TransferID,
        mt.TransferNumber,
        mt.TransferDate,
        mt.from_warehouse_id,
        w.WarehouseName,
        mt.ToDepartment,
        mt.Status,
        mt.IssuedBy,
        mt.ReceivedBy,
        mt.CreatedAt,
        wo.WONumber,
        (SELECT COUNT(*) FROM transfer_details WHERE TransferID = mt.TransferID) AS TotalItems,
        (SELECT COALESCE(SUM(QtyTransfer), 0) FROM transfer_details WHERE TransferID = mt.TransferID) AS TotalQty
    FROM material_transfers mt
    LEFT JOIN warehouses w ON mt.from_warehouse_id = w.WarehouseID
    LEFT JOIN production_orders wo ON mt.ProductionOrderID = wo.ProductionOrderID
    $whereClause
    ORDER BY mt.TransferDate DESC
    LIMIT $limit OFFSET $offset
";
$transfers = fetchAll($query, $params);

// Get Success/Error Message
$message = isset($_GET['msg']) ? $_GET['msg'] : '';
$messageType = isset($_GET['type']) ? $_GET['type'] : '';
?>

<div id="page-content-wrapper">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3">
                <i class="fas fa-arrow-right me-2 text-primary"></i>Material Transfers
            </h1>
            <p class="text-muted">Manage material transfers to production</p>
        </div>
        <a href="<?= url('material_transfers', 'create') ?>" class="btn btn-primary">
            <i class="fas fa-plus me-1"></i>Add Transfer
        </a>
    </div>

    <!-- Alert Message -->
    <?php if($message): ?>
    <div class="alert alert-<?= $messageType ?> alert-dismissible fade show" role="alert">
        <?php 
        if($message == 'created') echo 'Material Transfer berhasil dibuat!';
        elseif($message == 'updated') echo 'Material Transfer berhasil diperbarui!';
        elseif($message == 'deleted') echo 'Material Transfer berhasil dihapus!';
        else echo htmlspecialchars($message);
        ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <!-- Search -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <input type="hidden" name="page" value="material_transfers">
                <div class="col-md-10">
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                        <input type="text" name="search" class="form-control" 
                               placeholder="Search by transfer number or WO..." 
                               value="<?= htmlspecialchars($search) ?>">
                    </div>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search me-1"></i>Search
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Table -->
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <span><i class="fas fa-list me-1"></i> Material Transfer List</span>
                <span class="badge bg-primary"><?= number_format($totalData) ?> Records</span>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover table-striped mb-0">
                    <thead>
                        <tr>
                            <th width="50">#</th>
                            <th>Transfer Number</th>
                            <th>Date</th>
                            <th>WO Number</th>
                            <th>From Warehouse</th>
                            <th>To Department</th>
                            <th>Items</th>
                            <th>Qty</th>
                            <th>Status</th>
                            <th>Issued By</th>
                            <th width="120">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($transfers)): ?>
                        <tr>
                            <td colspan="11" class="text-center text-muted py-4">
                                <i class="fas fa-inbox fa-2x d-block mb-2"></i>
                                No material transfers found
                            </td>
                        </tr>
                        <?php else: ?>
                        <?php 
                        $no = $offset + 1;
                        foreach($transfers as $row): 
                        ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td>
                                <span class="badge bg-info"><?= htmlspecialchars($row['TransferNumber']) ?></span>
                            </td>
                            <td><?= date('d/m/Y', strtotime($row['TransferDate'])) ?></td>
                            <td>
                                <?php if($row['WONumber']): ?>
                                <?= htmlspecialchars($row['WONumber']) ?>
                                <?php else: ?>
                                <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($row['WarehouseName']) ?></td>
                            <td><?= htmlspecialchars($row['ToDepartment']) ?></td>
                            <td>
                                <span class="badge bg-secondary"><?= number_format($row['TotalItems']) ?></span>
                            </td>
                            <td><?= number_format($row['TotalQty']) ?></td>
                            <td><?= getStatusBadge($row['Status']) ?></td>
                            <td><?= htmlspecialchars($row['IssuedBy']) ?></td>
                            <td>
                                <div class="btn-group btn-group-sm">
                                    <a href="<?= url('material_transfers', 'view', ['id' => $row['TransferID']]) ?>" 
                                       class="btn btn-outline-info" title="View">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="<?= url('material_transfers', 'edit', ['id' => $row['TransferID']]) ?>" 
                                       class="btn btn-outline-primary" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="<?= url('material_transfers', 'delete', ['id' => $row['TransferID']]) ?>" 
                                       class="btn btn-outline-danger" title="Delete"
                                       onclick="return confirm('Are you sure you want to delete this transfer?')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php if($totalPages > 1): ?>
        <div class="card-footer">
            <nav>
                <ul class="pagination pagination-sm mb-0">
                    <?php if($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=material_transfers&page_num=<?= $page-1 ?>&search=<?= urlencode($search) ?>">
                            <i class="fas fa-chevron-left"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <?php for($i = 1; $i <= $totalPages; $i++): ?>
                    <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                        <a class="page-link" href="?page=material_transfers&page_num=<?= $i ?>&search=<?= urlencode($search) ?>">
                            <?= $i ?>
                        </a>
                    </li>
                    <?php endfor; ?>
                    
                    <?php if($page < $totalPages): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=material_transfers&page_num=<?= $page+1 ?>&search=<?= urlencode($search) ?>">
                            <i class="fas fa-chevron-right"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
        <?php endif; ?>
    </div>
</div>