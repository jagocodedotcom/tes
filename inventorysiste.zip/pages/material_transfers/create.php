<?php
// ======================================================
// HALAMAN TAMBAH MATERIAL TRANSFER
// ======================================================
ob_start();

// Get warehouses for dropdown
$warehouses = fetchAll("SELECT WarehouseID, WarehouseName FROM warehouses WHERE IsActive = 1 ORDER BY WarehouseName");

// Get Production Orders for dropdown (yang masih Open/Running)
$workOrders = fetchAll("
    SELECT ProductionOrderID, WONumber 
    FROM production_orders 
    WHERE Status IN ('Open', 'Running') 
    ORDER BY WONumber
");

// Get materials for dropdown
$materials = fetchAll("SELECT MaterialID, MaterialCode, MaterialName, UOM FROM materials WHERE Active = 1 ORDER BY MaterialName");

// Proses submit form
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $transferDate = $_POST['transfer_date'];
    $productionOrderID = isset($_POST['production_order_id']) ? (int)$_POST['production_order_id'] : null;
    
    // ============================================================
    // PERBAIKAN: from_warehouse_id (sesuai database)
    // ============================================================
    $fromWarehouseID = isset($_POST['from_warehouse_id']) ? (int)$_POST['from_warehouse_id'] : 0;
    
    $toDepartment = trim($_POST['to_department']);
    $issuedBy = trim($_POST['issued_by']);
    
    // Ambil data items dari form
    $materialIDs = isset($_POST['material_id']) ? $_POST['material_id'] : [];
    $qtys = isset($_POST['qty']) ? $_POST['qty'] : [];
    
    $errors = [];
    
    // Validasi
    if(empty($transferDate)) $errors[] = "Transfer Date is required";
    if(empty($fromWarehouseID)) $errors[] = "From Warehouse is required";
    if(empty($toDepartment)) $errors[] = "To Department is required";
    if(empty($issuedBy)) $errors[] = "Issued By is required";
    if(empty($materialIDs) || count($materialIDs) == 0) $errors[] = "At least one item is required";
    
    // Validasi setiap item
    foreach($materialIDs as $index => $mid) {
        if(empty($mid)) $errors[] = "Item #" . ($index+1) . ": Material is required";
        if(empty($qtys[$index]) || $qtys[$index] <= 0) $errors[] = "Item #" . ($index+1) . ": Quantity must be greater than 0";
        
        // ============================================================
        // Cek stock availability - PAKAI WarehouseID (di material_stock)
        // ============================================================
        if(!empty($mid) && !empty($qtys[$index])) {
            $stock = fetchOne("
                SELECT QtyAvailable 
                FROM material_stock 
                WHERE MaterialID = ? AND WarehouseID = ?
            ", [$mid, $fromWarehouseID]);
            
            if(!$stock || $stock['QtyAvailable'] < $qtys[$index]) {
                $materialName = fetchOne("SELECT MaterialName FROM materials WHERE MaterialID = ?", [$mid]);
                $available = $stock ? $stock['QtyAvailable'] : 0;
                $errors[] = "Item #" . ($index+1) . ": Insufficient stock for " . ($materialName ? $materialName['MaterialName'] : 'Material') . 
                            " (Available: " . number_format($available) . ", Requested: " . number_format($qtys[$index]) . ")";
            }
        }
    }
    
    if(empty($errors)) {
        try {
            // Generate Transfer Number
            $year = date('Y');
            $month = date('m');
            $lastTransfer = fetchOne("SELECT TransferNumber FROM material_transfers ORDER BY TransferID DESC LIMIT 1");
            $lastNumber = 0;
            if($lastTransfer) {
                $lastNumber = (int)substr($lastTransfer['TransferNumber'], -4);
            }
            $newNumber = str_pad($lastNumber + 1, 4, '0', STR_PAD_LEFT);
            $transferNumber = 'TR-' . $year . $month . '-' . $newNumber;
            
            // ============================================================
            // INSERT HEADER - PAKAI from_warehouse_id (sesuai database)
            // ============================================================
            $sql = "INSERT INTO material_transfers (TransferNumber, TransferDate, ProductionOrderID, from_warehouse_id, ToDepartment, Status, IssuedBy) 
                    VALUES (?, ?, ?, ?, ?, 'Issued', ?)";
            query($sql, [$transferNumber, $transferDate, $productionOrderID, $fromWarehouseID, $toDepartment, $issuedBy]);
            $transferID = $pdo->lastInsertId();
            
            // Insert Transfer Details
            foreach($materialIDs as $index => $materialID) {
                if(empty($materialID)) continue;
                $qty = $qtys[$index];
                
                $sqlDetail = "INSERT INTO transfer_details (TransferID, MaterialID, QtyTransfer) 
                              VALUES (?, ?, ?)";
                query($sqlDetail, [$transferID, $materialID, $qty]);
                
                // ============================================================
                // Update stock reserved - PAKAI WarehouseID (di material_stock)
                // ============================================================
                query("UPDATE material_stock SET QtyReserved = QtyReserved + ? WHERE MaterialID = ? AND WarehouseID = ?", 
                      [$qty, $materialID, $fromWarehouseID]);
            }
            
            ob_clean();
            header("Location: index.php?page=material_transfers&msg=created&type=success");
            exit;
        } catch(PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}

ob_end_clean();
?>
<div id="page-content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3"><i class="fas fa-arrow-right-plus me-2 text-primary"></i>Add Material Transfer</h1>
            <p class="text-muted">Create new material transfer to production</p>
        </div>
        <a href="<?= url('material_transfers') ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i>Back
        </a>
    </div>

    <?php if(isset($errors) && !empty($errors)): ?>
    <div class="alert alert-danger">
        <strong><i class="fas fa-exclamation-circle me-1"></i> Please fix the following errors:</strong>
        <ul class="mb-0 mt-1">
            <?php foreach($errors as $error): ?>
            <li><?= htmlspecialchars($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header"><i class="fas fa-edit me-1"></i> Material Transfer Form</div>
        <div class="card-body">
            <form method="POST" action="" id="transferForm">
                <div class="row g-3">
                    <!-- Transfer Date -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Transfer Date <span class="text-danger">*</span></label>
                        <input type="date" name="transfer_date" class="form-control" 
                               value="<?= isset($_POST['transfer_date']) ? $_POST['transfer_date'] : date('Y-m-d') ?>" 
                               required>
                    </div>
                    
                    <!-- Work Order -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Work Order</label>
                        <select name="production_order_id" class="form-select">
                            <option value="">-- Without WO --</option>
                            <?php foreach($workOrders as $wo): ?>
                            <option value="<?= $wo['ProductionOrderID'] ?>" 
                                    <?= (isset($_POST['production_order_id']) && $_POST['production_order_id'] == $wo['ProductionOrderID']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($wo['WONumber']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                        <small class="text-muted">Optional: Select WO if this transfer is for a work order</small>
                    </div>
                    
                    <!-- From Warehouse -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">From Warehouse <span class="text-danger">*</span></label>
                        <select name="from_warehouse_id" class="form-select" required>
                            <option value="">-- Select Warehouse --</option>
                            <?php foreach($warehouses as $wh): ?>
                            <option value="<?= $wh['WarehouseID'] ?>" 
                                    <?= (isset($_POST['from_warehouse_id']) && $_POST['from_warehouse_id'] == $wh['WarehouseID']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($wh['WarehouseName']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <!-- To Department -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">To Department <span class="text-danger">*</span></label>
                        <select name="to_department" class="form-select" required>
                            <option value="">-- Select Department --</option>
                            <option value="Produksi" <?= (isset($_POST['to_department']) && $_POST['to_department'] == 'Produksi') ? 'selected' : '' ?>>Produksi</option>
                            <option value="QC" <?= (isset($_POST['to_department']) && $_POST['to_department'] == 'QC') ? 'selected' : '' ?>>QC</option>
                            <option value="Packing" <?= (isset($_POST['to_department']) && $_POST['to_department'] == 'Packing') ? 'selected' : '' ?>>Packing</option>
                            <option value="Assembly" <?= (isset($_POST['to_department']) && $_POST['to_department'] == 'Assembly') ? 'selected' : '' ?>>Assembly</option>
                        </select>
                    </div>
                    
                    <!-- Issued By -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Issued By <span class="text-danger">*</span></label>
                        <input type="text" name="issued_by" class="form-control" 
                               placeholder="e.g: warehouse1" 
                               value="<?= isset($_POST['issued_by']) ? htmlspecialchars($_POST['issued_by']) : '' ?>" 
                               required>
                    </div>
                    
                    <!-- Items Section -->
                    <div class="col-12">
                        <hr>
                        <h5 class="fw-bold"><i class="fas fa-list me-2"></i>Items</h5>
                        <div id="itemsContainer">
                            <div class="row g-2 item-row">
                                <div class="col-md-7">
                                    <select name="material_id[]" class="form-select" required>
                                        <option value="">-- Select Material --</option>
                                        <?php foreach($materials as $mat): ?>
                                        <option value="<?= $mat['MaterialID'] ?>">
                                            <?= htmlspecialchars($mat['MaterialCode']) ?> - <?= htmlspecialchars($mat['MaterialName']) ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <input type="number" name="qty[]" class="form-control" placeholder="Qty Transfer" min="1" required>
                                </div>
                                <div class="col-md-1">
                                    <button type="button" class="btn btn-danger btn-sm remove-item" style="display:none;">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <button type="button" class="btn btn-sm btn-outline-primary mt-2" id="addItem">
                            <i class="fas fa-plus me-1"></i>Add Item
                        </button>
                    </div>
                    
                    <!-- Buttons -->
                    <div class="col-12">
                        <hr>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Create Transfer
                        </button>
                        <!-- <a href="<?= url('material_transfers') ?>" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i>Cancel
                        </a> -->
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Add new item row
document.getElementById('addItem').addEventListener('click', function() {
    var container = document.getElementById('itemsContainer');
    var rows = container.querySelectorAll('.item-row');
    var lastRow = rows[rows.length - 1];
    var newRow = lastRow.cloneNode(true);
    
    // Reset values
    newRow.querySelectorAll('input').forEach(function(input) {
        input.value = '';
    });
    newRow.querySelectorAll('select').forEach(function(select) {
        select.selectedIndex = 0;
    });
    
    // Show remove button
    var removeBtn = newRow.querySelector('.remove-item');
    removeBtn.style.display = 'inline-block';
    
    container.appendChild(newRow);
});

// Remove item row
document.addEventListener('click', function(e) {
    if (e.target.closest('.remove-item')) {
        var row = e.target.closest('.item-row');
        if (document.querySelectorAll('.item-row').length > 1) {
            row.remove();
        }
    }
});
</script>