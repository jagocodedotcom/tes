<?php
// ======================================================
// HALAMAN TAMBAH CUSTOMER
// ======================================================

// Proses submit form
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $customerCode = trim($_POST['customer_code']);
    $customerName = trim($_POST['customer_name']);
    $address = trim($_POST['address']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $status = isset($_POST['status']) ? (int)$_POST['status'] : 1;
    
    $errors = [];
    
    // Validasi required
    if(empty($customerCode)) $errors[] = "Customer Code is required";
    if(empty($customerName)) $errors[] = "Customer Name is required";
    if(empty($address)) $errors[] = "Address is required";
    if(empty($phone)) $errors[] = "Phone number is required";
    
    // Validasi phone hanya angka
    if(!empty($phone) && !preg_match('/^[0-9]+$/', $phone)) {
        $errors[] = "Phone number must contain only numbers (0-9)";
    }
    
    // Validasi email format
    if(!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format";
    }
    
    // Cek duplicate code
    if(empty($errors)) {
        $check = fetchOne("SELECT CustomerID FROM customers WHERE CustomerCode = ?", [$customerCode]);
        if($check) {
            $errors[] = "Customer Code already exists!";
        }
    }
    
    if(empty($errors)) {
        try {
            $sql = "INSERT INTO customers (CustomerCode, CustomerName, Address, Phone, Email, Status) 
                    VALUES (?, ?, ?, ?, ?, ?)";
            query($sql, [$customerCode, $customerName, $address, $phone, $email, $status]);
            
            header("Location: index.php?page=customers&msg=created&type=success");
            exit;
        } catch(PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}
?>

<div id="page-content-wrapper" class="p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3"><i class="fas fa-user-plus me-2 text-primary"></i>Add Customer</h1>
            <p class="text-muted">Add new customer data</p>
        </div>
        <a href="index.php?page=customers" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i>Back
        </a>
    </div>

    <?php if(isset($errors) && !empty($errors)): ?>
    <div class="alert alert-danger">
        <strong><i class="fas fa-exclamation-circle me-1"></i> Please fix the following errors:</strong>
        <ul class="mb-0 mt-1">
            <?php foreach($errors as $error): ?>
            <li><?= htmlspecialchars($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header"><i class="fas fa-edit me-1"></i> Customer Form</div>
        <div class="card-body">
            <form method="POST" action="" id="customerForm">
                <div class="row g-3">
                    <!-- Customer Code -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Customer Code <span class="text-danger">*</span></label>
                        <input type="text" name="customer_code" class="form-control" 
                               placeholder="e.g: CUST-001" 
                               value="<?= isset($_POST['customer_code']) ? htmlspecialchars($_POST['customer_code']) : '' ?>" 
                               required>
                        <small class="text-muted">Unique identifier for the customer</small>
                    </div>
                    
                    <!-- Customer Name -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Customer Name <span class="text-danger">*</span></label>
                        <input type="text" name="customer_name" class="form-control" 
                               placeholder="e.g: PT Indah Plastik" 
                               value="<?= isset($_POST['customer_name']) ? htmlspecialchars($_POST['customer_name']) : '' ?>" 
                               required>
                    </div>
                    
                    <!-- Address (WAJIB) -->
                    <div class="col-12">
                        <label class="form-label fw-bold">Address <span class="text-danger">*</span></label>
                        <textarea name="address" class="form-control" rows="2" 
                                  placeholder="Complete address (e.g: Jl. Industri No. 5, Jakarta)" 
                                  required><?= isset($_POST['address']) ? htmlspecialchars($_POST['address']) : '' ?></textarea>
                        <small class="text-muted">Complete address is required</small>
                    </div>
                    
                    <!-- Phone (WAJIB & HANYA ANGKA) -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Phone <span class="text-danger">*</span></label>
                        <input type="tel" name="phone" class="form-control" 
                               placeholder="e.g: 0217771001" 
                               value="<?= isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : '' ?>" 
                               pattern="[0-9]+" 
                               maxlength="15"
                               required>
                        <small class="text-muted">Numbers only (e.g: 0217771001)</small>
                    </div>
                    
                    <!-- Email -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Email</label>
                        <input type="email" name="email" class="form-control" 
                               placeholder="e.g: info@company.co.id" 
                               value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '' ?>">
                        <small class="text-muted">Optional, but must be valid email format</small>
                    </div>
                    
                    <!-- Status -->
                    <div class="col-12">
                        <label class="form-label fw-bold">Status</label>
                        <div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="status" id="status1" value="1" checked>
                                <label class="form-check-label" for="status1">
                                    <span class="badge bg-success">Active</span>
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="status" id="status0" value="0">
                                <label class="form-check-label" for="status0">
                                    <span class="badge bg-danger">Inactive</span>
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Buttons -->
                    <div class="col-12">
                        <hr>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Save Customer
                        </button>
                     
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- JavaScript untuk validasi phone hanya angka -->
<script>
document.getElementById('customerForm').addEventListener('submit', function(e) {
    var phone = document.querySelector('input[name="phone"]');
    var phoneValue = phone.value.replace(/\D/g, ''); // Hapus semua non-digit
    
    if (phoneValue.length === 0) {
        alert('Phone number is required!');
        e.preventDefault();
        return false;
    }
    
    // Update value dengan hanya angka
    phone.value = phoneValue;
    
    return true;
});

// Validasi real-time: hanya angka yang boleh diinput
document.querySelector('input[name="phone"]').addEventListener('input', function(e) {
    this.value = this.value.replace(/\D/g, '');
});
</script>