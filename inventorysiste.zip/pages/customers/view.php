<?php
// ======================================================
// HALAMAN DETAIL CUSTOMER
// ======================================================

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$customer = fetchOne("SELECT * FROM customers WHERE CustomerID = ?", [$id]);

if(!$customer) {
    header("Location: index.php?page=customers&msg=Customer not found&type=danger");
    exit;
}

$totalOrders = fetchCount("SELECT COUNT(*) FROM customer_pos WHERE CustomerID = ?", [$id]);

// HAPUS TotalAmount karena tidak ada di tabel
$recentOrders = fetchAll("
    SELECT 
        CustomerPOID, 
        PONumber, 
        PODate, 
        DeliveryDate, 
        Status, 
        CreatedAt
    FROM customer_pos 
    WHERE CustomerID = ?
    ORDER BY CreatedAt DESC
    LIMIT 5
", [$id]);
?>

<div id="page-content-wrapper" class="p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3"><i class="fas fa-user me-2 text-primary"></i>Customer Detail</h1>
            <p class="text-muted">View complete customer information</p>
        </div>
        <div>
            <a href="index.php?page=customers&action=edit&id=<?= $id ?>" class="btn btn-primary">
                <i class="fas fa-edit me-1"></i>Edit
            </a>
            <a href="index.php?page=customers" class="btn btn-secondary">
                <i class="fas fa-arrow-left me-1"></i>Back
            </a>
        </div>
    </div>

    <div class="row g-3">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-header"><i class="fas fa-info-circle me-1"></i> Customer Information</div>
                <div class="card-body">
                    <table class="table table-bordered mb-0">
                        <tr>
                            <th width="40%">Customer Code</th>
                            <td><span class="badge bg-info"><?= htmlspecialchars($customer['CustomerCode']) ?></span></td>
                        </tr>
                        <tr>
                            <th>Customer Name</th>
                            <td><strong><?= htmlspecialchars($customer['CustomerName']) ?></strong></td>
                        </tr>
                        <tr>
                            <th>Address</th>
                            <td><?= nl2br(htmlspecialchars($customer['Address'])) ?></td>
                        </tr>
                        <tr>
                            <th>Phone</th>
                            <td><?= htmlspecialchars($customer['Phone']) ?></td>
                        </tr>
                        <tr>
                            <th>Email</th>
                            <td><a href="mailto:<?= htmlspecialchars($customer['Email']) ?>"><?= htmlspecialchars($customer['Email']) ?></a></td>
                        </tr>
                        <tr>
                            <th>Status</th>
                            <td>
                                <?php if($customer['Status'] == 1): ?>
                                <span class="badge bg-success">Active</span>
                                <?php else: ?>
                                <span class="badge bg-danger">Inactive</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>Total Orders</th>
                            <td><span class="badge bg-primary"><?= number_format($totalOrders) ?></span></td>
                        </tr>
                        <tr>
                            <th>Created At</th>
                            <td><?= date('d/m/Y H:i', strtotime($customer['CreatedAt'])) ?></td>
                        </tr>
                        <tr>
                            <th>Updated At</th>
                            <td><?= date('d/m/Y H:i', strtotime($customer['UpdatedAt'])) ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="card">
                <div class="card-header"><i class="fas fa-file-invoice me-1"></i> Recent Orders</div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-sm mb-0">
                            <thead>
                                <tr>
                                    <th>PO Number</th>
                                    <th>Date</th>
                                    <th>Delivery</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(empty($recentOrders)): ?>
                                <tr>
                                    <td colspan="4" class="text-center text-muted py-3">
                                        <i class="fas fa-inbox d-block mb-1"></i>
                                        No orders found
                                    </td>
                                </tr>
                                <?php else: ?>
                                <?php foreach($recentOrders as $order): ?>
                                <tr>
                                    <td><?= htmlspecialchars($order['PONumber']) ?></td>
                                    <td><?= date('d/m/Y', strtotime($order['PODate'])) ?></td>
                                    <td>
                                        <?php if($order['DeliveryDate']): ?>
                                        <?= date('d/m/Y', strtotime($order['DeliveryDate'])) ?>
                                        <?php else: ?>
                                        <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php 
                                        $colors = [
                                            'Open' => 'primary',
                                            'Production' => 'info',
                                            'Partial' => 'warning',
                                            'Completed' => 'success',
                                            'Cancelled' => 'danger'
                                        ];
                                        $color = isset($colors[$order['Status']]) ? $colors[$order['Status']] : 'secondary';
                                        ?>
                                        <span class="badge bg-<?= $color ?>"><?= htmlspecialchars($order['Status']) ?></span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php if($totalOrders > 5): ?>
                    <div class="card-footer text-center">
                        <a href="index.php?page=customer_pos&customer_id=<?= $id ?>" class="btn btn-sm btn-outline-primary">
                            View All Orders
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>