<?php
// ======================================================
// HALAMAN EDIT CUSTOMER
// ======================================================

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$customer = fetchOne("SELECT * FROM customers WHERE CustomerID = ?", [$id]);

if(!$customer) {
    header("Location: index.php?page=customers&msg=Customer not found&type=danger");
    exit;
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $customerCode = trim($_POST['customer_code']);
    $customerName = trim($_POST['customer_name']);
    $address = trim($_POST['address']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $status = isset($_POST['status']) ? (int)$_POST['status'] : 1;
    
    $errors = [];
    
    // Validasi required
    if(empty($customerCode)) $errors[] = "Customer Code is required";
    if(empty($customerName)) $errors[] = "Customer Name is required";
    if(empty($address)) $errors[] = "Address is required";
    if(empty($phone)) $errors[] = "Phone number is required";
    
    // Validasi phone hanya angka
    if(!empty($phone) && !preg_match('/^[0-9]+$/', $phone)) {
        $errors[] = "Phone number must contain only numbers (0-9)";
    }
    
    // Validasi email format
    if(!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format";
    }
    
    if(empty($errors)) {
        $check = fetchOne("SELECT CustomerID FROM customers WHERE CustomerCode = ? AND CustomerID != ?", [$customerCode, $id]);
        if($check) {
            $errors[] = "Customer Code already exists!";
        }
    }
    
    if(empty($errors)) {
        try {
            $sql = "UPDATE customers SET 
                    CustomerCode = ?, 
                    CustomerName = ?, 
                    Address = ?, 
                    Phone = ?, 
                    Email = ?, 
                    Status = ?,
                    UpdatedAt = NOW()
                    WHERE CustomerID = ?";
            query($sql, [$customerCode, $customerName, $address, $phone, $email, $status, $id]);
            
            header("Location: index.php?page=customers&msg=updated&type=success");
            exit;
        } catch(PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}
?>

<div id="page-content-wrapper" class="p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3"><i class="fas fa-user-edit me-2 text-primary"></i>Edit Customer</h1>
            <p class="text-muted">Edit customer: <?= htmlspecialchars($customer['CustomerCode']) ?></p>
        </div>
        <a href="index.php?page=customers" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i>Back
        </a>
    </div>

    <?php if(isset($errors) && !empty($errors)): ?>
    <div class="alert alert-danger">
        <strong><i class="fas fa-exclamation-circle me-1"></i> Please fix the following errors:</strong>
        <ul class="mb-0 mt-1">
            <?php foreach($errors as $error): ?>
            <li><?= htmlspecialchars($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header"><i class="fas fa-edit me-1"></i> Edit Customer Form</div>
        <div class="card-body">
            <form method="POST" action="" id="customerForm">
                <div class="row g-3">
                    <!-- Customer Code -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Customer Code <span class="text-danger">*</span></label>
                        <input type="text" name="customer_code" class="form-control" 
                               value="<?= htmlspecialchars($customer['CustomerCode']) ?>" 
                               required>
                        <small class="text-muted">Unique identifier for the customer</small>
                    </div>
                    
                    <!-- Customer Name -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Customer Name <span class="text-danger">*</span></label>
                        <input type="text" name="customer_name" class="form-control" 
                               value="<?= htmlspecialchars($customer['CustomerName']) ?>" 
                               required>
                    </div>
                    
                    <!-- Address (WAJIB) -->
                    <div class="col-12">
                        <label class="form-label fw-bold">Address <span class="text-danger">*</span></label>
                        <textarea name="address" class="form-control" rows="2" 
                                  placeholder="Complete address" 
                                  required><?= htmlspecialchars($customer['Address']) ?></textarea>
                        <small class="text-muted">Complete address is required</small>
                    </div>
                    
                    <!-- Phone (WAJIB & HANYA ANGKA) -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Phone <span class="text-danger">*</span></label>
                        <input type="tel" name="phone" class="form-control" 
                               placeholder="e.g: 0217771001" 
                               value="<?= htmlspecialchars($customer['Phone']) ?>" 
                               pattern="[0-9]+" 
                               maxlength="15"
                               required>
                        <small class="text-muted">Numbers only (e.g: 0217771001)</small>
                    </div>
                    
                    <!-- Email -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Email</label>
                        <input type="email" name="email" class="form-control" 
                               placeholder="e.g: info@company.co.id" 
                               value="<?= htmlspecialchars($customer['Email']) ?>">
                        <small class="text-muted">Optional, but must be valid email format</small>
                    </div>
                    
                    <!-- Status -->
                    <div class="col-12">
                        <label class="form-label fw-bold">Status</label>
                        <div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="status" id="status1" value="1" 
                                       <?= $customer['Status'] == 1 ? 'checked' : '' ?>>
                                <label class="form-check-label" for="status1">
                                    <span class="badge bg-success">Active</span>
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="status" id="status0" value="0"
                                       <?= $customer['Status'] == 0 ? 'checked' : '' ?>>
                                <label class="form-check-label" for="status0">
                                    <span class="badge bg-danger">Inactive</span>
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Info -->
                    <div class="col-12">
                        <div class="alert alert-info">
                            <small>
                                <i class="fas fa-info-circle me-1"></i>
                                Created: <?= date('d/m/Y H:i', strtotime($customer['CreatedAt'])) ?>
                                <?php if($customer['UpdatedAt'] != $customer['CreatedAt']): ?>
                                | Updated: <?= date('d/m/Y H:i', strtotime($customer['UpdatedAt'])) ?>
                                <?php endif; ?>
                            </small>
                        </div>
                    </div>
                    
                    <!-- Buttons -->
                    <div class="col-12">
                        <hr>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Update Customer
                        </button>
                      
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- JavaScript untuk validasi phone hanya angka -->
<script>
document.getElementById('customerForm').addEventListener('submit', function(e) {
    var phone = document.querySelector('input[name="phone"]');
    var phoneValue = phone.value.replace(/\D/g, '');
    
    if (phoneValue.length === 0) {
        alert('Phone number is required!');
        e.preventDefault();
        return false;
    }
    
    phone.value = phoneValue;
    return true;
});

// Validasi real-time: hanya angka yang boleh diinput
document.querySelector('input[name="phone"]').addEventListener('input', function(e) {
    this.value = this.value.replace(/\D/g, '');
});
</script>