<?php
// ======================================================
// HALAMAN EDIT PURCHASE ORDER
// ======================================================
ob_start();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Get PO Header
$po = fetchOne("SELECT * FROM purchase_orders WHERE POID = ?", [$id]);

if(!$po) {
    ob_clean();
    header("Location: index.php?page=purchase_orders&msg=Purchase Order not found&type=danger");
    exit;
}

// Get suppliers for dropdown
$suppliers = fetchAll("SELECT SupplierID, SupplierName FROM suppliers WHERE Status = 1 ORDER BY SupplierName");

// Get materials for dropdown
$materials = fetchAll("SELECT MaterialID, MaterialCode, MaterialName, UOM FROM materials WHERE Active = 1 ORDER BY MaterialName");

// Get existing PO details
$existingDetails = fetchAll("
    SELECT 
        PODetailID,
        MaterialID,
        QtyOrder,
        Price,
        Total,
        QtyReceived,
        QtyRemaining
    FROM purchase_order_details 
    WHERE POID = ?
    ORDER BY PODetailID
", [$id]);

// Proses submit form
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $supplierID = isset($_POST['supplier_id']) ? (int)$_POST['supplier_id'] : 0;
    $poDate = $_POST['po_date'];
    $status = $_POST['status'];
    $notes = trim($_POST['notes']);
    
    // Ambil data items dari form
    $detailIDs = isset($_POST['detail_id']) ? $_POST['detail_id'] : [];
    $materialIDs = isset($_POST['material_id']) ? $_POST['material_id'] : [];
    $qtys = isset($_POST['qty']) ? $_POST['qty'] : [];
    $prices = isset($_POST['price']) ? $_POST['price'] : [];
    
    $errors = [];
    
    // Validasi
    if(empty($supplierID)) $errors[] = "Supplier is required";
    if(empty($poDate)) $errors[] = "PO Date is required";
    if(empty($materialIDs) || count($materialIDs) == 0) $errors[] = "At least one item is required";
    
    // Validasi setiap item
    foreach($materialIDs as $index => $mid) {
        if(empty($mid)) $errors[] = "Item #" . ($index+1) . ": Material is required";
        if(empty($qtys[$index]) || $qtys[$index] <= 0) $errors[] = "Item #" . ($index+1) . ": Quantity must be greater than 0";
        if(empty($prices[$index]) || $prices[$index] < 0) $errors[] = "Item #" . ($index+1) . ": Price cannot be negative";
    }
    
    // Cek jika PO sudah memiliki receipt, tidak boleh edit status ke Draft
    if($status == 'Draft' && $po['Status'] != 'Draft') {
        $errors[] = "Cannot change status to Draft because PO already has receipts";
    }
    
    if(empty($errors)) {
        try {
            // Update PO Header
            $sql = "UPDATE purchase_orders SET 
                    SupplierID = ?, 
                    PODate = ?, 
                    Status = ?, 
                    Notes = ?
                    WHERE POID = ?";
            query($sql, [$supplierID, $poDate, $status, $notes, $id]);
            
            // Delete existing details
            query("DELETE FROM purchase_order_details WHERE POID = ?", [$id]);
            
            // Insert new details
            foreach($materialIDs as $index => $materialID) {
                if(empty($materialID)) continue;
                $qty = $qtys[$index];
                $price = $prices[$index];
                $total = $qty * $price;
                
                // Jika ada detail ID, gunakan untuk update (tapi karena kita delete semua, insert ulang)
                $sqlDetail = "INSERT INTO purchase_order_details (POID, MaterialID, QtyOrder, Price, Total, QtyRemaining) 
                              VALUES (?, ?, ?, ?, ?, ?)";
                query($sqlDetail, [$id, $materialID, $qty, $price, $total, $qty]);
            }
            
            ob_clean();
            header("Location: index.php?page=purchase_orders&msg=updated&type=success");
            exit;
        } catch(PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}

ob_end_clean();
?>
<div id="page-content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3"><i class="fas fa-file-invoice-plus me-2 text-primary"></i>Edit Purchase Order</h1>
            <p class="text-muted">Edit purchase order: <?= htmlspecialchars($po['PONumber']) ?></p>
        </div>
        <a href="<?= url('purchase_orders') ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i>Back
        </a>
    </div>

    <?php if(isset($errors) && !empty($errors)): ?>
    <div class="alert alert-danger">
        <strong><i class="fas fa-exclamation-circle me-1"></i> Please fix the following errors:</strong>
        <ul class="mb-0 mt-1">
            <?php foreach($errors as $error): ?>
            <li><?= htmlspecialchars($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header"><i class="fas fa-edit me-1"></i> Purchase Order Form</div>
        <div class="card-body">
            <form method="POST" action="" id="poForm">
                <div class="row g-3">
                    <!-- Supplier -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Supplier <span class="text-danger">*</span></label>
                        <select name="supplier_id" class="form-select" required>
                            <option value="">-- Select Supplier --</option>
                            <?php foreach($suppliers as $sup): ?>
                            <option value="<?= $sup['SupplierID'] ?>" 
                                    <?= ($po['SupplierID'] == $sup['SupplierID']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($sup['SupplierName']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <!-- PO Date -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">PO Date <span class="text-danger">*</span></label>
                        <input type="date" name="po_date" class="form-control" 
                               value="<?= $po['PODate'] ?>" 
                               required>
                    </div>
                    
                    <!-- Status -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Status <span class="text-danger">*</span></label>
                        <select name="status" class="form-select" required>
                            <option value="Draft" <?= $po['Status'] == 'Draft' ? 'selected' : '' ?>>Draft</option>
                            <option value="Submitted" <?= $po['Status'] == 'Submitted' ? 'selected' : '' ?>>Submitted</option>
                            <option value="Approved" <?= $po['Status'] == 'Approved' ? 'selected' : '' ?>>Approved</option>
                            <option value="Partial" <?= $po['Status'] == 'Partial' ? 'selected' : '' ?>>Partial</option>
                            <option value="Completed" <?= $po['Status'] == 'Completed' ? 'selected' : '' ?>>Completed</option>
                            <option value="Cancelled" <?= $po['Status'] == 'Cancelled' ? 'selected' : '' ?>>Cancelled</option>
                        </select>
                        <?php if($po['Status'] != 'Draft'): ?>
                        <small class="text-warning">
                            <i class="fas fa-info-circle me-1"></i>
                            PO sudah memiliki status <?= $po['Status'] ?>. Hati-hati mengubah status.
                        </small>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Created Info -->
                    <div class="col-md-6">
                        <div class="alert alert-info">
                            <small>
                                <i class="fas fa-info-circle me-1"></i>
                                Created: <?= date('d/m/Y H:i', strtotime($po['CreatedAt'])) ?>
                                <?php if($po['UpdatedAt'] != $po['CreatedAt']): ?>
                                <br>Updated: <?= date('d/m/Y H:i', strtotime($po['UpdatedAt'])) ?>
                                <?php endif; ?>
                            </small>
                        </div>
                    </div>
                    
                    <!-- Notes -->
                    <div class="col-12">
                        <label class="form-label fw-bold">Notes</label>
                        <textarea name="notes" class="form-control" rows="2" 
                                  placeholder="Additional notes"><?= htmlspecialchars($po['Notes']) ?></textarea>
                    </div>
                    
                    <!-- Items Section -->
                    <div class="col-12">
                        <hr>
                        <h5 class="fw-bold"><i class="fas fa-list me-2"></i>Items</h5>
                        <div id="itemsContainer">
                            <?php if(empty($existingDetails)): ?>
                            <div class="row g-2 item-row">
                                <div class="col-md-5">
                                    <select name="material_id[]" class="form-select" required>
                                        <option value="">-- Select Material --</option>
                                        <?php foreach($materials as $mat): ?>
                                        <option value="<?= $mat['MaterialID'] ?>">
                                            <?= htmlspecialchars($mat['MaterialCode']) ?> - <?= htmlspecialchars($mat['MaterialName']) ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <input type="number" name="qty[]" class="form-control" placeholder="Qty" min="1" required>
                                </div>
                                <div class="col-md-3">
                                    <input type="number" name="price[]" class="form-control" placeholder="Price" min="0" step="1000" required>
                                </div>
                                <div class="col-md-1">
                                    <button type="button" class="btn btn-danger btn-sm remove-item" style="display:none;">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                            </div>
                            <?php else: ?>
                            <?php foreach($existingDetails as $index => $item): ?>
                            <div class="row g-2 item-row">
                                <input type="hidden" name="detail_id[]" value="<?= $item['PODetailID'] ?>">
                                <div class="col-md-5">
                                    <select name="material_id[]" class="form-select" required>
                                        <option value="">-- Select Material --</option>
                                        <?php foreach($materials as $mat): ?>
                                        <option value="<?= $mat['MaterialID'] ?>" 
                                                <?= ($item['MaterialID'] == $mat['MaterialID']) ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($mat['MaterialCode']) ?> - <?= htmlspecialchars($mat['MaterialName']) ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <input type="number" name="qty[]" class="form-control" placeholder="Qty" min="1" 
                                           value="<?= $item['QtyOrder'] ?>" required>
                                </div>
                                <div class="col-md-3">
                                    <input type="number" name="price[]" class="form-control" placeholder="Price" min="0" step="1000" 
                                           value="<?= $item['Price'] ?>" required>
                                </div>
                                <div class="col-md-1">
                                    <button type="button" class="btn btn-danger btn-sm remove-item" 
                                            <?= (count($existingDetails) <= 1) ? 'style="display:none;"' : '' ?>>
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                                <?php if($item['QtyReceived'] > 0): ?>
                                <div class="col-12">
                                    <small class="text-muted">
                                        <i class="fas fa-info-circle me-1"></i>
                                        Already received: <?= number_format($item['QtyReceived']) ?> 
                                        (Remaining: <?= number_format($item['QtyRemaining']) ?>)
                                    </small>
                                </div>
                                <?php endif; ?>
                            </div>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                        <button type="button" class="btn btn-sm btn-outline-primary mt-2" id="addItem">
                            <i class="fas fa-plus me-1"></i>Add Item
                        </button>
                    </div>
                    
                    <!-- Buttons -->
                    <div class="col-12">
                        <hr>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Update Purchase Order
                        </button>
                       <!--  <a href="<?= url('purchase_orders') ?>" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i>Cancel
                        </a> -->
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Add new item row
document.getElementById('addItem').addEventListener('click', function() {
    var container = document.getElementById('itemsContainer');
    var rows = container.querySelectorAll('.item-row');
    var lastRow = rows[rows.length - 1];
    var newRow = lastRow.cloneNode(true);
    
    // Reset values
    newRow.querySelectorAll('input').forEach(function(input) {
        if(input.type != 'hidden') {
            input.value = '';
        }
    });
    newRow.querySelectorAll('select').forEach(function(select) {
        select.selectedIndex = 0;
    });
    
    // Remove any info messages
    var infoDiv = newRow.querySelector('.col-12');
    if(infoDiv) {
        infoDiv.remove();
    }
    
    // Show remove button
    var removeBtn = newRow.querySelector('.remove-item');
    removeBtn.style.display = 'inline-block';
    
    container.appendChild(newRow);
});

// Remove item row
document.addEventListener('click', function(e) {
    if (e.target.closest('.remove-item')) {
        var row = e.target.closest('.item-row');
        if (document.querySelectorAll('.item-row').length > 1) {
            row.remove();
        }
    }
});
</script>