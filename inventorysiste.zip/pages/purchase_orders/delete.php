<?php
// ======================================================
// PROSES HAPUS PURCHASE ORDER
// ======================================================
ob_start();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$po = fetchOne("SELECT * FROM purchase_orders WHERE POID = ?", [$id]);

if(!$po) {
    ob_clean();
    header("Location: index.php?page=purchase_orders&msg=Purchase Order not found&type=danger");
    exit;
}

// Cek apakah PO sudah memiliki receipt
$hasReceipts = fetchCount("SELECT COUNT(*) FROM material_receipts WHERE POID = ?", [$id]);

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    if($hasReceipts > 0) {
        // Soft delete - hanya ubah status
        query("UPDATE purchase_orders SET Status = 'Cancelled' WHERE POID = ?", [$id]);
    } else {
        // Permanent delete
        query("DELETE FROM purchase_order_details WHERE POID = ?", [$id]);
        query("DELETE FROM purchase_orders WHERE POID = ?", [$id]);
    }
    
    ob_clean();
    header("Location: index.php?page=purchase_orders&msg=deleted&type=success");
    exit;
}

ob_end_clean();
?>
<div id="page-content-wrapper">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-header bg-danger text-white">
                    <i class="fas fa-exclamation-triangle me-1"></i> Confirm Delete
                </div>
                <div class="card-body text-center py-4">
                    <i class="fas fa-file-invoice fa-4x text-danger mb-3"></i>
                    <h4>Are you sure you want to delete this purchase order?</h4>
                    <p class="text-muted">
                        <strong><?= htmlspecialchars($po['PONumber']) ?></strong>
                        <br>
                        Date: <?= date('d/m/Y', strtotime($po['PODate'])) ?>
                        <br>
                        Status: <?= $po['Status'] ?>
                    </p>
                    
                    <?php if($hasReceipts > 0): ?>
                    <div class="alert alert-warning">
                        <i class="fas fa-info-circle me-1"></i>
                        This PO has <strong><?= number_format($hasReceipts) ?> receipt(s)</strong>.
                        PO will be <strong>cancelled</strong> instead of permanently deleted.
                    </div>
                    <?php else: ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-info-circle me-1"></i>
                        This PO has <strong>no receipts</strong>.
                        PO will be <strong>permanently deleted</strong>.
                    </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="" class="d-inline">
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash me-1"></i> Yes, Delete
                        </button>
                        <a href="<?= url('purchase_orders') ?>" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i> Cancel
                        </a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>