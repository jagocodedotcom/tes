<?php
// ======================================================
// HALAMAN DETAIL PURCHASE ORDER
// ======================================================

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Get PO Header
$po = fetchOne("
    SELECT 
        po.*,
        s.SupplierName,
        s.Address,
        s.Phone,
        s.Email
    FROM purchase_orders po
    LEFT JOIN suppliers s ON po.SupplierID = s.SupplierID
    WHERE po.POID = ?
", [$id]);

if(!$po) {
    header("Location: index.php?page=purchase_orders&msg=Purchase Order not found&type=danger");
    exit;
}

// Get PO Details
$details = fetchAll("
    SELECT 
        pod.*,
        m.MaterialCode,
        m.MaterialName,
        m.UOM
    FROM purchase_order_details pod
    LEFT JOIN materials m ON pod.MaterialID = m.MaterialID
    WHERE pod.POID = ?
    ORDER BY pod.PODetailID
", [$id]);

// Calculate totals
$totalQty = 0;
$totalAmount = 0;
foreach($details as $d) {
    $totalQty += $d['QtyOrder'];
    $totalAmount += $d['Total'];
}
?>

<div id="page-content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3">
                <i class="fas fa-file-invoice me-2 text-primary"></i>Purchase Order Detail
            </h1>
            <p class="text-muted">View purchase order details</p>
        </div>
        <div>
            <a href="<?= url('purchase_orders', 'edit', ['id' => $id]) ?>" class="btn btn-primary">
                <i class="fas fa-edit me-1"></i>Edit
            </a>
            <a href="<?= url('purchase_orders') ?>" class="btn btn-secondary">
                <i class="fas fa-arrow-left me-1"></i>Back
            </a>
        </div>
    </div>

    <!-- PO Information -->
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-info-circle me-1"></i> Purchase Order Information
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <table class="table table-bordered mb-0">
                        <tr>
                            <th width="35%">PO Number</th>
                            <td><span class="badge bg-info"><?= htmlspecialchars($po['PONumber']) ?></span></td>
                        </tr>
                        <tr>
                            <th>PO Date</th>
                            <td><?= date('d/m/Y', strtotime($po['PODate'])) ?></td>
                        </tr>
                        <tr>
                            <th>Status</th>
                            <td><?= getStatusBadge($po['Status']) ?></td>
                        </tr>
                        <tr>
                            <th>Created By</th>
                            <td><?= htmlspecialchars($po['CreatedBy']) ?></td>
                        </tr>
                        <tr>
                            <th>Created At</th>
                            <td><?= date('d/m/Y H:i', strtotime($po['CreatedAt'])) ?></td>
                        </tr>
                    </table>
                </div>
                <div class="col-md-6">
                    <table class="table table-bordered mb-0">
                        <tr>
                            <th width="35%">Supplier</th>
                            <td><strong><?= htmlspecialchars($po['SupplierName']) ?></strong></td>
                        </tr>
                        <tr>
                            <th>Address</th>
                            <td><?= nl2br(htmlspecialchars($po['Address'])) ?></td>
                        </tr>
                        <tr>
                            <th>Phone</th>
                            <td><?= htmlspecialchars($po['Phone']) ?></td>
                        </tr>
                        <tr>
                            <th>Email</th>
                            <td><?= htmlspecialchars($po['Email']) ?></td>
                        </tr>
                        <tr>
                            <th>Notes</th>
                            <td><?= nl2br(htmlspecialchars($po['Notes'])) ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Items -->
    <div class="card">
        <div class="card-header">
            <i class="fas fa-list me-1"></i> Items
            <span class="badge bg-secondary float-end">Total: <?= number_format($totalQty) ?> items</span>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-striped mb-0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Material Code</th>
                            <th>Material Name</th>
                            <th>UOM</th>
                            <th class="text-end">Qty</th>
                            <th class="text-end">Price</th>
                            <th class="text-end">Total</th>
                            <th class="text-end">Received</th>
                            <th class="text-end">Remaining</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($details)): ?>
                        <tr>
                            <td colspan="9" class="text-center text-muted py-3">No items found</td>
                        </tr>
                        <?php else: ?>
                        <?php $no = 1; foreach($details as $row): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= htmlspecialchars($row['MaterialCode']) ?></td>
                            <td><?= htmlspecialchars($row['MaterialName']) ?></td>
                            <td><?= htmlspecialchars($row['UOM']) ?></td>
                            <td class="text-end"><?= number_format($row['QtyOrder']) ?></td>
                            <td class="text-end">Rp <?= number_format($row['Price'], 0) ?></td>
                            <td class="text-end">Rp <?= number_format($row['Total'], 0) ?></td>
                            <td class="text-end"><?= number_format($row['QtyReceived']) ?></td>
                            <td class="text-end"><?= number_format($row['QtyRemaining']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <tr class="table-active">
                            <td colspan="4" class="text-end fw-bold">Grand Total</td>
                            <td class="text-end fw-bold"><?= number_format($totalQty) ?></td>
                            <td></td>
                            <td class="text-end fw-bold">Rp <?= number_format($totalAmount, 0) ?></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>