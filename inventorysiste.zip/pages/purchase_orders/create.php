<?php
// ======================================================
// HALAMAN TAMBAH PURCHASE ORDER
// ======================================================
ob_start();

// Get suppliers for dropdown
$suppliers = fetchAll("SELECT SupplierID, SupplierName FROM suppliers WHERE Status = 1 ORDER BY SupplierName");

// Get materials for dropdown
$materials = fetchAll("SELECT MaterialID, MaterialCode, MaterialName, UOM FROM materials WHERE Active = 1 ORDER BY MaterialName");

// Proses submit form
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $supplierID = isset($_POST['supplier_id']) ? (int)$_POST['supplier_id'] : 0;
    $poDate = $_POST['po_date'];
    $notes = trim($_POST['notes']);
    $createdBy = 'purchasing1'; // Nanti dari session
    
    // Ambil data items dari form
    $materialIDs = isset($_POST['material_id']) ? $_POST['material_id'] : [];
    $qtys = isset($_POST['qty']) ? $_POST['qty'] : [];
    $prices = isset($_POST['price']) ? $_POST['price'] : [];
    
    $errors = [];
    
    // Validasi
    if(empty($supplierID)) $errors[] = "Supplier is required";
    if(empty($poDate)) $errors[] = "PO Date is required";
    if(empty($materialIDs) || count($materialIDs) == 0) $errors[] = "At least one item is required";
    
    // Validasi setiap item
    foreach($materialIDs as $index => $mid) {
        if(empty($mid)) $errors[] = "Item #" . ($index+1) . ": Material is required";
        if(empty($qtys[$index]) || $qtys[$index] <= 0) $errors[] = "Item #" . ($index+1) . ": Quantity must be greater than 0";
        if(empty($prices[$index]) || $prices[$index] < 0) $errors[] = "Item #" . ($index+1) . ": Price cannot be negative";
    }
    
    if(empty($errors)) {
        try {
            // Generate PO Number
            $year = date('Y');
            $month = date('m');
            $lastPO = fetchOne("SELECT PONumber FROM purchase_orders ORDER BY POID DESC LIMIT 1");
            $lastNumber = 0;
            if($lastPO) {
                $lastNumber = (int)substr($lastPO['PONumber'], -4);
            }
            $newNumber = str_pad($lastNumber + 1, 4, '0', STR_PAD_LEFT);
            $poNumber = 'PO-' . $year . $month . '-' . $newNumber;
            
            // Insert PO Header
            $sql = "INSERT INTO purchase_orders (PONumber, PODate, SupplierID, Status, CreatedBy, Notes) 
                    VALUES (?, ?, ?, 'Draft', ?, ?)";
            query($sql, [$poNumber, $poDate, $supplierID, $createdBy, $notes]);
            $poID = $pdo->lastInsertId();
            
            // Insert PO Details
            foreach($materialIDs as $index => $materialID) {
                if(empty($materialID)) continue;
                $qty = $qtys[$index];
                $price = $prices[$index];
                $total = $qty * $price;
                
                $sqlDetail = "INSERT INTO purchase_order_details (POID, MaterialID, QtyOrder, Price, Total, QtyRemaining) 
                              VALUES (?, ?, ?, ?, ?, ?)";
                query($sqlDetail, [$poID, $materialID, $qty, $price, $total, $qty]);
            }
            
            ob_clean();
            header("Location: index.php?page=purchase_orders&msg=created&type=success");
            exit;
        } catch(PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}

ob_end_clean();
?>
<div id="page-content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3"><i class="fas fa-file-invoice-plus me-2 text-primary"></i>Add Purchase Order</h1>
            <p class="text-muted">Create new purchase order</p>
        </div>
        <a href="<?= url('purchase_orders') ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i>Back
        </a>
    </div>

    <?php if(isset($errors) && !empty($errors)): ?>
    <div class="alert alert-danger">
        <strong><i class="fas fa-exclamation-circle me-1"></i> Please fix the following errors:</strong>
        <ul class="mb-0 mt-1">
            <?php foreach($errors as $error): ?>
            <li><?= htmlspecialchars($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header"><i class="fas fa-edit me-1"></i> Purchase Order Form</div>
        <div class="card-body">
            <form method="POST" action="" id="poForm">
                <div class="row g-3">
                    <!-- Supplier -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Supplier <span class="text-danger">*</span></label>
                        <select name="supplier_id" class="form-select" required>
                            <option value="">-- Select Supplier --</option>
                            <?php foreach($suppliers as $sup): ?>
                            <option value="<?= $sup['SupplierID'] ?>" 
                                    <?= (isset($_POST['supplier_id']) && $_POST['supplier_id'] == $sup['SupplierID']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($sup['SupplierName']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <!-- PO Date -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">PO Date <span class="text-danger">*</span></label>
                        <input type="date" name="po_date" class="form-control" 
                               value="<?= isset($_POST['po_date']) ? $_POST['po_date'] : date('Y-m-d') ?>" 
                               required>
                    </div>
                    
                    <!-- Notes -->
                    <div class="col-12">
                        <label class="form-label fw-bold">Notes</label>
                        <textarea name="notes" class="form-control" rows="2" 
                                  placeholder="Additional notes"><?= isset($_POST['notes']) ? htmlspecialchars($_POST['notes']) : '' ?></textarea>
                    </div>
                    
                    <!-- Items Section -->
                    <div class="col-12">
                        <hr>
                        <h5 class="fw-bold"><i class="fas fa-list me-2"></i>Items</h5>
                        <div id="itemsContainer">
                            <div class="row g-2 item-row">
                                <div class="col-md-5">
                                    <select name="material_id[]" class="form-select" required>
                                        <option value="">-- Select Material --</option>
                                        <?php foreach($materials as $mat): ?>
                                        <option value="<?= $mat['MaterialID'] ?>">
                                            <?= htmlspecialchars($mat['MaterialCode']) ?> - <?= htmlspecialchars($mat['MaterialName']) ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <input type="number" name="qty[]" class="form-control" placeholder="Qty" min="1" required>
                                </div>
                                <div class="col-md-3">
                                    <input type="number" name="price[]" class="form-control" placeholder="Price" min="0" step="1000" required>
                                </div>
                                <div class="col-md-1">
                                    <button type="button" class="btn btn-danger btn-sm remove-item" style="display:none;">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <button type="button" class="btn btn-sm btn-outline-primary mt-2" id="addItem">
                            <i class="fas fa-plus me-1"></i>Add Item
                        </button>
                    </div>
                    
                    <!-- Buttons -->
                    <div class="col-12">
                        <hr>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Create Purchase Order
                        </button>
                        <!-- <a href="<?= url('purchase_orders') ?>" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i>Cancel
                        </a> -->
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Add new item row
document.getElementById('addItem').addEventListener('click', function() {
    var container = document.getElementById('itemsContainer');
    var rows = container.querySelectorAll('.item-row');
    var lastRow = rows[rows.length - 1];
    var newRow = lastRow.cloneNode(true);
    
    // Reset values
    newRow.querySelectorAll('input').forEach(function(input) {
        input.value = '';
    });
    newRow.querySelectorAll('select').forEach(function(select) {
        select.selectedIndex = 0;
    });
    
    // Show remove button
    var removeBtn = newRow.querySelector('.remove-item');
    removeBtn.style.display = 'inline-block';
    
    container.appendChild(newRow);
});

// Remove item row
document.addEventListener('click', function(e) {
    if (e.target.closest('.remove-item')) {
        var row = e.target.closest('.item-row');
        if (document.querySelectorAll('.item-row').length > 1) {
            row.remove();
        }
    }
});
</script>