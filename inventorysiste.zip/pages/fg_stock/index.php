<?php
// ======================================================
// HALAMAN STOCK FINISHED GOODS
// ======================================================

// Pagination
$page = isset($_GET['page_num']) ? (int)$_GET['page_num'] : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

// Search
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Filter by warehouse
$warehouseFilter = isset($_GET['warehouse']) ? (int)$_GET['warehouse'] : 0;

// Build Query
$whereClause = "WHERE 1=1";
$params = [];

if (!empty($search)) {
    $whereClause .= " AND (p.ProductCode LIKE ? OR p.ProductName LIKE ? OR s.BatchNo LIKE ? OR s.PalletNo LIKE ?)";
    $searchTerm = "%$search%";
    $params = [$searchTerm, $searchTerm, $searchTerm, $searchTerm];
}

if ($warehouseFilter > 0) {
    $whereClause .= " AND s.WarehouseID = ?";
    $params[] = $warehouseFilter;
}

// Get Total Data
$totalQuery = "
    SELECT COUNT(*) 
    FROM stock_fg s
    LEFT JOIN products p ON s.ProductID = p.ProductID
    $whereClause
";
$totalData = fetchCount($totalQuery, $params);
$totalPages = ceil($totalData / $limit);

// Get Data
$query = "
    SELECT 
        s.StockFGID,
        p.ProductCode,
        p.ProductName,
        p.UOM,
        p.Category,
        p.UnitPrice,
        w.WarehouseName,
        s.QtyOnHand,
        s.QtyReserved,
        s.QtyAvailable,
        s.BatchNo,
        s.PalletNo,
        s.BinLocation,
        s.LastUpdated,
        (SELECT COUNT(*) FROM fg_receipt_details WHERE ProductID = s.ProductID AND BatchNo = s.BatchNo) AS TotalReceipts
    FROM stock_fg s
    LEFT JOIN products p ON s.ProductID = p.ProductID
    LEFT JOIN warehouses w ON s.WarehouseID = w.WarehouseID
    $whereClause
    ORDER BY p.ProductName
    LIMIT $limit OFFSET $offset
";
$stocks = fetchAll($query, $params);

// Get warehouses for filter
$warehouses = fetchAll("SELECT WarehouseID, WarehouseName FROM warehouses WHERE IsActive = 1 ORDER BY WarehouseName");

// Get Summary
$summary = fetchOne("
    SELECT 
        COUNT(DISTINCT s.ProductID) AS TotalProducts,
        COALESCE(SUM(s.QtyOnHand), 0) AS TotalStock,
        COALESCE(SUM(s.QtyReserved), 0) AS TotalReserved,
        COALESCE(SUM(s.QtyAvailable), 0) AS TotalAvailable
    FROM stock_fg s
");

// Get Stock by Warehouse
$stockByWarehouse = fetchAll("
    SELECT 
        w.WarehouseName,
        COALESCE(SUM(s.QtyOnHand), 0) AS TotalStock,
        COALESCE(SUM(s.QtyAvailable), 0) AS TotalAvailable
    FROM stock_fg s
    LEFT JOIN warehouses w ON s.WarehouseID = w.WarehouseID
    GROUP BY s.WarehouseID
    ORDER BY w.WarehouseName
");

// Get Top Products
$topProducts = fetchAll("
    SELECT 
        p.ProductCode,
        p.ProductName,
        COALESCE(SUM(s.QtyOnHand), 0) AS TotalStock
    FROM stock_fg s
    LEFT JOIN products p ON s.ProductID = p.ProductID
    GROUP BY s.ProductID
    ORDER BY TotalStock DESC
    LIMIT 5
");
?>

<div id="page-content-wrapper">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3">
                <i class="fas fa-boxes me-2 text-primary"></i>FG Stock
            </h1>
            <p class="text-muted">View finished goods stock levels</p>
        </div>
        <a href="<?= url('fg_receipts', 'create') ?>" class="btn btn-primary">
            <i class="fas fa-plus me-1"></i>Add FG Receipt
        </a>
    </div>

    <!-- Summary Cards -->
    <div class="row g-3 mb-4">
        <div class="col-md-3">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-white-50">Total Products</h6>
                            <h2 class="display-6 fw-bold"><?= number_format($summary['TotalProducts']) ?></h2>
                        </div>
                        <i class="fas fa-box fa-3x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-white-50">Total Stock</h6>
                            <h2 class="display-6 fw-bold"><?= number_format($summary['TotalStock']) ?></h2>
                        </div>
                        <i class="fas fa-warehouse fa-3x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-warning text-dark">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-dark-50">Reserved</h6>
                            <h2 class="display-6 fw-bold"><?= number_format($summary['TotalReserved']) ?></h2>
                        </div>
                        <i class="fas fa-clock fa-3x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-white-50">Available</h6>
                            <h2 class="display-6 fw-bold"><?= number_format($summary['TotalAvailable']) ?></h2>
                        </div>
                        <i class="fas fa-check-circle fa-3x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Charts Row -->
    <div class="row g-3 mb-4">
        <!-- Stock by Warehouse -->
        <div class="col-md-6">
            <div class="card h-100">
                <div class="card-header">
                    <i class="fas fa-warehouse me-1"></i> Stock by Warehouse
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Warehouse</th>
                                    <th class="text-end">Total Stock</th>
                                    <th class="text-end">Available</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($stockByWarehouse as $sw): ?>
                                <tr>
                                    <td><?= htmlspecialchars($sw['WarehouseName']) ?></td>
                                    <td class="text-end"><?= number_format($sw['TotalStock']) ?></td>
                                    <td class="text-end text-success"><?= number_format($sw['TotalAvailable']) ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Top Products -->
        <div class="col-md-6">
            <div class="card h-100">
                <div class="card-header">
                    <i class="fas fa-chart-bar me-1"></i> Top Products by Stock
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th class="text-end">Stock</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($topProducts as $tp): ?>
                                <tr>
                                    <td>
                                        <span class="badge bg-secondary"><?= htmlspecialchars($tp['ProductCode']) ?></span>
                                        <?= htmlspecialchars($tp['ProductName']) ?>
                                    </td>
                                    <td class="text-end"><?= number_format($tp['TotalStock']) ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Search & Filter -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <input type="hidden" name="page" value="fg_stock">
                <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                        <input type="text" name="search" class="form-control" 
                               placeholder="Search by product code, name, batch, or pallet..." 
                               value="<?= htmlspecialchars($search) ?>">
                    </div>
                </div>
                <div class="col-md-3">
                    <select name="warehouse" class="form-select">
                        <option value="0">All Warehouses</option>
                        <?php foreach($warehouses as $w): ?>
                        <option value="<?= $w['WarehouseID'] ?>" <?= ($warehouseFilter == $w['WarehouseID']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($w['WarehouseName']) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-filter me-1"></i>Filter
                    </button>
                </div>
                <div class="col-md-2">
                    <a href="<?= url('fg_stock') ?>" class="btn btn-secondary w-100">
                        <i class="fas fa-undo me-1"></i>Reset
                    </a>
                </div>
            </form>
        </div>
    </div>

    <!-- Table -->
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <span><i class="fas fa-list me-1"></i> FG Stock List</span>
                <span class="badge bg-primary"><?= number_format($totalData) ?> Records</span>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover table-striped mb-0">
                    <thead>
                        <tr>
                            <th width="50">#</th>
                            <th>Product Code</th>
                            <th>Product Name</th>
                            <th>Warehouse</th>
                            <th>Batch</th>
                            <th>Pallet</th>
                            <th>Bin</th>
                            <th class="text-end">On Hand</th>
                            <th class="text-end">Reserved</th>
                            <th class="text-end">Available</th>
                            <th>Last Updated</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($stocks)): ?>
                        <tr>
                            <td colspan="11" class="text-center text-muted py-4">
                                <i class="fas fa-inbox fa-2x d-block mb-2"></i>
                                No FG stock found
                            </td>
                        </tr>
                        <?php else: ?>
                        <?php 
                        $no = $offset + 1;
                        foreach($stocks as $row): 
                        ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td>
                                <span class="badge bg-success"><?= htmlspecialchars($row['ProductCode']) ?></span>
                            </td>
                            <td>
                                <strong><?= htmlspecialchars($row['ProductName']) ?></strong>
                                <br>
                                <small class="text-muted"><?= htmlspecialchars($row['Category']) ?></small>
                            </td>
                            <td><?= htmlspecialchars($row['WarehouseName']) ?></td>
                            <td>
                                <span class="badge bg-secondary"><?= htmlspecialchars($row['BatchNo']) ?></span>
                            </td>
                            <td><?= htmlspecialchars($row['PalletNo']) ?></td>
                            <td><?= htmlspecialchars($row['BinLocation']) ?></td>
                            <td class="text-end"><?= number_format($row['QtyOnHand']) ?></td>
                            <td class="text-end text-warning"><?= number_format($row['QtyReserved']) ?></td>
                            <td class="text-end text-success">
                                <strong><?= number_format($row['QtyAvailable']) ?></strong>
                            </td>
                            <td><?= date('d/m/Y H:i', strtotime($row['LastUpdated'])) ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php if($totalPages > 1): ?>
        <div class="card-footer">
            <nav>
                <ul class="pagination pagination-sm mb-0">
                    <?php if($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=fg_stock&page_num=<?= $page-1 ?>&search=<?= urlencode($search) ?>&warehouse=<?= $warehouseFilter ?>">
                            <i class="fas fa-chevron-left"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <?php for($i = 1; $i <= $totalPages; $i++): ?>
                    <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                        <a class="page-link" href="?page=fg_stock&page_num=<?= $i ?>&search=<?= urlencode($search) ?>&warehouse=<?= $warehouseFilter ?>">
                            <?= $i ?>
                        </a>
                    </li>
                    <?php endfor; ?>
                    
                    <?php if($page < $totalPages): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=fg_stock&page_num=<?= $page+1 ?>&search=<?= urlencode($search) ?>&warehouse=<?= $warehouseFilter ?>">
                            <i class="fas fa-chevron-right"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
        <?php endif; ?>
    </div>

    <!-- Export Button -->
    <div class="mt-3">
        <a href="#" class="btn btn-success" onclick="exportTable()">
            <i class="fas fa-file-excel me-1"></i>Export to Excel
        </a>
    </div>
</div>

<script>
function exportTable() {
    // Simple table export - can be enhanced
    var table = document.querySelector('.table');
    var html = table.outerHTML;
    var blob = new Blob([html], {type: 'text/html'});
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = 'fg_stock_export.xls';
    a.click();
    URL.revokeObjectURL(url);
}
</script>