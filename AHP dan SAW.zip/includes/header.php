<?php
// includes/header.php - OPTIMIZED VERSION
if (!defined('BASE_URL')) {
    define('BASE_URL', '/spk_beasiswa');
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?? 'SPK Beasiswa' ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        *{margin:0;padding:0;box-sizing:border-box}
        body{font-family:'Inter',sans-serif;background:#f8fafc;color:#1f2937;min-height:100vh;overflow-x:hidden}
        .app-wrapper{display:flex;min-height:100vh;width:100%}
        .app-content{flex:1;min-height:100vh;padding:20px 24px;margin-left:260px;width:calc(100% - 260px);transition:all .3s ease;background:#f8fafc}
        .app-content.expanded{margin-left:70px;width:calc(100% - 70px)}
        @media(max-width:992px){.app-content{margin-left:0!important;width:100%!important;padding:16px}}
        @media(max-width:576px){.app-content{padding:12px}}
        .table-responsive-custom{overflow-x:auto;-webkit-overflow-scrolling:touch;width:100%;display:block}
        .table-responsive-custom table{width:100%;min-width:600px;margin-bottom:0;background:#fff;border-radius:12px;overflow:hidden}
        .card-custom{background:#fff;border-radius:16px;border:1px solid #f1f5f9;box-shadow:0 1px 3px rgba(0,0,0,0.04);overflow:hidden;width:100%}
        .card-custom .card-body{padding:20px;overflow-x:auto}
        @media(max-width:576px){.card-custom .card-body{padding:12px}}
        .stat-card{background:#fff;border-radius:16px;padding:18px 20px;border:1px solid #f1f5f9;transition:all .3s ease;height:100%}
        .stat-card:hover{transform:translateY(-4px);box-shadow:0 4px 20px rgba(0,0,0,0.05)}
        @keyframes slideDown{from{opacity:0;transform:translateY(-10px)}to{opacity:1;transform:translateY(0)}}
        .alert{animation:slideDown .3s ease}
        ::-webkit-scrollbar{width:6px;height:6px}
        ::-webkit-scrollbar-track{background:#f1f5f9;border-radius:10px}
        ::-webkit-scrollbar-thumb{background:#cbd5e1;border-radius:10px}
        ::-webkit-scrollbar-thumb:hover{background:#94a3b8}
    </style>
</head>
<body>
    <div class="app-wrapper">