<?php
// includes/sidebar.php - PASTIKAN TIDAK ADA LOOP TAK TERBATAS
if (!defined('BASE_URL')) {
    define('BASE_URL', '/spk_beasiswa');
}
?>

<!-- ============================================
     SIDEBAR - PASTIKAN TIDAK ADA PHP LOOP
     ============================================ -->
<?php
// AMBIL DATA UNTUK BADGE DARI VARIABLE YANG SUDAH DITENTUKAN
$total_alt_badge = $total_alt ?? 0;
$total_krit_badge = $total_krit ?? 0;
$total_nilai_badge = $total_nilai ?? 0;
?>

<!-- Overlay untuk mobile -->
<div class="sidebar-overlay" id="sidebarOverlay"></div>

<!-- Mobile Toggle Button -->
<button class="mobile-toggle-btn" id="mobileToggleBtn">
    <i class="bi bi-list"></i>
</button>

<!-- SIDEBAR -->
<aside class="sidebar-wrapper" id="sidebarWrapper">

    <!-- Brand -->
    <a class="sidebar-brand" href="<?= BASE_URL ?>/modul/dashboard/">
        <div class="sidebar-brand-icon">
            <i class="bi bi-trophy-fill"></i>
        </div>
        <div class="sidebar-brand-text">
            <span class="brand-main">SPK <span>Beasiswa</span></span>
            <span class="brand-sub">Sistem Pendukung Keputusan</span>
        </div>
    </a>

    <!-- Toggle Button -->
    <button class="sidebar-toggle" id="sidebarToggle" title="Toggle Sidebar">
        <i class="bi bi-chevron-left toggle-icon"></i>
    </button>

    <!-- User Profile -->
    <div class="sidebar-user">
        <div class="sidebar-avatar">
            <?= strtoupper(substr($_SESSION['nama_lengkap'] ?? 'U', 0, 1)) ?>
        </div>
        <div class="sidebar-user-info">
            <div class="sidebar-user-name"><?= $_SESSION['nama_lengkap'] ?? 'User' ?></div>
            <div class="sidebar-user-role"><?= $_SESSION['role'] ?? 'User' ?></div>
        </div>
    </div>

    <!-- Navigation -->
    <nav class="sidebar-nav">
        <div class="sidebar-section">
            <div class="sidebar-section-title">Menu Utama</div>
            <a class="sidebar-link <?= strpos($_SERVER['REQUEST_URI'], 'dashboard') !== false ? 'active' : '' ?>" 
               href="<?= BASE_URL ?>/modul/dashboard/">
                <i class="bi bi-speedometer2"></i>
                <span class="sidebar-link-text">Dashboard</span>
            </a>
        </div>

        <div class="sidebar-section">
            <div class="sidebar-section-title">Data Master</div>
            <a class="sidebar-link <?= strpos($_SERVER['REQUEST_URI'], 'alternatif') !== false ? 'active' : '' ?>" 
               href="<?= BASE_URL ?>/modul/alternatif/">
                <i class="bi bi-people-fill"></i>
                <span class="sidebar-link-text">Alternatif</span>
                <span class="sidebar-link-badge"><?= $total_alt_badge ?></span>
            </a>
            <a class="sidebar-link <?= strpos($_SERVER['REQUEST_URI'], 'kriteria') !== false ? 'active' : '' ?>" 
               href="<?= BASE_URL ?>/modul/kriteria/">
                <i class="bi bi-list-check"></i>
                <span class="sidebar-link-text">Kriteria</span>
                <span class="sidebar-link-badge"><?= $total_krit_badge ?></span>
            </a>
            <a class="sidebar-link <?= strpos($_SERVER['REQUEST_URI'], 'nilai') !== false ? 'active' : '' ?>" 
               href="<?= BASE_URL ?>/modul/nilai/">
                <i class="bi bi-table"></i>
                <span class="sidebar-link-text">Nilai</span>
                <span class="sidebar-link-badge"><?= $total_nilai_badge ?></span>
            </a>
        </div>

        <div class="sidebar-section">
            <div class="sidebar-section-title">Proses & Hasil</div>
            <a class="sidebar-link <?= strpos($_SERVER['REQUEST_URI'], 'perhitungan') !== false ? 'active' : '' ?>" 
               href="<?= BASE_URL ?>/modul/perhitungan/">
                <i class="bi bi-calculator-fill"></i>
                <span class="sidebar-link-text">Perhitungan</span>
                <span class="sidebar-link-badge" style="background:#ef4444;color:#fff;padding:2px 6px;">
                    <i class="bi bi-circle-fill" style="font-size:0.3rem;animation:blink-dot 1.5s ease-in-out infinite;"></i>
                </span>
            </a>
        </div>

        <div class="sidebar-section" style="margin-top:auto;">
            <div class="sidebar-section-title">Akun</div>
            <a class="sidebar-link" href="<?= BASE_URL ?>/modul/login/logout.php">
                <i class="bi bi-box-arrow-right" style="color:#ef4444;"></i>
                <span class="sidebar-link-text" style="color:#ef4444;">Logout</span>
            </a>
        </div>
    </nav>

    <div class="sidebar-footer">
        <i class="bi bi-shield-check"></i>
        <span class="sidebar-footer-text">v2.0 · SPK Beasiswa</span>
    </div>
</aside>

<style>
    /* ============================================
       SIDEBAR STYLES - MINIFIED
       ============================================ */
    .sidebar-wrapper{position:fixed;top:0;left:0;bottom:0;width:260px;background:linear-gradient(180deg,#fff 0,#f0f4ff 50%,#e8edf8 100%);box-shadow:2px 0 20px rgba(0,0,0,0.05);z-index:1050;transition:all .3s ease;overflow:hidden;display:flex;flex-direction:column;border-right:1px solid rgba(1,24,81,0.06)}
    .sidebar-wrapper.collapsed{width:70px}
    .sidebar-wrapper.collapsed .sidebar-brand-text,.sidebar-wrapper.collapsed .sidebar-link-text,.sidebar-wrapper.collapsed .sidebar-link-badge,.sidebar-wrapper.collapsed .sidebar-user-name,.sidebar-wrapper.collapsed .sidebar-user-role,.sidebar-wrapper.collapsed .sidebar-footer-text{display:none}
    .sidebar-wrapper.collapsed .sidebar-brand{justify-content:center;padding:16px 0}
    .sidebar-wrapper.collapsed .sidebar-link{justify-content:center;padding:12px}
    .sidebar-wrapper.collapsed .sidebar-link i{font-size:1.3rem;margin:0}
    .sidebar-wrapper.collapsed .sidebar-user{justify-content:center;padding:12px 8px}
    .sidebar-brand{display:flex;align-items:center;gap:12px;padding:20px 18px 16px;border-bottom:2px solid rgba(1,24,81,0.06);flex-shrink:0;text-decoration:none}
    .sidebar-brand-icon{width:42px;height:42px;background:linear-gradient(135deg,#011851,#1a3a9a);border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.3rem;color:#fff;flex-shrink:0}
    .sidebar-brand-text .brand-main{font-weight:800;font-size:1.1rem;color:#011851}
    .sidebar-brand-text .brand-main span{color:#1a3a9a}
    .sidebar-brand-text .brand-sub{font-size:.55rem;color:#8a9bb8;letter-spacing:1px;text-transform:uppercase}
    .sidebar-toggle{position:absolute;top:50%;right:-12px;transform:translateY(-50%);width:24px;height:24px;background:#011851;border:2px solid #fff;border-radius:50%;color:#fff;font-size:.6rem;display:flex;align-items:center;justify-content:center;cursor:pointer;box-shadow:0 2px 10px rgba(1,24,81,0.2);z-index:10;padding:0}
    .sidebar-toggle:hover{transform:translateY(-50%) scale(1.1)}
    .sidebar-user{display:flex;align-items:center;gap:10px;padding:14px 16px;margin:8px 12px;background:rgba(1,24,81,0.04);border-radius:12px;flex-shrink:0}
    .sidebar-avatar{width:38px;height:38px;border-radius:50%;background:linear-gradient(135deg,#011851,#1a3a9a);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.9rem;color:#fff;flex-shrink:0}
    .sidebar-user-name{font-weight:600;font-size:.85rem;color:#011851}
    .sidebar-user-role{font-size:.6rem;color:#8a9bb8;text-transform:uppercase;letter-spacing:.5px}
    .sidebar-nav{flex:1;overflow-y:auto;padding:8px 12px}
    .sidebar-section-title{font-size:.55rem;text-transform:uppercase;letter-spacing:1px;color:#8a9bb8;padding:12px 12px 4px;font-weight:700}
    .sidebar-link{display:flex;align-items:center;gap:12px;padding:9px 14px;border-radius:10px;color:#4a5a7a;text-decoration:none;transition:all .2s ease;font-weight:500;font-size:.85rem}
    .sidebar-link i{font-size:1.1rem;width:22px;text-align:center;color:#8a9bb8;transition:all .3s ease}
    .sidebar-link:hover{background:rgba(1,24,81,0.05);color:#011851}
    .sidebar-link:hover i{color:#011851;transform:scale(1.1)}
    .sidebar-link.active{background:rgba(1,24,81,0.08);color:#011851;box-shadow:inset 3px 0 0 #011851}
    .sidebar-link.active i{color:#011851}
    .sidebar-link-badge{background:rgba(1,24,81,0.08);color:#011851;font-size:.55rem;font-weight:700;padding:2px 8px;border-radius:20px}
    .sidebar-footer{padding:14px 18px;border-top:2px solid rgba(1,24,81,0.06);flex-shrink:0;display:flex;align-items:center;gap:8px}
    .sidebar-footer-text{font-size:.6rem;color:#8a9bb8}
    @keyframes blink-dot{0%,100%{opacity:1}50%{opacity:.2}}
    @media(max-width:992px){.sidebar-wrapper{transform:translateX(-100%);width:280px}.sidebar-wrapper.mobile-open{transform:translateX(0);box-shadow:2px 0 30px rgba(0,0,0,0.15)}.sidebar-toggle{display:none}.sidebar-overlay{display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.3);z-index:1040;backdrop-filter:blur(2px)}.sidebar-overlay.active{display:block}.mobile-toggle-btn{position:fixed;bottom:20px;right:20px;width:50px;height:50px;border-radius:50%;background:linear-gradient(135deg,#011851,#1a3a9a);border:none;color:#fff;font-size:1.3rem;box-shadow:0 4px 20px rgba(1,24,81,0.35);z-index:1060;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all .3s ease}.mobile-toggle-btn:hover{transform:scale(1.05)}}
    @media(max-width:576px){.sidebar-wrapper{width:100%!important;max-width:320px}.mobile-toggle-btn{bottom:16px;right:16px;width:44px;height:44px;font-size:1.1rem}}
</style>

<script>
document.addEventListener('DOMContentLoaded',function(){
    const s=document.getElementById('sidebarWrapper'),t=document.getElementById('sidebarToggle'),m=document.getElementById('mobileToggleBtn'),o=document.getElementById('sidebarOverlay'),c=document.querySelector('.app-content');
    if(t){t.addEventListener('click',function(){s.classList.toggle('collapsed');if(c)c.classList.toggle('expanded');localStorage.setItem('sidebarCollapsed',s.classList.contains('collapsed'))})}
    function toggle(){s.classList.toggle('mobile-open');o.classList.toggle('active');const i=m.querySelector('i');i.className=s.classList.contains('mobile-open')?'bi bi-x-lg':'bi bi-list';document.body.style.overflow=s.classList.contains('mobile-open')?'hidden':''}
    if(m)m.addEventListener('click',toggle);if(o)o.addEventListener('click',toggle);
    document.querySelectorAll('.sidebar-link').forEach(function(l){l.addEventListener('click',function(){if(window.innerWidth<=992&&s.classList.contains('mobile-open'))toggle()})});
    let r;window.addEventListener('resize',function(){clearTimeout(r);r=setTimeout(function(){if(window.innerWidth>992&&s.classList.contains('mobile-open')){s.classList.remove('mobile-open');o.classList.remove('active');if(m){const i=m.querySelector('i');if(i)i.className='bi bi-list'}document.body.style.overflow=''}},250)});
    if(localStorage.getItem('sidebarCollapsed')==='true'&&window.innerWidth>992){s.classList.add('collapsed');if(c)c.classList.add('expanded')}
});
</script>