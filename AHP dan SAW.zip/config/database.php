<?php
ob_start(); 
// config/database.php - FIXED VERSION
require_once __DIR__ . '/config.php';

// ============================================
// KONFIGURASI DATABASE
// ============================================
$hosts = ['localhost', '127.0.0.1'];
$port = '3306';
$dbname = 'spk_beasiswa';
$username = 'root';
$password = '';

$connected = false;
$last_error = '';

// Coba semua host
foreach ($hosts as $host) {
    $connection = @fsockopen($host, $port, $errno, $errstr, 3);
    
    if ($connection) {
        fclose($connection);
        
        try {
            $mysqli = new mysqli($host, $username, $password, $dbname, $port);
            
            if ($mysqli->connect_error) {
                throw new Exception($mysqli->connect_error);
            }
            
            $mysqli->set_charset("utf8mb4");
            $connected = true;
            break;
            
        } catch (Exception $e) {
            $last_error = $e->getMessage();
            continue;
        }
    } else {
        $last_error = "No connection to $host:$port - $errstr ($errno)";
    }
}

if (!$connected) {
    die("
    <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 30px; background: #fff3f3; border: 1px solid #f5c6cb; border-radius: 10px;'>
        <h2 style='color: #721c24;'>⚠️ Koneksi Database Gagal</h2>
        <p><strong>Error:</strong> $last_error</p>
        <hr>
        <h4>💡 Solusi:</h4>
        <ol>
            <li>Pastikan MySQL sudah Running di XAMPP Control Panel</li>
            <li>Klik Start pada baris MySQL</li>
            <li>Refresh halaman ini</li>
        </ol>
    </div>
    ");
}

// ============================================
// CLASS STATEMENTWRAPPER - LENGKAP
// ============================================
class StatementWrapper {
    private $stmt;
    private $mysqli;
    private $sql;
    private $result;
    
    public function __construct($mysqli, $sql) {
        $this->mysqli = $mysqli;
        $this->sql = $sql;
    }
    
    public function execute($params = []) {
        $this->stmt = $this->mysqli->prepare($this->sql);
        if ($this->stmt === false) {
            throw new Exception($this->mysqli->error);
        }
        
        if (!empty($params)) {
            $types = '';
            $bindParams = [];
            foreach($params as $param) {
                if (is_int($param)) {
                    $types .= 'i';
                } elseif (is_float($param)) {
                    $types .= 'd';
                } elseif (is_null($param)) {
                    $types .= 's';
                    $param = null;
                } else {
                    $types .= 's';
                }
                $bindParams[] = $param;
            }
            $this->stmt->bind_param($types, ...$bindParams);
        }
        
        $executed = $this->stmt->execute();
        
        // Simpan result untuk method get_result()
        $this->result = $this->stmt->get_result();
        
        return $executed;
    }
    
    // ============================================
    // METHOD get_result() - FIX!
    // ============================================
    public function get_result() {
        if ($this->result === null) {
            // Jika belum di-execute, jalankan dulu
            $this->execute();
        }
        return $this->result;
    }
    
    public function fetch() {
        if ($this->result === null) {
            $this->execute();
        }
        return $this->result->fetch_assoc();
    }
    
    public function fetchAll() {
        if ($this->result === null) {
            $this->execute();
        }
        return $this->result->fetch_all(MYSQLI_ASSOC);
    }
    
    public function fetchColumn() {
        if ($this->result === null) {
            $this->execute();
        }
        $row = $this->result->fetch_row();
        return $row[0] ?? null;
    }
    
    public function rowCount() {
        if ($this->stmt === null) {
            return 0;
        }
        return $this->stmt->affected_rows;
    }
}

// ============================================
// CLASS DBWRAPPER
// ============================================
class DBWrapper {
    private $mysqli;
    
    public function __construct($mysqli) {
        $this->mysqli = $mysqli;
    }
    
    public function query($sql) {
        $result = $this->mysqli->query($sql);
        if ($result === false) {
            throw new Exception($this->mysqli->error);
        }
        return $result;
    }
    
    public function prepare($sql) {
        return new StatementWrapper($this->mysqli, $sql);
    }
    
    public function exec($sql) {
        return $this->mysqli->query($sql);
    }
    
    public function lastInsertId() {
        return $this->mysqli->insert_id;
    }
    
    public function errorInfo() {
        return [$this->mysqli->errno, $this->mysqli->error];
    }
}

$pdo = new DBWrapper($mysqli);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>