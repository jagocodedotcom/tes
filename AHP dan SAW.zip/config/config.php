<?php
// config/config.php
define('BASE_URL', '/spk_beasiswa');
define('BASE_PATH', __DIR__ . '/..');

// Set timezone
date_default_timezone_set('Asia/Jakarta');

// Error reporting untuk development
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
?>