<?php
header('Location: modul/login/');
exit;
?>