<?php
// cover_ebook.php - COVER EBOOK SPK BEASISWA AHP & SAW
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cover Ebook - SPK Beasiswa AHP & SAW</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        /* ============================================
           COVER EBOOK STYLES
           ============================================ */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: #f0f4ff;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            padding: 20px;
        }

        /* ============================================
           COVER CONTAINER
           ============================================ */
        .cover-wrapper {
            display: flex;
            gap: 40px;
            flex-wrap: wrap;
            align-items: center;
            justify-content: center;
            max-width: 1200px;
            width: 100%;
        }

        /* ============================================
           COVER UTAMA (BUKU)
           ============================================ */
        .cover-book {
            width: 450px;
            height: 600px;
            background: linear-gradient(145deg, #011851 0%, #0a2a7a 30%, #1a3a9a 60%, #2d4ab8 100%);
            border-radius: 16px;
            position: relative;
            overflow: hidden;
            box-shadow: 
                0 30px 80px rgba(1, 24, 81, 0.4),
                0 10px 30px rgba(0, 0, 0, 0.2),
                inset 0 0 60px rgba(255, 255, 255, 0.02);
            padding: 40px 36px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            transition: all 0.3s ease;
            flex-shrink: 0;
        }

        .cover-book:hover {
            transform: translateY(-10px) scale(1.01);
            box-shadow: 
                0 40px 100px rgba(1, 24, 81, 0.5),
                0 15px 40px rgba(0, 0, 0, 0.25);
        }

        /* Background efek */
        .cover-book::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -30%;
            width: 80%;
            height: 80%;
            background: radial-gradient(ellipse, rgba(255, 215, 0, 0.06), transparent 70%);
            border-radius: 50%;
            pointer-events: none;
        }

        .cover-book::after {
            content: '';
            position: absolute;
            bottom: -20%;
            left: -20%;
            width: 60%;
            height: 60%;
            background: radial-gradient(ellipse, rgba(255, 215, 0, 0.04), transparent 70%);
            border-radius: 50%;
            pointer-events: none;
        }

        /* Garis dekoratif */
        .cover-book .decorative-line {
            position: absolute;
            top: 0;
            right: 0;
            width: 200px;
            height: 200px;
            border-right: 3px solid rgba(255, 215, 0, 0.08);
            border-top: 3px solid rgba(255, 215, 0, 0.08);
            border-radius: 0 16px 0 0;
            pointer-events: none;
        }

        .cover-book .decorative-line-bottom {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 150px;
            height: 150px;
            border-left: 3px solid rgba(255, 215, 0, 0.06);
            border-bottom: 3px solid rgba(255, 215, 0, 0.06);
            border-radius: 0 0 0 16px;
            pointer-events: none;
        }

        /* ============================================
        COVER - BAGIAN ATAS
        ============================================ */
        .cover-top {
            position: relative;
            z-index: 2;
        }

        .cover-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: rgba(255, 215, 0, 0.12);
            border: 1px solid rgba(255, 215, 0, 0.2);
            border-radius: 30px;
            padding: 6px 16px 6px 10px;
            font-size: 0.7rem;
            font-weight: 600;
            color: #ffd966;
            letter-spacing: 0.5px;
            text-transform: uppercase;
            margin-bottom: 24px;
        }

        .cover-badge i {
            font-size: 0.8rem;
            background: #ffd966;
            color: #011851;
            border-radius: 50%;
            padding: 2px;
        }

        .cover-title {
            position: relative;
            z-index: 2;
        }

        .cover-title .pre-title {
            font-size: 0.75rem;
            font-weight: 400;
            color: rgba(255, 255, 255, 0.5);
            letter-spacing: 3px;
            text-transform: uppercase;
            margin-bottom: 8px;
        }

        .cover-title h1 {
            font-size: 2.6rem;
            font-weight: 900;
            color: #ffffff;
            line-height: 1.1;
            letter-spacing: -1px;
            margin-bottom: 4px;
        }

        .cover-title h1 span {
            color: #ffd966;
            position: relative;
        }

        .cover-title h1 span::after {
            content: '';
            position: absolute;
            bottom: 2px;
            left: 0;
            right: 0;
            height: 4px;
            background: #ffd966;
            border-radius: 4px;
            opacity: 0.3;
        }

        .cover-title .sub-title {
            font-size: 1rem;
            font-weight: 400;
            color: rgba(255, 255, 255, 0.7);
            margin-top: 8px;
            line-height: 1.5;
        }

        /* ============================================
        COVER - BAGIAN TENGAH (ILUSTRASI)
        ============================================ */
        .cover-middle {
            position: relative;
            z-index: 2;
            display: flex;
            justify-content: center;
            align-items: center;
            flex: 1;
            padding: 16px 0;
        }

        .cover-illustration {
            display: flex;
            gap: 20px;
            align-items: center;
            justify-content: center;
            flex-wrap: wrap;
            width: 100%;
        }

        .illustration-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 6px;
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid rgba(255, 255, 255, 0.06);
            border-radius: 14px;
            padding: 16px 20px;
            transition: all 0.3s ease;
            min-width: 70px;
        }

        .illustration-item:hover {
            background: rgba(255, 255, 255, 0.08);
            transform: scale(1.05);
        }

        .illustration-item .icon {
            font-size: 2rem;
            color: #ffd966;
        }

        .illustration-item .label {
            font-size: 0.55rem;
            font-weight: 600;
            color: rgba(255, 255, 255, 0.5);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .illustration-item .value {
            font-size: 0.8rem;
            font-weight: 700;
            color: #ffffff;
        }

        .illustration-divider {
            width: 2px;
            height: 50px;
            background: rgba(255, 255, 255, 0.06);
        }

        /* ============================================
        COVER - BAGIAN BAWAH
        ============================================ */
        .cover-bottom {
            position: relative;
            z-index: 2;
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            flex-wrap: wrap;
            gap: 16px;
        }

        .cover-methods {
            display: flex;
            gap: 12px;
            align-items: center;
        }

        .method-tag {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 700;
            color: #fff;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .method-tag.ahp {
            background: rgba(59, 130, 246, 0.2);
            border: 1px solid rgba(59, 130, 246, 0.3);
            color: #60a5fa;
        }

        .method-tag.saw {
            background: rgba(16, 185, 129, 0.2);
            border: 1px solid rgba(16, 185, 129, 0.3);
            color: #34d399;
        }

        .cover-author {
            text-align: right;
        }

        .cover-author .name {
            font-weight: 700;
            font-size: 0.9rem;
            color: #ffffff;
        }

        .cover-author .role {
            font-size: 0.65rem;
            color: rgba(255, 255, 255, 0.4);
        }

        .cover-bottom-line {
            width: 100%;
            height: 1px;
            background: linear-gradient(90deg, transparent, rgba(255, 215, 0, 0.15), transparent);
            margin-top: 12px;
        }

        /* ============================================
        COVER - SISI (EFFECT BUKU)
        ============================================ */
        .cover-spine {
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            width: 8px;
            background: linear-gradient(180deg, rgba(0,0,0,0.2), rgba(0,0,0,0.05), rgba(0,0,0,0.2));
            border-radius: 16px 0 0 16px;
        }

        /* ============================================
        INFO PANEL SAMPING
        ============================================ */
        .cover-info {
            max-width: 350px;
            padding: 20px;
        }

        .cover-info h2 {
            font-size: 1.2rem;
            font-weight: 700;
            color: #011851;
            margin-bottom: 12px;
        }

        .cover-info .desc {
            color: #4b5563;
            font-size: 0.9rem;
            line-height: 1.7;
            margin-bottom: 16px;
        }

        .cover-info .features {
            list-style: none;
            padding: 0;
        }

        .cover-info .features li {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 8px 0;
            border-bottom: 1px solid #f1f5f9;
            font-size: 0.85rem;
            color: #374151;
        }

        .cover-info .features li:last-child {
            border-bottom: none;
        }

        .cover-info .features li i {
            color: #011851;
            font-size: 1rem;
            width: 20px;
        }

        .cover-info .btn-download {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 12px 28px;
            background: linear-gradient(135deg, #011851, #1a3a9a);
            color: #fff;
            border: none;
            border-radius: 12px;
            font-weight: 600;
            font-size: 0.9rem;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            margin-top: 16px;
        }

        .cover-info .btn-download:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 30px rgba(1, 24, 81, 0.3);
            color: #fff;
        }

        /* ============================================
        RESPONSIVE
        ============================================ */
        @media (max-width: 900px) {
            .cover-wrapper {
                flex-direction: column;
                align-items: center;
            }

            .cover-book {
                width: 100%;
                max-width: 400px;
                height: 520px;
                padding: 30px 28px;
            }

            .cover-title h1 {
                font-size: 2rem;
            }

            .cover-info {
                max-width: 100%;
                text-align: center;
            }

            .cover-info .features {
                text-align: left;
                max-width: 400px;
                margin: 0 auto;
            }
        }

        @media (max-width: 480px) {
            .cover-book {
                height: 460px;
                padding: 24px 20px;
                border-radius: 12px;
            }

            .cover-title h1 {
                font-size: 1.6rem;
            }

            .cover-title .sub-title {
                font-size: 0.85rem;
            }

            .illustration-item {
                padding: 10px 14px;
                min-width: 50px;
            }

            .illustration-item .icon {
                font-size: 1.4rem;
            }

            .cover-methods {
                flex-wrap: wrap;
            }

            .cover-bottom {
                flex-direction: column;
                align-items: flex-start;
            }

            .cover-author {
                text-align: left;
                width: 100%;
            }

            .cover-info {
                padding: 10px;
            }
        }
    </style>
</head>
<body>

    <div class="cover-wrapper">

        <!-- ============================================
        COVER BUKU
        ============================================ -->
        <div class="cover-book" id="coverBook">

            <!-- Spine effect -->
            <div class="cover-spine"></div>

            <!-- Dekorasi -->
            <div class="decorative-line"></div>
            <div class="decorative-line-bottom"></div>

            <!-- BAGIAN ATAS -->
            <div class="cover-top">
                <div class="cover-badge">
                    <i class="bi bi-star-fill"></i>
                    Sistem Pendukung Keputusan
                </div>

                <div class="cover-title">
                    <div class="pre-title">📘 Panduan Lengkap</div>
                    <h1>
                        SPK <span>Beasiswa</span>
                    </h1>
                    <div class="sub-title">
                        Implementasi Metode <strong>AHP</strong> &amp; <strong>SAW</strong> 
                        untuk Seleksi Beasiswa Berprestasi
                    </div>
                </div>
            </div>

            <!-- BAGIAN TENGAH -->
            <div class="cover-middle">
                <div class="cover-illustration">
                    <div class="illustration-item">
                        <div class="icon">📊</div>
                        <div class="label">AHP</div>
                        <div class="value">Bobot</div>
                    </div>

                    <div class="illustration-divider"></div>

                    <div class="illustration-item">
                        <div class="icon">🧮</div>
                        <div class="label">SAW</div>
                        <div class="value">Ranking</div>
                    </div>

                    <div class="illustration-divider"></div>

                    <div class="illustration-item">
                        <div class="icon">🏆</div>
                        <div class="label">Hasil</div>
                        <div class="value">Akurat</div>
                    </div>
                </div>
            </div>

            <!-- BAGIAN BAWAH -->
            <div class="cover-bottom">
                <div class="cover-methods">
                    <span class="method-tag ahp">
                        <i class="bi bi-check-circle-fill"></i> AHP
                    </span>
                    <span class="method-tag saw">
                        <i class="bi bi-check-circle-fill"></i> SAW
                    </span>
                    <span class="method-tag" style="background:rgba(255,215,0,0.1);border-color:rgba(255,215,0,0.2);color:#ffd966;">
                        <i class="bi bi-trophy-fill"></i> Beasiswa
                    </span>
                </div>

                <div class="cover-author">
                    <div class="name">Sistem Pendukung Keputusan</div>
                    <div class="role">SPK Beasiswa Berprestasi</div>
                </div>

                <div class="cover-bottom-line"></div>
            </div>

        </div>

        <!-- ============================================
        INFO PANEL
        ============================================ -->
        <div class="cover-info">
            <h2>📖 Tentang Ebook Ini</h2>
            <p class="desc">
                Ebook ini membahas secara lengkap implementasi 
                <strong>SPK (Sistem Pendukung Keputusan)</strong> untuk 
                seleksi penerima beasiswa berprestasi menggunakan 
                metode <strong>AHP</strong> dan <strong>SAW</strong>.
            </p>

            <ul class="features">
                <li>
                    <i class="bi bi-check-circle-fill"></i>
                    <span><strong>5 Kriteria</strong> Penilaian Beasiswa</span>
                </li>
                <li>
                    <i class="bi bi-check-circle-fill"></i>
                    <span><strong>10 Alternatif</strong> Calon Penerima</span>
                </li>
                <li>
                    <i class="bi bi-check-circle-fill"></i>
                    <span>Perhitungan <strong>Bobot AHP</strong> dengan Uji Konsistensi</span>
                </li>
                <li>
                    <i class="bi bi-check-circle-fill"></i>
                    <span>Perhitungan <strong>Skor SAW</strong> &amp; Ranking</span>
                </li>
                <li>
                    <i class="bi bi-check-circle-fill"></i>
                    <span><strong>Perbandingan</strong> Hasil AHP &amp; SAW</span>
                </li>
                <li>
                    <i class="bi bi-check-circle-fill"></i>
                    <span>Studi Kasus <strong>Beasiswa Berprestasi</strong></span>
                </li>
            </ul>

            <a href="#" class="btn-download" onclick="downloadCover()">
                <i class="bi bi-download"></i>
                Download Cover
            </a>
        </div>

    </div>

    <!-- ============================================
    JAVASCRIPT
    ============================================ -->
    <script>
        // ============================================
        // DOWNLOAD COVER (SCREENSHOT)
        // ============================================
        function downloadCover() {
            alert('🖼️ Untuk mendownload cover, gunakan fitur screenshot browser:\n\n' +
                  '📌 Windows: Ctrl + Shift + S (Snipping Tool)\n' +
                  '📌 Mac: Cmd + Shift + 4\n' +
                  '📌 Atau gunakan ekstensi browser untuk screenshot');
        }

        // ============================================
        // KEYBOARD SHORTCUT - PRINT
        // ============================================
        document.addEventListener('keydown', function(e) {
            if (e.ctrlKey && e.key === 'p') {
                e.preventDefault();
                window.print();
            }
        });

        console.log('📚 Cover Ebook SPK Beasiswa loaded!');
        console.log('💡 Tekan Ctrl+P untuk print/save as PDF');
    </script>

</body>
</html>