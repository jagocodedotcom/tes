<?php
// modul/dashboard/index.php - DENGAN RINGKASAN METODE
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

require_once '../../config/database.php';

if(!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: ../login/');
    exit;
}

$page_title = 'Dashboard';

// ============================================
// AMBIL DATA UNTUK SIDEBAR
// ============================================
$result = $pdo->query("SELECT COUNT(*) FROM alternatif");
$row = $result->fetch_row();
$total_alt = $row[0] ?? 0;

$result = $pdo->query("SELECT COUNT(*) FROM kriteria");
$row = $result->fetch_row();
$total_krit = $row[0] ?? 0;

$result = $pdo->query("SELECT COUNT(*) FROM nilai_alternatif");
$row = $result->fetch_row();
$total_nilai = $row[0] ?? 0;

// ============================================
// AMBIL 3 BESAR
// ============================================
$result = $pdo->query("
    SELECT a.nama, a.nim, a.jurusan, h.skor_akhir, h.ranking, h.status
    FROM hasil_perhitungan h
    JOIN alternatif a ON h.id_alternatif = a.id_alternatif
    ORDER BY h.ranking
    LIMIT 3
");
$top3 = $result->fetch_all(MYSQLI_ASSOC);

// ============================================
// AMBIL DATA KRITERIA UNTUK RINGKASAN
// ============================================
$result = $pdo->query("SELECT * FROM kriteria ORDER BY bobot_ahp DESC");
$kriteria = $result->fetch_all(MYSQLI_ASSOC);

include '../../includes/header.php';
include '../../includes/sidebar.php';
?>

<style>
    /* ============================================
       DASHBOARD STYLES
       ============================================ */
    .stat-card {
        background: #fff;
        border-radius: 16px;
        padding: 18px 20px;
        border: 1px solid #f1f5f9;
        transition: all .3s ease;
        height: 100%;
    }
    .stat-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 4px 20px rgba(0,0,0,0.05);
    }

    .rank-card {
        border-radius: 16px;
        padding: 20px;
        text-align: center;
        height: 100%;
        transition: all .3s ease;
        border: 1px solid #f1f5f9;
    }
    .rank-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 8px 30px rgba(0,0,0,0.05);
    }
    .rank-card.rank-1 {
        background: linear-gradient(135deg, #fef3c7, #fde68a);
        border-color: #f59e0b;
    }
    .rank-card.rank-2 {
        background: linear-gradient(135deg, #f1f5f9, #e2e8f0);
        border-color: #94a3b8;
    }
    .rank-card.rank-3 {
        background: linear-gradient(135deg, #fef3c7, #fcd34d);
        border-color: #d97706;
    }
    .rank-card .rank-number {
        font-size: 2.5rem;
        font-weight: 800;
    }
    .rank-card .rank-emoji {
        font-size: 3rem;
    }

    /* ============================================
       RINGKASAN METODE
       ============================================ */
    .method-card {
        background: #fff;
        border-radius: 16px;
        border: 1px solid #f1f5f9;
        padding: 24px;
        height: 100%;
        transition: all .3s ease;
    }
    .method-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 4px 20px rgba(0,0,0,0.05);
    }
    .method-card .method-icon {
        font-size: 2.5rem;
        margin-bottom: 12px;
    }
    .method-card .method-title {
        font-weight: 700;
        font-size: 1.1rem;
        margin-bottom: 8px;
    }
    .method-card .method-title.ahp { color: #011851; }
    .method-card .method-title.saw { color: #059669; }
    .method-card .method-desc {
        color: #6b7280;
        font-size: .9rem;
        line-height: 1.6;
    }
    .method-card .method-step {
        background: #f8fafc;
        border-radius: 8px;
        padding: 8px 12px;
        margin: 4px 0;
        font-size: .85rem;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .method-card .method-step .step-num {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 24px;
        height: 24px;
        border-radius: 50%;
        font-size: .7rem;
        font-weight: 700;
        color: #fff;
        flex-shrink: 0;
    }
    .method-card .method-step .step-num.ahp-num { background: #011851; }
    .method-card .method-step .step-num.saw-num { background: #059669; }

    .method-badge {
        display: inline-block;
        padding: 2px 10px;
        border-radius: 20px;
        font-size: .7rem;
        font-weight: 600;
    }
    .method-badge.ahp-badge { background: #dbeafe; color: #011851; }
    .method-badge.saw-badge { background: #d1fae5; color: #065f46; }
    .method-badge.output-badge { background: #fef3c7; color: #92400e; }

    .card-custom {
        background: #fff;
        border-radius: 16px;
        border: 1px solid #f1f5f9;
        box-shadow: 0 1px 3px rgba(0,0,0,0.04);
        overflow: hidden;
        width: 100%;
    }
    .card-custom .card-body {
        padding: 20px;
        overflow-x: auto;
    }
    .card-custom .card-header {
        background: transparent;
        border-bottom: 1px solid #f1f5f9;
        padding: 16px 20px;
        font-weight: 600;
    }

    .table-responsive-custom {
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
        width: 100%;
        display: block;
    }
    .table-responsive-custom table {
        width: 100%;
        min-width: 600px;
        margin-bottom: 0;
        background: #fff;
        border-radius: 12px;
        overflow: hidden;
    }

    .quick-action-btn {
        padding: 8px 16px;
        border-radius: 10px;
        font-weight: 600;
        font-size: .85rem;
        transition: all .3s ease;
        border: none;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        text-decoration: none;
    }
    .quick-action-btn:hover {
        transform: translateY(-2px);
        text-decoration: none;
    }
    .quick-action-btn.primary {
        background: linear-gradient(135deg, #011851, #1a3a9a);
        color: #fff;
    }
    .quick-action-btn.primary:hover { box-shadow: 0 4px 15px rgba(1,24,81,0.3); color: #fff; }
    .quick-action-btn.success {
        background: linear-gradient(135deg, #059669, #34d399);
        color: #fff;
    }
    .quick-action-btn.success:hover { box-shadow: 0 4px 15px rgba(5,150,105,0.3); color: #fff; }
    .quick-action-btn.info {
        background: linear-gradient(135deg, #0ea5e9, #38bdf8);
        color: #fff;
    }
    .quick-action-btn.info:hover { box-shadow: 0 4px 15px rgba(14,165,233,0.3); color: #fff; }
    .quick-action-btn.warning {
        background: linear-gradient(135deg, #f59e0b, #fbbf24);
        color: #fff;
    }
    .quick-action-btn.warning:hover { box-shadow: 0 4px 15px rgba(245,158,11,0.3); color: #fff; }
</style>

<div class="app-content">

    <!-- ============================================
    HEADER
    ============================================ -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold mb-1">
                <i class="bi bi-speedometer2 text-primary me-2"></i>
                Dashboard
            </h4>
            <p class="text-muted small mb-0">
                <i class="bi bi-calendar3 me-1"></i>
                <?= date('l, d F Y') ?> · 
                <span class="badge bg-primary"><?= date('H:i') ?> WIB</span>
            </p>
        </div>
        <span class="badge bg-primary p-2">
            <i class="bi bi-person-circle me-1"></i>
            <?= $_SESSION['nama_lengkap'] ?? 'User' ?>
        </span>
    </div>

    <!-- ============================================
    STATISTIK
    ============================================ -->
    <div class="row g-3 mb-4">
        <div class="col-md-3 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h2 class="mb-0 fw-bold text-primary"><?= $total_alt ?></h2>
                        <small class="text-muted">Alternatif</small>
                    </div>
                    <i class="bi bi-people-fill text-primary fs-1 opacity-25"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h2 class="mb-0 fw-bold text-success"><?= $total_krit ?></h2>
                        <small class="text-muted">Kriteria</small>
                    </div>
                    <i class="bi bi-list-check text-success fs-1 opacity-25"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h2 class="mb-0 fw-bold text-info"><?= $total_nilai ?></h2>
                        <small class="text-muted">Data Nilai</small>
                    </div>
                    <i class="bi bi-table text-info fs-1 opacity-25"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h2 class="mb-0 fw-bold text-warning"><?= count($top3) ?></h2>
                        <small class="text-muted">3 Besar</small>
                    </div>
                    <i class="bi bi-trophy text-warning fs-1 opacity-25"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- ============================================
    RINGKASAN METODE AHP & SAW
    ============================================ -->
    <div class="row g-4 mb-4">

        <!-- CARD AHP -->
        <div class="col-md-6">
            <div class="method-card">
                <div class="method-icon">📊</div>
                <div class="method-title ahp">
                    AHP (Analytic Hierarchy Process)
                    <span class="method-badge ahp-badge ms-2">AHP</span>
                </div>
                <p class="method-desc">
                    <strong>Tujuan:</strong> Menentukan <strong>bobot kepentingan</strong> setiap kriteria.
                    <br>
                    <strong>Output:</strong> Bobot kriteria yang menunjukkan seberapa penting setiap faktor penilaian.
                </p>

                <div class="mt-3">
                    <strong class="small text-muted">📌 Langkah-langkah AHP:</strong>
                    <div class="method-step">
                        <span class="step-num ahp-num">1</span>
                        <span>Membuat <strong>Matriks Perbandingan</strong> antar kriteria (Skala Saaty 1-9)</span>
                    </div>
                    <div class="method-step">
                        <span class="step-num ahp-num">2</span>
                        <span><strong>Normalisasi</strong> matriks (membagi setiap nilai dengan jumlah kolom)</span>
                    </div>
                    <div class="method-step">
                        <span class="step-num ahp-num">3</span>
                        <span>Menghitung <strong>Bobot (Eigen Vector)</strong> dari rata-rata baris normalisasi</span>
                    </div>
                    <div class="method-step">
                        <span class="step-num ahp-num">4</span>
                        <span><strong>Uji Konsistensi</strong> (CR ≤ 0.10) untuk memastikan validitas perbandingan</span>
                    </div>
                </div>

                <div class="alert alert-info mt-3 mb-0">
                    <i class="bi bi-check-circle me-2"></i>
                    <strong>Hasil AHP:</strong>
                    <?php if(!empty($kriteria)): ?>
                        <?php foreach($kriteria as $k): ?>
                            <span class="badge bg-primary me-1"><?= $k['kode_kriteria'] ?> = <?= number_format($k['bobot_ahp'] * 100, 1) ?>%</span>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <span class="text-muted">Belum ada data kriteria</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- CARD SAW -->
        <div class="col-md-6">
            <div class="method-card">
                <div class="method-icon">🧮</div>
                <div class="method-title saw">
                    SAW (Simple Additive Weighting)
                    <span class="method-badge saw-badge ms-2">SAW</span>
                </div>
                <p class="method-desc">
                    <strong>Tujuan:</strong> Menghitung <strong>skor akhir</strong> setiap alternatif.
                    <br>
                    <strong>Output:</strong> Ranking alternatif berdasarkan skor tertinggi.
                </p>

                <div class="mt-3">
                    <strong class="small text-muted">📌 Langkah-langkah SAW:</strong>
                    <div class="method-step">
                        <span class="step-num saw-num">1</span>
                        <span><strong>Normalisasi</strong> nilai alternatif (Benefit: X/max, Cost: min/X)</span>
                    </div>
                    <div class="method-step">
                        <span class="step-num saw-num">2</span>
                        <span>Mengalikan <strong>bobot kriteria</strong> (dari AHP) dengan nilai normalisasi</span>
                    </div>
                    <div class="method-step">
                        <span class="step-num saw-num">3</span>
                        <span>Menjumlahkan hasil perkalian = <strong>Skor Akhir (V)</strong></span>
                    </div>
                    <div class="method-step">
                        <span class="step-num saw-num">4</span>
                        <span><strong>Ranking</strong> alternatif dari skor tertinggi ke terendah</span>
                    </div>
                </div>

                <div class="alert alert-success mt-3 mb-0">
                    <i class="bi bi-trophy me-2"></i>
                    <strong>Hasil SAW:</strong>
                    <?php if(!empty($top3)): ?>
                        <?php foreach($top3 as $index => $t): ?>
                            <span class="badge <?= $index == 0 ? 'bg-warning text-dark' : 'bg-success' ?> me-1">
                                #<?= $index + 1 ?> <?= htmlspecialchars($t['nama']) ?> = <?= number_format($t['skor_akhir'], 4) ?>
                            </span>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <span class="text-muted">Belum ada hasil perhitungan</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>

    </div>

    <!-- ============================================
    RUMUS & PERBANDINGAN METODE
    ============================================ -->
    <div class="row g-4 mb-4">

        <!-- RUMUS -->
        <div class="col-md-6">
            <div class="card-custom">
                <div class="card-header bg-white">
                    <i class="bi bi-journal-text text-primary me-2"></i>
                    Rumus AHP & SAW
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <h6 class="fw-bold text-primary">📐 Rumus AHP (Bobot Kriteria)</h6>
                        <div class="bg-light p-3 rounded-3 font-monospace" style="font-size:.85rem;">
                            W<sub>i</sub> = (1/n) × Σ(a<sub>ij</sub>')
                            <br>
                            <small class="text-muted">Dimana a<sub>ij</sub>' = a<sub>ij</sub> / Σ(a<sub>ij</sub>)</small>
                        </div>
                        <small class="text-muted">Contoh: W<sub>IPK</sub> = (0.519 + 0.538 + 0.442 + 0.368) / 4 = 0.475 (47.5%)</small>
                    </div>

                    <div>
                        <h6 class="fw-bold text-success">📐 Rumus SAW (Skor Akhir)</h6>
                        <div class="bg-light p-3 rounded-3 font-monospace" style="font-size:.85rem;">
                            V<sub>i</sub> = Σ (W<sub>j</sub> × r<sub>ij</sub>)
                            <br>
                            <small class="text-muted">Dimana r<sub>ij</sub> = normalisasi nilai alternatif</small>
                        </div>
                        <small class="text-muted">Contoh: V<sub>Andi</sub> = (0.475 × 1.00) + (0.227 × 0.57) + (0.095 × 0.80) + (0.047 × 0.78) + (0.137 × 1.00) = 0.8652</small>
                    </div>
                </div>
            </div>
        </div>

        <!-- PERBANDINGAN AHP vs SAW -->
        <div class="col-md-6">
            <div class="card-custom">
                <div class="card-header bg-white">
                    <i class="bi bi-arrow-left-right text-primary me-2"></i>
                    Perbandingan AHP vs SAW
                </div>
                <div class="card-body">
                    <div class="table-responsive-custom">
                        <table class="table table-bordered table-sm">
                            <thead>
                                <tr>
                                    <th style="width:25%;">Aspek</th>
                                    <th style="width:37.5%;" class="text-center text-primary">AHP</th>
                                    <th style="width:37.5%;" class="text-center text-success">SAW</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><strong>Fungsi</strong></td>
                                    <td>Menghitung <strong>bobot kriteria</strong></td>
                                    <td>Menghitung <strong>skor alternatif</strong></td>
                                </tr>
                                <tr>
                                    <td><strong>Input</strong></td>
                                    <td>Matriks perbandingan kriteria</td>
                                    <td>Nilai alternatif + Bobot AHP</td>
                                </tr>
                                <tr>
                                    <td><strong>Output</strong></td>
                                    <td><span class="badge bg-primary">Bobot (W)</span></td>
                                    <td><span class="badge bg-success">Skor + Ranking</span></td>
                                </tr>
                                <tr>
                                    <td><strong>Metode</strong></td>
                                    <td>Eigen Vector</td>
                                    <td>Normalisasi + Penjumlahan</td>
                                </tr>
                                <tr>
                                    <td><strong>Uji</strong></td>
                                    <td><span class="badge bg-warning text-dark">Konsistensi (CR)</span></td>
                                    <td><span class="badge bg-secondary">-</span></td>
                                </tr>
                                <tr>
                                    <td><strong>Kegunaan</strong></td>
                                    <td>Menentukan <strong>prioritas kriteria</strong></td>
                                    <td>Menentukan <strong>ranking alternatif</strong></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="alert alert-light mt-2 mb-0">
                        <i class="bi bi-info-circle me-2"></i>
                        <strong>Kesimpulan:</strong> AHP menentukan <span class="badge bg-primary">BOBOT</span>, SAW menentukan <span class="badge bg-success">RANKING</span>. Keduanya saling melengkapi!
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- ============================================
    3 BESAR
    ============================================ -->
    <div class="card-custom mb-4">
        <div class="card-header bg-white">
            <h5 class="fw-bold mb-0">
                <i class="bi bi-trophy-fill text-warning me-2"></i>
                3 Besar Calon Penerima Beasiswa
            </h5>
        </div>
        <div class="card-body">
            <?php if(!empty($top3)): ?>
                <div class="row g-3">
                    <?php 
                    $rankEmoji = ['🥇', '🥈', '🥉'];
                    $rankClass = ['rank-1', 'rank-2', 'rank-3'];
                    $badgeStatus = [
                        'penerima' => 'bg-success',
                        'cadangan1' => 'bg-warning text-dark',
                        'cadangan2' => 'bg-info'
                    ];
                    $statusText = [
                        'penerima' => '✅ Penerima',
                        'cadangan1' => '📌 Cadangan 1',
                        'cadangan2' => '📌 Cadangan 2'
                    ];
                    foreach($top3 as $index => $t): 
                    ?>
                        <div class="col-md-4">
                            <div class="rank-card <?= $rankClass[$index] ?? '' ?>">
                                <div class="rank-emoji"><?= $rankEmoji[$index] ?? '#' ?></div>
                                <div class="rank-number">#<?= $index + 1 ?></div>
                                <h6 class="fw-bold mt-2 mb-1"><?= htmlspecialchars($t['nama']) ?></h6>
                                <small class="text-muted"><?= htmlspecialchars($t['nim']) ?></small>
                                <div class="mt-2">
                                    <span class="badge <?= $badgeStatus[$t['status']] ?? 'bg-secondary' ?>">
                                        <?= $statusText[$t['status']] ?? $t['status'] ?>
                                    </span>
                                </div>
                                <div class="mt-2">
                                    <strong>Skor: </strong>
                                    <span class="fw-bold"><?= number_format($t['skor_akhir'], 4) ?></span>
                                </div>
                                <small class="text-muted d-block"><?= htmlspecialchars($t['jurusan']) ?></small>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="text-center py-4 text-muted">
                    <i class="bi bi-inbox display-4 d-block mb-2"></i>
                    <p>Belum ada hasil perhitungan.</p>
                    <a href="<?= BASE_URL ?>/modul/perhitungan/" class="btn btn-primary btn-sm">
                        <i class="bi bi-calculator"></i> Mulai Perhitungan
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- ============================================
    QUICK ACTION
    ============================================ -->
    <div class="card-custom">
        <div class="card-body">
            <h6 class="fw-bold mb-3">
                <i class="bi bi-lightning-fill text-warning me-2"></i>
                Quick Action
            </h6>
            <div class="d-flex flex-wrap gap-2">
                <a href="<?= BASE_URL ?>/modul/alternatif/tambah.php" class="quick-action-btn primary">
                    <i class="bi bi-plus-circle"></i> Tambah Alternatif
                </a>
                <a href="<?= BASE_URL ?>/modul/kriteria/tambah.php" class="quick-action-btn success">
                    <i class="bi bi-plus-circle"></i> Tambah Kriteria
                </a>
                <a href="<?= BASE_URL ?>/modul/nilai/tambah.php" class="quick-action-btn info">
                    <i class="bi bi-plus-circle"></i> Tambah Nilai
                </a>
                <a href="<?= BASE_URL ?>/modul/perhitungan/" class="quick-action-btn warning">
                    <i class="bi bi-calculator"></i> Hitung AHP & SAW
                </a>
                <a href="<?= BASE_URL ?>/modul/perhitungan/perbandingan.php" class="quick-action-btn" style="background:linear-gradient(135deg,#7c3aed,#a78bfa);color:#fff;">
                    <i class="bi bi-arrow-left-right"></i> Perbandingan
                </a>
            </div>
        </div>
    </div>

</div>

<?php include '../../includes/footer.php'; ?>