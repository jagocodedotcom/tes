<?php
// modul/kriteria/tambah.php - FIXED VERSION
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

ob_start();

require_once '../../config/database.php';

if(!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: ../login/');
    exit;
}

$page_title = 'Tambah Kriteria';

// ============================================
// AMBIL DATA UNTUK SIDEBAR - FIX: ganti fetchColumn()
// ============================================

// Total Alternatif
$result = $pdo->query("SELECT COUNT(*) FROM alternatif");
$row = $result->fetch_row();
$total_alt = $row[0] ?? 0;

// Total Kriteria
$result = $pdo->query("SELECT COUNT(*) FROM kriteria");
$row = $result->fetch_row();
$total_krit = $row[0] ?? 0;

// Total Nilai
$result = $pdo->query("SELECT COUNT(*) FROM nilai_alternatif");
$row = $result->fetch_row();
$total_nilai = $row[0] ?? 0;

// ============================================
// PROSES FORM
// ============================================
$error = null;

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $kode = trim($_POST['kode_kriteria']);
    $nama = trim($_POST['nama_kriteria']);
    $jenis = $_POST['jenis'];
    $bobot = floatval($_POST['bobot_ahp']);

    try {
        $stmt = $pdo->prepare("INSERT INTO kriteria (kode_kriteria, nama_kriteria, jenis, bobot_ahp) VALUES (?, ?, ?, ?)");
        $stmt->execute([$kode, $nama, $jenis, $bobot]);
        $_SESSION['success'] = 'Kriteria berhasil ditambahkan!';
        
        ob_end_clean();
        header('Location: index.php');
        exit;
    } catch(Exception $e) {
        $error = 'Gagal: ' . $e->getMessage();
    }
}

include '../../includes/header.php';
include '../../includes/sidebar.php';
?>

<style>
    .form-card{max-width:700px}
    .form-card .card{border-radius:16px;border:none;box-shadow:0 4px 20px rgba(0,0,0,0.04)}
    .form-card .form-control,.form-card .form-select{border-radius:12px;padding:12px 16px;border:1px solid #e5e7eb;transition:all .3s ease}
    .form-card .form-control:focus,.form-card .form-select:focus{border-color:#011851;box-shadow:0 0 0 4px rgba(1,24,81,0.08)}
    .form-card .form-label{font-weight:600;font-size:.9rem;color:#374151}
    .btn-submit{padding:12px 32px;border-radius:12px;font-weight:600;background:linear-gradient(135deg,#011851,#1a3a9a);border:none;color:#fff;transition:all .3s ease}
    .btn-submit:hover{transform:translateY(-2px);box-shadow:0 8px 25px rgba(1,24,81,0.3);color:#fff}
    .help-text{font-size:.75rem;color:#6b7280;margin-top:4px}
    .stat-mini{background:#fff;border-radius:12px;padding:16px 20px;border:1px solid #f1f5f9;transition:all .3s ease}
    .stat-mini:hover{transform:translateY(-4px);box-shadow:0 8px 25px rgba(0,0,0,0.05)}
    .stat-mini .number{font-size:1.8rem;font-weight:800;letter-spacing:-1px;color:#011851}
    .stat-mini .label{font-size:.8rem;color:#6b7280;font-weight:500}
</style>

<div class="app-content">

    <div class="d-flex align-items-center mb-4">
        <a href="index.php" class="btn btn-outline-secondary btn-sm me-3">
            <i class="bi bi-arrow-left"></i> Kembali
        </a>
        <h4 class="fw-bold mb-0">
            <i class="bi bi-plus-circle text-primary me-2"></i>
            Tambah Kriteria
        </h4>
    </div>

    <?php if(isset($error)): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <?= htmlspecialchars($error) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row g-3 mb-4">
        <div class="col-md-3 col-6">
            <div class="stat-mini">
                <div class="d-flex justify-content-between align-items-center">
                    <div><div class="number"><?= $total_alt ?></div><div class="label">Alternatif</div></div>
                    <i class="bi bi-people-fill text-primary fs-2 opacity-25"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-mini">
                <div class="d-flex justify-content-between align-items-center">
                    <div><div class="number"><?= $total_krit ?></div><div class="label">Kriteria</div></div>
                    <i class="bi bi-list-check text-success fs-2 opacity-25"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-mini">
                <div class="d-flex justify-content-between align-items-center">
                    <div><div class="number"><?= $total_nilai ?></div><div class="label">Nilai</div></div>
                    <i class="bi bi-table text-info fs-2 opacity-25"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-mini">
                <div class="d-flex justify-content-between align-items-center">
                    <div><div class="number">+1</div><div class="label">Akan Ditambah</div></div>
                    <i class="bi bi-plus-circle text-warning fs-2 opacity-25"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="form-card mx-auto">
        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label"><i class="bi bi-tag me-1"></i> Kode Kriteria</label>
                        <input type="text" name="kode_kriteria" class="form-control" placeholder="Contoh: C1, C2, C3..." required>
                        <div class="help-text">Gunakan kode unik seperti C1, C2, dst.</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><i class="bi bi-text-paragraph me-1"></i> Nama Kriteria</label>
                        <input type="text" name="nama_kriteria" class="form-control" placeholder="Contoh: IPK, Prestasi, dll" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><i class="bi bi-arrow-up-down me-1"></i> Jenis</label>
                        <select name="jenis" class="form-select">
                            <option value="benefit">📈 Benefit (semakin besar semakin baik)</option>
                            <option value="cost">📉 Cost (semakin kecil semakin baik)</option>
                        </select>
                        <div class="help-text">Pilih benefit jika nilai tinggi lebih baik, cost jika nilai rendah lebih baik.</div>
                    </div>
                    <div class="mb-4">
                        <label class="form-label"><i class="bi bi-percent me-1"></i> Bobot AHP</label>
                        <input type="number" name="bobot_ahp" class="form-control" step="0.0001" placeholder="Contoh: 0.4750" required>
                        <div class="help-text">Masukkan nilai bobot antara 0 - 1 (contoh: 0.4750).</div>
                    </div>
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn-submit flex-grow-1">
                            <i class="bi bi-save me-2"></i> Simpan Kriteria
                        </button>
                        <a href="index.php" class="btn btn-secondary" style="border-radius:12px;">
                            <i class="bi bi-x-lg"></i>
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>

</div>

<?php 
include '../../includes/footer.php';
ob_end_flush();
?>