<?php
// modul/kriteria/index.php - FINAL VERSION
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

require_once '../../config/database.php';

if(!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: ../login/');
    exit;
}

$page_title = 'Data Kriteria';

// ============================================
// AMBIL DATA UNTUK SIDEBAR
// ============================================

// Total Alternatif
$result = $pdo->query("SELECT COUNT(*) FROM alternatif");
$row = $result->fetch_row();
$total_alt = $row[0] ?? 0;

// Total Kriteria
$result = $pdo->query("SELECT COUNT(*) FROM kriteria");
$row = $result->fetch_row();
$total_krit = $row[0] ?? 0;

// Total Nilai
$result = $pdo->query("SELECT COUNT(*) FROM nilai_alternatif");
$row = $result->fetch_row();
$total_nilai = $row[0] ?? 0;

// ============================================
// AMBIL DATA KRITERIA
// ============================================
$result = $pdo->query("
    SELECT k.*, 
           COUNT(n.id_nilai) as total_nilai
    FROM kriteria k
    LEFT JOIN nilai_alternatif n ON k.id_kriteria = n.id_kriteria
    GROUP BY k.id_kriteria
    ORDER BY k.id_kriteria
");

if (!$result) {
    die("Error query: " . $pdo->errorInfo()[2]);
}

$kriteria = $result->fetch_all(MYSQLI_ASSOC);

include '../../includes/header.php';
include '../../includes/sidebar.php';
?>

<style>
    .stat-card {
        background: #ffffff;
        border-radius: 16px;
        padding: 18px 20px;
        border: 1px solid #f1f5f9;
        transition: all 0.3s ease;
        height: 100%;
    }

    .stat-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
    }

    .table-kriteria thead th {
        background: linear-gradient(135deg, #011851, #1a3a9a);
        color: white;
        font-weight: 600;
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        padding: 10px 14px;
        border: none;
    }

    .table-kriteria tbody td {
        padding: 10px 14px;
        vertical-align: middle;
    }

    .table-kriteria tbody tr:hover {
        background: #f8faff;
    }

    .btn-action {
        width: 34px;
        height: 34px;
        border-radius: 10px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        transition: all 0.2s ease;
        border: none;
    }

    .btn-action:hover {
        transform: scale(1.1);
    }

    .btn-action.edit {
        background: #fef3c7;
        color: #d97706;
    }

    .btn-action.delete {
        background: #fee2e2;
        color: #dc2626;
    }

    .search-box {
        position: relative;
    }

    .search-box input {
        padding-left: 40px;
        border-radius: 12px;
        border: 1px solid #e5e7eb;
        width: 100%;
        padding: 10px 16px 10px 40px;
    }

    .search-box input:focus {
        border-color: #011851;
        box-shadow: 0 0 0 3px rgba(1, 24, 81, 0.1);
        outline: none;
    }

    .search-box i {
        position: absolute;
        left: 14px;
        top: 50%;
        transform: translateY(-50%);
        color: #9ca3af;
    }

    .badge-jenis {
        padding: 4px 12px;
        border-radius: 20px;
        font-weight: 600;
        font-size: 0.7rem;
        text-transform: uppercase;
        letter-spacing: 0.3px;
    }

    .badge-jenis.benefit {
        background: #d1fae5;
        color: #065f46;
    }

    .badge-jenis.cost {
        background: #fee2e2;
        color: #991b1b;
    }

    .empty-state {
        text-align: center;
        padding: 40px 20px;
    }

    .empty-state i {
        font-size: 3rem;
        color: #d1d5db;
        margin-bottom: 16px;
    }

    .card-custom {
        background: #ffffff;
        border-radius: 16px;
        border: 1px solid #f1f5f9;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04);
        overflow: hidden;
        width: 100%;
    }

    .card-custom .card-body {
        padding: 20px;
        overflow-x: auto;
    }

    .table-responsive-custom {
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
        width: 100%;
        display: block;
    }

    .table-responsive-custom table {
        width: 100%;
        min-width: 600px;
        margin-bottom: 0;
        background: white;
        border-radius: 12px;
        overflow: hidden;
    }

    @media (max-width: 576px) {
        .card-custom .card-body {
            padding: 12px;
        }
    }
</style>

<div class="app-content">

    <!-- Header -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold mb-1">
                <i class="bi bi-list-check text-primary me-2"></i>
                Data Kriteria
            </h4>
            <p class="text-muted small mb-0">Kelola kriteria penilaian beasiswa</p>
        </div>
        <a href="tambah.php" class="btn btn-primary btn-sm">
            <i class="bi bi-plus-circle"></i> Tambah Kriteria
        </a>
    </div>

    <!-- Alert -->
    <?php if(isset($_SESSION['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="bi bi-check-circle-fill me-2"></i>
            <?= $_SESSION['success'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>

    <?php if(isset($_SESSION['error'])): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <?= $_SESSION['error'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <!-- Stats -->
    <div class="row g-3 mb-4">
        <div class="col-md-3 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h2 class="mb-0 fw-bold text-primary"><?= $total_alt ?></h2>
                        <small class="text-muted">Alternatif</small>
                    </div>
                    <i class="bi bi-people-fill text-primary fs-1 opacity-25"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h2 class="mb-0 fw-bold text-success"><?= $total_krit ?></h2>
                        <small class="text-muted">Kriteria</small>
                    </div>
                    <i class="bi bi-list-check text-success fs-1 opacity-25"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h2 class="mb-0 fw-bold text-info"><?= $total_nilai ?></h2>
                        <small class="text-muted">Nilai</small>
                    </div>
                    <i class="bi bi-table text-info fs-1 opacity-25"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h2 class="mb-0 fw-bold text-warning"><?= count($kriteria) ?></h2>
                        <small class="text-muted">Aktif</small>
                    </div>
                    <i class="bi bi-check-circle text-warning fs-1 opacity-25"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Search -->
    <div class="card card-custom mb-4">
        <div class="card-body">
            <div class="row g-3 align-items-center">
                <div class="col-md-6">
                    <div class="search-box">
                        <i class="bi bi-search"></i>
                        <input type="text" id="searchInput" class="form-control" placeholder="Cari kode atau nama kriteria...">
                    </div>
                </div>
                <div class="col-md-6 text-md-end">
                    <span class="text-muted small">
                        <i class="bi bi-database me-1"></i>
                        Menampilkan <strong id="visibleCount"><?= count($kriteria) ?></strong> data
                    </span>
                </div>
            </div>
        </div>
    </div>

    <!-- Table -->
    <div class="card card-custom">
        <div class="card-body">
            <div class="table-responsive-custom">
                <table class="table table-kriteria">
                    <thead>
                        <tr>
                            <th style="width: 50px;">#</th>
                            <th>Kode</th>
                            <th>Nama Kriteria</th>
                            <th>Jenis</th>
                            <th>Bobot</th>
                            <th class="text-center">Nilai</th>
                            <th class="text-center" style="width: 120px;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody id="tableBody">
                        <?php if(!empty($kriteria)): ?>
                            <?php $no = 1; foreach($kriteria as $row): ?>
                                <tr data-search="<?= strtolower($row['kode_kriteria'] . ' ' . $row['nama_kriteria']) ?>">
                                    <td class="fw-bold text-muted"><?= $no++ ?></td>
                                    <td>
                                        <span class="badge bg-primary"><?= htmlspecialchars($row['kode_kriteria']) ?></span>
                                    </td>
                                    <td>
                                        <div class="fw-semibold"><?= htmlspecialchars($row['nama_kriteria']) ?></div>
                                        <small class="text-muted">ID: <?= $row['id_kriteria'] ?></small>
                                    </td>
                                    <td>
                                        <span class="badge-jenis <?= $row['jenis'] ?>">
                                            <?= $row['jenis'] == 'benefit' ? '📈 Benefit' : '📉 Cost' ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="fw-bold text-primary"><?= number_format($row['bobot_ahp'] * 100, 1) ?>%</span>
                                    </td>
                                    <td class="text-center">
                                        <span class="badge bg-info"><?= $row['total_nilai'] ?></span>
                                    </td>
                                    <td>
                                        <div class="d-flex gap-1 justify-content-center">
                                            <a href="edit.php?id=<?= $row['id_kriteria'] ?>" class="btn-action edit" title="Edit">
                                                <i class="bi bi-pencil"></i>
                                            </a>
                                            <a href="hapus.php?id=<?= $row['id_kriteria'] ?>" class="btn-action delete" title="Hapus" onclick="return confirm('Yakin ingin menghapus kriteria ini?')">
                                                <i class="bi bi-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center py-4">
                                    <div class="empty-state">
                                        <i class="bi bi-list-ul"></i>
                                        <h5>Belum Ada Data Kriteria</h5>
                                        <p class="text-muted">Silakan tambahkan kriteria untuk penilaian</p>
                                        <a href="tambah.php" class="btn btn-primary btn-sm">
                                            <i class="bi bi-plus-circle"></i> Tambah Kriteria
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <!-- Footer -->
        <div class="card-footer bg-white border-0 pt-3 pb-3">
            <div class="d-flex justify-content-between align-items-center">
                <span class="text-muted small">
                    <i class="bi bi-database me-1"></i>
                    Total <strong><?= count($kriteria) ?></strong> data kriteria
                </span>
                <span class="text-muted small">
                    <i class="bi bi-clock me-1"></i>
                    Terakhir diupdate: <?= date('H:i:s') ?>
                </span>
            </div>
        </div>
    </div>

</div> <!-- .app-content -->

<script>
document.getElementById('searchInput')?.addEventListener('keyup', function() {
    const query = this.value.toLowerCase().trim();
    const rows = document.querySelectorAll('#tableBody tr[data-search]');
    let visible = 0;

    rows.forEach(function(row) {
        const searchData = row.getAttribute('data-search') || '';
        const match = searchData.includes(query);
        row.style.display = match ? '' : 'none';
        if (match) visible++;
    });

    document.getElementById('visibleCount').textContent = visible;
});
</script>

<?php include '../../includes/footer.php'; ?>