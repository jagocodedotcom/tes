<?php
require_once '../../config/database.php';

if(!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: ../login/');
    exit;
}

$id = $_GET['id'] ?? 0;

try {
    // Cek apakah ada nilai yang menggunakan kriteria ini
    $check = $pdo->prepare("SELECT COUNT(*) FROM nilai_alternatif WHERE id_kriteria = ?");
    $check->execute([$id]);
    $count = $check->fetchColumn();

    if($count > 0) {
        $_SESSION['error'] = "Kriteria tidak bisa dihapus karena sudah digunakan oleh $count data nilai!";
        header('Location: index.php');
        exit;
    }

    $stmt = $pdo->prepare("DELETE FROM kriteria WHERE id_kriteria = ?");
    $stmt->execute([$id]);
    $_SESSION['success'] = 'Kriteria berhasil dihapus!';
} catch(PDOException $e) {
    $_SESSION['error'] = 'Gagal hapus: ' . $e->getMessage();
}

header('Location: index.php');
exit;
?>