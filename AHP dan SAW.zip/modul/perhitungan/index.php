<?php
// modul/perhitungan/index.php - HALAMAN UTAMA
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

require_once '../../config/database.php';

if(!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: ../login/');
    exit;
}

$page_title = 'Perhitungan AHP & SAW';

// ============================================
// AMBIL DATA UNTUK SIDEBAR
// ============================================
$result = $pdo->query("SELECT COUNT(*) FROM alternatif");
$row = $result->fetch_row();
$total_alt = $row[0] ?? 0;

$result = $pdo->query("SELECT COUNT(*) FROM kriteria");
$row = $result->fetch_row();
$total_krit = $row[0] ?? 0;

$result = $pdo->query("SELECT COUNT(*) FROM nilai_alternatif");
$row = $result->fetch_row();
$total_nilai = $row[0] ?? 0;

include '../../includes/header.php';
include '../../includes/sidebar.php';
?>

<style>
    .menu-card{background:#fff;border-radius:16px;border:1px solid #f1f5f9;padding:30px;text-align:center;transition:all .3s ease;height:100%;cursor:pointer;text-decoration:none;color:inherit;display:block}
    .menu-card:hover{transform:translateY(-8px);box-shadow:0 12px 40px rgba(0,0,0,0.08);text-decoration:none;color:inherit}
    .menu-card .icon{font-size:3.5rem;margin-bottom:16px}
    .menu-card .icon.ahp{color:#011851}
    .menu-card .icon.saw{color:#059669}
    .menu-card .icon.compare{color:#7c3aed}
    .menu-card h5{font-weight:700;margin-bottom:8px}
    .menu-card p{color:#6b7280;font-size:.9rem;margin-bottom:0}
    .menu-card .badge-status{margin-top:12px}
    .stat-card{background:#fff;border-radius:16px;padding:18px 20px;border:1px solid #f1f5f9;transition:all .3s ease;height:100%}
    .stat-card:hover{transform:translateY(-4px);box-shadow:0 4px 20px rgba(0,0,0,0.05)}
</style>

<div class="app-content">

    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold mb-1">
                <i class="bi bi-calculator-fill text-primary me-2"></i>
                Perhitungan AHP &amp; SAW
            </h4>
            <p class="text-muted small mb-0">Pilih metode perhitungan detail step by step</p>
        </div>
        <span class="badge bg-primary p-2"><i class="bi bi-database me-1"></i> Data Siap</span>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-md-3 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div><h2 class="mb-0 fw-bold text-primary"><?= $total_alt ?></h2><small class="text-muted">Alternatif</small></div>
                    <i class="bi bi-people-fill text-primary fs-1 opacity-25"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div><h2 class="mb-0 fw-bold text-success"><?= $total_krit ?></h2><small class="text-muted">Kriteria</small></div>
                    <i class="bi bi-list-check text-success fs-1 opacity-25"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div><h2 class="mb-0 fw-bold text-info"><?= $total_nilai ?></h2><small class="text-muted">Nilai</small></div>
                    <i class="bi bi-table text-info fs-1 opacity-25"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div><h2 class="mb-0 fw-bold text-warning">3</h2><small class="text-muted">Menu</small></div>
                    <i class="bi bi-grid text-warning fs-1 opacity-25"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-md-4">
            <a href="ahp_detail.php" class="menu-card">
                <div class="icon ahp"><i class="bi bi-list-check"></i></div>
                <h5>AHP Detail</h5>
                <p>Step by Step perhitungan AHP<br>Matriks perbandingan, normalisasi, bobot</p>
                <div class="badge-status"><span class="badge bg-primary">Lihat Detail →</span></div>
                <div class="mt-2 small text-muted"><i class="bi bi-check-circle text-success"></i> 5 Steps</div>
            </a>
        </div>
        <div class="col-md-4">
            <a href="saw_detail.php" class="menu-card">
                <div class="icon saw"><i class="bi bi-calculator"></i></div>
                <h5>SAW Detail</h5>
                <p>Step by Step perhitungan SAW<br>Normalisasi, skor akhir, ranking</p>
                <div class="badge-status"><span class="badge bg-success">Lihat Detail →</span></div>
                <div class="mt-2 small text-muted"><i class="bi bi-check-circle text-success"></i> 4 Steps</div>
            </a>
        </div>
        <div class="col-md-4">
            <a href="perbandingan.php" class="menu-card">
                <div class="icon compare"><i class="bi bi-arrow-left-right"></i></div>
                <h5>Perbandingan</h5>
                <p>Bandingkan hasil<br>AHP &amp; SAW secara langsung</p>
                <div class="badge-status"><span class="badge bg-warning text-dark">Lihat Detail →</span></div>
                <div class="mt-2 small text-muted"><i class="bi bi-check-circle text-success"></i> Side by Side</div>
            </a>
        </div>
    </div>

    <div class="row mt-4">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h6 class="fw-bold"><i class="bi bi-info-circle text-primary me-2"></i> Metode Perhitungan</h6>
                    <p class="text-muted small mb-0">
                        <strong>AHP</strong> (Analytic Hierarchy Process) - Menentukan bobot kriteria melalui matriks perbandingan berpasangan dengan uji konsistensi.<br>
                        <strong>SAW</strong> (Simple Additive Weighting) - Menghitung skor akhir dan ranking alternatif dengan normalisasi dan perkalian bobot.
                    </p>
                </div>
            </div>
        </div>
    </div>

</div>

<?php include '../../includes/footer.php'; ?>