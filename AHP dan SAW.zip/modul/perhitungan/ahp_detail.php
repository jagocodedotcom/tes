<?php
// modul/perhitungan/ahp_detail.php - FIXED: Menampilkan Bobot Kriteria dengan Jelas
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

require_once '../../config/database.php';

if(!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: ../login/');
    exit;
}

$page_title = 'AHP - Step by Step Detail';

// ============================================
// AMBIL DATA UNTUK SIDEBAR
// ============================================
$result = $pdo->query("SELECT COUNT(*) FROM alternatif");
$row = $result->fetch_row();
$total_alt = $row[0] ?? 0;

$result = $pdo->query("SELECT COUNT(*) FROM kriteria");
$row = $result->fetch_row();
$total_krit = $row[0] ?? 0;

$result = $pdo->query("SELECT COUNT(*) FROM nilai_alternatif");
$row = $result->fetch_row();
$total_nilai = $row[0] ?? 0;

// ============================================
// 1. AMBIL DATA KRITERIA
// ============================================
$result = $pdo->query("SELECT * FROM kriteria ORDER BY id_kriteria");
$kriteria = $result->fetch_all(MYSQLI_ASSOC);
$n = count($kriteria);

// ============================================
// 2. AMBIL MATRIKS PERBANDINGAN
// ============================================
$result = $pdo->query("SELECT * FROM matriks_perbandingan ORDER BY id_kriteria1, id_kriteria2");
$matriks_data = $result->fetch_all(MYSQLI_ASSOC);

// Buat matriks 2D
$matriks = array();
for($i = 0; $i < $n; $i++) {
    for($j = 0; $j < $n; $j++) {
        $matriks[$i][$j] = 1;
    }
}

foreach($matriks_data as $m) {
    $i = $m['id_kriteria1'] - 1;
    $j = $m['id_kriteria2'] - 1;
    $matriks[$i][$j] = $m['nilai'];
    $matriks[$j][$i] = 1 / $m['nilai'];
}

// ============================================
// 3. HITUNG JUMLAH KOLOM (STEP 1)
// ============================================
$jumlah_kolom = array();
for($j = 0; $j < $n; $j++) {
    $sum = 0;
    for($i = 0; $i < $n; $i++) {
        $sum += $matriks[$i][$j];
    }
    $jumlah_kolom[$j] = $sum;
}

// ============================================
// 4. NORMALISASI MATRIKS (STEP 2)
// ============================================
$normalized = array();
for($i = 0; $i < $n; $i++) {
    for($j = 0; $j < $n; $j++) {
        $normalized[$i][$j] = $matriks[$i][$j] / $jumlah_kolom[$j];
    }
}

// ============================================
// 5. HITUNG BOBOT - EIGEN VECTOR (STEP 3)
// ============================================
$bobot = array();
$bobot_detail = array();
for($i = 0; $i < $n; $i++) {
    $sum = 0;
    $detail = array();
    for($j = 0; $j < $n; $j++) {
        $sum += $normalized[$i][$j];
        $detail[] = number_format($normalized[$i][$j], 4);
    }
    $bobot[$i] = $sum / $n;
    $bobot_detail[$i] = array(
        'sum' => $sum,
        'detail' => $detail,
        'count' => $n,
        'result' => $sum / $n
    );
}

// ============================================
// 6. UJI KONSISTENSI (STEP 4)
// ============================================
$lambda_max = 0;
$lambda_detail = array();
for($i = 0; $i < $n; $i++) {
    $sum = 0;
    for($j = 0; $j < $n; $j++) {
        $sum += $matriks[$i][$j] * $bobot[$j];
    }
    $lambda_detail[$i] = array(
        'sum' => $sum,
        'bobot' => $bobot[$i],
        'result' => $sum / $bobot[$i]
    );
    $lambda_max += $sum / $bobot[$i];
}
$lambda_max = $lambda_max / $n;

$ci = ($lambda_max - $n) / ($n - 1);

$ri_values = array(0, 0, 0.58, 0.90, 1.12, 1.24, 1.32, 1.41, 1.45, 1.49);
$ri = $ri_values[$n] ?? 1.49;
$cr = $ci / $ri;

$konsisten = $cr < 0.10;

include '../../includes/header.php';
include '../../includes/sidebar.php';
?>

<style>
    .step-card{background:#fff;border-radius:16px;border:1px solid #f1f5f9;padding:24px;margin-bottom:24px;transition:all .3s ease}
    .step-card:hover{box-shadow:0 4px 20px rgba(0,0,0,0.05)}
    .step-number{display:inline-flex;align-items:center;justify-content:center;width:40px;height:40px;background:#011851;color:#fff;border-radius:50%;font-weight:700;font-size:1rem;margin-right:14px;flex-shrink:0}
    .step-title{font-weight:700;font-size:1.2rem;color:#011851}
    .step-header{display:flex;align-items:center;margin-bottom:16px;flex-wrap:wrap;gap:8px}
    .step-desc{color:#6b7280;font-size:.9rem;margin-left:54px;margin-bottom:16px;line-height:1.6}
    .formula-box{background:#f0f4ff;border-radius:12px;padding:16px 20px;border-left:4px solid #011851;font-family:'Courier New',monospace;font-size:.9rem;margin:12px 0;overflow-x:auto}
    .table-ahp thead th{background:linear-gradient(135deg,#011851,#1a3a9a);color:#fff;font-weight:600;font-size:.75rem;text-transform:uppercase;letter-spacing:.5px;padding:10px 14px;border:none;text-align:center}
    .table-ahp tbody td{padding:10px 14px;vertical-align:middle;text-align:center}
    .table-ahp tbody tr:hover{background:#f8faff}
    .table-ahp tbody tr.row-total{background:#f0f4ff;font-weight:700}
    .highlight-cell{background:#dbeafe!important;font-weight:700}
    .result-box{background:linear-gradient(135deg,#011851,#1a3a9a);color:#fff;border-radius:12px;padding:16px 20px;margin:8px 0;text-align:center}
    .result-box .label{font-size:.75rem;opacity:.8;text-transform:uppercase;letter-spacing:.5px}
    .result-box .value{font-size:1.4rem;font-weight:700}
    .badge-konsisten{background:#d1fae5;color:#065f46;padding:6px 16px;border-radius:20px;font-weight:600}
    .badge-tidak{background:#fee2e2;color:#991b1b;padding:6px 16px;border-radius:20px;font-weight:600}
    .table-responsive-custom{overflow-x:auto;-webkit-overflow-scrolling:touch;width:100%;display:block}
    .table-responsive-custom table{width:100%;min-width:600px;margin-bottom:0;background:#fff;border-radius:12px;overflow:hidden}
    .bobot-card{background:#fff;border-radius:12px;padding:16px;border:1px solid #e5e7eb;text-align:center;transition:all .3s ease;height:100%}
    .bobot-card:hover{transform:translateY(-4px);box-shadow:0 4px 20px rgba(0,0,0,0.05)}
    .bobot-card .kode{font-size:.7rem;text-transform:uppercase;color:#6b7280;letter-spacing:.5px}
    .bobot-card .nilai{font-size:2rem;font-weight:800;color:#011851}
    .bobot-card .persen{font-size:1.2rem;font-weight:700;color:#011851}
    .bobot-card .nama{font-size:.85rem;color:#4b5563}
    .bobot-card .bar{height:8px;background:#e5e7eb;border-radius:10px;overflow:hidden;margin-top:8px}
    .bobot-card .bar .fill{height:100%;background:linear-gradient(90deg,#011851,#3b82f6);border-radius:10px;transition:width 1s ease}
    .bobot-card.tertinggi{border:2px solid #f59e0b;background:#fef3c7}
    .bobot-card.tertinggi .nilai{color:#92400e}
    .bobot-card.tertinggi .persen{color:#92400e}
    .bobot-card.terendah{border:2px solid #9ca3af;background:#f3f4f6}
    .bobot-card.terendah .nilai{color:#4b5563}
    .bobot-card.terendah .persen{color:#4b5563}
</style>

<div class="app-content">

    <!-- ============================================
    HEADER
    ============================================ -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold mb-1">
                <i class="bi bi-list-check text-primary me-2"></i>
                AHP - Step by Step Detail
            </h4>
            <p class="text-muted small mb-0">
                <i class="bi bi-info-circle me-1"></i>
                <strong>Output AHP adalah BOBOT KRITERIA</strong> - Menentukan seberapa penting setiap kriteria
            </p>
        </div>
        <div class="d-flex gap-2">
            <a href="index.php" class="btn btn-outline-secondary btn-sm">
                <i class="bi bi-arrow-left"></i> Kembali
            </a>
            <a href="saw_detail.php" class="btn btn-success btn-sm">
                <i class="bi bi-arrow-right"></i> Lihat SAW
            </a>
        </div>
    </div>

    <!-- ============================================
    INFO: APA ITU AHP?
    ============================================ -->
    <div class="alert alert-primary mb-4">
        <div class="d-flex align-items-start">
            <i class="bi bi-info-circle-fill fs-3 me-3"></i>
            <div>
                <strong>AHP (Analytic Hierarchy Process)</strong> digunakan untuk 
                <strong>menentukan bobot kepentingan setiap kriteria</strong>, 
                <span class="text-decoration-underline">BUKAN untuk menilai alternatif</span>.
                <br>
                <span class="badge bg-primary mt-1">📌 Output AHP = Bobot Kriteria</span>
                <span class="badge bg-success mt-1">📌 Output SAW = Ranking Alternatif</span>
            </div>
        </div>
    </div>
<div class="alert alert-primary mb-4">
    <div class="d-flex align-items-start">
        <i class="bi bi-info-circle-fill fs-3 me-3"></i>
        <div>
            <strong>📌 Data yang Digunakan:</strong>
            <br>
            Jumlah Kriteria: <strong><?= $n ?></strong>
            <br>
            Kriteria: 
            <?php for($i = 0; $i < $n; $i++): ?>
                <span class="badge bg-primary"><?= $kriteria[$i]['kode_kriteria'] ?> (<?= $kriteria[$i]['nama_kriteria'] ?>)</span>
            <?php endfor; ?>
            <br>
            <span class="badge bg-warning text-dark mt-1">⚠️ AHP hanya menghitung BOBOT KRITERIA, BUKAN nilai alternatif</span>
        </div>
    </div>
</div>
    <!-- ============================================
    STEP 1: MATRIKS PERBANDINGAN
    ============================================ -->
    <div class="step-card">
        <div class="step-header">
            <span class="step-number">1</span>
            <span class="step-title">Matriks Perbandingan Berpasangan</span>
        </div>
        <div class="step-desc">
            <strong>Tujuan:</strong> Membandingkan setiap kriteria dengan kriteria lain untuk mengetahui tingkat kepentingan relatif.
            <br>
            <strong>Skala Saaty:</strong> 1=Sama penting, 3=Agak penting, 5=Penting, 7=Sangat penting, 9=Mutlak penting
            <br>
            <strong>⚠️ Catatan:</strong> Matriks ini menghasilkan <span class="badge bg-primary">BOBOT KRITERIA</span>, bukan nilai alternatif.
        </div>

        <div class="formula-box">
            <strong>Matriks Perbandingan A = [a<sub>ij</sub>]</strong> 
            <br>
            Dimana a<sub>ij</sub> = seberapa penting kriteria i dibandingkan kriteria j
        </div>

        <div class="table-responsive-custom">
            <table class="table table-bordered table-ahp">
                <thead>
                    <tr>
                        <th style="min-width:80px;">Kriteria</th>
                        <?php for($i = 0; $i < $n; $i++): ?>
                            <th><?= $kriteria[$i]['kode_kriteria'] ?></th>
                        <?php endfor; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php for($i = 0; $i < $n; $i++): ?>
                        <tr>
                            <td><strong><?= $kriteria[$i]['kode_kriteria'] ?></strong></td>
                            <?php for($j = 0; $j < $n; $j++): ?>
                                <td>
                                    <?php 
                                    $val = $matriks[$i][$j];
                                    if($i == $j) {
                                        echo '<span class="badge bg-secondary">1</span>';
                                    } elseif($i < $j) {
                                        echo '<span class="fw-bold text-primary">' . number_format($val, 2) . '</span>';
                                    } else {
                                        echo '<span class="text-muted">1/' . number_format(1/$val, 2) . '</span>';
                                    }
                                    ?>
                                </td>
                            <?php endfor; ?>
                        </tr>
                    <?php endfor; ?>
                </tbody>
            </table>
        </div>

        <div class="alert alert-info mt-2">
            <i class="bi bi-info-circle me-2"></i>
            <strong>Interpretasi Matriks:</strong>
            <?php 
            $max_val = 0;
            $max_i = 0;
            $max_j = 0;
            for($i = 0; $i < $n; $i++) {
                for($j = 0; $j < $n; $j++) {
                    if($i < $j && $matriks[$i][$j] > $max_val) {
                        $max_val = $matriks[$i][$j];
                        $max_i = $i;
                        $max_j = $j;
                    }
                }
            }
            if($max_val > 0) {
                echo "Kriteria <strong>" . $kriteria[$max_i]['kode_kriteria'] . "</strong> ";
                if($max_val >= 7) echo "sangat lebih penting";
                elseif($max_val >= 5) echo "lebih penting";
                elseif($max_val >= 3) echo "agak lebih penting";
                else echo "sama pentingnya";
                echo " dari kriteria <strong>" . $kriteria[$max_j]['kode_kriteria'] . "</strong> ";
                echo "(nilai " . number_format($max_val, 2) . ")";
            }
            ?>
            <br>
            <span class="badge bg-primary mt-1">➡️ Ini akan menghasilkan bobot kriteria</span>
        </div>
    </div>

    <!-- ============================================
    STEP 2: NORMALISASI MATRIKS
    ============================================ -->
    <div class="step-card">
        <div class="step-header">
            <span class="step-number">2</span>
            <span class="step-title">Normalisasi Matriks</span>
        </div>
        <div class="step-desc">
            <strong>Tujuan:</strong> Menormalisasi matriks untuk menghitung bobot setiap kriteria.
            <br>
            <strong>Rumus:</strong> a<sub>ij</sub><sup>'</sup> = a<sub>ij</sub> / Σ(a<sub>ij</sub>)
            <br>
            <span class="badge bg-primary">📌 Langkah ini menghasilkan nilai normalisasi</span>
        </div>

        <div class="formula-box">
            <strong>Contoh Normalisasi Kolom <?= $kriteria[0]['kode_kriteria'] ?>:</strong><br>
            Jumlah = <?= number_format($matriks[0][0], 2) ?> + <?= number_format($matriks[1][0], 2) ?> + <?= number_format($matriks[2][0], 2) ?> + ... = <strong><?= number_format($jumlah_kolom[0], 4) ?></strong>
        </div>

        <div class="table-responsive-custom">
            <table class="table table-bordered table-ahp">
                <thead>
                    <tr>
                        <th>Kriteria</th>
                        <?php for($i = 0; $i < $n; $i++): ?>
                            <th><?= $kriteria[$i]['kode_kriteria'] ?></th>
                        <?php endfor; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php for($i = 0; $i < $n; $i++): ?>
                        <tr>
                            <td><strong><?= $kriteria[$i]['kode_kriteria'] ?></strong></td>
                            <?php for($j = 0; $j < $n; $j++): ?>
                                <td>
                                    <?= number_format($normalized[$i][$j], 4) ?>
                                    <br>
                                    <small class="text-muted">(<?= number_format($matriks[$i][$j], 2) ?> / <?= number_format($jumlah_kolom[$j], 4) ?>)</small>
                                </td>
                            <?php endfor; ?>
                        </tr>
                    <?php endfor; ?>
                    <tr class="row-total">
                        <td><strong>Jumlah Kolom</strong></td>
                        <?php for($j = 0; $j < $n; $j++): ?>
                            <td><strong><?= number_format($jumlah_kolom[$j], 4) ?></strong></td>
                        <?php endfor; ?>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <!-- ============================================
    STEP 3: HITUNG BOBOT (EIGEN VECTOR)
    ============================================ -->
    <div class="step-card">
        <div class="step-header">
            <span class="step-number">3</span>
            <span class="step-title">Hitung Bobot Kriteria (Eigen Vector) - <span class="badge bg-warning text-dark">⭐ HASIL AHP</span></span>
        </div>
        <div class="step-desc">
            <strong>Tujuan:</strong> Menghitung bobot setiap kriteria.
            <br>
            <strong>Rumus:</strong> W<sub>i</sub> = Σ(a<sub>ij</sub><sup>'</sup>) / n
            <br>
            <span class="badge bg-primary">📌 Inilah OUTPUT AHP: BOBOT KRITERIA</span>
        </div>

        <div class="formula-box">
            <strong>Contoh Perhitungan Bobot <?= $kriteria[0]['kode_kriteria'] ?>:</strong><br>
            W = (<?= implode(' + ', $bobot_detail[0]['detail']) ?>) / <?= $n ?> = <?= number_format($bobot_detail[0]['sum'], 4) ?> / <?= $n ?> = <strong><?= number_format($bobot[0], 4) ?></strong>
        </div>

        <div class="table-responsive-custom">
            <table class="table table-bordered table-ahp">
                <thead>
                    <tr>
                        <th>Kriteria</th>
                        <?php for($i = 0; $i < $n; $i++): ?>
                            <th><?= $kriteria[$i]['kode_kriteria'] ?></th>
                        <?php endfor; ?>
                        <th class="highlight-cell">Jumlah</th>
                        <th class="highlight-cell">Bobot (W) <br><small>⭐ OUTPUT AHP</small></th>
                    </tr>
                </thead>
                <tbody>
                    <?php for($i = 0; $i < $n; $i++): 
                        $is_max = ($bobot[$i] == max($bobot));
                        $is_min = ($bobot[$i] == min($bobot));
                    ?>
                        <tr style="<?= $is_max ? 'background:#fef3c7;' : ($is_min ? 'background:#f3f4f6;' : '') ?>">
                            <td><strong><?= $kriteria[$i]['kode_kriteria'] ?></strong></td>
                            <?php for($j = 0; $j < $n; $j++): ?>
                                <td><?= number_format($normalized[$i][$j], 4) ?></td>
                            <?php endfor; ?>
                            <td class="highlight-cell"><?= number_format($bobot_detail[$i]['sum'], 4) ?></td>
                            <td class="highlight-cell">
                                <strong><?= number_format($bobot[$i], 4) ?></strong>
                                <br>
                                <strong class="text-primary"><?= number_format($bobot[$i] * 100, 1) ?>%</strong>
                                <?php if($is_max): ?>
                                    <span class="badge bg-warning text-dark">⭐ TERTINGGI</span>
                                <?php elseif($is_min): ?>
                                    <span class="badge bg-secondary">⬇ TERENDAH</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endfor; ?>
                    <tr class="row-total">
                        <td><strong>Total</strong></td>
                        <?php for($j = 0; $j < $n; $j++): ?>
                            <td></td>
                        <?php endfor; ?>
                        <td class="highlight-cell"><?= number_format(array_sum($bobot), 4) ?></td>
                        <td class="highlight-cell"><strong>100%</strong></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- ============================================
        VISUALISASI BOBOT KRITERIA - HASIL AHP
        ============================================ -->
        <div class="mt-4">
            <h6 class="fw-bold text-center mb-3">
                <i class="bi bi-bar-chart-fill text-primary me-2"></i>
                Bobot Kriteria (Hasil AHP)
                <span class="badge bg-warning text-dark ms-2">⭐ OUTPUT</span>
            </h6>
            <div class="row g-3">
                <?php 
                $max_bobot = max($bobot);
                $min_bobot = min($bobot);
                for($i = 0; $i < $n; $i++): 
                    $is_max = ($bobot[$i] == $max_bobot);
                    $is_min = ($bobot[$i] == $min_bobot);
                    $persen = $bobot[$i] * 100;
                ?>
                    <div class="col-md-3 col-6">
                        <div class="bobot-card <?= $is_max ? 'tertinggi' : ($is_min ? 'terendah' : '') ?>">
                            <div class="kode"><?= $kriteria[$i]['kode_kriteria'] ?></div>
                            <div class="nilai"><?= number_format($persen, 1) ?><span class="persen">%</span></div>
                            <div class="nama"><?= $kriteria[$i]['nama_kriteria'] ?></div>
                            <div class="bar">
                                <div class="fill" style="width: <?= $persen ?>%;"></div>
                            </div>
                            <div class="mt-1">
                                <small class="text-muted">Bobot: <?= number_format($bobot[$i], 4) ?></small>
                                <?php if($is_max): ?>
                                    <span class="badge bg-warning text-dark">⭐</span>
                                <?php elseif($is_min): ?>
                                    <span class="badge bg-secondary">⬇</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endfor; ?>
            </div>
        </div>

        <div class="alert alert-success mt-3">
            <i class="bi bi-check-circle-fill me-2"></i>
            <strong>Kesimpulan AHP:</strong>
            Kriteria <strong><?= $kriteria[array_search($max_bobot, $bobot)]['kode_kriteria'] ?></strong> 
            memiliki bobot tertinggi (<strong><?= number_format($max_bobot * 100, 1) ?>%</strong>) 
            <span class="badge bg-warning text-dark">⭐</span>, 
            artinya paling berpengaruh dalam penilaian beasiswa.
            <br>
            Kriteria <strong><?= $kriteria[array_search($min_bobot, $bobot)]['kode_kriteria'] ?></strong> 
            memiliki bobot terendah (<strong><?= number_format($min_bobot * 100, 1) ?>%</strong>) 
            <span class="badge bg-secondary">⬇</span>.
            <br><br>
            <span class="badge bg-primary">📌 Bobot ini akan digunakan dalam perhitungan SAW</span>
        </div>
    </div>

    <!-- ============================================
    STEP 4: UJI KONSISTENSI
    ============================================ -->
    <div class="step-card">
        <div class="step-header">
            <span class="step-number">4</span>
            <span class="step-title">Uji Konsistensi</span>
        </div>
        <div class="step-desc">
            <strong>Tujuan:</strong> Memastikan konsistensi perbandingan berpasangan.
            <br>
            <strong>Syarat:</strong> CR ≤ 0.10 (konsisten)
        </div>

        <h6 class="fw-bold mt-3 mb-2">4a. Hitung λ (Lambda) Maksimum</h6>
        <div class="formula-box">
            <strong>Rumus:</strong> λ<sub>max</sub> = (1/n) × Σ (A × W)<sub>i</sub> / W<sub>i</sub>
        </div>

        <div class="table-responsive-custom">
            <table class="table table-bordered table-ahp">
                <thead>
                    <tr>
                        <th>Kriteria</th>
                        <th>(A × W)</th>
                        <th>W</th>
                        <th>(A × W) / W</th>
                    </tr>
                </thead>
                <tbody>
                    <?php for($i = 0; $i < $n; $i++): ?>
                        <tr>
                            <td><strong><?= $kriteria[$i]['kode_kriteria'] ?></strong></td>
                            <td><?= number_format($lambda_detail[$i]['sum'], 4) ?></td>
                            <td><?= number_format($lambda_detail[$i]['bobot'], 4) ?></td>
                            <td class="highlight-cell"><?= number_format($lambda_detail[$i]['result'], 4) ?></td>
                        </tr>
                    <?php endfor; ?>
                    <tr class="row-total">
                        <td colspan="3"><strong>λ<sub>max</sub> = Σ / n</strong></td>
                        <td class="highlight-cell">
                            <strong><?= number_format($lambda_max, 4) ?></strong>
                            <br>
                            <small>(<?= number_format(array_sum(array_column($lambda_detail, 'result')), 4) ?> / <?= $n ?>)</small>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <h6 class="fw-bold mt-3 mb-2">4b. Hitung Consistency Index (CI)</h6>
        <div class="formula-box">
            <strong>Rumus:</strong> CI = (λ<sub>max</sub> - n) / (n - 1)<br>
            CI = (<?= number_format($lambda_max, 4) ?> - <?= $n ?>) / (<?= $n ?> - 1) = <strong><?= number_format($ci, 4) ?></strong>
        </div>

        <h6 class="fw-bold mt-3 mb-2">4c. Hitung Consistency Ratio (CR)</h6>
        <div class="formula-box">
            <strong>Rumus:</strong> CR = CI / RI<br>
            CR = <?= number_format($ci, 4) ?> / <?= number_format($ri, 4) ?> = <strong><?= number_format($cr, 4) ?></strong>
            <br><br>
            <?php if($konsisten): ?>
                <span class="badge-konsisten">✅ Konsisten (CR ≤ 0.10)</span>
            <?php else: ?>
                <span class="badge-tidak">❌ Tidak Konsisten (CR > 0.10)</span>
            <?php endif; ?>
        </div>

        <div class="row g-3 mt-2">
            <div class="col-md-3 col-6">
                <div class="card">
                    <div class="card-body text-center">
                        <div class="text-muted small">λ<sub>max</sub></div>
                        <div class="fs-3 fw-bold text-primary"><?= number_format($lambda_max, 4) ?></div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="card">
                    <div class="card-body text-center">
                        <div class="text-muted small">CI</div>
                        <div class="fs-3 fw-bold text-primary"><?= number_format($ci, 4) ?></div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="card">
                    <div class="card-body text-center">
                        <div class="text-muted small">RI (n=<?= $n ?>)</div>
                        <div class="fs-3 fw-bold text-primary"><?= number_format($ri, 4) ?></div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="card <?= $konsisten ? 'border-success' : 'border-danger' ?>">
                    <div class="card-body text-center">
                        <div class="text-muted small">CR</div>
                        <div class="fs-3 fw-bold <?= $konsisten ? 'text-success' : 'text-danger' ?>">
                            <?= number_format($cr, 4) ?>
                        </div>
                        <div>
                            <?php if($konsisten): ?>
                                <span class="badge-konsisten">✅ Konsisten</span>
                            <?php else: ?>
                                <span class="badge-tidak">❌ Tidak Konsisten</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ============================================
    STEP 5: HASIL AKHIR AHP - RINGKASAN
    ============================================ -->
    <div class="step-card">
        <div class="step-header">
            <span class="step-number">5</span>
            <span class="step-title">Ringkasan Hasil AHP</span>
        </div>

        <div class="alert alert-success">
            <i class="bi bi-check-circle-fill me-2"></i>
            <strong>Kesimpulan AHP:</strong>
            Bobot kriteria telah berhasil dihitung dengan metode AHP.
            <?php if($konsisten): ?>
                <span class="badge-konsisten">✅ Konsisten (CR = <?= number_format($cr, 4) ?>)</span>
            <?php else: ?>
                <span class="badge-tidak">❌ Tidak Konsisten (CR = <?= number_format($cr, 4) ?>)</span>
            <?php endif; ?>
        </div>

        <div class="row g-3">
            <?php for($i = 0; $i < $n; $i++): 
                $is_max = ($bobot[$i] == max($bobot));
                $is_min = ($bobot[$i] == min($bobot));
            ?>
                <div class="col-md-3 col-6">
                    <div class="card <?= $is_max ? 'border-warning' : ($is_min ? 'border-secondary' : '') ?>">
                        <div class="card-body text-center">
                            <div class="text-muted small"><?= $kriteria[$i]['kode_kriteria'] ?></div>
                            <div class="fw-bold fs-3 <?= $is_max ? 'text-warning' : ($is_min ? 'text-secondary' : 'text-primary') ?>">
                                <?= number_format($bobot[$i] * 100, 1) ?>%
                            </div>
                            <div class="small text-muted"><?= $kriteria[$i]['nama_kriteria'] ?></div>
                            <div class="mt-1">
                                <span class="badge bg-secondary"><?= number_format($bobot[$i], 4) ?></span>
                                <?php if($is_max): ?>
                                    <span class="badge bg-warning text-dark">⭐ TERTINGGI</span>
                                <?php elseif($is_min): ?>
                                    <span class="badge bg-secondary">⬇ TERENDAH</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endfor; ?>
        </div>

        <div class="alert alert-info mt-3">
            <i class="bi bi-arrow-right-circle me-2"></i>
            <strong>Langkah Selanjutnya:</strong>
            Bobot kriteria di atas akan digunakan dalam perhitungan 
            <strong>SAW (Simple Additive Weighting)</strong> untuk menentukan ranking alternatif.
        </div>

        <div class="mt-3">
            <a href="saw_detail.php" class="btn btn-success">
                <i class="bi bi-arrow-right"></i> Lanjut ke SAW
            </a>
        </div>
    </div>

</div>

<?php include '../../includes/footer.php'; ?>