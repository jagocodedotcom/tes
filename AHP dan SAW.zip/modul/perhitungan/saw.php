<?php
// modul/perhitungan/saw.php - HALAMAN SAW
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

require_once '../../config/database.php';

if(!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: ../login/');
    exit;
}

$page_title = 'Perhitungan SAW';

// ============================================
// AMBIL DATA UNTUK SIDEBAR
// ============================================
$result = $pdo->query("SELECT COUNT(*) FROM alternatif");
$row = $result->fetch_row();
$total_alt = $row[0] ?? 0;

$result = $pdo->query("SELECT COUNT(*) FROM kriteria");
$row = $result->fetch_row();
$total_krit = $row[0] ?? 0;

$result = $pdo->query("SELECT COUNT(*) FROM nilai_alternatif");
$row = $result->fetch_row();
$total_nilai = $row[0] ?? 0;

// ============================================
// 1. AMBIL DATA DARI DATABASE
// ============================================
$result = $pdo->query("SELECT * FROM kriteria ORDER BY id_kriteria");
$kriteria = $result->fetch_all(MYSQLI_ASSOC);

$result = $pdo->query("SELECT * FROM alternatif ORDER BY id_alternatif");
$alternatif = $result->fetch_all(MYSQLI_ASSOC);

// Bobot dari AHP
$bobot = [];
foreach($kriteria as $k) {
    $bobot[$k['id_kriteria']] = $k['bobot_ahp'];
}

// ============================================
// 2. AMBIL DATA NILAI
// ============================================
$nilai_data = [];
foreach($alternatif as $alt) {
    $sql = "SELECT id_kriteria, nilai FROM nilai_alternatif WHERE id_alternatif = " . $alt['id_alternatif'];
    $result = $pdo->query($sql);
    $rows = $result->fetch_all(MYSQLI_ASSOC);
    foreach($rows as $row) {
        $nilai_data[$alt['id_alternatif']][$row['id_kriteria']] = $row['nilai'];
    }
}

// ============================================
// 3. NORMALISASI SAW
// ============================================
$normalized = [];
foreach($kriteria as $k) {
    $values = [];
    foreach($alternatif as $alt) {
        $val = $nilai_data[$alt['id_alternatif']][$k['id_kriteria']] ?? 0;
        $values[$alt['id_alternatif']] = $val;
    }
    
    $max = max($values);
    $min = min(array_filter($values, function($v) { return $v > 0; })) ?: 1;
    
    foreach($alternatif as $alt) {
        $val = $values[$alt['id_alternatif']];
        if($k['jenis'] == 'benefit') {
            $normalized[$alt['id_alternatif']][$k['id_kriteria']] = $max > 0 ? $val / $max : 0;
        } else {
            $normalized[$alt['id_alternatif']][$k['id_kriteria']] = $val > 0 ? $min / $val : 0;
        }
    }
}

// ============================================
// 4. HITUNG SKOR AKHIR SAW
// ============================================
$skor = [];
foreach($alternatif as $alt) {
    $total = 0;
    foreach($kriteria as $k) {
        $total += $bobot[$k['id_kriteria']] * ($normalized[$alt['id_alternatif']][$k['id_kriteria']] ?? 0);
    }
    $skor[$alt['id_alternatif']] = $total;
}

// ============================================
// 5. RANKING
// ============================================
arsort($skor);
$ranking = 1;
$status_list = ['penerima', 'cadangan1', 'cadangan2', 'tidak_terpilih'];

// Kosongkan tabel hasil
$pdo->query("TRUNCATE TABLE hasil_perhitungan");

foreach($skor as $id_alt => $nilai_skor) {
    $status = $ranking <= 3 ? $status_list[$ranking - 1] : 'tidak_terpilih';
    $stmt = $pdo->prepare("INSERT INTO hasil_perhitungan (id_alternatif, skor_akhir, ranking, status) VALUES (?, ?, ?, ?)");
    $stmt->execute([$id_alt, $nilai_skor, $ranking, $status]);
    $ranking++;
}

// Ambil hasil
$result = $pdo->query("
    SELECT h.*, a.nama, a.nim, a.jurusan 
    FROM hasil_perhitungan h 
    JOIN alternatif a ON h.id_alternatif = a.id_alternatif 
    ORDER BY h.ranking
");
$hasil = $result->fetch_all(MYSQLI_ASSOC);

include '../../includes/header.php';
include '../../includes/sidebar.php';
?>

<style>
    .step-card{background:#fff;border-radius:16px;border:1px solid #f1f5f9;padding:20px;margin-bottom:20px;transition:all .3s ease}
    .step-card:hover{box-shadow:0 4px 20px rgba(0,0,0,0.05)}
    .step-number{display:inline-flex;align-items:center;justify-content:center;width:36px;height:36px;background:#059669;color:#fff;border-radius:50%;font-weight:700;font-size:.9rem;margin-right:12px}
    .step-title{font-weight:700;font-size:1.1rem;color:#059669}
    .table-saw thead th{background:linear-gradient(135deg,#059669,#34d399);color:#fff;font-weight:600;font-size:.75rem;text-transform:uppercase;letter-spacing:.5px;padding:10px 14px;border:none}
    .table-saw tbody td{padding:10px 14px;vertical-align:middle;text-align:center}
    .table-saw tbody tr:hover{background:#ecfdf5}
    .formula-box{background:#ecfdf5;border-radius:12px;padding:16px 20px;border-left:4px solid #059669;font-family:'Courier New',monospace;font-size:.9rem;margin:10px 0;overflow-x:auto}
    .stat-card{background:#fff;border-radius:16px;padding:18px 20px;border:1px solid #f1f5f9;transition:all .3s ease;height:100%}
    .stat-card:hover{transform:translateY(-4px);box-shadow:0 4px 20px rgba(0,0,0,0.05)}
    .result-card{background:linear-gradient(135deg,#059669,#34d399);color:#fff;border-radius:16px;padding:20px;text-align:center;height:100%}
    .result-card .number{font-size:2rem;font-weight:800}
    .result-card .label{font-size:.8rem;opacity:.8}
    .highlight-cell{background:#d1fae5!important;font-weight:600}
    .rank-card{border-radius:16px;padding:20px;text-align:center;height:100%;transition:all .3s ease;border:1px solid #f1f5f9}
    .rank-card:hover{transform:translateY(-4px);box-shadow:0 8px 30px rgba(0,0,0,0.05)}
    .rank-card.rank-1{background:linear-gradient(135deg,#fef3c7,#fde68a);border-color:#f59e0b}
    .rank-card.rank-2{background:linear-gradient(135deg,#f1f5f9,#e2e8f0);border-color:#94a3b8}
    .rank-card.rank-3{background:linear-gradient(135deg,#fef3c7,#fcd34d);border-color:#d97706}
    .table-responsive-custom{overflow-x:auto;-webkit-overflow-scrolling:touch;width:100%;display:block}
    .table-responsive-custom table{width:100%;min-width:600px;margin-bottom:0;background:#fff;border-radius:12px;overflow:hidden}
</style>

<div class="app-content">

    <!-- Header -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold mb-1">
                <i class="bi bi-calculator-fill text-success me-2"></i>
                Perhitungan SAW (Simple Additive Weighting)
            </h4>
            <p class="text-muted small mb-0">Menghitung skor akhir dan ranking menggunakan metode SAW</p>
        </div>
        <div class="d-flex gap-2">
            <a href="ahp.php" class="btn btn-outline-secondary btn-sm">
                <i class="bi bi-arrow-left"></i> Lihat AHP
            </a>
            <a href="perbandingan.php" class="btn btn-warning btn-sm">
                <i class="bi bi-arrow-left-right"></i> Perbandingan
            </a>
            <a href="index.php" class="btn btn-primary btn-sm">
                <i class="bi bi-arrow-repeat"></i> Hitung Ulang
            </a>
        </div>
    </div>

    <!-- Stats -->
    <div class="row g-3 mb-4">
        <div class="col-md-3 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h2 class="mb-0 fw-bold text-primary"><?= $total_alt ?></h2>
                        <small class="text-muted">Alternatif</small>
                    </div>
                    <i class="bi bi-people-fill text-primary fs-1 opacity-25"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h2 class="mb-0 fw-bold text-success"><?= $total_krit ?></h2>
                        <small class="text-muted">Kriteria</small>
                    </div>
                    <i class="bi bi-list-check text-success fs-1 opacity-25"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h2 class="mb-0 fw-bold text-info"><?= $total_nilai ?></h2>
                        <small class="text-muted">Nilai</small>
                    </div>
                    <i class="bi bi-table text-info fs-1 opacity-25"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h2 class="mb-0 fw-bold text-warning"><?= count($hasil) ?></h2>
                        <small class="text-muted">Hasil</small>
                    </div>
                    <i class="bi bi-trophy text-warning fs-1 opacity-25"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- STEP 1: Bobot Kriteria (dari AHP) -->
    <div class="step-card">
        <div class="d-flex align-items-center mb-3">
            <span class="step-number">1</span>
            <span class="step-title">Bobot Kriteria (Hasil AHP)</span>
        </div>

        <div class="row g-3">
            <?php foreach($kriteria as $k): ?>
                <div class="col-md-3 col-6">
                    <div class="result-card">
                        <div class="label"><?= $k['kode_kriteria'] ?></div>
                        <div class="number"><?= number_format($k['bobot_ahp'] * 100, 1) ?>%</div>
                        <div class="label"><?= $k['nama_kriteria'] ?></div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- STEP 2: Matriks Nilai Awal -->
    <div class="step-card">
        <div class="d-flex align-items-center mb-3">
            <span class="step-number">2</span>
            <span class="step-title">Matriks Nilai Awal (X)</span>
        </div>

        <div class="table-responsive-custom">
            <table class="table table-bordered table-saw">
                <thead>
                    <tr>
                        <th>Alternatif</th>
                        <?php foreach($kriteria as $k): ?>
                            <th><?= $k['kode_kriteria'] ?> <br><small><?= $k['jenis'] == 'benefit' ? '↑' : '↓' ?></small></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($alternatif as $alt): ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($alt['nama']) ?></strong></td>
                            <?php foreach($kriteria as $k): ?>
                                <td>
                                    <?php 
                                    $val = $nilai_data[$alt['id_alternatif']][$k['id_kriteria']] ?? '-';
                                    echo $val !== '-' ? number_format($val, 2) : '-';
                                    ?>
                                </td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- STEP 3: Normalisasi SAW -->
    <div class="step-card">
        <div class="d-flex align-items-center mb-3">
            <span class="step-number">3</span>
            <span class="step-title">Normalisasi SAW</span>
        </div>

        <div class="formula-box mb-3">
            <strong>Rumus Normalisasi:</strong><br>
            <strong>Benefit:</strong> r<sub>ij</sub> = X<sub>ij</sub> / max(X<sub>j</sub>) &nbsp;|&nbsp; 
            <strong>Cost:</strong> r<sub>ij</sub> = min(X<sub>j</sub>) / X<sub>ij</sub>
        </div>

        <div class="table-responsive-custom">
            <table class="table table-bordered table-saw">
                <thead>
                    <tr>
                        <th>Alternatif</th>
                        <?php foreach($kriteria as $k): ?>
                            <th><?= $k['kode_kriteria'] ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($alternatif as $alt): ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($alt['nama']) ?></strong></td>
                            <?php foreach($kriteria as $k): ?>
                                <td><?= number_format($normalized[$alt['id_alternatif']][$k['id_kriteria']] ?? 0, 4) ?></td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- STEP 4: Skor Akhir -->
    <div class="step-card">
        <div class="d-flex align-items-center mb-3">
            <span class="step-number">4</span>
            <span class="step-title">Skor Akhir (V)</span>
        </div>

        <div class="formula-box mb-3">
            <strong>Rumus SAW:</strong> V<sub>i</sub> = Σ (W<sub>j</sub> × r<sub>ij</sub>)
        </div>

        <div class="table-responsive-custom">
            <table class="table table-bordered table-saw">
                <thead>
                    <tr>
                        <th>Alternatif</th>
                        <?php foreach($kriteria as $k): ?>
                            <th><?= $k['kode_kriteria'] ?> <br><small>W=<?= number_format($k['bobot_ahp'], 4) ?></small></th>
                        <?php endforeach; ?>
                        <th class="highlight-cell">Skor Akhir (V)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($alternatif as $alt): 
                        $total = $skor[$alt['id_alternatif']] ?? 0;
                    ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($alt['nama']) ?></strong></td>
                            <?php foreach($kriteria as $k): 
                                $weighted = $bobot[$k['id_kriteria']] * ($normalized[$alt['id_alternatif']][$k['id_kriteria']] ?? 0);
                            ?>
                                <td><?= number_format($weighted, 4) ?></td>
                            <?php endforeach; ?>
                            <td class="highlight-cell">
                                <span class="fw-bold fs-5 text-success"><?= number_format($total, 6) ?></span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- STEP 5: Ranking -->
    <div class="step-card">
        <div class="d-flex align-items-center mb-3">
            <span class="step-number">5</span>
            <span class="step-title">Ranking &amp; Kesimpulan</span>
        </div>

        <!-- 3 Besar -->
        <div class="row g-4 mb-4">
            <?php 
            $rankEmoji = ['🥇', '🥈', '🥉'];
            foreach($hasil as $index => $h): 
                if($index >= 3) break;
            ?>
                <div class="col-md-4">
                    <div class="rank-card rank-<?= $index + 1 ?>">
                        <div class="mb-2" style="font-size:3rem;"><?= $rankEmoji[$index] ?></div>
                        <div class="number">#<?= $h['ranking'] ?></div>
                        <div class="fw-bold fs-5"><?= htmlspecialchars($h['nama']) ?></div>
                        <div class="small"><?= htmlspecialchars($h['nim']) ?></div>
                        <div class="mt-2">
                            <span class="badge bg-primary">Skor: <?= number_format($h['skor_akhir'], 6) ?></span>
                        </div>
                        <div class="mt-2">
                            <span class="badge <?= $h['status'] == 'penerima' ? 'bg-success' : 'bg-warning text-dark' ?>">
                                <?= $h['status'] == 'penerima' ? '✅ Penerima' : ($h['status'] == 'cadangan1' ? '📌 Cadangan 1' : '📌 Cadangan 2') ?>
                            </span>
                        </div>
                        <div class="small mt-2"><?= htmlspecialchars($h['jurusan']) ?></div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Tabel Ranking Lengkap -->
        <div class="table-responsive-custom">
            <table class="table table-bordered table-saw">
                <thead>
                    <tr>
                        <th>Ranking</th>
                        <th>Nama</th>
                        <th>NIM</th>
                        <th>Jurusan</th>
                        <th class="text-center">Skor Akhir</th>
                        <th class="text-center">Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $rankEmojiAll = ['🥇', '🥈', '🥉', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];
                    $badgeStatus = [
                        'penerima' => 'bg-success',
                        'cadangan1' => 'bg-warning text-dark',
                        'cadangan2' => 'bg-info',
                        'tidak_terpilih' => 'bg-secondary'
                    ];
                    $statusText = [
                        'penerima' => '✅ Penerima',
                        'cadangan1' => '📌 Cadangan 1',
                        'cadangan2' => '📌 Cadangan 2',
                        'tidak_terpilih' => 'Tidak Terpilih'
                    ];
                    foreach($hasil as $h): 
                    ?>
                        <tr>
                            <td>
                                <span class="fs-5"><?= $rankEmojiAll[$h['ranking'] - 1] ?? '#' ?></span>
                                <span class="fw-bold">#<?= $h['ranking'] ?></span>
                            </td>
                            <td><?= htmlspecialchars($h['nama']) ?></td>
                            <td><?= htmlspecialchars($h['nim']) ?></td>
                            <td><?= htmlspecialchars($h['jurusan']) ?></td>
                            <td class="text-center">
                                <span class="fw-bold text-success"><?= number_format($h['skor_akhir'], 6) ?></span>
                            </td>
                            <td class="text-center">
                                <span class="badge <?= $badgeStatus[$h['status']] ?? 'bg-secondary' ?>">
                                    <?= $statusText[$h['status']] ?? $h['status'] ?>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Kesimpulan -->
        <?php if(!empty($hasil)): ?>
            <div class="alert alert-success mt-3">
                <i class="bi bi-check-circle-fill me-2"></i>
                <strong>Kesimpulan SAW:</strong>
                Berdasarkan hasil perhitungan SAW, calon penerima beasiswa adalah 
                <strong><?= htmlspecialchars($hasil[0]['nama']) ?></strong> 
                (NIM: <?= htmlspecialchars($hasil[0]['nim']) ?>) 
                dengan skor akhir <strong><?= number_format($hasil[0]['skor_akhir'], 6) ?></strong>.
            </div>
        <?php endif; ?>
    </div>

</div>

<?php include '../../includes/footer.php'; ?>