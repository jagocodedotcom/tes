<?php
// modul/perhitungan/perbandingan.php - SUPER DETAIL DENGAN TANDA
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

require_once '../../config/database.php';

if(!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: ../login/');
    exit;
}

$page_title = 'Perbandingan AHP & SAW - Detail';

// ============================================
// AMBIL DATA UNTUK SIDEBAR
// ============================================
$result = $pdo->query("SELECT COUNT(*) FROM alternatif");
$row = $result->fetch_row();
$total_alt = $row[0] ?? 0;

$result = $pdo->query("SELECT COUNT(*) FROM kriteria");
$row = $result->fetch_row();
$total_krit = $row[0] ?? 0;

$result = $pdo->query("SELECT COUNT(*) FROM nilai_alternatif");
$row = $result->fetch_row();
$total_nilai = $row[0] ?? 0;

// ============================================
// 1. AMBIL DATA KRITERIA
// ============================================
$result = $pdo->query("SELECT * FROM kriteria ORDER BY id_kriteria");
$kriteria = $result->fetch_all(MYSQLI_ASSOC);
$n = count($kriteria);

// ============================================
// 2. AMBIL MATRIKS PERBANDINGAN AHP
// ============================================
$result = $pdo->query("SELECT * FROM matriks_perbandingan ORDER BY id_kriteria1, id_kriteria2");
$matriks_data = $result->fetch_all(MYSQLI_ASSOC);

$matriks = array();
for($i = 0; $i < $n; $i++) {
    for($j = 0; $j < $n; $j++) {
        $matriks[$i][$j] = 1;
    }
}

foreach($matriks_data as $m) {
    $i = $m['id_kriteria1'] - 1;
    $j = $m['id_kriteria2'] - 1;
    $matriks[$i][$j] = $m['nilai'];
    $matriks[$j][$i] = 1 / $m['nilai'];
}

// ============================================
// 3. HITUNG BOBOT AHP
// ============================================
$jumlah_kolom = array();
for($j = 0; $j < $n; $j++) {
    $sum = 0;
    for($i = 0; $i < $n; $i++) {
        $sum += $matriks[$i][$j];
    }
    $jumlah_kolom[$j] = $sum;
}

$bobot_ahp = array();
for($i = 0; $i < $n; $i++) {
    $sum = 0;
    for($j = 0; $j < $n; $j++) {
        $sum += $matriks[$i][$j] / $jumlah_kolom[$j];
    }
    $bobot_ahp[$i] = $sum / $n;
}

// ============================================
// 4. AMBIL DATA ALTERNATIF & NILAI
// ============================================
$result = $pdo->query("SELECT * FROM alternatif ORDER BY id_alternatif");
$alternatif = $result->fetch_all(MYSQLI_ASSOC);

$nilai_data = array();
foreach($alternatif as $alt) {
    $sql = "SELECT id_kriteria, nilai FROM nilai_alternatif WHERE id_alternatif = " . $alt['id_alternatif'];
    $result = $pdo->query($sql);
    $rows = $result->fetch_all(MYSQLI_ASSOC);
    foreach($rows as $row) {
        $nilai_data[$alt['id_alternatif']][$row['id_kriteria']] = $row['nilai'];
    }
}

// ============================================
// 5. NORMALISASI SAW
// ============================================
$normalized = array();
foreach($kriteria as $k) {
    $values = array();
    foreach($alternatif as $alt) {
        $val = $nilai_data[$alt['id_alternatif']][$k['id_kriteria']] ?? 0;
        $values[$alt['id_alternatif']] = $val;
    }
    
    $max = max($values);
    $min = min(array_filter($values, function($v) { return $v > 0; })) ?: 1;
    
    foreach($alternatif as $alt) {
        $val = $values[$alt['id_alternatif']];
        if($k['jenis'] == 'benefit') {
            $normalized[$alt['id_alternatif']][$k['id_kriteria']] = $max > 0 ? $val / $max : 0;
        } else {
            $normalized[$alt['id_alternatif']][$k['id_kriteria']] = $val > 0 ? $min / $val : 0;
        }
    }
}

// ============================================
// 6. HITUNG SKOR SAW
// ============================================
$skor_saw = array();
foreach($alternatif as $alt) {
    $total = 0;
    foreach($kriteria as $k) {
        $total += $k['bobot_ahp'] * ($normalized[$alt['id_alternatif']][$k['id_kriteria']] ?? 0);
    }
    $skor_saw[$alt['id_alternatif']] = $total;
}
arsort($skor_saw);

// ============================================
// 7. AMBIL HASIL DARI DATABASE
// ============================================
$result = $pdo->query("
    SELECT h.*, a.nama, a.nim, a.jurusan 
    FROM hasil_perhitungan h 
    JOIN alternatif a ON h.id_alternatif = a.id_alternatif 
    ORDER BY h.ranking
");
$hasil = $result->fetch_all(MYSQLI_ASSOC);

// ============================================
// 8. TENTUKAN NILAI TERTINGGI & TERENDAH
// ============================================
// Cari bobot tertinggi dan terendah AHP
$max_bobot = max($bobot_ahp);
$min_bobot = min($bobot_ahp);
$max_bobot_idx = array_search($max_bobot, $bobot_ahp);
$min_bobot_idx = array_search($min_bobot, $bobot_ahp);

// Cari skor tertinggi dan terendah SAW
$skor_values = array_values($skor_saw);
$max_skor = max($skor_values);
$min_skor = min($skor_values);

include '../../includes/header.php';
include '../../includes/sidebar.php';
?>

<style>
    /* ============================================
       GLOBAL STYLES
       ============================================ */
    .comparison-card {
        background: #fff;
        border-radius: 16px;
        border: 1px solid #f1f5f9;
        padding: 24px;
        margin-bottom: 24px;
        transition: all .3s ease;
    }
    .comparison-card:hover {
        box-shadow: 0 4px 20px rgba(0,0,0,0.05);
    }
    
    .step-number {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 40px;
        height: 40px;
        background: #7c3aed;
        color: #fff;
        border-radius: 50%;
        font-weight: 700;
        font-size: 1rem;
        margin-right: 14px;
        flex-shrink: 0;
    }
    .step-title {
        font-weight: 700;
        font-size: 1.2rem;
        color: #7c3aed;
    }
    .step-header {
        display: flex;
        align-items: center;
        margin-bottom: 16px;
        flex-wrap: wrap;
        gap: 8px;
    }
    .step-desc {
        color: #6b7280;
        font-size: .9rem;
        margin-left: 54px;
        margin-bottom: 16px;
        line-height: 1.6;
    }
    
    /* ============================================
       TABLES
       ============================================ */
    .table-comp thead th {
        background: linear-gradient(135deg, #7c3aed, #a78bfa);
        color: #fff;
        font-weight: 600;
        font-size: .7rem;
        text-transform: uppercase;
        letter-spacing: .5px;
        padding: 8px 10px;
        border: none;
        text-align: center;
    }
    .table-comp tbody td {
        padding: 8px 10px;
        vertical-align: middle;
        text-align: center;
        font-size: .85rem;
    }
    .table-comp tbody tr:hover {
        background: #f5f3ff;
    }
    
    /* ============================================
       HIGHLIGHT CELLS - DENGAN TANDA
       ============================================ */
    .highlight-ahp {
        background: #dbeafe !important;
        border-left: 4px solid #011851 !important;
        font-weight: 700;
        color: #011851;
    }
    .highlight-ahp-max {
        background: #bfdbfe !important;
        border-left: 4px solid #011851 !important;
        border-right: 4px solid #011851 !important;
        font-weight: 800;
        color: #011851;
        box-shadow: 0 0 20px rgba(1, 24, 81, 0.15);
    }
    .highlight-ahp-min {
        background: #e8edf8 !important;
        border-left: 4px solid #6b7280 !important;
        font-weight: 700;
        color: #4b5563;
    }
    
    .highlight-saw {
        background: #d1fae5 !important;
        border-left: 4px solid #059669 !important;
        font-weight: 700;
        color: #065f46;
    }
    .highlight-saw-max {
        background: #a7f3d0 !important;
        border-left: 4px solid #059669 !important;
        border-right: 4px solid #059669 !important;
        font-weight: 800;
        color: #065f46;
        box-shadow: 0 0 20px rgba(5, 150, 105, 0.15);
    }
    .highlight-saw-min {
        background: #ecfdf5 !important;
        border-left: 4px solid #6b7280 !important;
        font-weight: 700;
        color: #4b5563;
    }
    
    .highlight-compare {
        background: #ede9fe !important;
        border-left: 4px solid #7c3aed !important;
        font-weight: 700;
        color: #5b21b6;
    }
    .highlight-compare-max {
        background: #ddd6fe !important;
        border-left: 4px solid #7c3aed !important;
        border-right: 4px solid #7c3aed !important;
        font-weight: 800;
        color: #5b21b6;
        box-shadow: 0 0 20px rgba(124, 58, 237, 0.15);
    }
    
    /* ============================================
       RESULT BOXES
       ============================================ */
    .result-box-ahp {
        background: linear-gradient(135deg, #011851, #1a3a9a);
        color: #fff;
        border-radius: 12px;
        padding: 16px 20px;
        margin: 8px 0;
        text-align: center;
        transition: all .3s ease;
    }
    .result-box-ahp:hover {
        transform: scale(1.02);
        box-shadow: 0 4px 20px rgba(1, 24, 81, 0.3);
    }
    .result-box-ahp .label {
        font-size: .75rem;
        opacity: .8;
        text-transform: uppercase;
        letter-spacing: .5px;
    }
    .result-box-ahp .value {
        font-size: 1.4rem;
        font-weight: 700;
    }
    .result-box-ahp .badge-mark {
        background: #ffd966;
        color: #011851;
        padding: 2px 10px;
        border-radius: 20px;
        font-size: .65rem;
        font-weight: 700;
    }
    
    .result-box-saw {
        background: linear-gradient(135deg, #059669, #34d399);
        color: #fff;
        border-radius: 12px;
        padding: 16px 20px;
        margin: 8px 0;
        text-align: center;
        transition: all .3s ease;
    }
    .result-box-saw:hover {
        transform: scale(1.02);
        box-shadow: 0 4px 20px rgba(5, 150, 105, 0.3);
    }
    .result-box-saw .label {
        font-size: .75rem;
        opacity: .8;
        text-transform: uppercase;
        letter-spacing: .5px;
    }
    .result-box-saw .value {
        font-size: 1.4rem;
        font-weight: 700;
    }
    .result-box-saw .badge-mark {
        background: #ffd966;
        color: #065f46;
        padding: 2px 10px;
        border-radius: 20px;
        font-size: .65rem;
        font-weight: 700;
    }
    
    /* ============================================
       RANK CARDS
       ============================================ */
    .rank-card {
        border-radius: 16px;
        padding: 20px;
        text-align: center;
        height: 100%;
        transition: all .3s ease;
        border: 1px solid #f1f5f9;
    }
    .rank-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 8px 30px rgba(0,0,0,0.05);
    }
    .rank-card.rank-1 {
        background: linear-gradient(135deg, #fef3c7, #fde68a);
        border-color: #f59e0b;
    }
    .rank-card.rank-2 {
        background: linear-gradient(135deg, #f1f5f9, #e2e8f0);
        border-color: #94a3b8;
    }
    .rank-card.rank-3 {
        background: linear-gradient(135deg, #fef3c7, #fcd34d);
        border-color: #d97706;
    }
    .rank-card .rank-number {
        font-size: 2.5rem;
        font-weight: 800;
    }
    .rank-card .rank-emoji {
        font-size: 3rem;
    }
    
    /* ============================================
       FORMULA BOX
       ============================================ */
    .formula-box {
        background: #f5f3ff;
        border-radius: 12px;
        padding: 16px 20px;
        border-left: 4px solid #7c3aed;
        font-family: 'Courier New', monospace;
        font-size: .9rem;
        margin: 12px 0;
        overflow-x: auto;
    }
    
    .badge-ahp {
        background: #011851;
        color: #fff;
        padding: 4px 12px;
        border-radius: 20px;
        font-weight: 600;
        font-size: .7rem;
    }
    .badge-saw {
        background: #059669;
        color: #fff;
        padding: 4px 12px;
        border-radius: 20px;
        font-weight: 600;
        font-size: .7rem;
    }
    
    .table-responsive-custom {
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
        width: 100%;
        display: block;
    }
    .table-responsive-custom table {
        width: 100%;
        min-width: 700px;
        margin-bottom: 0;
        background: #fff;
        border-radius: 12px;
        overflow: hidden;
    }
    
    .stat-card {
        background: #fff;
        border-radius: 16px;
        padding: 18px 20px;
        border: 1px solid #f1f5f9;
        transition: all .3s ease;
        height: 100%;
    }
    .stat-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 4px 20px rgba(0,0,0,0.05);
    }
    
    /* Legend */
    .legend-box {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 6px 14px;
        border-radius: 20px;
        font-size: .8rem;
        font-weight: 600;
    }
    .legend-ahp {
        background: #dbeafe;
        color: #011851;
    }
    .legend-saw {
        background: #d1fae5;
        color: #065f46;
    }
    .legend-compare {
        background: #ede9fe;
        color: #5b21b6;
    }
    .legend-max {
        border: 2px solid #f59e0b;
        background: #fef3c7;
        color: #92400e;
    }
    
    /* ============================================
       MARKER ICONS
       ============================================ */
    .marker-icon {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 22px;
        height: 22px;
        border-radius: 50%;
        font-size: .7rem;
        font-weight: 700;
        margin-left: 4px;
    }
    .marker-max {
        background: #f59e0b;
        color: #fff;
    }
    .marker-min {
        background: #6b7280;
        color: #fff;
    }
    .marker-high {
        background: #10b981;
        color: #fff;
    }
    .marker-low {
        background: #ef4444;
        color: #fff;
    }
</style>

<div class="app-content">

    <!-- ============================================
    HEADER
    ============================================ -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold mb-1">
                <i class="bi bi-arrow-left-right text-primary me-2"></i>
                Perbandingan AHP &amp; SAW - Detail
            </h4>
            <p class="text-muted small mb-0">
                <i class="bi bi-info-circle me-1"></i>
                Perbandingan hasil dengan <strong>tanda/penanda</strong> untuk nilai tertinggi 🔼, terendah 🔽, dan perbedaan
            </p>
        </div>
        <div class="d-flex gap-2">
            <a href="ahp_detail.php" class="btn btn-outline-primary btn-sm">
                <i class="bi bi-list-check"></i> AHP
            </a>
            <a href="saw_detail.php" class="btn btn-outline-success btn-sm">
                <i class="bi bi-calculator"></i> SAW
            </a>
            <a href="index.php" class="btn btn-primary btn-sm">
                <i class="bi bi-arrow-repeat"></i> Refresh
            </a>
        </div>
    </div>

    <!-- ============================================
    STATISTIK
    ============================================ -->
    <div class="row g-3 mb-4">
        <div class="col-md-3 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h2 class="mb-0 fw-bold text-primary"><?= $total_alt ?></h2>
                        <small class="text-muted">Alternatif</small>
                    </div>
                    <i class="bi bi-people-fill text-primary fs-1 opacity-25"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h2 class="mb-0 fw-bold text-success"><?= $total_krit ?></h2>
                        <small class="text-muted">Kriteria</small>
                    </div>
                    <i class="bi bi-list-check text-success fs-1 opacity-25"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h2 class="mb-0 fw-bold text-info"><?= $total_nilai ?></h2>
                        <small class="text-muted">Nilai</small>
                    </div>
                    <i class="bi bi-table text-info fs-1 opacity-25"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h2 class="mb-0 fw-bold text-warning"><?= count($hasil) ?></h2>
                        <small class="text-muted">Hasil</small>
                    </div>
                    <i class="bi bi-trophy text-warning fs-1 opacity-25"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- ============================================
    LEGENDA LENGKAP
    ============================================ -->
    <div class="alert alert-light border mb-4">
        <div class="d-flex flex-wrap gap-3 align-items-center">
            <strong>Legenda:</strong>
            <span class="legend-box legend-ahp">
                <i class="bi bi-circle-fill" style="color:#011851;font-size:.6rem;"></i>
                AHP (Bobot)
            </span>
            <span class="legend-box legend-saw">
                <i class="bi bi-circle-fill" style="color:#059669;font-size:.6rem;"></i>
                SAW (Skor)
            </span>
            <span class="legend-box legend-compare">
                <i class="bi bi-circle-fill" style="color:#7c3aed;font-size:.6rem;"></i>
                Perbandingan
            </span>
            <span class="legend-box legend-max">
                <i class="bi bi-star-fill" style="color:#f59e0b;font-size:.6rem;"></i>
                Nilai Tertinggi
            </span>
            <span class="legend-box" style="background:#e8edf8;color:#4b5563;">
                <i class="bi bi-arrow-down" style="color:#6b7280;"></i>
                Nilai Terendah
            </span>
        </div>
    </div>

    <!-- ============================================
    STEP 1: PERBANDINGAN BOBOT AHP
    ============================================ -->
    <div class="comparison-card">
        <div class="step-header">
            <span class="step-number">1</span>
            <span class="step-title">Perbandingan Bobot AHP <span class="badge-ahp ms-2">AHP</span></span>
        </div>
        <div class="step-desc">
            <strong>Hasil AHP:</strong> Bobot setiap kriteria dari matriks perbandingan berpasangan.
            <br>
            <strong>Tanda:</strong> 
            <span class="badge bg-warning text-dark">⭐ Tertinggi</span> 
            <span class="badge bg-secondary">⬇ Terendah</span>
        </div>

        <div class="row g-3">
            <?php for($i = 0; $i < $n; $i++): 
                $is_max = ($bobot_ahp[$i] == $max_bobot);
                $is_min = ($bobot_ahp[$i] == $min_bobot);
            ?>
                <div class="col-md-3 col-6">
                    <div class="result-box-ahp" style="<?= $is_max ? 'border: 3px solid #f59e0b;' : '' ?>">
                        <div class="label">
                            <?= $kriteria[$i]['kode_kriteria'] ?>
                            <?php if($is_max): ?>
                                <span class="badge-mark">⭐ TERTINGGI</span>
                            <?php elseif($is_min): ?>
                                <span class="badge-mark" style="background:#6b7280;color:#fff;">⬇ TERENDAH</span>
                            <?php endif; ?>
                        </div>
                        <div class="value"><?= number_format($bobot_ahp[$i] * 100, 1) ?>%</div>
                        <div class="label"><?= $kriteria[$i]['nama_kriteria'] ?></div>
                        <div class="label mt-1">Bobot = <?= number_format($bobot_ahp[$i], 4) ?></div>
                    </div>
                </div>
            <?php endfor; ?>
        </div>

        <div class="alert alert-info mt-3">
            <i class="bi bi-info-circle me-2"></i>
            <strong>Interpretasi:</strong>
            Kriteria <strong><?= $kriteria[$max_bobot_idx]['kode_kriteria'] ?></strong> memiliki bobot tertinggi 
            (<strong><?= number_format($max_bobot * 100, 1) ?>%</strong>) 
            <span class="badge bg-warning text-dark">⭐</span>, 
            artinya paling berpengaruh dalam penilaian.
            Kriteria <strong><?= $kriteria[$min_bobot_idx]['kode_kriteria'] ?></strong> memiliki bobot terendah 
            (<strong><?= number_format($min_bobot * 100, 1) ?>%</strong>)
            <span class="badge bg-secondary">⬇</span>.
        </div>
    </div>

    <!-- ============================================
    STEP 2: PERBANDINGAN SKOR SAW
    ============================================ -->
    <div class="comparison-card">
        <div class="step-header">
            <span class="step-number">2</span>
            <span class="step-title">Perbandingan Skor SAW <span class="badge-saw ms-2">SAW</span></span>
        </div>
        <div class="step-desc">
            <strong>Hasil SAW:</strong> Skor akhir dan ranking setiap alternatif.
            <br>
            <strong>Tanda:</strong> 
            <span class="badge bg-warning text-dark">⭐ Skor Tertinggi</span> 
            <span class="badge bg-secondary">⬇ Skor Terendah</span>
            <span class="badge bg-success">✅ Penerima</span>
            <span class="badge bg-warning text-dark">📌 Cadangan</span>
        </div>

        <div class="table-responsive-custom">
            <table class="table table-bordered table-comp">
                <thead>
                    <tr>
                        <th>Ranking</th>
                        <th>Alternatif</th>
                        <th>NIM</th>
                        <th>Skor SAW</th>
                        <th>Status</th>
                        <th>Keterangan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $rankEmojiAll = ['🥇', '🥈', '🥉', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];
                    $badgeStatus = [
                        'penerima' => 'bg-success',
                        'cadangan1' => 'bg-warning text-dark',
                        'cadangan2' => 'bg-info',
                        'tidak_terpilih' => 'bg-secondary'
                    ];
                    $statusText = [
                        'penerima' => '✅ Penerima',
                        'cadangan1' => '📌 Cadangan 1',
                        'cadangan2' => '📌 Cadangan 2',
                        'tidak_terpilih' => 'Tidak Terpilih'
                    ];
                    foreach($hasil as $h):
                        $is_max_skor = ($h['skor_akhir'] == $max_skor);
                        $is_min_skor = ($h['skor_akhir'] == $min_skor);
                    ?>
                        <tr>
                            <td>
                                <span class="fs-4"><?= $rankEmojiAll[$h['ranking'] - 1] ?? '#' ?></span>
                                <span class="fw-bold">#<?= $h['ranking'] ?></span>
                            </td>
                            <td><strong><?= htmlspecialchars($h['nama']) ?></strong></td>
                            <td><?= htmlspecialchars($h['nim']) ?></td>
                            <td class="<?= $is_max_skor ? 'highlight-saw-max' : ($is_min_skor ? 'highlight-saw-min' : 'highlight-saw') ?>">
                                <span class="fw-bold fs-5"><?= number_format($h['skor_akhir'], 6) ?></span>
                                <?php if($is_max_skor): ?>
                                    <span class="marker-icon marker-max">⭐</span>
                                <?php elseif($is_min_skor): ?>
                                    <span class="marker-icon marker-min">⬇</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge <?= $badgeStatus[$h['status']] ?? 'bg-secondary' ?>">
                                    <?= $statusText[$h['status']] ?? $h['status'] ?>
                                </span>
                            </td>
                            <td>
                                <?php if($h['status'] == 'penerima'): ?>
                                    <span class="badge bg-success">🏆 PENERIMA</span>
                                <?php elseif($h['status'] == 'cadangan1'): ?>
                                    <span class="badge bg-warning text-dark">📌 CADANGAN 1</span>
                                <?php elseif($h['status'] == 'cadangan2'): ?>
                                    <span class="badge bg-info">📌 CADANGAN 2</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">-</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="alert alert-success mt-3">
            <i class="bi bi-trophy me-2"></i>
            <strong>Skor Tertinggi:</strong> 
            <strong><?= htmlspecialchars($hasil[0]['nama'] ?? '-') ?></strong> 
            dengan skor <strong><?= number_format($max_skor, 6) ?></strong> 
            <span class="badge bg-warning text-dark">⭐</span>
            <br>
            <i class="bi bi-arrow-down me-2"></i>
            <strong>Skor Terendah:</strong> 
            <strong><?= htmlspecialchars($hasil[count($hasil)-1]['nama'] ?? '-') ?></strong> 
            dengan skor <strong><?= number_format($min_skor, 6) ?></strong>
            <span class="badge bg-secondary">⬇</span>
        </div>
    </div>

    <!-- ============================================
    STEP 3: PERBANDINGAN SIDE BY SIDE
    ============================================ -->
    <div class="comparison-card">
        <div class="step-header">
            <span class="step-number">3</span>
            <span class="step-title">Perbandingan Side by Side <span class="badge-ahp ms-2">AHP</span> <span class="badge-saw ms-1">SAW</span></span>
        </div>
        <div class="step-desc">
            <strong>Perbandingan langsung:</strong> Nilai awal (🔵 AHP) dan Normalisasi (🟢 SAW) setiap alternatif.
            <br>
            <strong>Tanda:</strong> 
            <span class="badge" style="background:#dbeafe;color:#011851;">🔵 AHP</span>
            <span class="badge" style="background:#d1fae5;color:#065f46;">🟢 SAW</span>
            <span class="badge" style="background:#ede9fe;color:#5b21b6;">🟣 Perbandingan</span>
        </div>

        <div class="table-responsive-custom">
            <table class="table table-bordered table-comp">
                <thead>
                    <tr>
                        <th rowspan="2" style="min-width:100px;">Alternatif</th>
                        <?php for($i = 0; $i < $n; $i++): ?>
                            <th colspan="2" class="text-center" style="background:linear-gradient(135deg,#dbeafe,#d1fae5);">
                                <?= $kriteria[$i]['kode_kriteria'] ?>
                                <br>
                                <small>
                                    <?php if($kriteria[$i]['jenis'] == 'benefit'): ?>
                                        <span class="badge bg-success">↑</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">↓</span>
                                    <?php endif; ?>
                                    W = <?= number_format($bobot_ahp[$i], 3) ?>
                                </small>
                            </th>
                        <?php endfor; ?>
                        <th rowspan="2" class="highlight-compare-max">Skor Akhir</th>
                        <th rowspan="2" class="highlight-compare-max">Ranking</th>
                    </tr>
                    <tr>
                        <?php for($i = 0; $i < $n; $i++): ?>
                            <th style="background:#dbeafe;font-size:.65rem;color:#011851;">
                                🔵 Nilai
                            </th>
                            <th style="background:#d1fae5;font-size:.65rem;color:#065f46;">
                                🟢 Normalisasi
                            </th>
                        <?php endfor; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $rankEmojiAll = ['🥇', '🥈', '🥉', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];
                    foreach($hasil as $h):
                        $alt = null;
                        foreach($alternatif as $a) {
                            if($a['id_alternatif'] == $h['id_alternatif']) {
                                $alt = $a;
                                break;
                            }
                        }
                        if(!$alt) continue;
                        
                        $is_max_skor = ($h['skor_akhir'] == $max_skor);
                        $is_min_skor = ($h['skor_akhir'] == $min_skor);
                    ?>
                        <tr>
                            <td>
                                <strong><?= htmlspecialchars($alt['nama']) ?></strong>
                                <?php if($h['ranking'] == 1): ?>
                                    <span class="badge bg-warning text-dark">⭐</span>
                                <?php endif; ?>
                            </td>
                            <?php for($i = 0; $i < $n; $i++): 
                                $k = $kriteria[$i];
                                $nilai = $nilai_data[$alt['id_alternatif']][$k['id_kriteria']] ?? 0;
                                $norm = $normalized[$alt['id_alternatif']][$k['id_kriteria']] ?? 0;
                                
                                // Cek apakah nilai ini max atau min
                                $is_max_nilai = false;
                                $is_min_nilai = false;
                                foreach($alternatif as $a2) {
                                    $v = $nilai_data[$a2['id_alternatif']][$k['id_kriteria']] ?? 0;
                                    if($v > $nilai) $is_max_nilai = false;
                                    if($v < $nilai) $is_min_nilai = false;
                                }
                            ?>
                                <td style="background:#f0f4ff; <?= $is_max_nilai ? 'border:2px solid #f59e0b;' : '' ?>">
                                    <?= number_format($nilai, 2) ?>
                                    <?php if($is_max_nilai): ?>
                                        <span class="marker-icon marker-max" style="font-size:.5rem;width:16px;height:16px;">⭐</span>
                                    <?php endif; ?>
                                </td>
                                <td style="background:#ecfdf5; <?= $norm == 1 ? 'border:2px solid #f59e0b;' : '' ?>">
                                    <?= number_format($norm, 4) ?>
                                    <?php if($norm == 1): ?>
                                        <span class="marker-icon marker-max" style="font-size:.5rem;width:16px;height:16px;">⭐</span>
                                    <?php endif; ?>
                                </td>
                            <?php endfor; ?>
                            <td class="<?= $is_max_skor ? 'highlight-compare-max' : 'highlight-compare' ?>">
                                <span class="fw-bold fs-5"><?= number_format($h['skor_akhir'], 6) ?></span>
                                <?php if($is_max_skor): ?>
                                    <span class="marker-icon marker-max">⭐</span>
                                <?php elseif($is_min_skor): ?>
                                    <span class="marker-icon marker-min">⬇</span>
                                <?php endif; ?>
                            </td>
                            <td class="highlight-compare">
                                <span class="fs-4"><?= $rankEmojiAll[$h['ranking'] - 1] ?? '#' ?></span>
                                <span class="fw-bold">#<?= $h['ranking'] ?></span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- ============================================
    STEP 4: RINGKASAN PERBANDINGAN
    ============================================ -->
    <div class="comparison-card">
        <div class="step-header">
            <span class="step-number">4</span>
            <span class="step-title">Ringkasan Perbandingan</span>
        </div>

        <div class="row g-4">
            <!-- Ringkasan AHP -->
            <div class="col-md-6">
                <div class="card h-100">
                    <div class="card-header bg-transparent">
                        <h6 class="fw-bold text-primary mb-0">
                            <i class="bi bi-list-check me-2"></i>
                            Ringkasan AHP
                            <span class="badge-ahp ms-2">AHP</span>
                        </h6>
                    </div>
                    <div class="card-body">
                        <table class="table table-sm table-bordered">
                            <thead>
                                <tr><th>Kriteria</th><th>Bobot</th><th>Keterangan</th></tr>
                            </thead>
                            <tbody>
                                <?php for($i = 0; $i < $n; $i++): 
                                    $is_max = ($bobot_ahp[$i] == $max_bobot);
                                    $is_min = ($bobot_ahp[$i] == $min_bobot);
                                ?>
                                    <tr>
                                        <td><?= $kriteria[$i]['kode_kriteria'] ?> - <?= $kriteria[$i]['nama_kriteria'] ?></td>
                                        <td>
                                            <span class="badge bg-primary"><?= number_format($bobot_ahp[$i] * 100, 1) ?>%</span>
                                        </td>
                                        <td>
                                            <?php if($is_max): ?>
                                                <span class="badge bg-warning text-dark">⭐ TERTINGGI</span>
                                            <?php elseif($is_min): ?>
                                                <span class="badge bg-secondary">⬇ TERENDAH</span>
                                            <?php else: ?>
                                                <span class="badge bg-light text-dark">-</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endfor; ?>
                                <tr class="fw-bold">
                                    <td>Total</td>
                                    <td>100%</td>
                                    <td></td>
                                </tr>
                            </tbody>
                        </table>
                        <div class="alert alert-info mb-0">
                            <i class="bi bi-check-circle me-2"></i>
                            Bobot tertinggi: <strong><?= $kriteria[$max_bobot_idx]['kode_kriteria'] ?></strong> 
                            (<strong><?= number_format($max_bobot * 100, 1) ?>%</strong>) 
                            <span class="badge bg-warning text-dark">⭐</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Ringkasan SAW -->
            <div class="col-md-6">
                <div class="card h-100">
                    <div class="card-header bg-transparent">
                        <h6 class="fw-bold text-success mb-0">
                            <i class="bi bi-calculator me-2"></i>
                            Ringkasan SAW
                            <span class="badge-saw ms-2">SAW</span>
                        </h6>
                    </div>
                    <div class="card-body">
                        <table class="table table-sm table-bordered">
                            <thead>
                                <tr><th>Ranking</th><th>Alternatif</th><th>Skor</th><th>Status</th></tr>
                            </thead>
                            <tbody>
                                <?php foreach($hasil as $h): 
                                    $is_max_skor = ($h['skor_akhir'] == $max_skor);
                                    $is_min_skor = ($h['skor_akhir'] == $min_skor);
                                ?>
                                    <tr>
                                        <td>#<?= $h['ranking'] ?></td>
                                        <td><?= htmlspecialchars($h['nama']) ?></td>
                                        <td>
                                            <span class="badge bg-success"><?= number_format($h['skor_akhir'], 6) ?></span>
                                            <?php if($is_max_skor): ?>
                                                <span class="marker-icon marker-max">⭐</span>
                                            <?php elseif($is_min_skor): ?>
                                                <span class="marker-icon marker-min">⬇</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="badge <?= $badgeStatus[$h['status']] ?? 'bg-secondary' ?>">
                                                <?= $statusText[$h['status']] ?? $h['status'] ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <div class="alert alert-success mb-0">
                            <i class="bi bi-trophy me-2"></i>
                            Penerima: <strong><?= htmlspecialchars($hasil[0]['nama'] ?? '-') ?></strong>
                            (Skor: <strong><?= number_format($max_skor, 6) ?></strong>) 
                            <span class="badge bg-warning text-dark">⭐</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ============================================
    STEP 5: KESIMPULAN AKHIR
    ============================================ -->
    <div class="comparison-card">
        <div class="step-header">
            <span class="step-number">5</span>
            <span class="step-title">Kesimpulan Akhir</span>
        </div>

        <?php if(!empty($hasil)): ?>
            <div class="alert alert-success">
                <i class="bi bi-check-circle-fill me-2"></i>
                <strong>Kesimpulan Akhir:</strong>
                <br><br>
                <div class="row">
                    <div class="col-md-6">
                        <div class="card bg-light">
                            <div class="card-body">
                                <h6 class="fw-bold text-primary">
                                    <i class="bi bi-list-check me-2"></i>
                                    AHP (Bobot Kriteria)
                                </h6>
                                <ul class="list-unstyled">
                                    <li>✅ Bobot tertinggi: <strong><?= $kriteria[$max_bobot_idx]['kode_kriteria'] ?></strong> 
                                        (<strong><?= number_format($max_bobot * 100, 1) ?>%</strong>) 
                                        <span class="badge bg-warning text-dark">⭐</span></li>
                                    <li>✅ Bobot terendah: <strong><?= $kriteria[$min_bobot_idx]['kode_kriteria'] ?></strong> 
                                        (<strong><?= number_format($min_bobot * 100, 1) ?>%</strong>) 
                                        <span class="badge bg-secondary">⬇</span></li>
                                    <li>✅ Total bobot: <strong>100%</strong></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card bg-light">
                            <div class="card-body">
                                <h6 class="fw-bold text-success">
                                    <i class="bi bi-calculator me-2"></i>
                                    SAW (Ranking Alternatif)
                                </h6>
                                <ul class="list-unstyled">
                                    <li>🏆 Penerima: <strong><?= htmlspecialchars($hasil[0]['nama']) ?></strong> 
                                        (Skor: <strong><?= number_format($hasil[0]['skor_akhir'], 6) ?></strong>) 
                                        <span class="badge bg-warning text-dark">⭐</span></li>
                                    <li>📌 Cadangan 1: <strong><?= htmlspecialchars($hasil[1]['nama'] ?? '-') ?></strong></li>
                                    <li>📌 Cadangan 2: <strong><?= htmlspecialchars($hasil[2]['nama'] ?? '-') ?></strong></li>
                                    <li>✅ Skor tertinggi: <strong><?= number_format($max_skor, 6) ?></strong> 
                                        <span class="badge bg-warning text-dark">⭐</span></li>
                                    <li>⬇ Skor terendah: <strong><?= number_format($min_skor, 6) ?></strong> 
                                        <span class="badge bg-secondary">⬇</span></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mt-3 text-center">
                    <span class="badge-ahp">AHP</span> + 
                    <span class="badge-saw">SAW</span> = 
                    <strong>Keputusan Akhir: <?= htmlspecialchars($hasil[0]['nama']) ?></strong> 
                    terpilih sebagai penerima beasiswa! 🎉
                </div>
            </div>
        <?php else: ?>
            <div class="alert alert-warning">
                <i class="bi bi-exclamation-triangle-fill me-2"></i>
                Belum ada data perhitungan. Pastikan data alternatif, kriteria, dan nilai sudah tersedia.
            </div>
        <?php endif; ?>

        <div class="d-flex gap-2 mt-3">
            <a href="ahp_detail.php" class="btn btn-primary">
                <i class="bi bi-list-check"></i> Detail AHP
            </a>
            <a href="saw_detail.php" class="btn btn-success">
                <i class="bi bi-calculator"></i> Detail SAW
            </a>
            <a href="index.php" class="btn btn-secondary">
                <i class="bi bi-arrow-left"></i> Kembali
            </a>
        </div>
    </div>

</div>

<?php include '../../includes/footer.php'; ?>