<?php
// modul/perhitungan/ahp.php - HALAMAN AHP
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

require_once '../../config/database.php';

if(!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: ../login/');
    exit;
}

$page_title = 'Perhitungan AHP';

// ============================================
// AMBIL DATA UNTUK SIDEBAR
// ============================================
$result = $pdo->query("SELECT COUNT(*) FROM alternatif");
$row = $result->fetch_row();
$total_alt = $row[0] ?? 0;

$result = $pdo->query("SELECT COUNT(*) FROM kriteria");
$row = $result->fetch_row();
$total_krit = $row[0] ?? 0;

$result = $pdo->query("SELECT COUNT(*) FROM nilai_alternatif");
$row = $result->fetch_row();
$total_nilai = $row[0] ?? 0;

// ============================================
// 1. AMBIL DATA KRITERIA
// ============================================
$result = $pdo->query("SELECT * FROM kriteria ORDER BY id_kriteria");
$kriteria = $result->fetch_all(MYSQLI_ASSOC);

// ============================================
// 2. AMBIL MATRIKS PERBANDINGAN
// ============================================
$result = $pdo->query("SELECT * FROM matriks_perbandingan ORDER BY id_kriteria1, id_kriteria2");
$matriks_data = $result->fetch_all(MYSQLI_ASSOC);

// Buat matriks 2D
$matriks = [];
$n = count($kriteria);
for($i = 0; $i < $n; $i++) {
    for($j = 0; $j < $n; $j++) {
        $matriks[$i][$j] = 1;
    }
}

foreach($matriks_data as $m) {
    $i = $m['id_kriteria1'] - 1;
    $j = $m['id_kriteria2'] - 1;
    $matriks[$i][$j] = $m['nilai'];
    $matriks[$j][$i] = 1 / $m['nilai'];
}

// ============================================
// 3. NORMALISASI MATRIKS AHP
// ============================================
$normalized = [];
$jumlah_kolom = [];

// Hitung jumlah kolom
for($j = 0; $j < $n; $j++) {
    $sum = 0;
    for($i = 0; $i < $n; $i++) {
        $sum += $matriks[$i][$j];
    }
    $jumlah_kolom[$j] = $sum;
}

// Normalisasi
for($i = 0; $i < $n; $i++) {
    for($j = 0; $j < $n; $j++) {
        $normalized[$i][$j] = $matriks[$i][$j] / $jumlah_kolom[$j];
    }
}

// ============================================
// 4. HITUNG BOBOT (EIGEN VECTOR)
// ============================================
$bobot = [];
for($i = 0; $i < $n; $i++) {
    $sum = 0;
    for($j = 0; $j < $n; $j++) {
        $sum += $normalized[$i][$j];
    }
    $bobot[$i] = $sum / $n;
}

// ============================================
// 5. UJI KONSISTENSI
// ============================================
// Hitung λ max
$lambda_max = 0;
for($i = 0; $i < $n; $i++) {
    $sum = 0;
    for($j = 0; $j < $n; $j++) {
        $sum += $matriks[$i][$j] * $bobot[$j];
    }
    $lambda_max += $sum / $bobot[$i];
}
$lambda_max = $lambda_max / $n;

$ci = ($lambda_max - $n) / ($n - 1);

// RI untuk n=1-10
$ri_values = [0, 0, 0.58, 0.90, 1.12, 1.24, 1.32, 1.41, 1.45, 1.49];
$ri = $ri_values[$n] ?? 1.49;
$cr = $ci / $ri;

$konsisten = $cr < 0.10;

include '../../includes/header.php';
include '../../includes/sidebar.php';
?>

<style>
    .step-card{background:#fff;border-radius:16px;border:1px solid #f1f5f9;padding:20px;margin-bottom:20px;transition:all .3s ease}
    .step-card:hover{box-shadow:0 4px 20px rgba(0,0,0,0.05)}
    .step-number{display:inline-flex;align-items:center;justify-content:center;width:36px;height:36px;background:#011851;color:#fff;border-radius:50%;font-weight:700;font-size:.9rem;margin-right:12px}
    .step-title{font-weight:700;font-size:1.1rem;color:#011851}
    .table-ahp thead th{background:linear-gradient(135deg,#011851,#1a3a9a);color:#fff;font-weight:600;font-size:.75rem;text-transform:uppercase;letter-spacing:.5px;padding:10px 14px;border:none}
    .table-ahp tbody td{padding:10px 14px;vertical-align:middle;text-align:center}
    .table-ahp tbody tr:hover{background:#f8faff}
    .formula-box{background:#f0f4ff;border-radius:12px;padding:16px 20px;border-left:4px solid #011851;font-family:'Courier New',monospace;font-size:.9rem;margin:10px 0;overflow-x:auto}
    .stat-card{background:#fff;border-radius:16px;padding:18px 20px;border:1px solid #f1f5f9;transition:all .3s ease;height:100%}
    .stat-card:hover{transform:translateY(-4px);box-shadow:0 4px 20px rgba(0,0,0,0.05)}
    .result-card{background:linear-gradient(135deg,#011851,#1a3a9a);color:#fff;border-radius:16px;padding:20px;text-align:center;height:100%}
    .result-card .number{font-size:2rem;font-weight:800}
    .result-card .label{font-size:.8rem;opacity:.8}
    .badge-konsisten{background:#d1fae5;color:#065f46;padding:8px 20px;border-radius:20px;font-weight:600}
    .badge-tidak{background:#fee2e2;color:#991b1b;padding:8px 20px;border-radius:20px;font-weight:600}
    .table-responsive-custom{overflow-x:auto;-webkit-overflow-scrolling:touch;width:100%;display:block}
    .table-responsive-custom table{width:100%;min-width:600px;margin-bottom:0;background:#fff;border-radius:12px;overflow:hidden}
</style>

<div class="app-content">

    <!-- Header -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold mb-1">
                <i class="bi bi-calculator-fill text-primary me-2"></i>
                Perhitungan AHP (Analytic Hierarchy Process)
            </h4>
            <p class="text-muted small mb-0">Menghitung bobot kriteria menggunakan metode perbandingan berpasangan</p>
        </div>
        <div class="d-flex gap-2">
            <a href="index.php" class="btn btn-outline-secondary btn-sm">
                <i class="bi bi-arrow-left"></i> Kembali
            </a>
            <a href="saw.php" class="btn btn-primary btn-sm">
                <i class="bi bi-arrow-right"></i> Lihat SAW
            </a>
        </div>
    </div>

    <!-- Stats -->
    <div class="row g-3 mb-4">
        <div class="col-md-3 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h2 class="mb-0 fw-bold text-primary"><?= $total_alt ?></h2>
                        <small class="text-muted">Alternatif</small>
                    </div>
                    <i class="bi bi-people-fill text-primary fs-1 opacity-25"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h2 class="mb-0 fw-bold text-success"><?= $total_krit ?></h2>
                        <small class="text-muted">Kriteria</small>
                    </div>
                    <i class="bi bi-list-check text-success fs-1 opacity-25"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h2 class="mb-0 fw-bold text-info"><?= $total_nilai ?></h2>
                        <small class="text-muted">Nilai</small>
                    </div>
                    <i class="bi bi-table text-info fs-1 opacity-25"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h2 class="mb-0 fw-bold text-warning"><?= $n ?></h2>
                        <small class="text-muted">Jumlah Kriteria</small>
                    </div>
                    <i class="bi bi-list text-warning fs-1 opacity-25"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- STEP 1: Matriks Perbandingan -->
    <div class="step-card">
        <div class="d-flex align-items-center mb-3">
            <span class="step-number">1</span>
            <span class="step-title">Matriks Perbandingan Berpasangan</span>
        </div>

        <div class="formula-box mb-3">
            <strong>Skala Perbandingan (Saaty):</strong><br>
            1 = Sama penting | 3 = Sedikit lebih penting | 5 = Lebih penting | 7 = Sangat penting | 9 = Mutlak lebih penting
        </div>

        <div class="table-responsive-custom">
            <table class="table table-bordered table-ahp">
                <thead>
                    <tr>
                        <th>Kriteria</th>
                        <?php foreach($kriteria as $k): ?>
                            <th><?= $k['kode_kriteria'] ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php for($i = 0; $i < $n; $i++): ?>
                        <tr>
                            <td><strong><?= $kriteria[$i]['kode_kriteria'] ?></strong></td>
                            <?php for($j = 0; $j < $n; $j++): ?>
                                <td>
                                    <?php 
                                    $val = $matriks[$i][$j];
                                    if($i == $j) {
                                        echo '<span class="badge bg-secondary">1</span>';
                                    } elseif($i < $j) {
                                        echo '<span class="fw-bold text-primary">' . number_format($val, 2) . '</span>';
                                    } else {
                                        echo '<span class="text-muted">1/' . number_format(1/$val, 2) . '</span>';
                                    }
                                    ?>
                                </td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endfor; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- STEP 2: Normalisasi Matriks -->
    <div class="step-card">
        <div class="d-flex align-items-center mb-3">
            <span class="step-number">2</span>
            <span class="step-title">Normalisasi Matriks</span>
        </div>

        <div class="formula-box mb-3">
            <strong>Rumus Normalisasi:</strong> a<sub>ij</sub> = a<sub>ij</sub> / Σ(a<sub>ij</sub>)
        </div>

        <div class="table-responsive-custom">
            <table class="table table-bordered table-ahp">
                <thead>
                    <tr>
                        <th>Kriteria</th>
                        <?php foreach($kriteria as $k): ?>
                            <th><?= $k['kode_kriteria'] ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php for($i = 0; $i < $n; $i++): ?>
                        <tr>
                            <td><strong><?= $kriteria[$i]['kode_kriteria'] ?></strong></td>
                            <?php for($j = 0; $j < $n; $j++): ?>
                                <td><?= number_format($normalized[$i][$j], 4) ?></td>
                            <?php endfor; ?>
                        </tr>
                    <?php endfor; ?>
                    <tr style="background:#f0f4ff;font-weight:700;">
                        <td><strong>Jumlah</strong></td>
                        <?php for($j = 0; $j < $n; $j++): ?>
                            <td><?= number_format($jumlah_kolom[$j], 4) ?></td>
                        <?php endfor; ?>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <!-- STEP 3: Bobot Kriteria -->
    <div class="step-card">
        <div class="d-flex align-items-center mb-3">
            <span class="step-number">3</span>
            <span class="step-title">Bobot Kriteria (Eigen Vector)</span>
        </div>

        <div class="formula-box mb-3">
            <strong>Rumus Bobot:</strong> W<sub>i</sub> = Σ(a<sub>ij</sub>) / n
        </div>

        <div class="row g-4">
            <?php foreach($kriteria as $i => $k): ?>
                <div class="col-md-3 col-6">
                    <div class="result-card">
                        <div class="label"><?= $k['kode_kriteria'] ?></div>
                        <div class="number"><?= number_format($bobot[$i] * 100, 1) ?>%</div>
                        <div class="label"><?= $k['nama_kriteria'] ?></div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- STEP 4: Uji Konsistensi -->
    <div class="step-card">
        <div class="d-flex align-items-center mb-3">
            <span class="step-number">4</span>
            <span class="step-title">Uji Konsistensi</span>
        </div>

        <div class="row g-4">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h6 class="fw-bold">Hasil Uji</h6>
                        <table class="table table-sm">
                            <tr>
                                <td>λ (Lambda) Max</td>
                                <td><strong><?= number_format($lambda_max, 4) ?></strong></td>
                            </tr>
                            <tr>
                                <td>n (Jumlah Kriteria)</td>
                                <td><strong><?= $n ?></strong></td>
                            </tr>
                            <tr>
                                <td>CI (Consistency Index)</td>
                                <td><strong><?= number_format($ci, 4) ?></strong></td>
                            </tr>
                            <tr>
                                <td>RI (Random Index)</td>
                                <td><strong><?= number_format($ri, 4) ?></strong></td>
                            </tr>
                            <tr>
                                <td>CR (Consistency Ratio)</td>
                                <td><strong><?= number_format($cr, 4) ?></strong></td>
                            </tr>
                            <tr>
                                <td>Status</td>
                                <td>
                                    <?php if($konsisten): ?>
                                        <span class="badge-konsisten">✅ Konsisten (CR ≤ 0.10)</span>
                                    <?php else: ?>
                                        <span class="badge-tidak">❌ Tidak Konsisten (CR > 0.10)</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h6 class="fw-bold">Rumus Uji Konsistensi</h6>
                        <div class="formula-box">
                            <strong>CI = (λmax - n) / (n - 1)</strong><br>
                            CI = (<?= number_format($lambda_max, 4) ?> - <?= $n ?>) / (<?= $n ?> - 1)<br>
                            CI = <strong><?= number_format($ci, 4) ?></strong>
                            <br><br>
                            <strong>CR = CI / RI</strong><br>
                            CR = <?= number_format($ci, 4) ?> / <?= number_format($ri, 4) ?><br>
                            CR = <strong><?= number_format($cr, 4) ?></strong>
                            <br><br>
                            <?php if($konsisten): ?>
                                <span class="badge-konsisten">✅ Konsisten (CR ≤ 0.10)</span>
                            <?php else: ?>
                                <span class="badge-tidak">❌ Tidak Konsisten (CR > 0.10)</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<?php include '../../includes/footer.php'; ?>