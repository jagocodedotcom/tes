<?php
require_once '../../config/database.php';

if(!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: ../login/');
    exit;
}

$id = $_GET['id'] ?? 0;

try {
    $stmt = $pdo->prepare("DELETE FROM nilai_alternatif WHERE id_nilai = ?");
    $stmt->execute([$id]);
    $_SESSION['success'] = 'Nilai berhasil dihapus!';
} catch(PDOException $e) {
    $_SESSION['error'] = 'Gagal hapus: ' . $e->getMessage();
}

header('Location: index.php');
exit;
?>