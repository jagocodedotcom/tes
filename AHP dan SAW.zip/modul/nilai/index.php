<?php
// modul/nilai/index.php - FINAL VERSION
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

require_once '../../config/database.php';

if(!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: ../login/');
    exit;
}

$page_title = 'Data Nilai';

// ============================================
// AMBIL DATA UNTUK SIDEBAR
// ============================================

// Total Alternatif
$result = $pdo->query("SELECT COUNT(*) FROM alternatif");
$row = $result->fetch_row();
$total_alt = $row[0] ?? 0;

// Total Kriteria
$result = $pdo->query("SELECT COUNT(*) FROM kriteria");
$row = $result->fetch_row();
$total_krit = $row[0] ?? 0;

// Total Nilai
$result = $pdo->query("SELECT COUNT(*) FROM nilai_alternatif");
$row = $result->fetch_row();
$total_nilai = $row[0] ?? 0;

// ============================================
// FILTER
// ============================================
$filter_alt = $_GET['alt'] ?? 0;

// Nama alternatif untuk judul
$nama_alternatif = '';
if($filter_alt > 0) {
    $stmt = $pdo->prepare("SELECT nama FROM alternatif WHERE id_alternatif = ?");
    $stmt->execute([$filter_alt]);
    $result = $stmt->get_result();
    $alt_data = $result->fetch_assoc();
    $nama_alternatif = $alt_data ? $alt_data['nama'] : '';
}

// ============================================
// AMBIL DATA NILAI
// ============================================
$sql = "
    SELECT n.*, a.nama as nama_alternatif, a.nim, k.kode_kriteria, k.nama_kriteria 
    FROM nilai_alternatif n
    JOIN alternatif a ON n.id_alternatif = a.id_alternatif
    JOIN kriteria k ON n.id_kriteria = k.id_kriteria
";

if($filter_alt > 0) {
    $sql .= " WHERE n.id_alternatif = $filter_alt";
}

$sql .= " ORDER BY a.nama, k.kode_kriteria";

$result = $pdo->query($sql);

if (!$result) {
    die("Error query: " . $pdo->errorInfo()[2]);
}

$nilai = $result->fetch_all(MYSQLI_ASSOC);

// ============================================
// AMBIL DAFTAR ALTERNATIF UNTUK FILTER
// ============================================
$result = $pdo->query("SELECT * FROM alternatif ORDER BY nama");
$alternatif_list = $result->fetch_all(MYSQLI_ASSOC);

include '../../includes/header.php';
include '../../includes/sidebar.php';
?>

<style>
    .stat-card {
        background: #ffffff;
        border-radius: 16px;
        padding: 18px 20px;
        border: 1px solid #f1f5f9;
        transition: all 0.3s ease;
        height: 100%;
    }

    .stat-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
    }

    .table-nilai thead th {
        background: linear-gradient(135deg, #011851, #1a3a9a);
        color: white;
        font-weight: 600;
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        padding: 10px 14px;
        border: none;
    }

    .table-nilai tbody td {
        padding: 10px 14px;
        vertical-align: middle;
    }

    .table-nilai tbody tr:hover {
        background: #f8faff;
    }

    .btn-action {
        width: 34px;
        height: 34px;
        border-radius: 10px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        transition: all 0.2s ease;
        border: none;
    }

    .btn-action:hover {
        transform: scale(1.1);
    }

    .btn-action.edit {
        background: #fef3c7;
        color: #d97706;
    }

    .btn-action.delete {
        background: #fee2e2;
        color: #dc2626;
    }

    .filter-card {
        background: #ffffff;
        border-radius: 16px;
        border: 1px solid #f1f5f9;
        padding: 20px;
    }

    .filter-card .form-select {
        border-radius: 12px;
        padding: 10px 16px;
        border: 1px solid #e5e7eb;
        width: 100%;
    }

    .filter-card .form-select:focus {
        border-color: #011851;
        box-shadow: 0 0 0 3px rgba(1, 24, 81, 0.1);
        outline: none;
    }

    .filter-card .form-label {
        font-weight: 600;
        font-size: 0.9rem;
        color: #374151;
    }

    .card-custom {
        background: #ffffff;
        border-radius: 16px;
        border: 1px solid #f1f5f9;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04);
        overflow: hidden;
        width: 100%;
    }

    .card-custom .card-body {
        padding: 20px;
        overflow-x: auto;
    }

    .table-responsive-custom {
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
        width: 100%;
        display: block;
    }

    .table-responsive-custom table {
        width: 100%;
        min-width: 600px;
        margin-bottom: 0;
        background: white;
        border-radius: 12px;
        overflow: hidden;
    }

    .empty-state {
        text-align: center;
        padding: 40px 20px;
    }

    .empty-state i {
        font-size: 3rem;
        color: #d1d5db;
        margin-bottom: 16px;
    }

    .badge-status {
        padding: 4px 12px;
        border-radius: 20px;
        font-weight: 600;
        font-size: 0.7rem;
    }

    @media (max-width: 576px) {
        .card-custom .card-body {
            padding: 12px;
        }
    }
</style>

<div class="app-content">

    <!-- Header -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold mb-1">
                <i class="bi bi-table text-primary me-2"></i>
                Data Nilai
                <?php if($nama_alternatif): ?>
                    <span class="badge bg-primary fs-6"><?= htmlspecialchars($nama_alternatif) ?></span>
                <?php endif; ?>
            </h4>
            <p class="text-muted small mb-0">Kelola data nilai setiap alternatif</p>
        </div>
        <a href="tambah.php" class="btn btn-primary btn-sm">
            <i class="bi bi-plus-circle"></i> Tambah Nilai
        </a>
    </div>

    <!-- Alert -->
    <?php if(isset($_SESSION['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="bi bi-check-circle-fill me-2"></i>
            <?= $_SESSION['success'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>

    <?php if(isset($_SESSION['error'])): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <?= $_SESSION['error'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <!-- Stats -->
    <div class="row g-3 mb-4">
        <div class="col-md-3 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h2 class="mb-0 fw-bold text-primary"><?= $total_alt ?></h2>
                        <small class="text-muted">Alternatif</small>
                    </div>
                    <i class="bi bi-people-fill text-primary fs-1 opacity-25"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h2 class="mb-0 fw-bold text-success"><?= $total_krit ?></h2>
                        <small class="text-muted">Kriteria</small>
                    </div>
                    <i class="bi bi-list-check text-success fs-1 opacity-25"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h2 class="mb-0 fw-bold text-info"><?= $total_nilai ?></h2>
                        <small class="text-muted">Total Nilai</small>
                    </div>
                    <i class="bi bi-table text-info fs-1 opacity-25"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h2 class="mb-0 fw-bold text-warning"><?= count($nilai) ?></h2>
                        <small class="text-muted">Ditampilkan</small>
                    </div>
                    <i class="bi bi-filter text-warning fs-1 opacity-25"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Filter -->
    <div class="filter-card mb-4">
        <form method="GET" class="row g-3 align-items-end">
            <div class="col-md-8">
                <label class="form-label">
                    <i class="bi bi-funnel me-1"></i> Filter Berdasarkan Alternatif
                </label>
                <select name="alt" class="form-select" onchange="this.form.submit()">
                    <option value="0">-- Semua Alternatif --</option>
                    <?php foreach($alternatif_list as $alt): ?>
                        <option value="<?= $alt['id_alternatif'] ?>" <?= $filter_alt == $alt['id_alternatif'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($alt['nama']) ?> (<?= htmlspecialchars($alt['nim']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <a href="index.php" class="btn btn-secondary w-100">
                    <i class="bi bi-arrow-counterclockwise"></i> Reset Filter
                </a>
            </div>
        </form>
    </div>

    <!-- Table -->
    <div class="card card-custom">
        <div class="card-body">
            <div class="table-responsive-custom">
                <table class="table table-nilai">
                    <thead>
                        <tr>
                            <th style="width: 50px;">#</th>
                            <th>Alternatif</th>
                            <th>NIM</th>
                            <th>Kriteria</th>
                            <th class="text-center">Nilai</th>
                            <th class="text-center" style="width: 120px;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(!empty($nilai)): ?>
                            <?php $no = 1; foreach($nilai as $row): ?>
                                <tr>
                                    <td class="fw-bold text-muted"><?= $no++ ?></td>
                                    <td>
                                        <div class="fw-semibold"><?= htmlspecialchars($row['nama_alternatif']) ?></div>
                                    </td>
                                    <td><?= htmlspecialchars($row['nim']) ?></td>
                                    <td>
                                        <span class="badge bg-primary"><?= htmlspecialchars($row['kode_kriteria']) ?></span>
                                        <?= htmlspecialchars($row['nama_kriteria']) ?>
                                    </td>
                                    <td class="text-center">
                                        <span class="fw-bold fs-5 text-primary"><?= number_format($row['nilai'], 2) ?></span>
                                    </td>
                                    <td>
                                        <div class="d-flex gap-1 justify-content-center">
                                            <a href="edit.php?id=<?= $row['id_nilai'] ?>" class="btn-action edit" title="Edit">
                                                <i class="bi bi-pencil"></i>
                                            </a>
                                            <a href="hapus.php?id=<?= $row['id_nilai'] ?>" class="btn-action delete" title="Hapus" onclick="return confirm('Yakin ingin menghapus data ini?')">
                                                <i class="bi bi-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center py-4">
                                    <div class="empty-state">
                                        <i class="bi bi-table"></i>
                                        <h5>Belum Ada Data Nilai</h5>
                                        <p class="text-muted">Silakan tambahkan data nilai untuk alternatif</p>
                                        <a href="tambah.php" class="btn btn-primary btn-sm">
                                            <i class="bi bi-plus-circle"></i> Tambah Nilai
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <!-- Footer -->
        <div class="card-footer bg-white border-0 pt-3 pb-3">
            <div class="d-flex justify-content-between align-items-center">
                <span class="text-muted small">
                    <i class="bi bi-database me-1"></i>
                    Total <strong><?= count($nilai) ?></strong> data nilai
                </span>
                <span class="text-muted small">
                    <i class="bi bi-clock me-1"></i>
                    Terakhir diupdate: <?= date('H:i:s') ?>
                </span>
            </div>
        </div>
    </div>

</div> <!-- .app-content -->

<?php include '../../includes/footer.php'; ?>