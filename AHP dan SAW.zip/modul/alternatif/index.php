<?php
// modul/alternatif/index.php - FIXED VERSION
require_once '../../config/database.php';

if(!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: ../login/');
    exit;
}

$page_title = 'Data Alternatif';

// ============================================
// PERBAIKAN: GANTI SEMUA fetchColumn() dengan fetch_row()
// ============================================

// Total Alternatif
$result = $pdo->query("SELECT COUNT(*) FROM alternatif");
$row = $result->fetch_row();
$total_alt = $row[0] ?? 0;

// Total Kriteria
$result = $pdo->query("SELECT COUNT(*) FROM kriteria");
$row = $result->fetch_row();
$total_krit = $row[0] ?? 0;

// Total Nilai
$result = $pdo->query("SELECT COUNT(*) FROM nilai_alternatif");
$row = $result->fetch_row();
$total_nilai = $row[0] ?? 0;

// Ambil data alternatif
$result = $pdo->query("
    SELECT a.*, 
           COUNT(n.id_nilai) as jumlah_nilai,
           AVG(n.nilai) as rata_nilai
    FROM alternatif a 
    LEFT JOIN nilai_alternatif n ON a.id_alternatif = n.id_alternatif 
    GROUP BY a.id_alternatif 
    ORDER BY a.id_alternatif DESC
");
$alternatif = $result->fetch_all(MYSQLI_ASSOC);

include '../../includes/header.php';
include '../../includes/sidebar.php';
?>

<div class="app-content">

    <!-- Header -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold mb-1">
                <i class="bi bi-people-fill text-primary me-2"></i>
                Data Alternatif
            </h4>
            <p class="text-muted small mb-0">Kelola data calon penerima beasiswa</p>
        </div>
        <a href="tambah.php" class="btn btn-primary btn-sm">
            <i class="bi bi-plus-circle"></i> Tambah Alternatif
        </a>
    </div>

    <!-- Alert -->
    <?php if(isset($_SESSION['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="bi bi-check-circle-fill me-2"></i>
            <?= $_SESSION['success'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>

    <?php if(isset($_SESSION['error'])): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <?= $_SESSION['error'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <!-- Stats -->
    <div class="row g-3 mb-4">
        <div class="col-md-3 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h2 class="mb-0 fw-bold text-primary"><?= $total_alt ?></h2>
                        <small class="text-muted">Alternatif</small>
                    </div>
                    <i class="bi bi-people-fill text-primary fs-1 opacity-25"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h2 class="mb-0 fw-bold text-success"><?= $total_krit ?></h2>
                        <small class="text-muted">Kriteria</small>
                    </div>
                    <i class="bi bi-list-check text-success fs-1 opacity-25"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h2 class="mb-0 fw-bold text-info"><?= $total_nilai ?></h2>
                        <small class="text-muted">Nilai</small>
                    </div>
                    <i class="bi bi-table text-info fs-1 opacity-25"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h2 class="mb-0 fw-bold text-warning"><?= count($alternatif) ?></h2>
                        <small class="text-muted">Ditampilkan</small>
                    </div>
                    <i class="bi bi-eye text-warning fs-1 opacity-25"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Search -->
    <div class="card card-custom mb-4">
        <div class="card-body">
            <div class="row g-3 align-items-center">
                <div class="col-md-6">
                    <div class="search-box">
                        <i class="bi bi-search"></i>
                        <input type="text" id="searchInput" class="form-control" placeholder="Cari nama, NIM, atau jurusan...">
                    </div>
                </div>
                <div class="col-md-6 text-md-end">
                    <span class="text-muted small">
                        <i class="bi bi-database me-1"></i>
                        Menampilkan <strong id="visibleCount"><?= count($alternatif) ?></strong> data
                    </span>
                </div>
            </div>
        </div>
    </div>

    <!-- Table -->
    <div class="card card-custom">
        <div class="card-body">
            <div class="table-responsive-custom">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nama</th>
                            <th>NIM</th>
                            <th>Jurusan</th>
                            <th class="text-center">Nilai</th>
                            <th class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody id="tableBody">
                        <?php if(!empty($alternatif)): ?>
                            <?php $no = 1; foreach($alternatif as $row): ?>
                                <tr data-search="<?= strtolower($row['nama'] . ' ' . $row['nim'] . ' ' . $row['jurusan']) ?>">
                                    <td><?= $no++ ?></td>
                                    <td><?= htmlspecialchars($row['nama']) ?></td>
                                    <td><?= htmlspecialchars($row['nim']) ?></td>
                                    <td><?= htmlspecialchars($row['jurusan']) ?></td>
                                    <td class="text-center">
                                        <span class="badge bg-primary">
                                            <?= $row['jumlah_nilai'] ?> / <?= $total_krit ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="d-flex gap-1">
                                            <a href="../nilai/index.php?alt=<?= $row['id_alternatif'] ?>" class="btn btn-info btn-sm" title="Lihat Nilai">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                            <a href="edit.php?id=<?= $row['id_alternatif'] ?>" class="btn btn-warning btn-sm" title="Edit">
                                                <i class="bi bi-pencil"></i>
                                            </a>
                                            <a href="hapus.php?id=<?= $row['id_alternatif'] ?>" class="btn btn-danger btn-sm" title="Hapus" onclick="return confirm('Yakin ingin menghapus data ini?')">
                                                <i class="bi bi-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center py-4">
                                    <i class="bi bi-inbox display-4 d-block text-muted"></i>
                                    <p class="text-muted">Belum ada data alternatif</p>
                                    <a href="tambah.php" class="btn btn-primary btn-sm">
                                        <i class="bi bi-plus-circle"></i> Tambah
                                    </a>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div> <!-- .app-content -->

<script>
document.getElementById('searchInput')?.addEventListener('keyup', function() {
    const query = this.value.toLowerCase().trim();
    const rows = document.querySelectorAll('#tableBody tr[data-search]');
    let visible = 0;

    rows.forEach(function(row) {
        const searchData = row.getAttribute('data-search') || '';
        const match = searchData.includes(query);
        row.style.display = match ? '' : 'none';
        if (match) visible++;
    });

    document.getElementById('visibleCount').textContent = visible;
});
</script>

<?php include '../../includes/footer.php'; ?>