<?php
// modul/alternatif/edit.php - FIXED VERSION
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

require_once '../../config/database.php';

if(!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: ../login/');
    exit;
}

$id = $_GET['id'] ?? 0;

// Ambil data alternatif
$stmt = $pdo->prepare("SELECT * FROM alternatif WHERE id_alternatif = ?");
$stmt->execute([$id]);
$result = $stmt->get_result();
$data = $result->fetch_assoc();

if(!$data) {
    $_SESSION['error'] = 'Data alternatif tidak ditemukan!';
    header('Location: index.php');
    exit;
}

$page_title = 'Edit Alternatif';

// ============================================
// AMBIL DATA UNTUK SIDEBAR
// ============================================

// Total Alternatif
$result = $pdo->query("SELECT COUNT(*) FROM alternatif");
$row = $result->fetch_row();
$total_alt = $row[0] ?? 0;

// Total Kriteria
$result = $pdo->query("SELECT COUNT(*) FROM kriteria");
$row = $result->fetch_row();
$total_krit = $row[0] ?? 0;

// Total Nilai
$result = $pdo->query("SELECT COUNT(*) FROM nilai_alternatif");
$row = $result->fetch_row();
$total_nilai = $row[0] ?? 0;

include '../../includes/header.php';
include '../../includes/sidebar.php';

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = trim($_POST['nama']);
    $nim = trim($_POST['nim']);
    $jurusan = trim($_POST['jurusan']);

    try {
        $stmt = $pdo->prepare("UPDATE alternatif SET nama=?, nim=?, jurusan=? WHERE id_alternatif=?");
        $stmt->execute([$nama, $nim, $jurusan, $id]);
        $_SESSION['success'] = 'Data alternatif berhasil diupdate!';
        header('Location: index.php');
        exit;
    } catch(Exception $e) {
        $error = 'Gagal update: ' . $e->getMessage();
    }
}
?>

<style>
    .form-card {
        max-width: 700px;
    }

    .form-card .card {
        border-radius: 16px;
        border: none;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.04);
    }

    .form-card .form-control {
        border-radius: 12px;
        padding: 12px 16px;
        border: 1px solid #e5e7eb;
        transition: all 0.3s ease;
    }

    .form-card .form-control:focus {
        border-color: #011851;
        box-shadow: 0 0 0 4px rgba(1, 24, 81, 0.08);
    }

    .form-card .form-label {
        font-weight: 600;
        font-size: 0.9rem;
        color: #374151;
    }

    .btn-submit {
        padding: 12px 32px;
        border-radius: 12px;
        font-weight: 600;
        background: linear-gradient(135deg, #f59e0b, #d97706);
        border: none;
        color: white;
        transition: all 0.3s ease;
    }

    .btn-submit:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(245, 158, 11, 0.3);
        color: white;
    }

    .stat-mini {
        background: white;
        border-radius: 12px;
        padding: 16px 20px;
        border: 1px solid #f1f5f9;
        transition: all 0.3s ease;
    }

    .stat-mini:hover {
        transform: translateY(-4px);
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.05);
    }

    .stat-mini .number {
        font-size: 1.8rem;
        font-weight: 800;
        letter-spacing: -1px;
        color: #011851;
    }

    .stat-mini .label {
        font-size: 0.8rem;
        color: #6b7280;
        font-weight: 500;
    }

    .info-box {
        background: #f0f4ff;
        border-radius: 12px;
        padding: 12px 16px;
        border-left: 4px solid #011851;
    }
</style>

<div class="app-content">

    <!-- Header -->
    <div class="d-flex align-items-center mb-4">
        <a href="index.php" class="btn btn-outline-secondary btn-sm me-3">
            <i class="bi bi-arrow-left"></i> Kembali
        </a>
        <h4 class="fw-bold mb-0">
            <i class="bi bi-pencil-square text-warning me-2"></i>
            Edit Alternatif
        </h4>
    </div>

    <!-- Alert -->
    <?php if(isset($error)): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <?= $error ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Info -->
    <div class="info-box mb-4">
        <div class="row g-3">
            <div class="col-md-4">
                <div class="text-muted small">ID Alternatif</div>
                <div class="fw-bold">#<?= $data['id_alternatif'] ?></div>
            </div>
            <div class="col-md-4">
                <div class="text-muted small">Dibuat</div>
                <div class="fw-bold"><?= date('d/m/Y H:i', strtotime($data['created_at'])) ?></div>
            </div>
            <div class="col-md-4">
                <div class="text-muted small">Status</div>
                <div class="fw-bold">
                    <span class="badge bg-warning text-dark">
                        <i class="bi bi-pencil"></i> Sedang Diedit
                    </span>
                </div>
            </div>
        </div>
    </div>

    <!-- Stats -->
    <div class="row g-3 mb-4">
        <div class="col-md-3 col-6">
            <div class="stat-mini">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="number"><?= $total_alt ?></div>
                        <div class="label">Total Alternatif</div>
                    </div>
                    <i class="bi bi-people-fill text-primary fs-2 opacity-25"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-mini">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="number"><?= $total_krit ?></div>
                        <div class="label">Total Kriteria</div>
                    </div>
                    <i class="bi bi-list-check text-success fs-2 opacity-25"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-mini">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="number"><?= $total_nilai ?></div>
                        <div class="label">Total Nilai</div>
                    </div>
                    <i class="bi bi-table text-info fs-2 opacity-25"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-mini">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="number">1</div>
                        <div class="label">Diedit</div>
                    </div>
                    <i class="bi bi-pencil text-warning fs-2 opacity-25"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Form -->
    <div class="form-card mx-auto">
        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="bi bi-person me-1"></i> Nama Lengkap
                        </label>
                        <input type="text" name="nama" class="form-control" value="<?= htmlspecialchars($data['nama']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="bi bi-card-text me-1"></i> NIM
                        </label>
                        <input type="text" name="nim" class="form-control" value="<?= htmlspecialchars($data['nim']) ?>" required>
                    </div>
                    <div class="mb-4">
                        <label class="form-label">
                            <i class="bi bi-mortarboard me-1"></i> Jurusan
                        </label>
                        <input type="text" name="jurusan" class="form-control" value="<?= htmlspecialchars($data['jurusan']) ?>" required>
                    </div>
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn-submit flex-grow-1">
                            <i class="bi bi-save me-2"></i> Update Data
                        </button>
                        <a href="index.php" class="btn btn-secondary" style="border-radius: 12px;">
                            <i class="bi bi-x-lg"></i>
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>

</div> <!-- .app-content -->

<?php include '../../includes/footer.php'; ?>