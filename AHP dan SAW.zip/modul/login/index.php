<?php
// modul/login/index.php - PREMIUM VERSION
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

require_once '../../config/database.php';

// Jika sudah login, redirect ke dashboard
if(isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    header('Location: ' . BASE_URL . '/modul/dashboard/');
    exit;
}

$page_title = 'Login';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SPK Beasiswa · Login</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <style>
        /* ============================================
           GLOBAL STYLES
           ============================================ */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #f0f4ff;
            padding: 20px;
            overflow-x: hidden;
        }

        /* ============================================
           BACKGROUND ANIMATION
           ============================================ */
        .bg-animation {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: 0;
            overflow: hidden;
            background: linear-gradient(135deg, #011851 0%, #1a3a9a 50%, #2d4ab8 100%);
        }

        .bg-animation .circle {
            position: absolute;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.03);
            animation: float 20s ease-in-out infinite;
        }

        .bg-animation .circle:nth-child(1) {
            width: 600px;
            height: 600px;
            top: -200px;
            right: -100px;
            animation-delay: 0s;
        }

        .bg-animation .circle:nth-child(2) {
            width: 400px;
            height: 400px;
            bottom: -100px;
            left: -50px;
            animation-delay: -5s;
        }

        .bg-animation .circle:nth-child(3) {
            width: 300px;
            height: 300px;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            animation-delay: -10s;
        }

        .bg-animation .circle:nth-child(4) {
            width: 150px;
            height: 150px;
            top: 20%;
            right: 20%;
            animation-delay: -3s;
            background: rgba(255, 215, 0, 0.05);
        }

        @keyframes float {
            0%, 100% { transform: translate(0, 0) scale(1); }
            25% { transform: translate(30px, -30px) scale(1.05); }
            50% { transform: translate(-20px, 20px) scale(0.95); }
            75% { transform: translate(20px, 30px) scale(1.02); }
        }

        /* ============================================
           PARTICLES
           ============================================ */
        .particles {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: 1;
            pointer-events: none;
        }

        .particle {
            position: absolute;
            width: 4px;
            height: 4px;
            background: rgba(255, 255, 255, 0.15);
            border-radius: 50%;
            animation: particleFloat 15s ease-in-out infinite;
        }

        .particle:nth-child(1) { left: 10%; animation-delay: 0s; }
        .particle:nth-child(2) { left: 20%; animation-delay: -2s; width: 6px; height: 6px; }
        .particle:nth-child(3) { left: 30%; animation-delay: -4s; }
        .particle:nth-child(4) { left: 40%; animation-delay: -6s; width: 8px; height: 8px; }
        .particle:nth-child(5) { left: 50%; animation-delay: -8s; }
        .particle:nth-child(6) { left: 60%; animation-delay: -10s; width: 5px; height: 5px; }
        .particle:nth-child(7) { left: 70%; animation-delay: -12s; }
        .particle:nth-child(8) { left: 80%; animation-delay: -14s; width: 7px; height: 7px; }
        .particle:nth-child(9) { left: 90%; animation-delay: -1s; }
        .particle:nth-child(10) { left: 95%; animation-delay: -7s; width: 3px; height: 3px; }

        @keyframes particleFloat {
            0%, 100% { transform: translateY(0) scale(1); opacity: 0.3; }
            50% { transform: translateY(-100vh) scale(0.5); opacity: 0.8; }
        }

        /* ============================================
           LOGIN CARD
           ============================================ */
        .login-wrapper {
            position: relative;
            z-index: 2;
            width: 100%;
            max-width: 440px;
            animation: slideUp 0.8s ease;
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(40px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .login-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: 24px;
            padding: 40px 36px;
            box-shadow: 0 20px 60px rgba(1, 24, 81, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: all 0.3s ease;
        }

        .login-card:hover {
            box-shadow: 0 30px 80px rgba(1, 24, 81, 0.25);
            transform: translateY(-4px);
        }

        /* Brand */
        .brand {
            text-align: center;
            margin-bottom: 32px;
        }

        .brand-icon {
            width: 72px;
            height: 72px;
            background: linear-gradient(135deg, #011851, #1a3a9a);
            border-radius: 20px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 2.2rem;
            color: white;
            box-shadow: 0 8px 30px rgba(1, 24, 81, 0.25);
            margin-bottom: 16px;
            transition: all 0.3s ease;
            animation: pulse-icon 3s ease-in-out infinite;
        }

        @keyframes pulse-icon {
            0%, 100% { box-shadow: 0 8px 30px rgba(1, 24, 81, 0.25); }
            50% { box-shadow: 0 8px 50px rgba(1, 24, 81, 0.4); }
        }

        .brand h1 {
            font-weight: 900;
            font-size: 1.8rem;
            color: #011851;
            letter-spacing: -0.5px;
            margin: 0;
        }

        .brand h1 span {
            color: #1a3a9a;
        }

        .brand p {
            color: #6b7280;
            font-size: 0.9rem;
            margin: 4px 0 0;
            font-weight: 400;
        }

        /* Form */
        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            font-weight: 600;
            font-size: 0.85rem;
            color: #374151;
            margin-bottom: 6px;
            display: block;
        }

        .form-group .input-group-custom {
            position: relative;
        }

        .form-group .input-group-custom .input-icon {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: #9ca3af;
            font-size: 1.1rem;
            transition: all 0.3s ease;
            pointer-events: none;
        }

        .form-group .input-group-custom .form-control {
            width: 100%;
            padding: 14px 16px 14px 46px;
            border: 2px solid #e5e7eb;
            border-radius: 14px;
            font-size: 0.95rem;
            font-weight: 500;
            transition: all 0.3s ease;
            background: #f9fafb;
            color: #1f2937;
        }

        .form-group .input-group-custom .form-control:focus {
            border-color: #011851;
            box-shadow: 0 0 0 4px rgba(1, 24, 81, 0.08);
            background: #ffffff;
            outline: none;
        }

        .form-group .input-group-custom .form-control:focus + .input-icon {
            color: #011851;
        }

        .form-group .input-group-custom .form-control::placeholder {
            color: #9ca3af;
            font-weight: 400;
        }

        /* Toggle Password */
        .toggle-password {
            position: absolute;
            right: 14px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: #9ca3af;
            cursor: pointer;
            font-size: 1.1rem;
            transition: all 0.3s ease;
            padding: 0;
            z-index: 5;
        }

        .toggle-password:hover {
            color: #011851;
        }

        /* Button */
        .btn-login {
            width: 100%;
            padding: 14px;
            border: none;
            border-radius: 14px;
            font-weight: 700;
            font-size: 1rem;
            background: linear-gradient(135deg, #011851, #1a3a9a);
            color: white;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            cursor: pointer;
        }

        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 30px rgba(1, 24, 81, 0.3);
        }

        .btn-login:active {
            transform: translateY(0);
        }

        .btn-login i {
            margin-right: 8px;
        }

        /* Footer */
        .login-footer {
            text-align: center;
            margin-top: 24px;
            padding-top: 20px;
            border-top: 1px solid #f1f5f9;
        }

        .login-footer .text-muted {
            font-size: 0.8rem;
            color: #9ca3af;
        }

        .login-footer .text-muted strong {
            color: #011851;
            font-weight: 700;
        }

        /* Alert */
        .alert-custom {
            border-radius: 14px;
            padding: 14px 18px;
            border: none;
            font-weight: 500;
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideDown 0.4s ease;
        }

        .alert-custom.alert-danger {
            background: #fef2f2;
            color: #991b1b;
        }

        .alert-custom.alert-success {
            background: #ecfdf5;
            color: #065f46;
        }

        .alert-custom i {
            font-size: 1.2rem;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* ============================================
           RESPONSIVE
           ============================================ */
        @media (max-width: 576px) {
            .login-card {
                padding: 28px 20px;
                border-radius: 20px;
            }

            .brand h1 {
                font-size: 1.5rem;
            }

            .brand-icon {
                width: 60px;
                height: 60px;
                font-size: 1.8rem;
            }

            .form-group .input-group-custom .form-control {
                padding: 12px 14px 12px 42px;
                font-size: 0.9rem;
            }

            .btn-login {
                padding: 12px;
                font-size: 0.95rem;
            }

            body {
                padding: 12px;
            }
        }

        @media (max-width: 400px) {
            .login-card {
                padding: 20px 16px;
            }

            .brand h1 {
                font-size: 1.3rem;
            }

            .brand p {
                font-size: 0.8rem;
            }
        }

        /* ============================================
           SCROLLBAR
           ============================================ */
        ::-webkit-scrollbar {
            width: 6px;
        }

        ::-webkit-scrollbar-track {
            background: #f1f5f9;
        }

        ::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 10px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: #94a3b8;
        }
    </style>
</head>
<body>

    <!-- ============================================
    BACKGROUND ANIMATION
    ============================================ -->
    <div class="bg-animation">
        <div class="circle"></div>
        <div class="circle"></div>
        <div class="circle"></div>
        <div class="circle"></div>
    </div>

    <!-- ============================================
    PARTICLES
    ============================================ -->
    <div class="particles">
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
    </div>

    <!-- ============================================
    LOGIN FORM
    ============================================ -->
    <div class="login-wrapper">
        <div class="login-card">

            <!-- Brand -->
            <div class="brand">
                <div class="brand-icon">
                    <i class="bi bi-trophy-fill"></i>
                </div>
                <h1>SPK <span>Beasiswa</span></h1>
                <p>Sistem Pendukung Keputusan Beasiswa Berprestasi</p>
            </div>

            <!-- Alert Error -->
            <?php if(isset($_SESSION['error'])): ?>
                <div class="alert-custom alert-danger">
                    <i class="bi bi-exclamation-triangle-fill"></i>
                    <?= $_SESSION['error'] ?>
                </div>
                <?php unset($_SESSION['error']); ?>
            <?php endif; ?>

            <!-- Alert Success -->
            <?php if(isset($_SESSION['success'])): ?>
                <div class="alert-custom alert-success">
                    <i class="bi bi-check-circle-fill"></i>
                    <?= $_SESSION['success'] ?>
                </div>
                <?php unset($_SESSION['success']); ?>
            <?php endif; ?>

            <!-- Form -->
            <form action="login.php" method="POST" autocomplete="off">
                <div class="form-group">
                    <label for="username">
                        <i class="bi bi-person me-1"></i> Username
                    </label>
                    <div class="input-group-custom">
                        <input type="text" 
                               id="username" 
                               name="username" 
                               class="form-control" 
                               placeholder="Masukkan username"
                               value="<?= isset($_POST['username']) ? htmlspecialchars($_POST['username']) : '' ?>"
                               required>
                        <i class="bi bi-person input-icon"></i>
                    </div>
                </div>

                <div class="form-group">
                    <label for="password">
                        <i class="bi bi-lock me-1"></i> Password
                    </label>
                    <div class="input-group-custom">
                        <input type="password" 
                               id="password" 
                               name="password" 
                               class="form-control" 
                               placeholder="Masukkan password"
                               required>
                        <i class="bi bi-lock input-icon"></i>
                        <button type="button" class="toggle-password" id="togglePassword" tabindex="-1">
                            <i class="bi bi-eye"></i>
                        </button>
                    </div>
                </div>

                <button type="submit" class="btn-login">
                    <i class="bi bi-box-arrow-in-right"></i>
                    Masuk ke Dashboard
                </button>
            </form>

            <!-- Footer -->
            <div class="login-footer">
                <p class="text-muted">
                    <i class="bi bi-info-circle me-1"></i>
                    Default: <strong>admin</strong> / <strong>password</strong>
                </p>
                <p class="text-muted small mb-0">
                    <i class="bi bi-shield-check me-1"></i>
                    Sistem Aman &amp; Terenkripsi
                </p>
            </div>

        </div>
    </div>

    <!-- ============================================
    JAVASCRIPT
    ============================================ -->
    <script>
    document.addEventListener('DOMContentLoaded', function() {

        // ========================================
        // TOGGLE PASSWORD VISIBILITY
        // ========================================
        const togglePassword = document.getElementById('togglePassword');
        const passwordInput = document.getElementById('password');

        if (togglePassword && passwordInput) {
            togglePassword.addEventListener('click', function() {
                const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                passwordInput.setAttribute('type', type);
                
                const icon = this.querySelector('i');
                if (icon) {
                    icon.className = type === 'password' ? 'bi bi-eye' : 'bi bi-eye-slash';
                }
            });
        }

        // ========================================
        // AUTO FOCUS USERNAME
        // ========================================
        const usernameInput = document.getElementById('username');
        if (usernameInput) {
            usernameInput.focus();
        }

        // ========================================
        // ENTER KEY SUBMIT
        // ========================================
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                const form = document.querySelector('form');
                if (form) {
                    form.submit();
                }
            }
        });

        // ========================================
        // CONSOLE LOG
        // ========================================
        console.log('✅ SPK Beasiswa Login Page Loaded');
        console.log('💡 Default: admin / password');
    });
    </script>

</body>
</html>