-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 30, 2026 at 10:13 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spk_beasiswa`
--

-- --------------------------------------------------------

--
-- Table structure for table `alternatif`
--

CREATE TABLE `alternatif` (
  `id_alternatif` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `nim` varchar(20) NOT NULL,
  `jurusan` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `alternatif`
--

INSERT INTO `alternatif` (`id_alternatif`, `nama`, `nim`, `jurusan`, `created_at`) VALUES
(1, 'Budi Santoso', '2023001', 'Teknik Informatika', '2026-07-29 04:59:27'),
(2, 'Siti Rahayu', '2023002', 'Sistem Informasi', '2026-07-29 04:59:27'),
(3, 'Andi Pratama', '2023003', 'Teknik Elektro', '2026-07-29 04:59:27'),
(7, 'tes', '12312321', 'dawda', '2026-07-30 04:27:05');

-- --------------------------------------------------------

--
-- Table structure for table `hasil_perhitungan`
--

CREATE TABLE `hasil_perhitungan` (
  `id_hasil` int(11) NOT NULL,
  `id_alternatif` int(11) NOT NULL,
  `skor_akhir` decimal(10,6) NOT NULL,
  `ranking` int(3) NOT NULL,
  `status` enum('penerima','cadangan1','cadangan2','tidak_terpilih') DEFAULT 'tidak_terpilih',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hasil_perhitungan`
--

INSERT INTO `hasil_perhitungan` (`id_hasil`, `id_alternatif`, `skor_akhir`, `ranking`, `status`, `created_at`) VALUES
(1, 2, 0.944462, 1, 'penerima', '2026-07-30 04:42:50'),
(2, 1, 0.860741, 2, 'cadangan1', '2026-07-30 04:42:50'),
(3, 3, 0.854270, 3, 'cadangan2', '2026-07-30 04:42:50'),
(4, 7, 0.000000, 4, 'tidak_terpilih', '2026-07-30 04:42:50');

-- --------------------------------------------------------

--
-- Table structure for table `kriteria`
--

CREATE TABLE `kriteria` (
  `id_kriteria` int(11) NOT NULL,
  `kode_kriteria` varchar(10) NOT NULL,
  `nama_kriteria` varchar(100) NOT NULL,
  `jenis` enum('benefit','cost') DEFAULT 'benefit',
  `bobot_ahp` decimal(5,4) DEFAULT 0.0000,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kriteria`
--

INSERT INTO `kriteria` (`id_kriteria`, `kode_kriteria`, `nama_kriteria`, `jenis`, `bobot_ahp`, `created_at`) VALUES
(1, 'C1', 'IPK', 'benefit', 0.4750, '2026-07-29 04:59:27'),
(2, 'C2', 'Prestasi Akademik', 'benefit', 0.2270, '2026-07-29 04:59:27'),
(3, 'C3', 'Prestasi Non-Akademik', 'benefit', 0.0950, '2026-07-29 04:59:27'),
(4, 'C4', 'Keaktifan', 'benefit', 0.0470, '2026-07-29 04:59:27'),
(5, 'C5', 'Penghasilan Orang Tua', 'cost', 0.1370, '2026-07-29 04:59:27');

-- --------------------------------------------------------

--
-- Table structure for table `matriks_perbandingan`
--

CREATE TABLE `matriks_perbandingan` (
  `id_matrik` int(11) NOT NULL,
  `id_kriteria1` int(11) NOT NULL,
  `id_kriteria2` int(11) NOT NULL,
  `nilai` decimal(5,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `matriks_perbandingan`
--

INSERT INTO `matriks_perbandingan` (`id_matrik`, `id_kriteria1`, `id_kriteria2`, `nilai`) VALUES
(1, 1, 1, 1.00),
(2, 1, 2, 3.00),
(3, 1, 3, 5.00),
(4, 1, 4, 7.00),
(5, 1, 5, 4.00),
(6, 2, 1, 0.33),
(7, 2, 2, 1.00),
(8, 2, 3, 3.00),
(9, 2, 4, 5.00),
(10, 2, 5, 2.00),
(11, 3, 1, 0.20),
(12, 3, 2, 0.33),
(13, 3, 3, 1.00),
(14, 3, 4, 3.00),
(15, 3, 5, 0.50),
(16, 4, 1, 0.14),
(17, 4, 2, 0.20),
(18, 4, 3, 0.33),
(19, 4, 4, 1.00),
(20, 4, 5, 0.33),
(21, 5, 1, 0.25),
(22, 5, 2, 0.50),
(23, 5, 3, 2.00),
(24, 5, 4, 3.00),
(25, 5, 5, 1.00);

-- --------------------------------------------------------

--
-- Table structure for table `nilai_alternatif`
--

CREATE TABLE `nilai_alternatif` (
  `id_nilai` int(11) NOT NULL,
  `id_alternatif` int(11) NOT NULL,
  `id_kriteria` int(11) NOT NULL,
  `nilai` decimal(10,4) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `nilai_alternatif`
--

INSERT INTO `nilai_alternatif` (`id_nilai`, `id_alternatif`, `id_kriteria`, `nilai`, `created_at`) VALUES
(1, 1, 1, 3.8000, '2026-07-29 04:59:27'),
(2, 1, 2, 5.0000, '2026-07-29 04:59:27'),
(3, 1, 3, 3.0000, '2026-07-29 04:59:27'),
(4, 1, 4, 8.0000, '2026-07-29 04:59:27'),
(5, 1, 5, 999999.9999, '2026-07-29 04:59:27'),
(6, 2, 1, 3.6000, '2026-07-29 04:59:27'),
(7, 2, 2, 7.0000, '2026-07-29 04:59:27'),
(8, 2, 3, 5.0000, '2026-07-29 04:59:27'),
(9, 2, 4, 9.0000, '2026-07-29 04:59:27'),
(10, 2, 5, 999999.9999, '2026-07-29 04:59:27'),
(11, 3, 1, 3.9000, '2026-07-29 04:59:27'),
(12, 3, 2, 4.0000, '2026-07-29 04:59:27'),
(13, 3, 3, 4.0000, '2026-07-29 04:59:27'),
(14, 3, 4, 7.0000, '2026-07-29 04:59:27'),
(15, 3, 5, 999999.9999, '2026-07-29 04:59:27');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `role` enum('admin','user') DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_user`, `username`, `password`, `nama_lengkap`, `role`, `created_at`) VALUES
(1, 'admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrator', 'admin', '2026-07-29 04:59:26');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alternatif`
--
ALTER TABLE `alternatif`
  ADD PRIMARY KEY (`id_alternatif`),
  ADD UNIQUE KEY `nim` (`nim`);

--
-- Indexes for table `hasil_perhitungan`
--
ALTER TABLE `hasil_perhitungan`
  ADD PRIMARY KEY (`id_hasil`),
  ADD KEY `id_alternatif` (`id_alternatif`);

--
-- Indexes for table `kriteria`
--
ALTER TABLE `kriteria`
  ADD PRIMARY KEY (`id_kriteria`),
  ADD UNIQUE KEY `kode_kriteria` (`kode_kriteria`);

--
-- Indexes for table `matriks_perbandingan`
--
ALTER TABLE `matriks_perbandingan`
  ADD PRIMARY KEY (`id_matrik`),
  ADD UNIQUE KEY `unique_pair` (`id_kriteria1`,`id_kriteria2`),
  ADD KEY `id_kriteria2` (`id_kriteria2`);

--
-- Indexes for table `nilai_alternatif`
--
ALTER TABLE `nilai_alternatif`
  ADD PRIMARY KEY (`id_nilai`),
  ADD UNIQUE KEY `unique_nilai` (`id_alternatif`,`id_kriteria`),
  ADD KEY `id_kriteria` (`id_kriteria`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alternatif`
--
ALTER TABLE `alternatif`
  MODIFY `id_alternatif` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `hasil_perhitungan`
--
ALTER TABLE `hasil_perhitungan`
  MODIFY `id_hasil` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `kriteria`
--
ALTER TABLE `kriteria`
  MODIFY `id_kriteria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `matriks_perbandingan`
--
ALTER TABLE `matriks_perbandingan`
  MODIFY `id_matrik` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `nilai_alternatif`
--
ALTER TABLE `nilai_alternatif`
  MODIFY `id_nilai` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `hasil_perhitungan`
--
ALTER TABLE `hasil_perhitungan`
  ADD CONSTRAINT `hasil_perhitungan_ibfk_1` FOREIGN KEY (`id_alternatif`) REFERENCES `alternatif` (`id_alternatif`) ON DELETE CASCADE;

--
-- Constraints for table `matriks_perbandingan`
--
ALTER TABLE `matriks_perbandingan`
  ADD CONSTRAINT `matriks_perbandingan_ibfk_1` FOREIGN KEY (`id_kriteria1`) REFERENCES `kriteria` (`id_kriteria`) ON DELETE CASCADE,
  ADD CONSTRAINT `matriks_perbandingan_ibfk_2` FOREIGN KEY (`id_kriteria2`) REFERENCES `kriteria` (`id_kriteria`) ON DELETE CASCADE;

--
-- Constraints for table `nilai_alternatif`
--
ALTER TABLE `nilai_alternatif`
  ADD CONSTRAINT `nilai_alternatif_ibfk_1` FOREIGN KEY (`id_alternatif`) REFERENCES `alternatif` (`id_alternatif`) ON DELETE CASCADE,
  ADD CONSTRAINT `nilai_alternatif_ibfk_2` FOREIGN KEY (`id_kriteria`) REFERENCES `kriteria` (`id_kriteria`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
